# final_basic seed25 完整软件复现包

本包只对应 `CAMERA_RAW_R2 · 1a5603c1 · seed25`（final_basic），包含同一份 bit、已验证驱动、运行程序、HDMI 叠加库、检测与测距模型、私有 RKNN/RGA/MPP 库、SciPy、4G 恢复工具和 Tailscale。适用于目前这台 RK3576 的原 Debian 12 / ARM64 / Linux 6.1.99 BSP。它不是操作系统镜像，也不含 FPGA 下载工具或 Tailscale 账号。

原有视频、算法和单／双目分别冷启动的路径已有板测。这个统一入口、手动联网策略及连续录像时间索引已完成离线适配，**整包的新冷启动实测仍须单独验证**，不要把离线通过当成再次上板通过。详见 `04_验证与验收.md`。

## 安放与校验

将压缩包传到 RK 后，在 RK 的 root 串口终端执行。串口为 1500000 baud、8N1、关闭流控；实际 COM／tty 节点以你的连接为准。

```sh
tar -xzf final-basic-seed25-repro.tar.gz -C /userdata
cd /userdata/final-basic-seed25-repro
./reproduce.sh verify
```

安装目录必须为 `/userdata/final-basic-seed25-repro`。首次解压前确认该目录不存在；升级时保留旧包，勿直接覆盖正在运行的程序。包内模型与依赖已经补齐，不需要复制旧调试目录。原 BSP 的系统组件仍需存在：Python 3.11、GI/GStreamer、Rockchip MPP/Gst 插件、RGA、NPU 驱动、NumPy/OpenCV、systemd、NetworkManager、modetest 等。

## 每次上电的操作

1. RK、FPGA 两板共同断电，再上电；下载 `bits/camera_raw_r2_1a5603c1_seed25.bit`，只写 SRAM。保持 CAM0、HDMI、SD；双目另接 CAM1；联网另接 EC200A、SIM、天线。
2. 在上述目录执行 `./reproduce.sh`。
3. 输入 `1` 选择单目 CAM0，或 `2` 选择双目。确认本次共同冷启动、bit 下载及资源独占。
4. 脚本将旧的开机自动拨号改为手动策略，然后询问是否联网。
5. 不联网输入 `n`：确认本机日期，或输入准确的北京时间；随后用终端菜单控制。此模式不会启动 Tailscale／4G 拨号。
6. 联网输入 `y`：先在电脑准备好同账号／同 tailnet 的 Tailscale；脚本再次询问组网是否准备完成，**只有回答 `y` 后才开启板卡 4G**。先建立数据连接，再用两个独立NTP参考校时，然后对4G接口严格验证HTTPS，最后启动Tailscale，避免旧日期导致证书尚未生效。板卡首次登录需要按输出链接在浏览器授权；已有登录状态只在原板保留，不在包中。脚本打印实际控制网址，再进入同一套终端菜单。

第一次使用本包前，旧系统原本可能已自动联网；首次运行只能关闭当时的旧连接，不能追溯阻止上电后已经产生的流量。手动策略保存后，后续启动由本包控制是否连接。它不会新增视频或应用自启动。

菜单可以查询功能、算法、AI、布局、实际 HDR/ISP/JPEG 参数、FPS 和录像状态。修改都交给同一个视频 owner，等待 APPLIED／ACTIVE 和对应新画面；遇忙、冲突或结果未知，不自动重发。

```sh
./reproduce.sh menu      # 重新进入本 boot 原会话的菜单
./reproduce.sh status    # 查看状态
./reproduce.sh stop      # 明确请求停止，并等待录像收尾
```

退出菜单不会关闭视频、网页或循环录像。停止后底层资源仍留置，本 boot 不允许重新 START；下一轮须共同冷启动并重新下载 bit。程序异常也不要删 guard、卸载驱动、强杀后重开。

如果仅在联网／本机时间问答前后中止准备，目录只有三份成功的软件预检日志，修订版入口会重新核对本boot仍未枚举、无驱动／owner／helper及启动标记，原样归档旧日志后允许继续准备。它不允许已经尝试采集的会话重开。新的准备错误会保存阶段与完整异常信息，避免再次只看到“目录已存在”。

仅针对旧入口已拨号但因日期过早而HTTPS证书失败的已知准备场景，修订版也能在精确五文件、无START_INTENT且两次原始硬件场景检查通过后原样归档继续；任意额外的校时、Tailscale、枚举或视频记录均不适用。

## 录像是默认必选

最终视频在车道／AI／FPS 等叠加之后分为 HDMI 与录像两路；不允许选择“只显示不录像”。SD 循环回收已封存的最旧片段，2GiB 低水位、3GiB 回收目标、1GiB 保留空间；原有最旧封存片段也可能被覆盖。当前未封口片段不会作为完成录像发布。

联网后在控制页进入录像回放，按北京时间选择范围；“全部录像”优先显示最新已定时片段。按时间查询仍按时间正序连续播放，可留存到电脑。离线终端也提供录像时间查询；读卡器可直接读取 SD 的 MP4 分段。

录像时间与限制、已验证功能清单、尚未完成事项分别见 `02_联网与循环录像.md`、`01_功能与操作.md`、`03_已知问题.md`。

## 文件与日志

- `control/`：唯一 owner、全部适用参数面板、本地／网页控制和录像回放实现。
- `runtime/`：原已验证的 SDK、MPP/HDMI 运行代码；实际加载的当前驱动只取 `driver/ph1a_c2h.ko`。
- `board-assets/`：已逐文件核对的模型、私有库、SciPy 和 AI 初始化依赖。
- `driver/`：本轮实际驱动、完整原构建审计、源码；新 boot 明确做相同内核的重新校验，**不伪称重新编译**。
- `network/`：原 EC200A 恢复脚本、官方 Tailscale 1.104.4 ARM64 二进制。
- `SHA256SUMS.json` / `DELIVERY.json`：文件身份与交付边界。
- RK 日志在 `/userdata/final-basic-seed25-state/run-<boot-id>/`；录像在 `/mnt/anlogic-sd/recordings/`；索引在 `/userdata/r5-history/live-index/recordings.sqlite3`。

请先用 `verify` 确认文件完整。不要在旧轮留置时启动本包；本包不会替操作者烧录、重启、改设备树或安装另一个内核。
