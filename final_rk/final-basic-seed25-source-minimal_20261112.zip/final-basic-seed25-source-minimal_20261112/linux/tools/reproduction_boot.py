"""final_basic seed25 operator entry: cold-select once, local or private 4G control.

No action occurs on import. `verify` is host/offline-safe. `start` is intended
for the user's root terminal after a real joint cold boot and SRAM download.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import socket
import stat
import subprocess
import sys
import time
import traceback
from functools import wraps
from uuid import UUID,uuid4

BIT='eee7eff50323a8a5c7ddc850d3873e1dda13473debbfe8a690bcb6bab17ac362'
INSTALL=Path('/userdata/final-basic-seed25-repro')
STATE=Path('/userdata/final-basic-seed25-state')
INDEX=Path('/userdata/r5-history/live-index/recordings.sqlite3')
TS_SOCKET='/run/r5-tailscale/tailscaled.sock'
ORIGIN='http://rk3576-history.tail346db8.ts.net'
ECM_MAC='02:0c:29:a3:9b:6d'  # This package targets the original, identified EC200A.
PREFLIGHT_FILES={'preflight-integration.json','software-preflight.json','software-imports.json'}
BEFORE_HELPERS={'configuration','software_preflight','manual_network_policy','network_choice',
                'local_time_confirmation','storage_prepare','index_prepare','replay_setup'}
_PREPARATION=None


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_new(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())


def verify(root):
    root=Path(root).resolve(strict=True)
    manifest=json.loads((root/'SHA256SUMS.json').read_text())
    for name,row in manifest.items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('unsafe manifest member')
        p=root/relative
        if (any(q.is_symlink() for q in (p,*p.parents)) or not p.is_file()
                or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']):
            raise ValueError('复现包文件缺失或校验不符：'+name)
    if digest(root/'bits/camera_raw_r2_1a5603c1_seed25.bit')!=BIT:raise ValueError('wrong bit')
    return dict(status='PACKAGE_FILES_VERIFIED_NOT_BOARD_ACCEPTANCE',files=len(manifest),hardware_actions=0)


def choose(prompt,choices,*,default=None,input_fn=input):
    while True:
        value=input_fn(prompt).strip().lower()
        if not value and default is not None:value=default
        if value in choices:return value
        print('请输入：'+' / '.join(choices))


def command(argv,*,timeout=20,ok=(0,),log=None):
    p=subprocess.run([str(x) for x in argv],capture_output=True,text=True,timeout=timeout,
        env=dict(os.environ,LC_ALL='C',PYTHONDONTWRITEBYTECODE='1'))
    result=dict(argv=[str(x) for x in argv],returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    if log is not None:save_new(log,result)
    if p.returncode not in ok:raise RuntimeError('命令失败：'+' '.join(map(str,argv))+'\n'+p.stderr[-1200:])
    return result


def load_file(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


def preparation_stage(name,*,boot=None,run=None,helpers=False,hardware=False):
    if _PREPARATION is None:return
    _PREPARATION['stage']=name
    if boot is not None:_PREPARATION['boot']=boot
    if run is not None:_PREPARATION['run']=str(run)
    _PREPARATION['helpers_started']|=helpers
    _PREPARATION['hardware_intent']|=hardware


def journal_preparation(function):
    @wraps(function)
    def wrapped(*args,**kwargs):
        global _PREPARATION
        previous=_PREPARATION
        context=dict(stage='startup',boot=None,run=None,helpers_started=False,hardware_intent=False)
        _PREPARATION=context
        try:return function(*args,**kwargs)
        except BaseException as error:
            if context['run'] is not None:
                path=Path(context['run'])/'prepare-failure.json'
                if not os.path.lexists(path):
                    try:save_new(path,dict(schema='FINAL_BASIC_PREPARATION_FAILURE_V1',**context,
                        exception_type=type(error).__name__,exception=str(error)[:4096],
                        traceback=traceback.format_exc()[-65536:]))
                    except Exception as logging_error:
                        print('首次准备错误日志写入失败：'+str(logging_error),file=sys.stderr)
            raise
        finally:_PREPARATION=previous
    return wrapped


def preparation_processes(proc=Path('/proc'),*,current_pid=None):
    current_pid=os.getpid() if current_pid is None else current_pid
    names={'reproduction_boot.py','recover_4g.py','curl','nmcli','launch_camera_parameters.py',
           'launch_camera_mono_yolo.py','launch_camera_session.py','replay_server.py','tailscaled'}
    modules={'mono_record_history','mono_record_history.reproduction_clock'}
    found=[];errors=[]
    for task in proc.glob('[0-9]*'):
        if int(task.name)==current_pid:continue
        try:
            args=[x.decode(errors='replace')for x in (task/'cmdline').read_bytes().split(b'\0')if x]
            if any(Path(arg).name in names or arg in modules for arg in args):
                found.append(dict(pid=int(task.name),argv=args))
        except (FileNotFoundError,ProcessLookupError):continue
        except OSError as error:errors.append(dict(pid=task.name,error=str(error)))
    return found,errors


def preparation_scene(root,boot):
    """Read metadata only; never bind, insmod, open native or stop a process."""
    observed=json.loads(command([sys.executable,'-B',root/'enumeration/tools/late_enumeration_full_fdt.py',
        'inspect','--controller','/sys/bus/platform/devices/2a210000.pcie','--driver','rk-pcie',
        '--vendor','0x1edb','--device','0xabcd'])['stdout'])
    old_path=sys.path[:]
    try:
        sys.path[:0]=[str(root/'control'),str(root/'runtime')]
        guards=load_file(root/'runtime/launch_calfix_algorithm_trial.py','_prepare_reentry_guards')
        handoff=load_file(root/'runtime/handoff.py','_prepare_reentry_owners')
        paths=guards.trial_guards(boot)+[Path('/run')/('dual-r3-driver-'+boot+'.started')]
        owners=handoff.owner_scan()
    finally:sys.path[:]=old_path
    helpers,errors=preparation_processes()
    return dict(boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),enumeration=observed,
        once_guards=[str(path)for path in paths if os.path.lexists(path)],
        native_modules=[str(path)for path in Path('/sys/module').glob('*')if path.name.startswith(('ph1a','sgdma'))],
        native_nodes=[str(path)for path in Path('/dev').glob('*')if path.name.startswith(('ph1a','sgdma'))],
        owners=owners['owners'],owner_errors=owners['errors'],prepare_helpers=helpers,errors=errors,
        owner_port_open=active_port(8766))


def validate_preparation_scene(scene,boot):
    if (not isinstance(scene,dict) or scene.get('boot')!=boot or scene.get('owner_port_open') is not False
            or any(type(scene.get(k))is not list or scene[k] for k in
                ('once_guards','native_modules','native_nodes','owners','owner_errors','prepare_helpers','errors'))):
        raise ValueError('准备重入场景有guard/owner/helper或无法确认；保留现场并共同冷启')
    observed=scene.get('enumeration')
    if (not isinstance(observed,dict) or observed.get('boot_id')!=boot or observed.get('state')!='RC_UNBOUND'
            or observed.get('controller_driver') is not None
            or any(type(observed.get(k))is not list or observed[k]for k in
                   ('issues','probe_threads','modules','pci_devices'))):
        raise ValueError('准备重入要求同boot原始RC_UNBOUND、无枚举/模块/probe；不得热重试')


def software_import_code(root,path):
    return ("import sys;sys.path[:0]="+repr([str(root/'control'),str(root/'runtime')])+";"
          "from camera_mono_yolo_assets import verify_live_dependencies;import json;"
          "c=json.load(open("+repr(str(path))+"));verify_live_dependencies(c['mono_yolo']);"
          "sys.path.insert(0,"+repr(str(root/'board-assets/userdata/anlogic_linux_v8_20261020_01/dependencies/scipy-1.10.1-cp311-aarch64'))+");"
          "import numpy,cv2,scipy,gi;gi.require_version('Gst','1.0');from gi.repository import Gst;"
          "from fps_hud import verify_libraries;verify_libraries('dual');"
          "print(json.dumps(dict(numpy=numpy.__version__,opencv=cv2.__version__,scipy=scipy.__version__,native_opened=False)))")


def preflight_metadata(root,run,boot):
    """Qualify pre-helper files or the exact old-RTC connect-only failure."""
    entries=list(run.iterdir());names={p.name for p in entries}
    network_only=names==PREFLIGHT_FILES|{'prepare-failure.json','4g-connect.log'}
    if not network_only and names not in (PREFLIGHT_FILES,PREFLIGHT_FILES|{'prepare-failure.json'}):
        raise ValueError('旧目录不只是三份preflight原件；保留现场并共同冷启')
    result={};identity={}
    for path in entries:
        before=path.lstat()
        if not stat.S_ISREG(before.st_mode) or before.st_size>1024*1024:
            raise ValueError('准备证据必须是有界普通文件，不能是链接或子目录')
        body=path.read_bytes();after=path.lstat()
        if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
            raise ValueError('准备证据读取期间改变')
        result[path.name]=body.decode('utf-8')if path.name=='4g-connect.log'else json.loads(body)
        identity[path.name]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    if any(type(value)is not dict for name,value in result.items()if name!='4g-connect.log'):raise ValueError('preflight证据必须是JSON对象')
    config=result['preflight-integration.json']
    if type(config)is not dict or config.get('cold_session')not in ('mono-jpeg','dual-jpeg'):
        raise ValueError('旧准备配置身份无效')
    mode='mono'if config['cold_session']=='mono-jpeg'else'dual'
    expected=json.loads((root/'control'/('integration-'+mode+'-template.json')).read_text())
    if config!=expected:raise ValueError('旧preflight配置不是本包未启动模板')
    native=result['software-preflight.json'];imports=result['software-imports.json'];cfgpath=run/'preflight-integration.json'
    if (native.get('returncode')!=0 or type(native.get('returncode'))is not int
            or native.get('argv')!=[sys.executable,'-B',str(root/'control/launch_camera_parameters.py'),
                '--integration-config',str(cfgpath),'--check-only','--check-native-files']
            or imports.get('returncode')!=0 or type(imports.get('returncode'))is not int
            or imports.get('argv')!=[sys.executable,'-B','-c',software_import_code(root,cfgpath)]):
        raise ValueError('三份preflight命令/结果不匹配，不能推断未启动')
    checked=json.loads(native['stdout']);loaded=json.loads(imports['stdout'])
    if (type(checked)is not dict or type(loaded)is not dict
            or checked.get('hardware_actions')!=0 or checked.get('native_files')!='VERIFIED'
            or checked.get('bit_sha256')!=BIT or checked.get('cameras')!=config['cameras']
            or checked.get('cold_session')!=config['cold_session'] or loaded.get('native_opened')is not False
            or any(not isinstance(loaded.get(k),str) or not loaded[k]for k in ('numpy','opencv','scipy'))):
        raise ValueError('旧preflight没有明确的无硬件成功回执')
    if 'prepare-failure.json'in result:
        failure=result['prepare-failure.json']
        network_connect_only=(network_only and
            failure.get('stage')=='network_helpers' and failure.get('helpers_started')is True and
            failure.get('exception_type')=='RuntimeError' and
            failure.get('exception')=='4G未就绪；查看4g-connect.log，本次不启动视频。' and
            'connect_4g' in failure.get('traceback','') and
            isinstance(result.get('4g-connect.log'),str) and
            ecm_data_ready(result['4g-connect.log']) and
            'USB网卡IPv4：' in result['4g-connect.log'] and
            'HTTPS检查失败：curl: (60)' in result['4g-connect.log'] and
            'certificate is not yet valid' in result['4g-connect.log'])
        if (failure.get('schema')!='FINAL_BASIC_PREPARATION_FAILURE_V1' or failure.get('boot')!=boot
                or failure.get('run')!=str(run) or failure.get('hardware_intent')is not False
                or not (network_connect_only or not network_only and failure.get('stage')in BEFORE_HELPERS
                        and failure.get('helpers_started')is False)
                or not isinstance(failure.get('exception_type'),str) or not isinstance(failure.get('traceback'),str)):
            raise ValueError('失败日志不是helpers之前的已知准备阶段，禁止重入')
    return identity


def prepare_run_directory(root,state,boot,*,scene_provider=None):
    root,state=Path(root),Path(state)
    if str(UUID(boot))!=boot:raise ValueError('canonical current boot required')
    run=state/('run-'+boot);prior=state/(boot+'.json')
    if os.path.lexists(prior):raise ValueError('本boot已有START_INTENT；不能恢复准备')
    if not os.path.lexists(run):run.mkdir(mode=0o700);return run
    if any(path.is_symlink()for path in (run,*run.parents)) or not run.is_dir():
        raise ValueError('准备目录不能是链接或其他类型')
    identity=preflight_metadata(root,run,boot)
    provider=scene_provider or (lambda:preparation_scene(root,boot))
    first=provider();validate_preparation_scene(first,boot)
    if os.path.lexists(prior) or preflight_metadata(root,run,boot)!=identity:
        raise ValueError('准备证据或START_INTENT在检查中改变')
    second=provider();validate_preparation_scene(second,boot)
    if os.path.lexists(prior) or preflight_metadata(root,run,boot)!=identity:
        raise ValueError('检查后START_INTENT或准备证据改变，禁止重入')
    network_only='4g-connect.log'in identity
    prefix='network-connect-only-archive-'if network_only else'preflight-only-archive-'
    archive_parent=state/(prefix+boot+'-'+uuid4().hex)
    archive_parent.mkdir(mode=0o700)
    run.rename(archive_parent/run.name)
    save_new(archive_parent/'reentry-proof.json',dict(boot=boot,files=identity,scene=second,
        action='RENAME_CONNECT_ONLY_PRE_VIDEO_FAILURE_NO_GUARD_REMOVAL'if network_only
               else'RENAME_PREFLIGHT_ONLY_NO_HARDWARE_NO_GUARD_REMOVAL'))
    run.mkdir(mode=0o700)
    print(('已原样归档联网准备失败日志（尚未启动PCIe/视频）：'if network_only
           else'已原样归档未触硬件的准备日志：')+str(archive_parent))
    return run


def active_port(port):
    with socket.socket() as s:
        s.settimeout(.5);return s.connect_ex(('127.0.0.1',port))==0


def modem_devices(sysroot=Path('/sys')):
    """Discover only EC200A USB interfaces; never disconnect other NICs."""
    result=[]
    for usb in (sysroot/'bus/usb/devices').glob('*'):
        try:
            if (usb/'idVendor').read_text().strip()!='2c7c' or (usb/'idProduct').read_text().strip()!='6005':continue
            for net in (sysroot/'class/net').iterdir():
                if usb.resolve() in net.resolve().parents:result.append(net.name)
        except FileNotFoundError:continue
    if len(set(result))>1:raise ValueError('发现多个4G网卡；请保持本轮只有一个EC200A')
    return sorted(set(result))


def service_exists(name):
    r=command(['systemctl','show',name,'-p','LoadState','--value'],ok=(0,1,4))
    return r['stdout'].strip() not in ('','not-found')


def modem_network_state(device):
    """Read both NM and kernel state; a failed query is never 'offline'."""
    values=command(['nmcli','-g','GENERAL.STATE,GENERAL.CON-UUID','device','show',device])['stdout'].splitlines()
    number=re.match(r'^\s*(\d+)\b',values[0]) if values else None
    if number is None or len(values)>2:raise RuntimeError('无法确认4G网卡的NetworkManager状态：'+device)
    uuid=values[1].strip() if len(values)==2 else ''
    rows=json.loads(command(['ip','-j','addr','show','dev',device])['stdout'])
    if (type(rows)is not list or len(rows)!=1 or rows[0].get('ifname')!=device
            or type(rows[0].get('addr_info'))is not list):raise RuntimeError('无法确认4G网卡的内核地址：'+device)
    return dict(nm_state=int(number[1]),connection_uuid=uuid,
        global_addresses=[a['local'] for a in rows[0]['addr_info']if a.get('scope')=='global'])


def modem_offline(state):
    return (state['nm_state']in (20,30) and state['connection_uuid']in ('','--')
            and not state['global_addresses'])


def disconnect_modem(device):
    before=modem_network_state(device)
    if modem_offline(before):return dict(status='ALREADY_DISCONNECTED',device=device,before=before)
    # rc6 includes a disconnect race as well as genuine failures. Never infer
    # success from its text or return code: independently verify actual state.
    result=command(['nmcli','--wait','10','device','disconnect',device],ok=(0,6,10))
    after=modem_network_state(device)
    if not modem_offline(after):
        raise RuntimeError('4G网卡未确认断开；保留状态：'+json.dumps(dict(device=device,result=result,after=after),ensure_ascii=False))
    return dict(status='DISCONNECTED_VERIFIED',device=device,before=before,after=after,command=result)


def disable_legacy_network(state):
    """One-time durable opt-in policy; no new boot-time application is enabled."""
    actions=[]
    for service in ('r5-4g-connect.service','r5-tailscaled.service'):
        if service_exists(service):
            # A disable alone does not prevent another unit's Wants= from
            # starting the old dialer. The missing condition also blocks that.
            directory=Path('/etc/systemd/system')/(service+'.d');directory.mkdir(parents=True,exist_ok=True)
            p=directory/'final-basic-manual-network.conf'
            content='[Unit]\nConditionPathExists=/run/final-basic-enable-legacy-network\n'
            if p.exists() and p.read_text()!=content:raise ValueError('manual-network policy file has unrelated content')
            if not p.exists():p.write_text(content)
            actions.append(command(['systemctl','disable','--now',service],ok=(0,1)))
    command(['systemctl','daemon-reload'])
    for name in ('r5-clock-observe.timer','r5-clock-observe.service'):
        if service_exists(name):actions.append(command(['systemctl','disable','--now',name],ok=(0,1)))
    devices=modem_devices()
    names=set(devices)|{'enx'+ECM_MAC.replace(':','')}
    macs={ECM_MAC}
    for device in devices:
        p=Path('/sys/class/net')/device/'address'
        if p.is_file():macs.add(p.read_text().strip().lower())
    # Also cover saved but inactive profiles: GENERAL.CON-UUID alone is empty
    # in that case. Match the identified modem's interface/MAC, not all USB NICs.
    profiles=command(['nmcli','-t','-f','UUID,TYPE','connection','show'])['stdout']
    for line in profiles.splitlines():
        uuid,kind=line.split(':',1)
        if kind!='802-3-ethernet':continue
        fields=command(['nmcli','-g','connection.interface-name,802-3-ethernet.mac-address','connection','show',uuid])['stdout'].splitlines()
        if (fields and fields[0] in names) or (len(fields)>1 and fields[1].lower().replace('\\:',':') in macs):
            actions.append(command(['nmcli','connection','modify',uuid,'connection.autoconnect','no']))
    for device in devices:
        uuid=command(['nmcli','-g','GENERAL.CON-UUID','device','show',device],ok=(0,10))['stdout'].strip()
        if re.fullmatch('[0-9a-f-]{36}',uuid):
            actions.append(command(['nmcli','connection','modify',uuid,'connection.autoconnect','no']))
        actions.append(disconnect_modem(device))
    path=state/'manual-network-policy.json'
    if not path.exists():save_new(path,dict(policy='NO_4G_UNTIL_OPERATOR_Y',actions=actions))


def software_preflight(root,config,run):
    """All ordinary file/import checks precede enumeration, driver or KMS IO."""
    control=root/'control';runtime=root/'runtime'
    path=run/'preflight-integration.json';save_new(path,config)
    command([sys.executable,'-B',control/'launch_camera_parameters.py','--integration-config',path,
        '--check-only','--check-native-files'],timeout=45,log=run/'software-preflight.json')
    code=software_import_code(root,path)
    command([sys.executable,'-B','-c',code],timeout=40,log=run/'software-imports.json')


def start_process(argv,path,*,cwd=None,env=None):
    with Path(path).open('xb') as f:
        p=subprocess.Popen([str(x) for x in argv],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,
            start_new_session=True,cwd=cwd,env=env)
    return p


def ecm_data_ready(text):
    # These exact messages belong to the hash-pinned recovery script. Merely
    # seeing a USB NIC does not mean SIM/LTE registration or dialing is done.
    return 'ECM拨号成功。' in text or 'ECM已经连接，保留当前连接。' in text


def connect_4g(root,run):
    """Called only after the operator's explicit tailnet-ready y."""
    helper=start_process([sys.executable,'-B',root/'network/recover_4g.py','--wait-seconds','90','--defer-https'],run/'4g-connect.log')
    deadline=time.monotonic()+90;connected=False
    while time.monotonic()<deadline:
        devices=modem_devices()
        log_text=(run/'4g-connect.log').read_text(errors='replace')[-16384:]
        if devices and not connected and ecm_data_ready(log_text):
            device=devices[0]
            command(['nmcli','--wait','20','device','connect',device],timeout=25)
            uuid=command(['nmcli','-g','GENERAL.CON-UUID','device','show',device])['stdout'].strip()
            command(['nmcli','connection','modify',uuid,'connection.autoconnect','no'])
            connected=True
        if helper.poll() is not None:break
        time.sleep(.5)
    if helper.poll() is None or helper.returncode!=0 or not connected:
        raise RuntimeError('4G未就绪；查看4g-connect.log，本次不启动视频。')


def verify_4g_https(run):
    devices=modem_devices()
    if len(devices)!=1:raise RuntimeError('校时后未发现唯一EC200A网卡；不启动视频。')
    device=devices[0];state=modem_network_state(device)
    if state['nm_state']!=100 or not state['global_addresses'] or state['connection_uuid']in ('','--'):
        raise RuntimeError('校时后4G数据连接未就绪；不启动视频。')
    result=command(['curl','--noproxy','*','--interface',device,
        '--silent','--show-error','--head','--output','/dev/null','--write-out','%{http_code}',
        '--connect-timeout','5','--max-time','12','https://www.baidu.com'],
        timeout=15,log=run/'4g-https.json')
    if not re.fullmatch(r'[23]\d\d',result['stdout'].strip()):
        raise RuntimeError('校时后4G HTTPS状态异常；不启动视频。')
    return dict(device=device,status='STRICT_HTTPS_VERIFIED_AFTER_CLOCK',http_status=result['stdout'].strip())


def start_tailnet(root,run):
    # TLS/login needs a sensible system clock: the caller synchronizes NTP
    # over the newly connected 4G before this stage, including on first boot.
    ts=root/'network/tailscale';daemon=root/'network/tailscaled'
    Path('/run/r5-tailscale').mkdir(mode=0o700,exist_ok=True)
    Path('/var/lib/r5-tailscale').mkdir(mode=0o700,exist_ok=True)
    process=start_process([daemon,'--tun=userspace-networking','--state=/var/lib/r5-tailscale/tailscaled.state',
        '--socket='+TS_SOCKET,'--port=41641'],run/'tailscaled.log')
    deadline=time.monotonic()+10
    while not Path(TS_SOCKET).exists():
        if process.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Tailscale未启动，见tailscaled.log')
        time.sleep(.1)
    args=[ts,'--socket='+TS_SOCKET]
    status=command(args+['status','--json'],ok=(0,1))
    try:backend=json.loads(status['stdout']).get('BackendState')
    except ValueError:backend=None
    if backend!='Running':
        print('板卡尚未登录Tailscale。请打开接下来输出的登录链接，并使用上位机相同账号完成授权。')
        # Login is interactive account approval, not a stored/reused auth key.
        p=subprocess.run([str(x) for x in args+['up','--accept-dns=false','--accept-routes=false','--hostname=rk3576-history','--timeout=120s']],timeout=130)
        if p.returncode:raise RuntimeError('Tailscale登录未完成；不继续启动。')
    status=json.loads(command(args+['status','--json'])['stdout'])
    if status.get('BackendState')!='Running':raise RuntimeError('Tailscale未组网')
    dns=status.get('Self',{}).get('DNSName','').rstrip('.')
    if not re.fullmatch('[a-z0-9-]+\.[a-z0-9-]+\.ts\.net',dns):raise RuntimeError('未取得本板Tailscale DNS名称')
    command(args+['serve','--bg','--http=80','http://127.0.0.1:8765'])
    return 'http://'+dns


def select_network(input_fn=input):
    if choose('是否开启本轮4G网页控制？[y/N]：',('y','n'),default='n',input_fn=input_fn)!='y':return False
    print('请先在上位机电脑安装并登录Tailscale，加入与板卡相同的tailnet。本包不包含账号、私钥或登录状态。')
    return choose('上位机组网准备已完成？输入 y 后才开启板卡4G；n 取消联网：',('y','n'),input_fn=input_fn)=='y'


def network_bootstrap(root,run,control,online):
    if not online:return ORIGIN
    connect_4g(root,run)
    sync_network_time(control,run)
    verify_4g_https(run)
    return start_tailnet(root,run)


def confirm_local_time(input_fn=input):
    zone=datetime.timezone(datetime.timedelta(hours=8))
    print('离线录像按确认的本机时间查询，标为LOCAL_UNVERIFIED，不声称网络校时。')
    while True:
        current=datetime.datetime.now(zone).isoformat(timespec='seconds')
        text=input_fn('当前北京时间 '+current+'。正确输入 y；不正确请输入 YYYY-MM-DD HH:MM:SS：').strip()
        if text.lower()=='y':return
        try:
            value=datetime.datetime.strptime(text,'%Y-%m-%d %H:%M:%S').replace(tzinfo=zone)
            if not 2026<=value.year<=2035:raise ValueError('支持2026至2035年')
            time.clock_settime_ns(time.CLOCK_REALTIME,int(value.timestamp()*1e9))
        except ValueError:print('时间格式不正确，请重新输入。')


def sync_network_time(control,run):
    # Import the private, bundled history implementation, not any old install.
    sys.path.insert(0,str(control))
    from mono_record_history.clock_probe import bounded_probes,DEFAULT_SERVERS,sample
    from mono_record_history.clock_ledger import qualify_sample
    probes=bounded_probes(DEFAULT_SERVERS);mono=time.monotonic_ns()
    good=[r for r in probes if r.get('valid')]
    if len(good)!=2:raise RuntimeError('两个独立NTP参考未就绪；不启动带错误日期的视频，请检查4G或重新冷启选离线。')
    estimated=sum(r['utc_ns']+mono-r['monotonic_ns'] for r in good)//2
    proposed=qualify_sample(Path('/proc/sys/kernel/random/boot_id').read_text().strip(),mono,estimated,probes)
    if not proposed['valid']:raise RuntimeError('两个NTP参考不一致；不设置时间。')
    time.clock_settime_ns(time.CLOCK_REALTIME,proposed['utc_ns']+time.monotonic_ns()-mono)
    reference=sample()
    if not reference['valid']:raise RuntimeError('设置后时间核验未通过；视频尚未启动。')
    save_new(run/'network-time-reference.json',reference)
    return reference


def discover_route(snapshot,boot):
    """Use current debugfs/modetest identities, not historical DRM node IDs."""
    query=snapshot['query'];text=query['stdout'];found=[]
    for debug,item in snapshot['drm'].items():
        route=item['state']
        for connector in snapshot['connectors']:
            if connector['status']!='connected':continue
            name=Path(connector['path']).name.split('-',1)[1]
            c=re.search(r'^connector\[(\d+)\]: '+re.escape(name)+r'\n\s*crtc=([^\n]+)',route,re.M)
            if not c or c[2]=='(null)':continue
            crtc=re.search(r'^crtc\[(\d+)\]: '+re.escape(c[2])+r'$',route,re.M)
            if crtc is None:continue
            ids=[int(x) for x in re.findall(r'^(\d+)\s+\d+\s+\(',text.split('CRTCs:\n',1)[1].split('Planes:\n',1)[0],re.M)]
            index=ids.index(int(crtc[1]));planes=[];ptext=text.split('Planes:\n',1)[1]
            for p in re.finditer(r'^(\d+)\s+\d+\s+\d+\s+\S+\s+\S+\s+\d+\s+(0x[0-9a-fA-F]+)\s*$',ptext,re.M):
                block=re.split(r'^\d+\s',ptext[p.end():],1,flags=re.M)[0]
                if (int(p[2],16)&(1<<index) and re.search(r'^\s*formats:.*\bNV12\b',block,re.M)
                        and re.search(r'^plane\['+p[1]+r'\]: [^\n]+\n\s*crtc='+re.escape(c[2])+r'$',route,re.M)):
                    planes.append(int(p[1]))
            if len(planes)!=1:raise ValueError('当前HDMI可用NV12显示plane不唯一')
            found.append(dict(format='CALFIX_KMS_SELECTION_V1',boot_id=boot,driver_name='rockchip',
                connector_sysfs=connector['path'],connector_id=int(c[1]),crtc_id=int(crtc[1]),crtc_index=index,
                plane_id=planes[0],route_reviewed=True,query=query,route_evidence=route,
                route_sha256=hashlib.sha256(route.encode()).hexdigest(),captured_monotonic_s=time.monotonic(),debug=debug))
    identities={(x['connector_sysfs'],x['connector_id'],x['crtc_id'],x['plane_id']) for x in found}
    if len(identities)!=1:raise ValueError('请仅连接一个HDMI显示器并保持桌面初始显示路由；当前route缺失或不唯一')
    return found[0]


def sd_ready(config):
    sd=config['recording'];mount=Path(sd['mount']);device=Path('/dev/disk/by-uuid')/sd['uuid']
    if not device.exists():raise ValueError('未发现已确认的SD卡UUID；不写入其他磁盘')
    block=Path('/sys/dev/block')/f'{os.major(device.stat().st_rdev)}:{os.minor(device.stat().st_rdev)}'
    cids=[(p/'device/cid').read_text().strip() for p in (block.resolve(),*block.resolve().parents) if (p/'device/cid').is_file()]
    if sd['cid'] not in cids:raise ValueError('SD卡CID不符；更换卡需明确核对配置')
    mount.mkdir(parents=True,exist_ok=True)
    rows=[x for x in Path('/proc/self/mountinfo').read_text().splitlines() if len(x.split())>5 and x.split()[4]==str(mount)]
    if not rows:command(['mount','-t','vfat','-o','rw,nosuid,nodev',device,mount])
    elif len(rows)!=1 or 'rw' not in rows[0].split()[5].split(','):raise ValueError('SD当前不是唯一rw挂载；未自动重挂载')
    if mount.stat().st_dev!=device.stat().st_rdev:raise ValueError('SD挂载路径不是该卡')


def enumeration(root,run,boot,note):
    tool=root/'enumeration/tools/late_enumeration_full_fdt.py'
    base=['--controller','/sys/bus/platform/devices/2a210000.pcie','--driver','rk-pcie','--vendor','0x1edb','--device','0xabcd']
    observed=json.loads(command([sys.executable,'-B',tool,'inspect']+base,log=run/'enum-inspect.json')['stdout'])
    if observed['state']!='RC_UNBOUND' or observed['issues'] or observed['probe_threads'] or observed['modules'] or observed['pci_devices']:
        raise ValueError('枚举前场景不是全新共同冷启动；保留现场，不重试')
    if (observed['dt_sha256'],observed['fdt_sha256'])!=('6cb4f464d2377c6d5dd802a29c0d81429ff95876ddfed992e1f332efcb60673b','0fedaa64e834ba9d50c221c1d737d5d17d64d30552b1f18633ffe421f4f59c89'):
        raise ValueError('设备树与已验证BSP不符；不修改设备树')
    policy={'/usr/lib/udev/rules.d/80-drivers.rules':'0941cea0be8d3564556b5787a87cf55971fd3e46e19c56ad68a4205e8ad3a560','/usr/lib/udev/rules.d/80-debian-compat.rules':'a76997a57ec03550753cc9adb362e1e788fa4a845fa2ac896afb1031f70ce1e5','/etc/rc.local':'0ea34b76490aae158456a5714e7bf7f9d0af66e0a3af67d10a9d92401ed03d7d'}
    if any(digest(p)!=h for p,h in policy.items()):raise ValueError('BSP自动加载政策与已验证场景不同')
    value=json.loads((root/'enumeration/templates/enum-evidence.json').read_text())
    value['fpga'].update(boot_id=boot,image_sha256=BIT,configured=True,pcie_mode_ready=True,
        external_refclock_ready=True,board_power_ready=True,app_disabled=True,reference=note)
    value['cold'].update(boot_id=boot,evidence_id='FINAL-BASIC-REPRO-'+boot,operator_attestation=note,
        no_prior_dma_exposure=True,no_owner_or_quarantine=True,no_probe_in_progress=True,exclusive_control=True,
        autoload_policy_reviewed=True,autoload_reference='Exact current BSP policy hashes checked; no module/PCI/probe before one enumeration')
    evidence=run/'enum-evidence.json';save_new(evidence,value)
    opts=base+['--expected-boot-id',boot,'--evidence',str(evidence)]
    plan=json.loads(command([sys.executable,'-B',tool,'plan']+opts,log=run/'enum-plan.json')['stdout'])
    if not plan['admitted']:raise ValueError('原枚举工具拒绝当前场景')
    receipts=run/'enumeration-receipts'
    receipts.mkdir(mode=0o700)  # ReceiptStore deliberately refuses a missing directory.
    result=json.loads(command([sys.executable,'-B',tool,'apply']+opts+['--receipt-dir',str(receipts),'--timeout-s','20','--execute-bind'],timeout=35,log=run/'enum-apply.json')['stdout'])
    if result['status']!='COMPLETED_ENUMERATION_ONLY' or result['write_count']!=1:raise RuntimeError('枚举未完成，禁止重试')


def launch_video(root,run,config,boot,note):
    control=root/'control';runtime=root/'runtime'
    sys.path[:0]=[str(control),str(runtime)]
    from handoff import owner_scan
    from launch_calfix_algorithm_trial import trial_guards
    scan=owner_scan()
    if scan['owners'] or scan['errors'] or any(os.path.lexists(x) for x in trial_guards(boot)):
        raise ValueError('已有native owner或本boot尝试记录，不能接管')
    from reproduction_driver import revalidate,live_identity
    from camera_session_driver import check_target
    lock=json.loads((control/'camera-runtime-lock.json').read_text())
    audit=revalidate(json.loads((root/'driver/original-build-audit.json').read_text()),root/'driver/ph1a_c2h.ko',boot,
        lock['session_driver_source_sha256'],live_kernel=live_identity())
    audit_path=run/'current-driver-audit.json';save_new(audit_path,audit)
    enumeration(root,run,boot,note)
    import dual_r3_driver as driver
    driver.STEREO_KO_SHA256=audit['module']['sha256'];driver.STEREO_KO_BYTES=audit['module']['bytes']
    driver.STEREO_KO_BUILD_ID=audit['origin_build_audit']['module_info']['build_id']
    from dual_r3_load import load_once
    loaded=load_once(root/'driver/ph1a_c2h.ko',boot,run/'driver-evidence',note,execute=True,identity='stereo-n2')
    target=check_target(audit_path,digest(audit_path),boot=boot,source_hashes=lock['session_driver_source_sha256'],expected_bdf=loaded['target']['bdf'])
    display=load_file(runtime/'peer/linux/rk_debug/display_info.py','repro_display_info')
    query=display.inspect_display('/usr/bin/modetest','rockchip',timeout_s=5,max_output_bytes=1048576)
    snapshot=dict(query=query,drm={},connectors=[])
    for p in Path('/sys/kernel/debug/dri').iterdir():
        if p.name.isdigit() and (p/'state').is_file():snapshot['drm'][str(p)]=dict(state=(p/'state').read_text(),clients=(p/'clients').read_text())
    for p in Path('/sys/class/drm').glob('card*-HDMI-A-*'):
        snapshot['connectors'].append(dict(path=str(p),status=(p/'status').read_text().strip()))
    save_new(run/'drm-snapshot.json',snapshot);selection=discover_route(snapshot,boot)
    from kms_display import validate_selection,load_selection,check_no_drm_clients
    validate_selection(selection,boot)
    command(['systemctl','stop','lightdm'],timeout=20)
    check_no_drm_clients()
    selection.update(query=display.inspect_display('/usr/bin/modetest','rockchip',timeout_s=5,max_output_bytes=1048576),captured_monotonic_s=time.monotonic())
    selected=run/'kms-selection.json';save_new(selected,selection);load_selection(selected,digest(selected),boot,live=True)
    config.update(connector_id=selection['connector_id'],plane_id=selection['plane_id'],allow_topology_rebuild=False)
    cfgpath=run/'integration.json';save_new(cfgpath,config)
    command([sys.executable,'-B',control/'launch_camera_parameters.py','--integration-config',cfgpath,'--check-only','--check-native-files'],timeout=40,log=run/'check-only.json')
    argv=[sys.executable,'-B',control/'launch_camera_parameters.py','--integration-config',cfgpath,'--run-dir',run/'capture',
        '--expected-boot',boot,'--expected-bdf',target['bdf'],'--bit-sha256',BIT,'--kms-selection',selected,
        '--kms-selection-sha256',digest(selected),'--session-driver-audit',audit_path,'--session-driver-audit-sha256',digest(audit_path),
        '--joint-cold-confirmed','--programming-note',note,'--run']
    save_new(run/'launch-intent.json',dict(argv=[str(x) for x in argv],note=note))
    process=start_process(argv,run/'owner.log',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',LC_ALL='C'))
    return process


def client(origin):
    try:from . import reproduction_control as cli
    except ImportError:import reproduction_control as cli
    cli.ORIGIN=origin;cli.HOST=origin.removeprefix('http://')
    return cli


@journal_preparation
def start(root,input_fn=input):
    if os.geteuid()!=0 or os.uname().machine!='aarch64':raise ValueError('请在原RK3576的root终端运行；不是虚拟机')
    if root!=INSTALL:raise ValueError('请将包完整放在 '+str(INSTALL))
    verify(root);STATE.mkdir(parents=True,exist_ok=True)
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    preparation_stage('boot_checked',boot=boot)
    prior=STATE/(boot+'.json')
    if prior.exists():
        record=json.loads(prior.read_text())
        ready_path=Path(record['run'])/'READY.json'
        if active_port(8766) and ready_path.is_file():
            ready=json.loads(ready_path.read_text());pid=ready['owner_pid']
            cmd=Path('/proc')/str(pid)/'cmdline'
            if (ready['boot']!=boot or not cmd.is_file()
                    or str(root/'control/launch_camera_parameters.py').encode() not in cmd.read_bytes()
                    or str(Path(record['run'])/'capture').encode() not in cmd.read_bytes()):
                raise ValueError('已记录owner身份不符；不接管另一个进程')
            live=client(record['origin']).Client().state()
            if live['run_id']!=ready['run_id'] or live.get('bit_sha256')!=BIT:
                raise ValueError('当前HTTP会话不是本包记录的owner')
            print('本boot已启动，进入原会话菜单，不重新初始化。')
            return client(record['origin']).main(['menu'])
        raise ValueError('本boot有启动记录；请查看日志并共同冷启动，不能重新START')
    if Path('/sys/module/ph1a_c2h').exists() or active_port(8766):raise ValueError('已有视频/驱动会话，请共同冷启动后使用本包')
    mode=choose('本次模式：1 单目CAM0 / 2 双目：',('1','2'),input_fn=input_fn)
    if choose('确认两板已共同冷启、仅SRAM下载本包seed25 bit、连接就绪且资源独占？[y/n]：',('y','n'),input_fn=input_fn)!='y':return 2
    run=prepare_run_directory(root,STATE,boot)
    preparation_stage('configuration',run=run)
    control=root/'control';sys.path[:0]=[str(control),str(root/'runtime')]
    config=json.loads((control/('integration-mono-template.json' if mode=='1' else 'integration-dual-template.json')).read_text())
    preparation_stage('software_preflight')
    software_preflight(root,config,run)
    print('使用手动联网策略：关闭旧开机自动拨号及4G网卡自动连接；不新增应用自启动。')
    preparation_stage('manual_network_policy')
    disable_legacy_network(STATE)
    preparation_stage('network_choice')
    online=select_network(input_fn)
    if online:
        preparation_stage('network_helpers',helpers=True)
        origin=network_bootstrap(root,run,control,online)
    else:
        origin=ORIGIN
        for dev in modem_devices():disconnect_modem(dev)
        preparation_stage('local_time_confirmation')
        confirm_local_time(input_fn)
    config['control_origin']=origin
    config['recording']['clock_policy']='NETWORK_ANCHORED' if online else 'LOCAL_UNVERIFIED'
    config['recording']['clock_dir']=str(STATE/'clock')
    preparation_stage('storage_prepare')
    sd_ready(config)
    preparation_stage('index_prepare')
    INDEX.parent.mkdir(parents=True,exist_ok=True)
    from mono_record_history.live_index import update_clock
    update_clock(INDEX,boot,[])
    preparation_stage('replay_setup')
    if service_exists('r5-history-replay.service'):command(['systemctl','stop','r5-history-replay.service'])
    if active_port(8765):raise ValueError('8765已有未知回放进程，不接管')
    preparation_stage('replay_clock_helpers',helpers=True)
    history=start_process([sys.executable,'-B','-m','mono_record_history','serve','--live-index',INDEX,'--port','8765','--algorithm-control'],run/'replay.log',cwd=control)
    clock_argv=[sys.executable,'-B','-m','mono_record_history.reproduction_clock','--clock-dir',STATE/'clock','--index',INDEX,
        '--boot',boot,'--policy',config['recording']['clock_policy']]
    clock_argv+=(['--network-reference',run/'network-time-reference.json'] if online else ['--operator-confirmed'])
    observer=start_process(clock_argv,run/'clock.log',cwd=control)
    from display_recording import admit
    deadline=time.monotonic()+25
    while True:
        if history.poll() is not None or observer.poll() is not None:raise RuntimeError('录像索引或时钟进程退出，见日志；未启动视频')
        try:admit(config['recording'],boot=boot,require_space=False);break
        except ValueError:
            if time.monotonic()>deadline:raise
            time.sleep(.5)
    note='Operator terminal confirms joint cold, exact seed25 SRAM bit, cameras/HDMI/SD and exclusive resources. Cold '+config['cold_session']+'. No SRAM readback; no online topology rebuild.'
    preparation_stage('start_intent',hardware=True)
    save_new(prior,dict(boot=boot,mode=mode,origin=origin,online=online,run=str(run),status='START_INTENT_NO_RETRY'))
    save_new(run/'programming.json',dict(boot_id=boot,bit_sha256=BIT,note=note,sram_readback=False))
    preparation_stage('video_start')
    process=launch_video(root,run,config,boot,note)
    c=client(origin);api=c.Client();deadline=time.monotonic()+50
    while True:
        if process.poll() is not None:raise RuntimeError('视频进程退出，见owner.log；不重新启动')
        try:
            state=api.state()
            if state['phase']=='READY':break
            if state['phase'] in ('FAULTED','STOPPED'):raise RuntimeError('视频启动异常：'+str(state.get('failure')))
        except (OSError,c.ControlError):
            if time.monotonic()>deadline:raise RuntimeError('首幅画面未确认，保留现场，不重试')
        if time.monotonic()>deadline:raise RuntimeError('首幅画面确认超时，保留现场')
        time.sleep(.25)
    save_new(run/'READY.json',dict(boot=boot,owner_pid=process.pid,run_id=state['run_id'],origin=origin,
        cold_session=config['cold_session'],max_seconds=None,max_commands=None))
    print('已确认新画面。HDMI FPS与最终画面循环录像已开启。')
    print('网页：'+origin+'/control/' if online else '本轮离线：只通过当前终端菜单操作。')
    print('日志：'+str(run)+'；退出菜单不会停止视频。')
    return c.main(['menu'])


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('command',nargs='?',default='start',choices=['start','verify','menu','status','stop'])
    a=p.parse_args(argv);root=a.root.resolve(strict=True)
    if a.command=='verify':print(json.dumps(verify(root),ensure_ascii=False));return 0
    if a.command!='start':
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        record=json.loads((STATE/(boot+'.json')).read_text())
        return client(record['origin']).main([a.command])
    return start(root)

if __name__=='__main__':
    try:raise SystemExit(main())
    except (EOFError,KeyboardInterrupt):print('\n已退出；未发送停止或重试。');raise SystemExit(2)
    except Exception as error:print('未继续执行：'+str(error),file=sys.stderr);raise SystemExit(2)
