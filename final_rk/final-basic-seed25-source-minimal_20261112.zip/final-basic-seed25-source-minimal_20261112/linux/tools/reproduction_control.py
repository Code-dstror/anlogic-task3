"""中文终端控制台：只连接 127.0.0.1:8766 的既有 final_basic owner。

本模块可直接复制到 control/ 运行，仅依赖 Python 标准库。不打开设备、
BAR、驱动、串口或远程网络，也不启动/重启相机。API 对应
camera_parameter_control.py / unified_stereo_control.py；每次修改只 POST 一次。

例：python3 reproduction_control.py status
    python3 reproduction_control.py mode yolo --wait-seconds 60
    python3 reproduction_control.py parameters base.flags=true base.frame_budget=400000
    python3 reproduction_control.py parameters extension.product_mode=HDR
    python3 reproduction_control.py wait <request_id>
    python3 reproduction_control.py stop
无参数进入菜单；退出菜单、EOF 或 Ctrl-C 都不会停止 owner。
"""
import argparse
from copy import deepcopy
import datetime
import http.client
import json
import math
import re
import secrets
import sys
import time
from urllib.parse import urlencode

ADDRESS = ('127.0.0.1', 8766)
REPLAY_ADDRESS = ('127.0.0.1', 8765)
ORIGIN = 'http://rk3576-history.tail346db8.ts.net'
HOST = 'rk3576-history.tail346db8.ts.net'
BIT = 'eee7eff50323a8a5c7ddc850d3873e1dda13473debbfe8a690bcb6bab17ac362'
SCHEMA = 'FINAL_BASIC_PARAMETERS_V1'
MAX_RESPONSE = 65536
MAX_REQUEST = 1024
MAX_RECORDING_RESPONSE = 256 * 1024
SUCCESS = {'VIDEO_CONFIRMED', 'QUALITY_VIDEO_CONFIRMED'}
FAILED = {'CONFIG_REJECTED_VIDEO_CONTINUES', 'AI_FAILED_VIDEO_CONTINUES',
          'CANCELLED_BY_STOP', 'LAYOUT_NOT_CONFIRMED'}


class ControlError(RuntimeError):
    exit_code = 2


class OutcomeUnknown(ControlError):
    exit_code = 3


class CommandFailed(ControlError):
    exit_code = 4


def public(value):
    """Do not print the HTTP control token in status/results or errors."""
    if isinstance(value, dict):
        return {k: public(v) for k, v in value.items() if k != 'token'}
    if isinstance(value, list):
        return [public(v) for v in value]
    return value


def panel_fields(state):
    panel = state.get('fpga_parameters')
    if not isinstance(panel, dict) or panel.get('schema') != SCHEMA:
        raise ControlError('当前 owner 未提供 final_basic 的实际 ACTIVE 参数快照。')
    fields = panel.get('fields')
    if not isinstance(fields, list) or any(not isinstance(r, dict) or not isinstance(r.get('path'), str) for r in fields):
        raise ControlError('owner 参数字段格式异常；未提交修改。')
    return panel, {row['path']: row for row in fields}


def parse_value(row, raw):
    if row.get('read_only') or row.get('access') in ('fixed', 'unavailable'):
        raise ControlError(row['path'] + ' 为只读或未开放字段。')
    kind = row.get('kind')
    if kind == 'boolean':
        if type(raw) is bool:
            return raw
        if isinstance(raw, str):
            if raw.lower() in ('true', 'on', '开', '开启'): return True
            if raw.lower() in ('false', 'off', '关', '关闭'): return False
        raise ControlError(row['path'] + ' 需要 true/false 开关值。')
    if kind == 'enum' and isinstance(raw, str):
        for option in row.get('options', []):
            if raw == str(option['value']) or raw == option.get('label'):
                raw = option['value']; break
    if isinstance(raw, str) and re.fullmatch(r'[+-]?[0-9]+', raw):
        raw = int(raw)
    if type(raw) is not int or kind not in ('integer', 'enum'):
        raise ControlError(row['path'] + ' 需要准确整数，不能使用小数或布尔值。')
    if not row['minimum'] <= raw <= row['maximum']:
        raise ControlError('%s 超出实际范围 %s–%s。' % (row['path'], row['minimum'], row['maximum']))
    if kind == 'enum' and raw not in {option['value'] for option in row.get('options', [])}:
        raise ControlError(row['path'] + ' 不是当前开放的枚举值。')
    return raw


def parameter_patch(state, values):
    """Use cached field types/ranges only; the owner remains the validator."""
    panel, fields = panel_fields(state)
    if not isinstance(values, dict) or not values or len(values) > 32:
        raise ControlError('需要 1–32 项明确的参数修改。')
    patch = {}
    for path, value in values.items():
        if path not in fields:
            raise ControlError('参数未开放：' + str(path))
        patch[path] = parse_value(fields[path], value)
    def value(path):
        return patch[path] if path in patch else fields.get(path, {}).get('value')
    if value('base.min_quality') > value('base.quality'):
        raise ControlError('min_quality 不能高于 quality；请在同一补丁内明确调整。')
    if value('base.flags') and not value('base.frame_budget'):
        raise ControlError('自适应质量需要非零 frame_budget；请在同一补丁内明确设置。')
    if value('extension.processing_enables.LANE') and not value('extension.processing_enables.MULTISCALE'):
        raise ControlError('车道需要多尺度；请在同一补丁内设置 MULTISCALE=true。')
    hdr = value('extension.product_mode')
    if hdr != 2 and any('.hdr_' in path for path in patch):
        raise ControlError('修改 HDR 字段需同时启用 HDR；关闭时由 owner 清零。')
    if hdr == 2 and panel['active_document']['extension']['product_mode'] != 2 and not panel.get('hdr_policy'):
        raise ControlError('owner 没有已确认的 HDR 策略；不能填入示例默认值。')
    if value('extension.dehaze_lut_generation') and not value('extension.processing_enables.DEHAZE'):
        raise ControlError('去雾关闭时 generation 必须为 0。')
    return patch


def assignments(items):
    result = {}
    for item in items:
        if '=' not in item:
            raise ControlError('参数格式为 path=value，例如 base.quality=75。')
        path, value = item.split('=', 1)
        path, value = path.strip(), value.strip()
        if not path or not value or path in result:
            raise ControlError('参数名和值不能为空，也不能重复：' + path)
        result[path] = value
    return result


def recording_time(text, *, beijing=False):
    if not isinstance(text,str) or not text.strip():raise ControlError('需要明确的录像查询时间。')
    text=text.strip()
    if text.startswith('北京时间'):
        beijing=True;text=text[len('北京时间'):].strip()
    try:value=datetime.datetime.fromisoformat(text.replace('Z','+00:00'))
    except ValueError as exc:raise ControlError('时间格式错误；使用带偏移ISO或 --beijing 的 YYYY-MM-DD HH:MM:SS。')from exc
    if value.tzinfo is None:
        if not beijing:raise ControlError('时间缺少偏移；请加 --beijing 明确北京时间，或使用 +08:00 / Z。')
        value=value.replace(tzinfo=datetime.timezone(datetime.timedelta(hours=8)))
    return value.astimezone(datetime.timezone.utc)


def recording_rows(rows):
    result=[]
    for row in rows:
        if not isinstance(row,dict) or not isinstance(row.get('asset_id'),str):
            raise OutcomeUnknown('本地录像索引条目格式异常。')
        item={key:row.get(key)for key in ('asset_id','utc_start','utc_end','clock_quality','recording_id',
            'boot_id','relative_path','bytes','sample_count')}
        recording_id=item['recording_id'];name=item['relative_path']
        if (isinstance(recording_id,str) and re.fullmatch('[A-Za-z0-9_-]{1,128}',recording_id)
                and isinstance(name,str) and re.fullmatch(r'segment-[0-9]{5,20}\.mp4',name)):
            item['sd_path']='/mnt/anlogic-sd/recordings/'+recording_id+'/'+name
        result.append(item)
    return result


class Client:
    def __init__(self, *, connection_factory=http.client.HTTPConnection, request_timeout=3,
                 clock=time.monotonic, sleep=time.sleep, nonce=lambda: secrets.token_hex(12)):
        self.factory, self.request_timeout = connection_factory, request_timeout
        self.clock, self.sleep, self.nonce = clock, sleep, nonce
        if type(request_timeout) not in (int, float) or not math.isfinite(request_timeout) or not 0 < request_timeout <= 10:
            raise ValueError('HTTP timeout must be finite and 0..10 seconds')

    def _http(self, method, path, *, payload=None, token=None, timeout=None):
        headers = {'Host': HOST, 'Cache-Control': 'no-store'}
        body = None
        if payload is not None:
            body = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
            if len(body) > MAX_REQUEST:
                raise ControlError('补丁超过既有接口 1024B 上限；请明确拆分并重新确认基线，不会自动拆分。')
            headers.update(Origin=ORIGIN, **{'X-Control-Token': token, 'Content-Type': 'application/json'})
        connection = self.factory(*ADDRESS, timeout=self.request_timeout if timeout is None else timeout)
        try:
            # http.client connects to the numeric loopback address directly;
            # proxy/DNS/environment network settings are never consulted.
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            data = response.read(MAX_RESPONSE + 1)
            if len(data) > MAX_RESPONSE:
                raise ValueError('owner response exceeds 64KiB')
            if method == 'POST' and response.status != 202:
                if response.status in (400, 403, 409):
                    raise ControlError('请求未受理（可能与网页并发、基线或参数校验有关）；请重新查询，不自动重发。')
                raise OutcomeUnknown('POST 响应异常，修改结果未知；不要重发。')
            if method == 'GET' and response.status != 200:
                raise OutcomeUnknown('本地 owner 查询失败，HTTP %d。' % response.status)
            result = json.loads(data)
            if not isinstance(result, dict): raise ValueError('object response required')
            return result
        except ControlError:
            raise
        except (OSError, ValueError, http.client.HTTPException) as error:
            prefix = '修改结果未知；不要重发' if method == 'POST' else '本地 owner 暂不可用'
            raise OutcomeUnknown(prefix + '（%s）。' % type(error).__name__) from error
        finally:
            try: connection.close()
            except OSError: pass

    def state(self, *, timeout=None):
        state = self._http('GET', '/control/api/state', timeout=timeout)
        if (not isinstance(state.get('run_id'), str) or not re.fullmatch('[0-9a-f]{32}', state['run_id'])
                or type(state.get('revision')) is not int or state['revision'] < 0
                or not isinstance(state.get('commands'), list)):
            raise OutcomeUnknown('本地 owner 状态格式异常；未提交修改。')
        return state

    def recordings(self,start,end,*,beijing=False,limit=100,offset=0,pages=1,order='asc'):
        """Read sealed-file metadata only; no /media request or local DB open."""
        start=recording_time(start,beijing=beijing);end=recording_time(end,beijing=beijing)
        if end<=start:raise ControlError('结束时间必须晚于开始时间。')
        if (type(limit)is not int or not 1<=limit<=200 or type(offset)is not int or not 0<=offset<2**63
                or type(pages)is not int or not 1<=pages<=20 or order not in ('asc','desc')):
            raise ControlError('每页1–200条、最多1–20页，offset需为非负整数，排序asc/desc。')
        result=[];seen=set();cursor=offset;has_more=False;next_offset=None
        for unused in range(pages):
            query=urlencode(dict(start=start.isoformat(),end=end.isoformat(),limit=limit,offset=cursor,order=order))
            connection=self.factory(*REPLAY_ADDRESS,timeout=self.request_timeout)
            try:
                connection.request('GET','/api/recordings?'+query,headers={'Host':HOST,'Cache-Control':'no-store'})
                response=connection.getresponse();body=response.read(MAX_RECORDING_RESPONSE+1)
                if response.status!=200 or len(body)>MAX_RECORDING_RESPONSE:
                    raise OutcomeUnknown('本地录像索引查询失败或响应超过256KiB；未读取视频。')
                data=json.loads(body)
                if (not isinstance(data,dict) or not isinstance(data.get('assets'),list)
                        or len(data['assets'])>limit or type(data.get('has_more'))is not bool):
                    raise ValueError('invalid recording page')
                has_more=data['has_more'];next_offset=data.get('next_offset')
                if has_more and (type(next_offset)is not int or not cursor<next_offset<2**63 or not data['assets']):
                    raise ValueError('recording pagination did not advance')
                for row in recording_rows(data['assets']):
                    if row['asset_id'] not in seen:seen.add(row['asset_id']);result.append(row)
                if not has_more:next_offset=None;break
                cursor=next_offset
            except ControlError:raise
            except (OSError,ValueError,http.client.HTTPException)as exc:
                raise OutcomeUnknown('本地录像索引暂不可用；未修改索引、未读取视频（%s）。'%type(exc).__name__)from exc
            finally:
                try:connection.close()
                except OSError:pass
        return dict(assets=result,has_more=has_more,next_offset=next_offset,limit=limit,offset=offset,
            start_utc=start.isoformat(),end_utc=end.isoformat(),order=order,
            scope='仅查询当前HTTP索引；未读取视频、未按文件名猜时间。SD路径由索引ID/相对名推导，循环回收后可能失效。')

    def submit(self, action, value=None, *, state=None, wait_seconds=60):
        self._budget(wait_seconds)
        state = self.state() if state is None else deepcopy(state)
        if state.get('bit_sha256') != BIT:
            raise ControlError('当前 owner 不是预期的 final_basic seed25；未提交修改。')
        if action == 'stop':
            if not state.get('can_stop'): raise ControlError('当前会话已停止或正在停止。')
        else:
            panel_fields(state)
            if not state.get('accepting'): raise ControlError('owner 正忙、无新鲜心跳或已停止；请先查询状态。')
        request = dict(run_id=state['run_id'], revision=state['revision'],
            request_id='%s-%s-%s' % (state['run_id'], state['revision'], self.nonce()), action=action)
        if action == 'mode':
            if value not in {row['id'] for row in state.get('modes', [])}:
                raise ControlError('此会话不提供该模式（YOLO 仅支持单目）。')
            if value == 'yolo' and state.get('topology_cameras') != 1:
                raise ControlError('YOLO 仅支持单目 CAM0。')
            if value == 'yolo' and (state.get('ai') or {}).get('retained') and not (state.get('ai') or {}).get('retired'):
                raise ControlError('旧 AI 资源尚未退休；可选择其他视频模式。')
            request['mode'] = value
        elif action == 'layout':
            if value not in {row['id'] for row in state.get('layouts', [])}: raise ControlError('此会话不提供该布局。')
            request['layout'] = value
        elif action == 'quality':
            if type(value) is not int or not 1 <= value <= 100: raise ControlError('JPEG Q 必须是 1–100 的整数。')
            parameter_patch(state, {'base.quality': value})
            request['quality'] = value
        elif action == 'parameters':
            panel, _ = panel_fields(state)
            request.update(patch=parameter_patch(state, value),
                baseline={key: panel[key] for key in ('session', 'epoch', 'fingerprint')})
        elif action != 'stop':
            raise ControlError('仅支持 mode/layout/quality/parameters/stop。')
        token = state.get('token')
        if not isinstance(token, str) or not token or not token.isascii():
            raise ControlError('owner 未提供有效控制 token；未提交修改。')
        try:
            accepted = self._http('POST', '/control/api/command', payload=request, token=token)
        except OutcomeUnknown as error:
            raise OutcomeUnknown('%s request_id=%s；可用 wait %s 只读查询。' %
                (error, request['request_id'], request['request_id'])) from error
        if accepted.get('request') != request:
            raise OutcomeUnknown('受理回执不匹配；不要重发。request_id=' + request['request_id'])
        return self.wait(request['request_id'], wait_seconds=wait_seconds, request=request)

    @staticmethod
    def _budget(seconds):
        if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 0 < seconds <= 300:
            raise ControlError('单次确认等待必须是 0–300 秒内的正数；没有累计运行限制。')

    def wait(self, request_id, *, wait_seconds=60, request=None):
        self._budget(wait_seconds)
        match = re.fullmatch(r'([0-9a-f]{32})-[0-9]+-[A-Za-z0-9_-]{8,48}', request_id)
        if match is None: raise ControlError('request_id 格式不正确。')
        deadline = self.clock() + wait_seconds
        while self.clock() < deadline:
            state = self.state(timeout=min(self.request_timeout, max(.001, deadline - self.clock())))
            if state['run_id'] != match.group(1):
                raise OutcomeUnknown('owner 会话已改变；旧请求结果不能推断，不会重发。')
            entry = next((row for row in state['commands'] if row.get('request', {}).get('request_id') == request_id), None)
            if entry is None:
                raise OutcomeUnknown('请求不在近期记录中；不能推断未执行，不会重发。request_id=' + request_id)
            if request is not None and entry.get('request') != request:
                raise OutcomeUnknown('请求记录内容不匹配；不会重发。')
            action = entry['request']['action'];status = entry.get('status')
            if action == 'stop' and state.get('phase') == 'STOPPED':
                return public(dict(status='STOPPED', request_id=request_id, confirmation=dict(phase='STOPPED'), state=state))
            if status in FAILED:
                suffix = '；合法视频继续' if status in ('AI_FAILED_VIDEO_CONTINUES', 'CONFIG_REJECTED_VIDEO_CONTINUES') else ''
                raise CommandFailed('%s%s：%s；request_id=%s' % (status, suffix, entry.get('error', ''), request_id))
            if status in SUCCESS:
                proof = entry.get('confirmation') or {}
                if type(proof.get('frame_ordinal')) is not int or proof['frame_ordinal'] <= 0:
                    raise OutcomeUnknown('状态缺少真实画面确认；不能视为成功。')
                if action == 'layout':
                    if type(proof.get('layout_revision')) is not int or proof['layout_revision'] <= 0:
                        raise OutcomeUnknown('状态缺少真实布局版本确认。')
                else:
                    if (type(proof.get('session')) is not int or proof['session'] <= 0
                            or type(proof.get('mode_epoch')) is not int or proof['mode_epoch'] <= 0
                            or proof.get('action') != action):
                        raise OutcomeUnknown('状态缺少 APPLIED/新画面确认；不能视为成功。')
                    if action == 'parameters':
                        origin = entry['request']['baseline']
                        if proof['session'] != origin['session'] or proof['mode_epoch'] <= origin['epoch']:
                            raise OutcomeUnknown('确认属于其他 session/旧 epoch。')
                    if action == 'quality' and proof.get('quality') != entry['request']['quality']:
                        raise OutcomeUnknown('确认质量与请求不一致。')
                    if entry['request'].get('mode') == 'yolo' and proof.get('mode') != 'yolo':
                        raise CommandFailed('YOLO 未取得 owner 的首结果/输出确认；合法视频状态请查询 ai。')
                # VIDEO_CONFIRMED is emitted by the owner only after its
                # APPLIED/ACTIVE/new video gate, and for YOLO its first result
                # plus native output proof. Current ai may since have changed.
                return public(dict(status=status, request_id=request_id, confirmation=proof, state=state))
            if state.get('phase') in ('FAULTED', 'STOPPED'):
                raise CommandFailed('owner 已结束或异常，未确认此请求：' + str(state.get('failure') or state['phase']))
            self.sleep(min(.25, max(0, deadline - self.clock())))
        raise OutcomeUnknown('单次等待超时；未停止 owner、未重发。request_id=' + request_id)


def field_text(row):
    tag = '只读' if row.get('read_only') else '可写'
    limits = ('枚举 ' + ', '.join('%s=%s' % (v['value'], v['label']) for v in row.get('options', []))
        if row.get('kind') == 'enum' else 'true/false' if row.get('kind') == 'boolean'
        else '%s–%s %s' % (row.get('minimum'), row.get('maximum'), row.get('unit', '')))
    return '%s [%s] %s = %s；%s' % (row.get('label', row['path']), tag, row['path'], row.get('value'), limits)


def fps_status(state):
    return dict(source_rates=state.get('source_rates'),
        common_output_counters=(state.get('recording') or {}).get('native'),
        scope='输入 FPS 来自 owner 已验收产品窗口；共同输出为累计计数，不冒充物理 HDMI 刷新率。')


def display_recordings(result,output):
    output.write(result['scope']+'\n')
    for row in result['assets']:
        output.write('%s — %s · %s · %s · asset=%s\n'%
            (row['utc_start'],row['utc_end'],row['clock_quality'],row['relative_path'],row['asset_id']))
        if row.get('sd_path'):output.write('  SD：'+row['sd_path']+'\n')
    if not result['assets']:
        output.write('当前索引未返回该时间段片段；不能据此认定未录制，片段可能未入库或已循环回收。\n')
    if result['has_more']:output.write('还有后续页；下次使用 --offset %s（当前结果并非冻结快照）。\n'%result['next_offset'])


def display(state, topic, output):
    if topic == 'status':
        output.write('会话 %s · %s · 模式 %s · 布局 %s · Q%s\n' %
            (state['run_id'], state.get('phase'), state.get('mode'), state.get('current'), state.get('quality')))
        for key,label in (('ai','AI'),('source_rates','逐眼输入 FPS'),('recording','录像')):
            output.write(label + '：' + json.dumps(public(state.get(key)), ensure_ascii=False) + '\n')
    elif topic in ('modes', 'layouts'):
        for index, row in enumerate(state.get(topic, []), 1):
            output.write('%d. %s · %s\n' % (index, row['id'], row.get('label', row['id'])))
    elif topic == 'parameters':
        panel, _ = panel_fields(state)
        output.write('ACTIVE session=%s epoch=%s fingerprint=%s；HDR策略来源=%s\n' %
            (panel['session'], panel['epoch'], panel['fingerprint'], panel.get('hdr_policy_origin')))
        for index, row in enumerate(panel['fields'], 1): output.write('%d. %s\n' % (index, field_text(row)))
    else:
        output.write(json.dumps(public(fps_status(state) if topic=='fps' else state.get(topic)), ensure_ascii=False, indent=2) + '\n')


def menu(client, input_fn, output, error, wait_seconds):
    def ask(text):
        output.write(text);output.flush();return input_fn().strip()
    def change_parameters():
        state=client.state();panel,_=panel_fields(state);draft={}
        display(state,'parameters',output)
        while True:
            choice=ask('字段编号（a 提交本次补丁，c 取消返回）：')
            if choice.lower() in ('c',''):return
            if choice.lower()=='a':
                if not draft:raise ControlError('尚未修改参数。')
                result=client.submit('parameters',draft,state=state,wait_seconds=wait_seconds)
                output.write('已确认：'+json.dumps(result['confirmation'],ensure_ascii=False)+'\n');return
            if not choice.isdigit() or not 1<=int(choice)<=len(panel['fields']):
                error.write('请选择已列出的字段编号。\n');continue
            row=panel['fields'][int(choice)-1]
            try:
                if row.get('read_only'):raise ControlError(row['path']+' 为只读。')
                draft[row['path']]=parse_value(row,ask(field_text(row)+'；输入新值：'))
                output.write('草稿：'+json.dumps(draft,ensure_ascii=False)+'\n')
            except ControlError as exc:error.write(str(exc)+'\n')
    try:
        while True:
            output.write('\n1 状态/FPS/录像  2 可用模式  3 可用布局  4 AI状态  5 参数/只读范围\n'
                '6 切换模式  7 切换布局  8 JPEG质量Q  9 编辑参数补丁\n'
                'r 按北京时间查询SD录像索引（只读，不下载视频）\n'
                's 明确停止本轮相机  q 退出菜单（相机继续运行）\n')
            choice=ask('选择：').lower()
            if choice in ('q','0','exit'):break
            try:
                if choice in ('1','2','3','4','5'):
                    display(client.state(),{'1':'status','2':'modes','3':'layouts','4':'ai','5':'parameters'}[choice],output)
                elif choice in ('6','7'):
                    state=client.state();topic='modes' if choice=='6' else 'layouts'
                    display(state,topic,output);value=ask('输入编号或 ID（空白返回）：')
                    if not value:continue
                    if value.isdigit() and 1<=int(value)<=len(state.get(topic,[])):value=state[topic][int(value)-1]['id']
                    result=client.submit('mode' if choice=='6' else 'layout',value,state=state,wait_seconds=wait_seconds)
                    output.write('已确认：'+json.dumps(result['confirmation'],ensure_ascii=False)+'\n')
                elif choice=='8':
                    value=ask('JPEG Q 1–100（空白返回）：')
                    if not value:continue
                    if not re.fullmatch('[0-9]+',value):raise ControlError('Q需要整数。')
                    result=client.submit('quality',int(value),wait_seconds=wait_seconds)
                    output.write('已确认：'+json.dumps(result['confirmation'],ensure_ascii=False)+'\n')
                elif choice=='9':change_parameters()
                elif choice=='r':
                    start=ask('北京时间开始 YYYY-MM-DD HH:MM:SS（空白返回）：')
                    if not start:continue
                    end=ask('北京时间结束 YYYY-MM-DD HH:MM:SS：')
                    count=ask('最多查询页数1–20（默认1，每页100条）：')or'1'
                    if not count.isdigit():raise ControlError('页数需要整数。')
                    display_recordings(client.recordings(start,end,beijing=True,pages=int(count)),output)
                elif choice=='s':
                    result=client.submit('stop',wait_seconds=wait_seconds)
                    output.write('本轮已停止；退出菜单不会重新启动。\n')
                else:error.write('未知菜单选项。\n')
            except ControlError as exc:error.write(str(exc)+'\n')
    except (EOFError,KeyboardInterrupt):pass
    output.write('已退出终端菜单；未额外发送停止请求。\n')
    return 0


def main(argv=None, *, client=None, input_fn=input, output=None, error=None):
    output=sys.stdout if output is None else output;error=sys.stderr if error is None else error
    parser=argparse.ArgumentParser(description='final_basic 本地终端控制：退出不停止相机；修改只POST一次。',allow_abbrev=False)
    parser.add_argument('--json',action='store_true',help='输出去除控制token的JSON')
    parser.add_argument('--wait-seconds',type=float,default=60,help='单次确认等待秒数，0<值<=300；非累计限制')
    subs=parser.add_subparsers(dest='command')
    for name in ('menu','status','modes','layouts','ai','fps','recording'):
        item=subs.add_parser(name)
        item.add_argument('--json',action='store_true',default=argparse.SUPPRESS)
    recordings=subs.add_parser('recordings',help='按明确时间查询SD已封存片段索引；不回传视频')
    recordings.add_argument('--start');recordings.add_argument('--end')
    recordings.add_argument('--beijing',action='store_true',help='将无偏移输入明确按北京时间+08:00解释')
    recordings.add_argument('--limit',type=int,default=100);recordings.add_argument('--offset',type=int,default=0)
    recordings.add_argument('--pages',type=int,default=1);recordings.add_argument('--order',choices=['asc','desc'],default='asc')
    recordings.add_argument('--json',action='store_true',default=argparse.SUPPRESS)
    for name in ('mode','layout','quality','wait','stop','parameters','patch'):
        item=subs.add_parser(name)
        item.add_argument('--json',action='store_true',default=argparse.SUPPRESS)
        item.add_argument('--wait-seconds',type=float,default=argparse.SUPPRESS)
        if name in ('mode','layout','wait'):item.add_argument('value')
        elif name=='quality':item.add_argument('value',type=int)
        elif name in ('parameters','patch'):
            item.add_argument('values',nargs='*',help='path=value；布尔true/false，枚举数值或标签')
            item.add_argument('--patch-json',help='平面JSON对象，与path=value二选一')
    args=parser.parse_args(argv);client=Client() if client is None else client
    try:
        Client._budget(args.wait_seconds)
        command=args.command or 'menu'
        if command=='menu':return menu(client,input_fn,output,error,args.wait_seconds)
        if command=='recordings':
            if not args.start and not args.end:
                output.write('用法：recordings --beijing --start "2026-11-10 15:00:00" --end "2026-11-10 15:05:00"\n'
                    '也可输入带偏移ISO，例如 2026-11-10T15:00:00+08:00；菜单 r 可交互查询。\n');return 0
            result=client.recordings(args.start,args.end,beijing=args.beijing,limit=args.limit,
                offset=args.offset,pages=args.pages,order=args.order)
            if args.json:output.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
            else:display_recordings(result,output)
            return 0
        queries=('status','modes','layouts','ai','fps','recording')
        if command in queries or command=='parameters' and not args.values and not args.patch_json:
            state=client.state()
            if args.json:
                value=(state if command=='status' else fps_status(state) if command=='fps' else
                       state.get('fpga_parameters' if command=='parameters' else command))
                output.write(json.dumps(public(value),ensure_ascii=False,indent=2)+'\n')
            else:display(state,command,output)
            return 0
        if command=='wait':result=client.wait(args.value,wait_seconds=args.wait_seconds)
        elif command in ('parameters','patch'):
            if args.patch_json and args.values:raise ControlError('JSON补丁与path=value不能混用。')
            try:values=json.loads(args.patch_json) if args.patch_json else assignments(args.values)
            except (ValueError,TypeError) as exc:raise ControlError('补丁JSON格式不正确。') from exc
            result=client.submit('parameters',values,wait_seconds=args.wait_seconds)
        else:result=client.submit(command,getattr(args,'value',None),wait_seconds=args.wait_seconds)
        if args.json:output.write(json.dumps(public(result),ensure_ascii=False,indent=2)+'\n')
        else:output.write('已确认：'+json.dumps(result['confirmation'],ensure_ascii=False)+'\n')
        return 0
    except ControlError as exc:
        error.write((json.dumps(dict(error=str(exc),exit_code=exc.exit_code),ensure_ascii=False) if args.json else str(exc))+'\n')
        return exc.exit_code
    except KeyboardInterrupt:
        error.write('已中断终端等待；未停止owner，也未重发修改。\n');return 130


if __name__=='__main__':raise SystemExit(main())
