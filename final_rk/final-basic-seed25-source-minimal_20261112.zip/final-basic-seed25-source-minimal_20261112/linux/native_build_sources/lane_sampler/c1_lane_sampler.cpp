// Display sampling only. The unchanged core's lane_evaluate is supplied by
// function pointer; this library contains no solver, image or device code.
#include "c1_core_source/lane_tracker.h"
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>

struct LanePoint { uint16_t x, y; };
struct LaneCurve { uint32_t count, label; LanePoint points[542]; };
static_assert(sizeof(LanePoint)==4 && sizeof(LaneCurve)==2176,"Display lane ABI differs");
using Evaluate=double (*)(const Curve*,double);

extern "C" uint32_t c1_lane_sampler_abi() { return 1; }
extern "C" uint32_t c1_lane_sampler_curve_bytes() { return sizeof(LaneCurve); }
extern "C" int c1_lane_sample(void *function,const Curve *curves,uint32_t count,
                              LaneCurve *output,size_t output_bytes) {
    if (!output || output_bytes!=2*sizeof(LaneCurve)) return 0;
    std::memset(output,0,output_bytes); // Failure cannot lend old sampled lines.
    if (!function || count>2 || (count && !curves)) return 0;
    const auto evaluate=reinterpret_cast<Evaluate>(function);
    LaneCurve sampled[2]{};
    for (uint32_t index=0;index<count;++index) {
        const auto& curve=curves[index];
        if (curve.n<3 || curve.n>6 || curve.label<0 || curve.label>2 || curve.support<16) return 0;
        for (int k=0;k<curve.n;++k) {
            if (!std::isfinite(curve.y[k]) || !std::isfinite(curve.x[k]) ||
                !std::isfinite(curve.tangent[k]) || (k && curve.y[k]<=curve.y[k-1])) return 0;
        }
        if (!std::isfinite(curve.median_error) || !std::isfinite(curve.p90_error) ||
            !std::isfinite(curve.score) || curve.y[0]<676 || curve.y[curve.n-1]>1076) return 0;
        const int begin=static_cast<int>(std::ceil(curve.y[0]));
        const int end=static_cast<int>(std::floor(curve.y[curve.n-1]));
        auto& target=sampled[index];target.label=static_cast<uint32_t>(curve.label);
        auto append=[&](int y) {
            if (target.count>=542 || y<0 || y>=1080) return false;
            const double x=evaluate(&curve,static_cast<double>(y));
            if (!std::isfinite(x) || x<0 || x>=1920) return false;
            const double rounded=std::floor(x+.5);
            if (rounded>=1920) return false;
            target.points[target.count++]={static_cast<uint16_t>(rounded),static_cast<uint16_t>(y)};
            return true;
        };
        for (int y=begin;y<=end;y+=2) if (!append(y)) return 0;
        if (target.count && target.points[target.count-1].y!=end && !append(end)) return 0;
        if (target.count<2) return 0;
    }
    std::memcpy(output,sampled,sizeof sampled);
    return 1;
}
