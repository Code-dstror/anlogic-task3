#pragma once

// ABI declarations for the unchanged experimental lane_tracker.cpp.
// C++17, 32-bit int, 64-bit double; do not pack these native structures.
#include <cstdint>

struct Point { int x, y, strength, cls, width; };
struct Curve {
    int n, support, label, track_id;
    double y[6], x[6], tangent[6];
    double median_error, p90_error, score;
};
static_assert(sizeof(int) == 4 && sizeof(double) == 8, "Unsupported native ABI");
static_assert(sizeof(Point) == 20 && sizeof(Curve) == 184, "Unexpected layout");

extern "C" {
void* lane_create();
void lane_destroy(void* handle);
double lane_evaluate(const Curve* curve, double y);
// Required: valid handle, points[303], output[2], assignments[303], path_count.
// count=0 is a current empty observation, never a request for an old curve.
int lane_process(void* handle, const Point* points, int count,
                 uint32_t session, uint32_t epoch, uint32_t sequence,
                 int camera, double time, Curve* output,
                 int* assignments, int* path_count);
}
