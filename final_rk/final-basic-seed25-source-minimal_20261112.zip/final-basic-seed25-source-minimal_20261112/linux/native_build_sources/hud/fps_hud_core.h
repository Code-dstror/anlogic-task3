/* Frame-driven host-rate HUD. No scheduler, GStreamer, allocation or device IO.
 * Keep one counter per source/camera; zero-initialize or explicitly reset it.
 * A source identity is an increasing nonzero token, not an exposure timestamp.
 * No observe/draw call means no refresh: a frozen picture retains its HUD.
 */
#ifndef R5_FPS_HUD_CORE_H
#define R5_FPS_HUD_CORE_H
#include <stddef.h>
#include <stdint.h>
#include <limits.h>

#define FPS_HUD_SCALE 3u
#define FPS_HUD_PADDING 4u
#define FPS_HUD_MAX_TEXT 31u
#define FPS_HUD_MIN_CELLS 20u /* CAMx FPS + largest u32-tenths decimal value */
#define FPS_HUD_INTERVAL_NS UINT64_C(1000000000)

struct fps_hud_counter {
    uint64_t total,last_identity,base_total,base_ns,last_ns;
    uint32_t fps_tenths;
    unsigned initialized,valid,failed;
};
static inline void fps_hud_reset(struct fps_hud_counter *c) {
    if(c)*c=(struct fps_hud_counter){0};
}
static inline int fps_hud_fail(struct fps_hud_counter *c) {
    if(c) { c->failed=1;c->valid=0; }
    return 0;
}
/* Rounded delta*1e10/elapsed, without overflowing intermediate products and
 * without compiler-specific 128-bit arithmetic or floating-point/libm calls.
 * Constant 34-bit multiply/divide; called only when a rate interval completes.
 */
static inline int fps_hud_rate(uint64_t delta,uint64_t elapsed,uint32_t *out) {
    const uint64_t scale=UINT64_C(10000000000);
    uint64_t remainder=0;uint32_t quotient=0;
    if(!out || !elapsed || delta>=elapsed)return 0; /* >=1 frame/ns exceeds u32. */
    for(uint64_t bit=UINT64_C(1)<<33;bit;bit>>=1) {
        if(quotient>UINT32_MAX/2u)return 0;
        quotient*=2u;
        if(remainder>=elapsed-remainder) {
            remainder-=elapsed-remainder;
            if(quotient==UINT32_MAX)return 0;
            quotient++;
        } else remainder+=remainder;
        if(scale&bit) {
            if(remainder>=elapsed-delta) {
                remainder-=elapsed-delta;
                if(quotient==UINT32_MAX)return 0;
                quotient++;
            } else remainder+=delta;
        }
    }
    if(remainder>=elapsed-remainder) {
        if(quotient==UINT32_MAX)return 0;
        quotient++;
    }
    *out=quotient;return 1;
}
/* present=1 accepts a new nonzero identity, equal identities are held inputs.
 * present=0 or identity=0 observes output time only (no source increment).
 * Equal clock values are permitted; backward clocks/identities and arithmetic
 * overflow latch failed/invalid. Only an explicit software reset clears it.
 * The first accepted frame is included in total and in the initial baseline,
 * so the first interval measures new frames after its opening sample.
 */
static inline int fps_hud_observe(struct fps_hud_counter *c,uint64_t now_ns,
                                  uint64_t identity,int present) {
    if(!c || c->failed)return 0;
    if((present!=0 && present!=1) || (c->initialized && now_ns<c->last_ns))return fps_hud_fail(c);
    if(present && identity) {
        if(identity<c->last_identity)return fps_hud_fail(c);
        if(identity!=c->last_identity) {
            if(c->total==UINT64_MAX)return fps_hud_fail(c);
            c->total++;c->last_identity=identity;
        }
    }
    if(!c->initialized) {
        c->initialized=1;c->base_ns=now_ns;c->last_ns=now_ns;
        c->base_total=c->total;c->valid=0;return 1;
    }
    c->last_ns=now_ns;
    if(c->total<c->base_total || now_ns<c->base_ns)return fps_hud_fail(c);
    uint64_t elapsed=now_ns-c->base_ns;
    if(elapsed>=FPS_HUD_INTERVAL_NS) {
        uint32_t rate;
        if(!fps_hud_rate(c->total-c->base_total,elapsed,&rate))return fps_hud_fail(c);
        c->fps_tenths=rate;c->valid=1;c->base_total=c->total;c->base_ns=now_ns;
    }
    return 1;
}
/* Null, insufficient output space or camera outside {0,1}: reject without
 * modifying output. Failed/uninitialized counters display the invalid value.
 */
static inline int fps_hud_format(char *out,size_t capacity,unsigned camera,
                                 const struct fps_hud_counter *c) {
    char text[32]="CAM0 FPS ";size_t n=9;
    if(!out || !c || camera>1)return 0;
    text[3]=(char)('0'+camera);
    if(c->initialized && c->valid && !c->failed) {
        char digits[10];unsigned count=0;uint32_t value=c->fps_tenths/10u;
        do { digits[count++]=(char)('0'+value%10u);value/=10u; } while(value);
        while(count)text[n++]=digits[--count];
        text[n++]='.';text[n++]=(char)('0'+c->fps_tenths%10u);
    } else {
        text[n++]='-';text[n++]='-';text[n++]='.';text[n++]='-';
    }
    if(capacity<=n)return 0;
    for(size_t i=0;i<n;i++)out[i]=text[i];
    out[n]=0;return 1;
}
/* Seven 5-bit rows, most significant displayed column is bit4. */
static inline const uint8_t *fps_hud_glyph(unsigned char ch) {
    static const uint8_t glyphs[19][7]={
        {14,17,16,16,16,17,14}, /* C */
        {14,17,17,31,17,17,17}, /* A */
        {17,27,21,21,17,17,17}, /* M */
        {31,16,16,30,16,16,16}, /* F */
        {30,17,17,30,16,16,16}, /* P */
        {15,16,16,14,1,1,30},   /* S */
        {14,17,19,21,25,17,14}, /* 0 */
        {4,12,4,4,4,4,14},     /* 1 */
        {14,17,1,2,4,8,31},    /* 2 */
        {30,1,1,14,1,1,30},    /* 3 */
        {2,6,10,18,31,2,2},    /* 4 */
        {31,16,16,30,1,1,30},  /* 5 */
        {14,16,16,30,17,17,14},/* 6 */
        {31,1,2,4,8,8,8},      /* 7 */
        {14,17,17,14,17,17,14},/* 8 */
        {14,17,17,15,1,1,14},  /* 9 */
        {0,0,0,0,0,0,4},      /* . */
        {0,0,0,31,0,0,0},     /* - */
        {0,0,0,0,0,0,0}       /* space */
    };
    switch(ch) {
        case 'C':return glyphs[0];case 'A':return glyphs[1];case 'M':return glyphs[2];
        case 'F':return glyphs[3];case 'P':return glyphs[4];case 'S':return glyphs[5];
        case '.':return glyphs[16];case '-':return glyphs[17];case ' ':return glyphs[18];
        default:return ch>='0' && ch<='9'?glyphs[6+ch-'0']:NULL;
    }
}
/* Returns an even-aligned local background rectangle. Positions supplied to
 * draw must also be even, so UV writes never leak into neighboring pixels.
 * Minimum20 cells gives all formatted FPS values the same opaque extent,
 * clearing old trailing digits when redrawing a held buffer with shorter text.
 * No empty/all-space line, newline, unsupported glyph or >31-character text.
 */
static inline int fps_hud_text_extent(const char *text,uint32_t *width,uint32_t *height) {
    size_t n=0;int nonspace=0;
    if(!text || !width || !height)return 0;
    while(n<=FPS_HUD_MAX_TEXT && text[n]) {
        if(n==FPS_HUD_MAX_TEXT || !fps_hud_glyph((unsigned char)text[n]))return 0;
        nonspace|=text[n]!=' ';n++;
    }
    if(!n || !nonspace)return 0;
    size_t cells=n<FPS_HUD_MIN_CELLS?FPS_HUD_MIN_CELLS:n;
    *width=(uint32_t)(2u*FPS_HUD_PADDING+6u*FPS_HUD_SCALE*cells);
    *height=(2u*FPS_HUD_PADDING+7u*FPS_HUD_SCALE+1u)&~1u;
    return 1;
}
struct fps_hud_surface {
    uint8_t *y,*uv;
    ptrdiff_t ys,uvs;
    uint32_t width,height;
    size_t y_span,uv_span; /* verified mapped bytes available from each pointer */
};
static inline int fps_hud_plane_span(uint32_t rows,uint32_t width,ptrdiff_t stride,size_t *span) {
    if(!span || !rows || !width || stride<=0 || (uintmax_t)stride<width)return 0;
    size_t pitch=(size_t)stride;
    if((uintmax_t)stride>SIZE_MAX || (size_t)(rows-1)>(SIZE_MAX-width)/pitch)return 0;
    *span=(size_t)(rows-1)*pitch+width;return 1;
}
/* Validate the entire visible plane spans before changing any byte. The caller
 * owns the mapping and verifies the supplied span belongs to accessible memory.
 * Rendering touches only this opaque black rectangle and its neutral UV area;
 * row padding, other pixels and the other camera HUD remain untouched.
 */
static inline int fps_hud_draw(struct fps_hud_surface *s,uint32_t x,uint32_t y,const char *text) {
    uint32_t w,h;size_t y_need,uv_need;
    if(!s || !s->y || !s->uv || !s->width || !s->height ||
       (s->width&1u) || (s->height&1u) || (x&1u) || (y&1u) ||
       !fps_hud_text_extent(text,&w,&h) || x>s->width || y>s->height ||
       w>s->width-x || h>s->height-y ||
       !fps_hud_plane_span(s->height,s->width,s->ys,&y_need) ||
       !fps_hud_plane_span(s->height/2u,s->width,s->uvs,&uv_need) ||
       y_need>s->y_span || uv_need>s->uv_span)return 0;
    char content[FPS_HUD_MAX_TEXT+1u];size_t length=0;
    do { content[length]=text[length]; } while(text[length++] && length<FPS_HUD_MAX_TEXT);
    content[FPS_HUD_MAX_TEXT]=0;
    uintptr_t ya=(uintptr_t)s->y,ua=(uintptr_t)s->uv;
    if(y_need>UINTPTR_MAX-ya || uv_need>UINTPTR_MAX-ua ||
       (ya<ua?ua-ya<y_need:ya-ua<uv_need))return 0;
    for(uint32_t yy=0;yy<h;yy++)for(uint32_t xx=0;xx<w;xx++)
        s->y[(size_t)(y+yy)*(size_t)s->ys+x+xx]=16;
    for(uint32_t yy=0;yy<h/2u;yy++)for(uint32_t xx=0;xx<w;xx++)
        s->uv[(size_t)(y/2u+yy)*(size_t)s->uvs+x+xx]=128;
    for(size_t i=0;content[i];i++) {
        const uint8_t *glyph=fps_hud_glyph((unsigned char)content[i]);
        uint32_t origin_x=x+FPS_HUD_PADDING+(uint32_t)i*6u*FPS_HUD_SCALE;
        for(unsigned row=0;row<7;row++)for(unsigned col=0;col<5;col++)if(glyph[row]&(1u<<(4u-col)))
            for(unsigned dy=0;dy<FPS_HUD_SCALE;dy++)for(unsigned dx=0;dx<FPS_HUD_SCALE;dx++)
                s->y[(size_t)(y+FPS_HUD_PADDING+row*FPS_HUD_SCALE+dy)*(size_t)s->ys+
                     origin_x+col*FPS_HUD_SCALE+dx]=235;
    }
    return 1;
}
#endif
