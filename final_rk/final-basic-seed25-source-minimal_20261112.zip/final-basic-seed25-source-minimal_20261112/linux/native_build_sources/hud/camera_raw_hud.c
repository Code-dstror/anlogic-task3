/* CAMERA_RAW derivative: one/two actual inputs, same-frame lane, FPS, recorder.
 * Scalar SOURCE metadata only; no DMA/native-receiver operations or teardown.
 */
#include <gst/gst.h>
#include <gst/video/video.h>
#include <gst/video/gstvideoaggregator.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include "fps_hud_core.h"

#define INPUTS 128u
#define OUTPUTS 512u
typedef struct { uint64_t pts,token,session,epoch,sequence,camera,jpeg_session,slot,generation,received; } Input;
typedef struct { uint64_t ordinal,pts,stamp,layout,revision; Input camera[2]; } Output;
typedef struct { uint16_t x,y; } LanePoint;
typedef struct { uint32_t count,label; LanePoint points[542]; } LaneCurve;
typedef struct { uint32_t count; LaneCurve curves[2]; } Lane;
typedef struct { Input identity; Lane lane; } Tagged;
typedef struct { Input camera[2]; uint64_t layout,revision; Lane lane; } Pair;
static unsigned camera_count=2;
static Lane input_lane[INPUTS];
static GMutex lock;
static GstElement *mix;
static GstPad *mix_pads[2];
static GQuark input_key,pair_key;
static GType registered_type;
static GstFlowReturn (*parent_aggregate)(GstVideoAggregator*,GstBuffer*);
static GstFlowReturn (*parent_frame_cycle)(GstAggregator*,gboolean);
static gboolean (*parent_src_event)(GstAggregator*,GstEvent*);
static Input input[2][INPUTS];
static Output output[OUTPUTS];
static struct fps_hud_counter fps[2];
static uint64_t tokens[2],decoded[2],registered[2],replaced[2],head,count,frames,error;
static uint64_t requested_layout,requested_revision,applied_layout,applied_revision,last_visible=3;
static uint64_t cycle_layout,cycle_revision;
static uint64_t frozen;
#define REALTIME_SLOT_LAG (50u*GST_MSECOND)
#define REALTIME_INPUT_AGE (500u*GST_MSECOND)
static uint64_t realtime_enabled,qos_updates,stale_drops,duplicate_drops;
static uint64_t preview_enabled,preview_threads,fast_mask,fast_updates;
static uint64_t input_period[2][INPUTS],duration_missing[2],duration_filled[2],duration_other[2];
static uint64_t duration_original[2]={GST_CLOCK_TIME_NONE,GST_CLOCK_TIME_NONE},duration_expected[2];
static uint64_t last_accepted,last_pts,last_lag,max_lag,last_age[2],last_new[2],new_inputs[2],last_token[2],last_mask;
static uint64_t now_ns(void) { struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000000000u+t.tv_nsec; }
static void fail(unsigned code) { g_mutex_lock(&lock);if(!error)error=code;g_mutex_unlock(&lock); }

/* Our deadline observation belongs to the output schedule. Do not propagate
 * it into either decoder and turn it into an uncounted input-frame discard. */
static GstPadProbeReturn local_qos(GstPad *pad,GstPadProbeInfo *info,gpointer unused) {
    (void)pad;(void)unused;GstEvent *event=GST_PAD_PROBE_INFO_EVENT(info);
    gboolean local=FALSE;const GstStructure *s=event?gst_event_get_structure(event):NULL;
    if(event && GST_EVENT_TYPE(event)==GST_EVENT_QOS && s &&
       gst_structure_get_boolean(s,"u4-output-deadline",&local) && local)return GST_PAD_PROBE_DROP;
    return GST_PAD_PROBE_OK;
}

static GstPadProbeReturn tag(GstPad *pad,GstPadProbeInfo *info,gpointer opaque) {
    (void)pad;unsigned camera=GPOINTER_TO_UINT(opaque);
    GstBuffer *b=GST_PAD_PROBE_INFO_BUFFER(info);Input selected={0};Tagged value={0};uint64_t period=0;
    if(!b || !GST_CLOCK_TIME_IS_VALID(GST_BUFFER_PTS(b)) || camera>=camera_count) { fail(1);return GST_PAD_PROBE_DROP; }
    g_mutex_lock(&lock);
    if(error) { g_mutex_unlock(&lock);return GST_PAD_PROBE_DROP; }
    for(unsigned i=0;i<INPUTS;i++)if(input[camera][i].token && input[camera][i].pts==GST_BUFFER_PTS(b)) {
        selected=input[camera][i];period=input_period[camera][i];if(camera==0)value.lane=input_lane[i];break;
    }
    if(!selected.token) { error=2;g_mutex_unlock(&lock);return GST_PAD_PROBE_DROP; }
    uint64_t original=GST_BUFFER_DURATION(b);
    if(preview_enabled) {
        if(!period) { error=13;g_mutex_unlock(&lock);return GST_PAD_PROBE_DROP; }
        duration_original[camera]=original;duration_expected[camera]=period;
        if(original==GST_CLOCK_TIME_NONE)duration_missing[camera]++;
        else if(original<period-1 || original>period+1)duration_other[camera]++;
    } else period=0;
    decoded[camera]++;g_mutex_unlock(&lock);
    if(period && original==GST_CLOCK_TIME_NONE) {
        /* The immutable period belongs to this exact SOURCE/PTS, including
         * SDR60/HDR30 transitions already queued in the decoder. COW only the
         * header before attaching Tagged; preserve video meta and lane data. */
        b=gst_buffer_make_writable(b);GST_PAD_PROBE_INFO_DATA(info)=b;
        if(!b) { fail(12);return GST_PAD_PROBE_DROP; }
        GST_BUFFER_DURATION(b)=period;
        g_mutex_lock(&lock);duration_filled[camera]++;g_mutex_unlock(&lock);
    }
    value.identity=selected;
    Tagged *copy=g_memdup2(&value,sizeof value);
    gst_mini_object_set_qdata(GST_MINI_OBJECT(b),input_key,copy,g_free);
    return GST_PAD_PROBE_OK;
}

static GstFlowReturn aggregate(GstVideoAggregator *vagg,GstBuffer *buffer) {
    Pair pair={0};
    if(GST_ELEMENT(vagg)!=mix || !buffer) { fail(3);return GST_FLOW_ERROR; }
    for(unsigned i=0;i<camera_count;i++) {
        GstBuffer *current=gst_video_aggregator_pad_get_current_buffer(GST_VIDEO_AGGREGATOR_PAD(mix_pads[i]));
        Input *selected=current?gst_mini_object_get_qdata(GST_MINI_OBJECT(current),input_key):NULL;
        if(selected) { pair.camera[i]=*selected;if(i==0)pair.lane=((Tagged*)selected)->lane; }
    }
    g_mutex_lock(&lock);
    if(error) { g_mutex_unlock(&lock);return GST_FLOW_ERROR; }
    pair.layout=cycle_layout;pair.revision=cycle_revision;
    g_mutex_unlock(&lock);
    GstFlowReturn flow=parent_aggregate(vagg,buffer);
    if(flow==GST_FLOW_OK)gst_mini_object_set_qdata(GST_MINI_OBJECT(buffer),pair_key,g_memdup2(&pair,sizeof pair),g_free);
    return flow;
}

static GstFlowReturn frame_cycle(GstAggregator *aggregator,gboolean timeout) {
    g_mutex_lock(&lock);
    gboolean changed=cycle_layout!=requested_layout || cycle_revision!=requested_revision;
    gboolean configure_fast=preview_enabled && (!fast_updates || cycle_layout!=requested_layout);
    cycle_layout=requested_layout;cycle_revision=requested_revision;g_mutex_unlock(&lock);
    /* GstVideoAggregator prepares/scales its selected inputs before calling
     * aggregate_frames. Apply layout at the outer aggregate entry, so both
     * preparation and pixels use this same captured revision. */
    for(unsigned i=0;changed && i<camera_count;i++) {
        gboolean both=cycle_layout==0,visible=both || cycle_layout==i+1;
        g_object_set(mix_pads[i],"xpos",both?(int)i*960:0,"ypos",both?270:0,
            "width",both?960:1920,"height",both?540:1080,"alpha",visible?1.0:0.0,NULL);
    }
    if(configure_fast) {
        /* Non-NULL converter-config forces conversion even for full-size
         * identical caps. Only dual SBS scales; mono/full retain NULL. */
        gboolean scale=camera_count==2 && cycle_layout==0;
        GstStructure *config=scale?gst_structure_new("GstVideoConverterConfig",
            GST_VIDEO_CONVERTER_OPT_RESAMPLER_METHOD,GST_TYPE_VIDEO_RESAMPLER_METHOD,GST_VIDEO_RESAMPLER_METHOD_LINEAR,
            GST_VIDEO_CONVERTER_OPT_THREADS,G_TYPE_UINT,(guint)preview_threads,NULL):NULL;
        for(unsigned i=0;i<camera_count;i++)g_object_set(mix_pads[i],"converter-config",config,NULL);
        if(config)gst_structure_free(config);
        g_mutex_lock(&lock);fast_mask=scale?3:0;fast_updates++;g_mutex_unlock(&lock);
    }
    if(realtime_enabled) {
        GstClock *clock=gst_element_get_clock(GST_ELEMENT(aggregator));
        GstClockTime base=gst_element_get_base_time(GST_ELEMENT(aggregator));
        GstClockTime current=clock?gst_clock_get_time(clock):GST_CLOCK_TIME_NONE;
        if(clock)gst_object_unref(clock);
        if(!GST_CLOCK_TIME_IS_VALID(current) || !GST_CLOCK_TIME_IS_VALID(base) || current<base) {
            fail(10);return GST_FLOW_ERROR;
        }
        GstClockTime running=current-base;
        GstClockTime earliest=running>REALTIME_SLOT_LAG?running-REALTIME_SLOT_LAG:0;
        GstEvent *event=gst_event_new_qos(GST_QOS_TYPE_UNDERFLOW,1.0,0,earliest);
        gst_structure_set(gst_event_writable_structure(event),"u4-output-deadline",G_TYPE_BOOLEAN,TRUE,NULL);
        /* GstVideoAggregator evaluates this BEFORE allocating/preparing the
         * next output. Missed slots advance without pixels or recorder ordinals.
         * No SOURCE or output PTS is rewritten. Parent consumes the event. */
        parent_src_event(aggregator,event);
        g_mutex_lock(&lock);qos_updates++;g_mutex_unlock(&lock);
    }
    return parent_frame_cycle(aggregator,timeout);
}

static void class_init(gpointer klass,gpointer data) {
    (void)data;GstVideoAggregatorClass *parent=g_type_class_peek_parent(klass);
    parent_aggregate=parent->aggregate_frames;
    parent_frame_cycle=GST_AGGREGATOR_CLASS(parent)->aggregate;
    parent_src_event=GST_AGGREGATOR_CLASS(parent)->src_event;
    ((GstVideoAggregatorClass*)klass)->aggregate_frames=aggregate;
    GST_AGGREGATOR_CLASS(klass)->aggregate=frame_cycle;
}

int u3_hud_register(void) {
    if(registered_type)return 1;
    GstElement *base=gst_element_factory_make("compositor",NULL);
    if(!base)return 0;
    GType parent=G_TYPE_FROM_INSTANCE(base);GTypeQuery query={0};g_type_query(parent,&query);gst_object_unref(base);
    if(query.class_size<sizeof(GstVideoAggregatorClass) || query.class_size>UINT16_MAX ||
            query.instance_size<sizeof(GstVideoAggregator) || query.instance_size>UINT16_MAX)return 0;
    GTypeInfo info={.class_size=(guint16)query.class_size,.class_init=class_init,.instance_size=(guint16)query.instance_size};
    GType type=g_type_register_static(parent,"CameraRawSelectedCompositor",&info,0);
    input_key=g_quark_from_static_string("u3-stereo-owned-input-v1");pair_key=g_quark_from_static_string("u3-stereo-selected-pair-v1");
    if(!type || !gst_element_register(NULL,"u3stereocompositor",0,type))return 0;
    registered_type=type;return 1;
}

static int plane(const GstVideoFrame *f,unsigned p,unsigned rows,size_t *span) {
    uintptr_t address=(uintptr_t)GST_VIDEO_FRAME_PLANE_DATA(f,p);int stride=GST_VIDEO_FRAME_PLANE_STRIDE(f,p);
    if(!address || stride<1920)return 0;
    size_t needed=(size_t)(rows-1)*(unsigned)stride+1920;
    for(unsigned i=0;i<GST_VIDEO_MAX_PLANES;i++) {
        uintptr_t start=(uintptr_t)f->map[i].data;size_t size=f->map[i].size;
        if(start && address>=start && address-start<=size && needed<=size-(address-start)) { *span=needed;return 1; }
    }
    return 0;
}

static void cr_lane_pixel(struct fps_hud_surface *s,int x,int y,unsigned label) {
    static const unsigned char color[3][3]={{210,16,146},{170,166,16},{220,16,166}};
    if(x<0 || y<0 || x>=1920 || y>=1080)return;
    s->y[(size_t)y*s->ys+x]=color[label][0];
    size_t at=(size_t)(y/2)*s->uvs+(unsigned)(x&~1);
    s->uv[at]=color[label][1];s->uv[at+1]=color[label][2];
}
static void cr_lane_dot(struct fps_hud_surface *s,int x,int y,unsigned label) {
    for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++)if(dx*dx+dy*dy<=4)cr_lane_pixel(s,x+dx,y+dy,label);
}
static void cr_draw_lane(struct fps_hud_surface *s,const Lane *lane) {
    for(unsigned c=0;c<lane->count;c++) {
        const LaneCurve *curve=&lane->curves[c];
        for(unsigned i=1;i<curve->count;i++) {
            int x=curve->points[i-1].x,y=curve->points[i-1].y,xx=curve->points[i].x,yy=curve->points[i].y;
            int dx=xx>x?xx-x:x-xx,sx=x<xx?1:-1,dy=yy>y?y-yy:yy-y,sy=y<yy?1:-1,err=dx+dy;
            for(;;) { cr_lane_dot(s,x,y,curve->label);if(x==xx && y==yy)break;
                int e=2*err;if(e>=dy){err+=dy;x+=sx;}if(e<=dx){err+=dx;y+=sy;}}
        }
    }
}

static GstPadProbeReturn draw(GstPad *pad,GstPadProbeInfo *probe,gpointer opaque) {
    g_mutex_lock(&lock);gboolean stopped=frozen!=0;g_mutex_unlock(&lock);
    if(stopped)return GST_PAD_PROBE_DROP;
    (void)opaque;GstBuffer *buffer=GST_PAD_PROBE_INFO_BUFFER(probe);
    Pair *selected=buffer?gst_mini_object_get_qdata(GST_MINI_OBJECT(buffer),pair_key):NULL;
    if(!selected) { fail(4);return GST_PAD_PROBE_DROP; }
    Pair pair=*selected;
    /* Never publish startup black or claim either camera progressed before
     * both real decoder inputs are available. Held inputs remain identifiable. */
    if(!pair.camera[0].token || (camera_count==2 && !pair.camera[1].token))return GST_PAD_PROBE_DROP;
    uint64_t stamp=now_ns(),visible=pair.layout==0?3:UINT64_C(1)<<(pair.layout-1);
    uint64_t age[2]={0,0};
    for(unsigned c=0;c<camera_count;c++) {
        if(stamp<pair.camera[c].received) { fail(11);return GST_PAD_PROBE_DROP; }
        age[c]=stamp-pair.camera[c].received;
    }
    g_mutex_lock(&lock);
    if(realtime_enabled) {
        for(unsigned c=0;c<2;c++)if((visible&(1u<<c)) && age[c]>REALTIME_INPUT_AGE) {
            stale_drops++;g_mutex_unlock(&lock);return GST_PAD_PROBE_DROP;
        }
        /* A repeated full-screen token adds no new picture. Discard before
         * the common tee, so KMS/encoder receive the same accepted sequence.
         * A layout/revision change must still publish its first real output. */
        unsigned c=pair.layout==2?1:0;
        if(pair.layout && applied_revision==pair.revision && applied_layout==pair.layout && last_token[c]==pair.camera[c].token) {
            duplicate_drops++;g_mutex_unlock(&lock);return GST_PAD_PROBE_DROP;
        }
    }
    g_mutex_unlock(&lock);
    GstVideoInfo vi;GstCaps *caps=gst_pad_get_current_caps(pad);
    gboolean valid=caps && gst_video_info_from_caps(&vi,caps);
    if(caps)gst_caps_unref(caps);
    if(!valid || GST_VIDEO_INFO_FORMAT(&vi)!=GST_VIDEO_FORMAT_NV12 ||
            GST_VIDEO_INFO_WIDTH(&vi)!=1920 || GST_VIDEO_INFO_HEIGHT(&vi)!=1080) { fail(5);return GST_PAD_PROBE_DROP; }
    buffer=gst_buffer_make_writable(buffer);GST_PAD_PROBE_INFO_DATA(probe)=buffer;
    GstVideoFrame frame;if(!buffer || !gst_video_frame_map(&frame,&vi,buffer,GST_MAP_WRITE)) { fail(6);return GST_PAD_PROBE_DROP; }
    size_t ys=0,uvs=0;valid=plane(&frame,0,1080,&ys)&&plane(&frame,1,540,&uvs);
    uintptr_t y=(uintptr_t)GST_VIDEO_FRAME_PLANE_DATA(&frame,0),uv=(uintptr_t)GST_VIDEO_FRAME_PLANE_DATA(&frame,1);
    if(!valid || !(y<uv?uv-y>=ys:y-uv>=uvs)) { gst_video_frame_unmap(&frame);fail(7);return GST_PAD_PROBE_DROP; }
    struct fps_hud_surface surface={GST_VIDEO_FRAME_PLANE_DATA(&frame,0),GST_VIDEO_FRAME_PLANE_DATA(&frame,1),
        GST_VIDEO_FRAME_PLANE_STRIDE(&frame,0),GST_VIDEO_FRAME_PLANE_STRIDE(&frame,1),1920,1080,ys,uvs};
    char text[48];
    if(camera_count==1)cr_draw_lane(&surface,&pair.lane);
    g_mutex_lock(&lock);
    if(frozen || error || count==OUTPUTS) { if(!frozen && !error)error=8;g_mutex_unlock(&lock);gst_video_frame_unmap(&frame);return GST_PAD_PROBE_DROP; }
    if(visible!=last_visible) { fps_hud_reset(&fps[0]);fps_hud_reset(&fps[1]);last_visible=visible; }
    for(unsigned c=0;c<2;c++)if(visible&(1u<<c)) {
        if(!fps_hud_observe(&fps[c],stamp,pair.camera[c].token,1) ||
           !fps_hud_format(text,sizeof text,c,&fps[c]) ||
           !fps_hud_draw(&surface,pair.layout==0?16+960*c:16,pair.layout==0?282:16,text))error=9;
    }
    if(!error) {
        Output *entry=&output[(head+count)%OUTPUTS];
        *entry=(Output){.ordinal=++frames,.pts=GST_BUFFER_PTS(buffer),.stamp=stamp,.layout=pair.layout,.revision=pair.revision,
                        .camera={pair.camera[0],pair.camera[1]}};
        count++;applied_layout=pair.layout;applied_revision=pair.revision;
        last_accepted=stamp;last_pts=GST_BUFFER_PTS(buffer);last_mask=visible;
        for(unsigned c=0;c<2;c++) {
            last_age[c]=age[c];
            if((visible&(1u<<c)) && last_token[c]!=pair.camera[c].token) {
                last_new[c]=stamp;new_inputs[c]++;last_token[c]=pair.camera[c].token;
            }
        }
        GstClock *clock=gst_element_get_clock(mix);GstClockTime base=gst_element_get_base_time(mix);
        GstClockTime current=clock?gst_clock_get_time(clock):GST_CLOCK_TIME_NONE;
        if(clock)gst_object_unref(clock);
        if(GST_CLOCK_TIME_IS_VALID(current) && GST_CLOCK_TIME_IS_VALID(base) && current>=base) {
            GstClockTime output_running=gst_segment_to_running_time(
                &GST_AGGREGATOR_PAD(GST_AGGREGATOR(mix)->srcpad)->segment,GST_FORMAT_TIME,last_pts);
            if(GST_CLOCK_TIME_IS_VALID(output_running)) {
                last_lag=current-base>output_running?current-base-output_running:0;
                if(last_lag>max_lag)max_lag=last_lag;
            }
        }
    }
    valid=error==0;g_mutex_unlock(&lock);gst_video_frame_unmap(&frame);
    return valid?GST_PAD_PROBE_OK:GST_PAD_PROBE_DROP;
}

int u3_hud_attach(void *pipeline) {
    if(mix || !input_key || !pair_key)return 0;
    mix=gst_bin_get_by_name(GST_BIN(pipeline),"stereo_mix");
    GstElement *final=gst_bin_get_by_name(GST_BIN(pipeline),"stereo_final");
    if(!mix || !final)return 0;
    for(unsigned i=0;i<camera_count;i++) {
        mix_pads[i]=gst_element_get_static_pad(mix,i?"sink_1":"sink_0");
        GstElement *decoded=gst_bin_get_by_name(GST_BIN(pipeline),i?"stereo_decoded1":"stereo_decoded0");
        GstPad *decoded_pad=decoded?gst_element_get_static_pad(decoded,"src"):NULL;
        if(!mix_pads[i] || !decoded_pad)return 0;
        if(preview_enabled) {
            GParamSpec *property=g_object_class_find_property(G_OBJECT_GET_CLASS(mix_pads[i]),"converter-config");
            if(!property || G_PARAM_SPEC_VALUE_TYPE(property)!=GST_TYPE_STRUCTURE ||
               !(property->flags&G_PARAM_READABLE) || !(property->flags&G_PARAM_WRITABLE))return 0;
        }
        /* Aggregator forwards directly to each peer, bypassing its own sink
         * pad event probe. Filter at the decoded identity before the decoder. */
        if(!gst_pad_add_probe(decoded_pad,GST_PAD_PROBE_TYPE_EVENT_UPSTREAM,local_qos,NULL,NULL))return 0;
        gulong id=gst_pad_add_probe(decoded_pad,GST_PAD_PROBE_TYPE_BUFFER,tag,GUINT_TO_POINTER(i),NULL);
        gst_object_unref(decoded_pad);gst_object_unref(decoded);
        if(!id)return 0;
    }
    GstPad *pad=gst_element_get_static_pad(final,"src");
    if(!pad)return 0;
    gulong probe=gst_pad_add_probe(pad,GST_PAD_PROBE_TYPE_BUFFER,draw,NULL,NULL);gst_object_unref(pad);gst_object_unref(final);
    return probe!=0;
}

int u3_hud_input(const uint64_t *values) {
    if(!values || values[5]>=camera_count || !values[0] || !values[2] || !values[8] || !values[9])return 0;
    unsigned c=(unsigned)values[5];g_mutex_lock(&lock);
    if(error || tokens[c]==UINT64_MAX) { g_mutex_unlock(&lock);return 0; }
    Input *entry=&input[c][tokens[c]%INPUTS];if(entry->token)replaced[c]++;
    input_period[c][tokens[c]%INPUTS]=0;
    if(c==0)memset(&input_lane[tokens[c]%INPUTS],0,sizeof(Lane));
    memcpy(entry,values,sizeof *entry);entry->token=++tokens[c];registered[c]++;
    g_mutex_unlock(&lock);return 1;
}

int u3_hud_layout(unsigned layout,uint64_t revision) {
    if(layout>2 || !revision || (camera_count==1 && layout!=1))return 0;g_mutex_lock(&lock);
    if(error || revision<=requested_revision) { g_mutex_unlock(&lock);return 0; }
    requested_layout=layout;requested_revision=revision;g_mutex_unlock(&lock);return 1;
}

/* Only the recorder consumes this ring, matching its common ordinal/PTS.
 * Do not discard or substitute an output if an association is missing. */
int u3_hud_take(uint64_t ordinal,uint64_t pts,Output *out) {
    if(!out)return 0;g_mutex_lock(&lock);
    if(error || !count || output[head].ordinal!=ordinal || output[head].pts!=pts) { g_mutex_unlock(&lock);return 0; }
    *out=output[head];head=(head+1)%OUTPUTS;count--;g_mutex_unlock(&lock);return 1;
}

int u3_hud_stats(uint64_t *out) {
    if(!out)return 0;g_mutex_lock(&lock);
    uint64_t values[]={1,error,frames,count,registered[0],registered[1],decoded[0],decoded[1],
        fps[0].total,fps[1].total,fps[0].valid,fps[1].valid,fps[0].fps_tenths,fps[1].fps_tenths,
        applied_layout,applied_revision,replaced[0],replaced[1]};
    memcpy(out,values,sizeof values);g_mutex_unlock(&lock);return 1;
}

int u3_hud_freeze(void) { g_mutex_lock(&lock);frozen=1;g_mutex_unlock(&lock);return 1; }

/* Opt-in only. Existing R3 deliveries retain their original timing behavior. */
int u3_hud_realtime_configure(void) {
    g_mutex_lock(&lock);
    if(mix || frames || registered[0] || registered[1] || realtime_enabled) { g_mutex_unlock(&lock);return 0; }
    realtime_enabled=1;g_mutex_unlock(&lock);return 1;
}

/* Separate ABI: never enlarge the original 18-u64 stats caller's buffer. */
int u3_hud_realtime_stats(uint64_t *out,unsigned length) {
    if(!out || length!=18)return 0;g_mutex_lock(&lock);
    uint64_t values[]={1,realtime_enabled,qos_updates,stale_drops,duplicate_drops,
        last_accepted,last_pts,last_lag,max_lag,last_age[0],last_age[1],last_new[0],last_new[1],
        last_mask,new_inputs[0],new_inputs[1],REALTIME_SLOT_LAG,REALTIME_INPUT_AGE};
    memcpy(out,values,sizeof values);g_mutex_unlock(&lock);return 1;
}

/* Configure one cold topology before any input or graph attachment. */
int cr_hud_topology(unsigned cameras) {
    g_mutex_lock(&lock);
    if((cameras!=1 && cameras!=2) || mix || registered[0] || registered[1] || preview_enabled) { g_mutex_unlock(&lock);return 0; }
    camera_count=cameras;g_mutex_unlock(&lock);return 1;
}
/* Register immutable current-frame polylines before pushing that exact PTS. */
int cr_hud_lane(uint64_t pts,const void *packed,unsigned bytes,unsigned count) {
    if(camera_count!=1 || !packed || bytes!=sizeof(LaneCurve)*2 || count>2)return 0;
    const LaneCurve *curves=packed;
    for(unsigned c=0;c<count;c++) {
        if(curves[c].count<2 || curves[c].count>542 || curves[c].label>2)return 0;
        for(unsigned i=0;i<curves[c].count;i++)if(curves[c].points[i].x>=1920 || curves[c].points[i].y>=1080 ||
            (i && curves[c].points[i].y<=curves[c].points[i-1].y))return 0;
    }
    g_mutex_lock(&lock);
    for(unsigned i=0;i<INPUTS;i++)if(input[0][i].token && input[0][i].pts==pts) {
        input_lane[i].count=count;memcpy(input_lane[i].curves,curves,bytes);g_mutex_unlock(&lock);return 1;
    }
    g_mutex_unlock(&lock);return 0;
}

/* CAMERA_RAW-only combined opt-in, once after topology and before attach/input.
 * Existing configurations omit it and preserve the original behavior/ABIs. */
int cr_hud_preview_policy(unsigned threads) {
    if(threads!=2)return 0;g_mutex_lock(&lock);
    if(mix || frames || registered[0] || registered[1] || preview_enabled) { g_mutex_unlock(&lock);return 0; }
    preview_enabled=1;preview_threads=threads;g_mutex_unlock(&lock);return 1;
}

/* Register after u3_hud_input and before push. Never mutate a queued input's
 * expected interval based on a later requested or applied mode. */
int cr_hud_frame_duration(unsigned camera,uint64_t pts,uint64_t period) {
    g_mutex_lock(&lock);
    if(!preview_enabled || error || camera>=camera_count || !pts ||
       (period!=GST_SECOND/30 && !(camera_count==1 && period==GST_SECOND/60))) { g_mutex_unlock(&lock);return 0; }
    for(unsigned i=0;i<INPUTS;i++)if(input[camera][i].token && input[camera][i].pts==pts) {
        if(input_period[camera][i]) { g_mutex_unlock(&lock);return 0; }
        input_period[camera][i]=period;g_mutex_unlock(&lock);return 1;
    }
    g_mutex_unlock(&lock);return 0;
}

/* Same independent six-u64 scaler ABI as R5; never enlarge original arrays. */
int u3_hud_fast_stats(uint64_t *out,unsigned length) {
    if(!out || length!=6)return 0;g_mutex_lock(&lock);
    uint64_t values[]={1,preview_enabled,preview_threads,fast_mask,fast_updates,GST_VIDEO_RESAMPLER_METHOD_LINEAR};
    memcpy(out,values,sizeof values);g_mutex_unlock(&lock);return 1;
}

int cr_hud_duration_stats(uint64_t *out,unsigned length) {
    if(!out || length!=12)return 0;g_mutex_lock(&lock);
    uint64_t values[]={1,preview_enabled,duration_missing[0],duration_missing[1],duration_filled[0],duration_filled[1],
        duration_other[0],duration_other[1],duration_original[0],duration_original[1],duration_expected[0],duration_expected[1]};
    memcpy(out,values,sizeof values);g_mutex_unlock(&lock);return 1;
}

/* Display-only retirement for a normal, sealed JPEG session. The caller has
 * joined its recorder and completed GST_STATE_NULL; never called on faults.
 * No Receiver, DMA mapping, kernel lease or FPGA register is accessed here. */
int cr_hud_retire(void *pipeline) {
    GstState state,pending;
    if(!pipeline || !mix || !gst_object_has_as_ancestor(GST_OBJECT(mix),GST_OBJECT(pipeline)) ||
       gst_element_get_state(GST_ELEMENT(pipeline),&state,&pending,0)!=GST_STATE_CHANGE_SUCCESS ||
       state!=GST_STATE_NULL || pending!=GST_STATE_VOID_PENDING)return 0;
    g_mutex_lock(&lock);
    if(!frozen || error || count) { g_mutex_unlock(&lock);return 0; }
    for(unsigned i=0;i<2;i++) { if(mix_pads[i])gst_object_unref(mix_pads[i]);mix_pads[i]=NULL; }
    gst_object_unref(mix);mix=NULL;
    memset(input,0,sizeof input);memset(output,0,sizeof output);memset(input_lane,0,sizeof input_lane);
    memset(input_period,0,sizeof input_period);memset(fps,0,sizeof fps);
    memset(tokens,0,sizeof tokens);memset(decoded,0,sizeof decoded);memset(registered,0,sizeof registered);
    memset(replaced,0,sizeof replaced);memset(duration_missing,0,sizeof duration_missing);
    memset(duration_filled,0,sizeof duration_filled);memset(duration_other,0,sizeof duration_other);
    memset(duration_expected,0,sizeof duration_expected);memset(last_age,0,sizeof last_age);
    memset(last_new,0,sizeof last_new);memset(new_inputs,0,sizeof new_inputs);memset(last_token,0,sizeof last_token);
    duration_original[0]=duration_original[1]=GST_CLOCK_TIME_NONE;
    head=count=frames=error=requested_layout=requested_revision=applied_layout=applied_revision=0;
    cycle_layout=cycle_revision=frozen=realtime_enabled=qos_updates=stale_drops=duplicate_drops=0;
    preview_enabled=preview_threads=fast_mask=fast_updates=0;
    last_accepted=last_pts=last_lag=max_lag=last_mask=0;last_visible=3;camera_count=2;
    g_mutex_unlock(&lock);return 1;
}
