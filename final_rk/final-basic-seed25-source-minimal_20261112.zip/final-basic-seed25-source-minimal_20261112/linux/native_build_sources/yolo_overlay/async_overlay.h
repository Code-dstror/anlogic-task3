#ifndef Y26_ASYNC_OVERLAY_H
#define Y26_ASYNC_OVERLAY_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

#define Y26_ASYNC_ABI_VERSION 1u
#define Y26_ASYNC_CONTEXT_BYTES 92u
#define Y26_ASYNC_BOX_BYTES 68u
#define Y26_ASYNC_STATS_BYTES 160u
#define Y26_ASYNC_DMA_STATS_BYTES 32u
#define Y26_ASYNC_FRAME_CAPACITY 64u
#define Y26_ASYNC_BOX_CAPACITY 300u
#define Y26_ASYNC_DEFAULT_MAX_AGE_NS UINT64_C(500000000)

typedef struct {
    uint32_t session, epoch, camera, kind, format, role, cohort_len;
    char cohort[64]; /* 1..64 printable ASCII bytes; length is authoritative */
} Y26AsyncContext;

typedef struct {
    int32_t x1, y1, x2, y2, level; /* level=-3..2, source1080p bounds */
    char label[48]; /* printable ASCII, NUL terminated, <=47 bytes */
} Y26AsyncBox;

typedef struct {
    uint64_t abi_version, frames_seen, overlay_frames, passthrough_frames;
    uint64_t map_failures, unsupported_frames, lock_misses, metadata_overwrites;
    uint64_t frame_misses, result_updates, result_rejects, expired_frames;
    uint64_t context_resets, table_size, enabled, generation, result_sequence;
    uint64_t result_count, copied_bytes, draw_ns_total;
} Y26AsyncStats;

typedef struct {
    uint64_t sync_starts, sync_ends, sync_failures, dmabuf_frames;
} Y26AsyncDmaStats;

/* Call after gst_init. Factory name is y26asyncoverlay, NV12 1920x1080 only.
 * get_handle accepts a GstElement*. Caller keeps an element reference until
 * every API call/streaming operation has ceased. Returned handle is borrowed.
 * No function opens a device, starts inference, or configures FPGA/KMS.
 */
int y26_async_register_element(void);
void *y26_async_get_handle(void *element);
int y26_async_enable(void *handle, int enabled, const Y26AsyncContext *context,
                     uint64_t generation, uint64_t max_age_ns);
int y26_async_register_frame(void *handle, uint64_t pts,
                             const Y26AsyncContext *context, uint32_t source_sequence);
int y26_async_update_latest(void *handle, uint64_t generation,
                            const Y26AsyncContext *context, uint32_t source_sequence,
                            uint64_t original_received_ns, const Y26AsyncBox *boxes,
                            uint32_t count);
int y26_async_clear(void *handle, uint64_t generation);
int y26_async_stats(void *handle, Y26AsyncStats *stats);
int y26_async_dma_stats(void *handle, Y26AsyncDmaStats *stats);

/* Return1 accepted,0 invalid/stale. enable(on) requires positive generation.
 * enable/clear reject generation<current. enable(off) removes ON indicator
 * and results. clear removes results only and preserves current ON status.
 * register_frame is called before pushing that exact PTS, and never waits on
 * AI. A new video context invalidates previous-context results immediately.
 * Result sequence may lag video sequence: it must be <= the current frame.
 * Expiry removes only boxes; the independent AI ON indicator remains.
 * Streaming metadata contention, unsupported caps/layout or mapping failure
 * returns a reference to the original unchanged input buffer with FLOW_OK.
 */

#ifdef __cplusplus
}
#endif
#endif
