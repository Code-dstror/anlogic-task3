#include "async_overlay.h"
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>
#include <gst/allocators/gstdmabuf.h>
#include <linux/dma-buf.h>
#include <sys/ioctl.h>
#include <cerrno>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <mutex>
#include <new>
#include <time.h>

static_assert(sizeof(Y26AsyncContext) == Y26_ASYNC_CONTEXT_BYTES, "context ABI");
static_assert(sizeof(Y26AsyncBox) == Y26_ASYNC_BOX_BYTES, "box ABI");
static_assert(sizeof(Y26AsyncStats) == Y26_ASYNC_STATS_BYTES, "stats ABI");
static_assert(sizeof(Y26AsyncDmaStats) == Y26_ASYNC_DMA_STATS_BYTES, "DMA stats ABI");

namespace {
constexpr unsigned W = 1920, H = 1080;
constexpr size_t COMPACT_BYTES = W * H * 3 / 2;
uint64_t monotonic_ns() {
    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return uint64_t(ts.tv_sec) * 1000000000 + ts.tv_nsec;
}
bool valid_context(const Y26AsyncContext *c) {
    if (!c || !c->session || !c->epoch || !c->cohort_len || c->cohort_len > 64) return false;
    for (unsigned i = 0; i < c->cohort_len; ++i)
        if (static_cast<unsigned char>(c->cohort[i]) < 33 || static_cast<unsigned char>(c->cohort[i]) > 126) return false;
    return true;
}
bool same(const Y26AsyncContext& a, const Y26AsyncContext& b) {
    return a.session == b.session && a.epoch == b.epoch && a.camera == b.camera &&
        a.kind == b.kind && a.format == b.format && a.role == b.role &&
        a.cohort_len == b.cohort_len && !memcmp(a.cohort, b.cohort, a.cohort_len);
}
bool valid_box(const Y26AsyncBox& b) {
    if (b.x1 < 0 || b.y1 < 0 || b.x2 <= b.x1 || b.y2 <= b.y1 || b.x2 > int(W) || b.y2 > int(H) || b.level < -3 || b.level > 2) return false;
    for (unsigned i = 0; i < sizeof b.label; ++i) {
        unsigned c = static_cast<unsigned char>(b.label[i]);
        if (!c) return true;
        if (c < 32 || c > 126) return false;
    }
    return false;
}
struct FrameEntry {
    bool used = false;
    uint64_t pts = 0, generation = 0;
    uint32_t sequence = 0;
    Y26AsyncContext context{};
};
struct Counters {
    std::atomic<uint64_t> frames{0}, overlays{0}, passes{0}, map_failures{0}, unsupported{0};
    std::atomic<uint64_t> lock_misses{0}, overwrites{0}, frame_misses{0}, updates{0}, rejects{0};
    std::atomic<uint64_t> expired{0}, resets{0}, bytes{0}, draw_ns{0};
    std::atomic<uint64_t> sync_starts{0}, sync_ends{0}, sync_failures{0}, dmabuf_frames{0};
};
#ifdef Y26_ASYNC_TESTING
std::atomic<int> test_dma_ioctl_mode{0}; // host fixtures only; absent in production
std::atomic<uint64_t> test_copies_created{0}, test_copies_finalized{0};
void test_copy_finalized(gpointer, GstMiniObject *) { test_copies_finalized.fetch_add(1); }
#endif
int dma_sync_ioctl(int fd, uint64_t flags) {
#ifdef Y26_ASYNC_TESTING
    const int mode = test_dma_ioctl_mode.load();
    if (mode == 1) return 0;
    if (mode == 2) return flags & DMA_BUF_SYNC_END ? -1 : 0;
#endif
    dma_buf_sync sync{}; sync.flags = flags;
    int rc;
    do { rc = ioctl(fd, DMA_BUF_IOCTL_SYNC, &sync); } while (rc < 0 && errno == EINTR);
    return rc;
}
struct DmaReadGuard {
    Counters& stats;
    std::array<int, 64> fds{};
    unsigned count = 0;
    bool saw_dma = false;
    explicit DmaReadGuard(Counters& s): stats(s) {}
    bool finish() {
        bool ok = true;
        while (count) {
            const int fd = fds[--count]; // no destructor retry on unknown END
            if (dma_sync_ioctl(fd, DMA_BUF_SYNC_END | DMA_BUF_SYNC_READ) < 0) {
                stats.sync_failures.fetch_add(1); ok = false;
            } else stats.sync_ends.fetch_add(1);
        }
        return ok;
    }
    bool start(GstBuffer *buffer) {
        for (unsigned i = 0; i < gst_buffer_n_memory(buffer); ++i) {
            GstMemory *memory = gst_buffer_peek_memory(buffer, i);
            if (!gst_is_dmabuf_memory(memory)) continue;
            if (!saw_dma) { saw_dma = true; stats.dmabuf_frames.fetch_add(1); }
            const int fd = gst_dmabuf_memory_get_fd(memory); // borrowed; never close
            if (std::find(fds.begin(), fds.begin() + count, fd) != fds.begin() + count) continue;
            if (fd < 0 || count == fds.size() || dma_sync_ioctl(fd, DMA_BUF_SYNC_START | DMA_BUF_SYNC_READ) < 0) {
                stats.sync_failures.fetch_add(1); finish(); return false;
            }
            fds[count++] = fd; stats.sync_starts.fetch_add(1);
        }
        return true;
    }
    ~DmaReadGuard() { finish(); }
};
struct State {
    std::mutex mutex;
    Counters stats;
    bool enabled = false, context_valid = false, result_valid = false;
    bool have_result_sequence = false;
    uint64_t generation = 0, revision = 0, max_age = Y26_ASYNC_DEFAULT_MAX_AGE_NS, received = 0;
    uint32_t result_sequence = 0, count = 0;
    Y26AsyncContext context{};
    std::array<Y26AsyncBox, Y26_ASYNC_BOX_CAPACITY> boxes{};
    std::array<FrameEntry, Y26_ASYNC_FRAME_CAPACITY> frames{};
    unsigned next = 0, table_size = 0;
    GstVideoInfo info{}; // caps and prepare are serialized by GstBaseTransform
    bool supported_caps = false;
#ifdef Y26_ASYNC_TESTING
    std::atomic<bool> cancel_before_commit{false};
#endif
    void clear_frames() {
        for (auto& f : frames) f.used = false;
        table_size = next = 0;
    }
    void clear_result() { result_valid = false; count = 0; }
    void change_context(const Y26AsyncContext& c) {
        if (context_valid && !same(context, c)) stats.resets.fetch_add(1);
        context = c; context_valid = true;
        clear_frames(); clear_result(); have_result_sequence = false; ++revision;
    }
};
struct Selection {
    uint64_t generation = 0, revision = 0, received = 0, max_age = 0;
    Y26AsyncContext context{};
    uint32_t count = 0;
    std::array<Y26AsyncBox, Y26_ASYNC_BOX_CAPACITY> boxes{};
};
}

typedef struct _Y26AsyncOverlay { GstBaseTransform parent; State *state; } Y26AsyncOverlay;
typedef struct _Y26AsyncOverlayClass { GstBaseTransformClass parent; } Y26AsyncOverlayClass;
G_DEFINE_TYPE(Y26AsyncOverlay, y26_async_overlay, GST_TYPE_BASE_TRANSFORM)

static State *get_state(void *handle) {
    if (!handle || !G_TYPE_CHECK_INSTANCE_TYPE(static_cast<GTypeInstance*>(handle), y26_async_overlay_get_type())) return nullptr;
    return reinterpret_cast<Y26AsyncOverlay*>(handle)->state;
}
static gboolean set_caps(GstBaseTransform *base, GstCaps *input, GstCaps *) {
    auto s = reinterpret_cast<Y26AsyncOverlay*>(base)->state;
    gst_video_info_init(&s->info);
    s->supported_caps = gst_video_info_from_caps(&s->info, input) &&
        GST_VIDEO_INFO_FORMAT(&s->info) == GST_VIDEO_FORMAT_NV12 &&
        GST_VIDEO_INFO_WIDTH(&s->info) == int(W) && GST_VIDEO_INFO_HEIGHT(&s->info) == int(H);
    // A newly allocated compact system-memory buffer must not masquerade as
    // memory:DMABuf or AFBC. Mappable MPP memory under ordinary raw caps works.
    if (gst_caps_get_size(input)) {
        const auto features = gst_caps_get_features(input, 0);
        const auto structure = gst_caps_get_structure(input, 0);
        gint afbc = 0;
        if (gst_caps_features_is_any(features) ||
            !gst_caps_features_contains(features, GST_CAPS_FEATURE_MEMORY_SYSTEM_MEMORY) ||
            (gst_structure_has_field(structure, "arm-afbc") &&
             (!gst_structure_get_int(structure, "arm-afbc", &afbc) || afbc != 0))) s->supported_caps = false;
    }
    return TRUE; // unsupported input remains on the original video route
}
static bool plane_valid(const GstVideoFrame& frame, unsigned p, unsigned rows) {
    const auto data = static_cast<const unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&frame, p));
    const int stride = GST_VIDEO_FRAME_PLANE_STRIDE(&frame, p);
    if (!data || stride < int(W)) return false;
    const size_t span = size_t(rows - 1) * unsigned(stride) + W;
    const uintptr_t address = reinterpret_cast<uintptr_t>(data);
    for (unsigned i = 0; i < GST_VIDEO_MAX_PLANES; ++i) {
        const auto start = reinterpret_cast<uintptr_t>(frame.map[i].data);
        const size_t size = frame.map[i].size;
        if (start && address >= start && address - start <= size && span <= size - (address - start)) return true;
    }
    return false;
}
static bool usable_frame(const GstVideoFrame& f) {
    if (GST_VIDEO_FRAME_FORMAT(&f) != GST_VIDEO_FORMAT_NV12 || GST_VIDEO_FRAME_WIDTH(&f) != int(W) ||
        GST_VIDEO_FRAME_HEIGHT(&f) != int(H) || !plane_valid(f, 0, H) || !plane_valid(f, 1, H / 2)) return false;
    const uintptr_t y = reinterpret_cast<uintptr_t>(GST_VIDEO_FRAME_PLANE_DATA(&f, 0));
    const uintptr_t uv = reinterpret_cast<uintptr_t>(GST_VIDEO_FRAME_PLANE_DATA(&f, 1));
    const size_t ys = size_t(H - 1) * unsigned(GST_VIDEO_FRAME_PLANE_STRIDE(&f, 0)) + W;
    const size_t uvs = size_t(H / 2 - 1) * unsigned(GST_VIDEO_FRAME_PLANE_STRIDE(&f, 1)) + W;
    return y < uv ? uv - y >= ys : y - uv >= uvs;
}
static bool select_overlay(State& s, uint64_t pts, Selection& selected) {
    std::unique_lock<std::mutex> lock(s.mutex, std::try_to_lock);
    if (!lock.owns_lock()) { s.stats.lock_misses.fetch_add(1); return false; }
    if (!s.enabled || !s.context_valid) return false;
    FrameEntry frame{}; bool found = false;
    for (auto& f : s.frames) if (f.used && f.pts == pts) {
        frame = f; f.used = false; --s.table_size; found = true; break;
    }
    if (!found || frame.generation != s.generation || !same(frame.context, s.context)) {
        s.stats.frame_misses.fetch_add(1); return false;
    }
    selected.generation = s.generation; selected.revision = s.revision; selected.context = s.context;
    const uint64_t now = monotonic_ns();
    if (s.result_valid && (now < s.received || now - s.received >= s.max_age)) {
        s.clear_result(); s.stats.expired.fetch_add(1);
    }
    if (s.result_valid && s.result_sequence <= frame.sequence) {
        selected.count = s.count;
        selected.received = s.received; selected.max_age = s.max_age;
        std::copy_n(s.boxes.begin(), s.count, selected.boxes.begin());
    }
    return true; // enabled indicator is independent of result availability
}
struct Surface { unsigned char *y, *uv; int ys, uvs; };
static void pixel(Surface& s, int x, int y, int level) {
    if (x < 0 || x >= int(W) || y < 0 || y >= int(H)) return;
    unsigned char yy = 235, u = 128, v = 128;
    if (level == 2) { yy = 76; u = 85; v = 255; }
    else if (level == 1) { yy = 226; u = 0; v = 149; }
    else if (level == 0) { yy = 179; u = 171; v = 0; }
    s.y[size_t(y) * s.ys + x] = yy;
    const size_t offset = size_t(y / 2) * s.uvs + unsigned(x & ~1);
    s.uv[offset] = u; s.uv[offset + 1] = v;
}
static const unsigned char FONT[36][7] = {
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,30},
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
};
static void text(Surface& s, int x, int y, const char *label, int level) {
    for (unsigned n = 0; n < 47 && label[n]; ++n, x += 12) {
        unsigned c = static_cast<unsigned char>(label[n]);
        if (c >= 'a' && c <= 'z') c -= 'a' - 'A';
        for (unsigned row = 0; row < 7; ++row) {
            const unsigned bits = c >= '0' && c <= '9' ? FONT[c - '0'][row] :
                c >= 'A' && c <= 'Z' ? FONT[10 + c - 'A'][row] :
                c == '-' ? (row == 3 ? 31 : 0) : c == '.' ? (row == 6 ? 4 : 0) :
                c == ':' ? (row == 2 || row == 5 ? 4 : 0) : 0;
            for (unsigned col = 0; col < 5; ++col) if (bits & (1u << (4 - col)))
                for (int dy = 0; dy < 2; ++dy) for (int dx = 0; dx < 2; ++dx)
                    pixel(s, x + int(col) * 2 + dx, y + int(row) * 2 + dy, level);
        }
    }
}
static void draw(Surface& s, const Selection& selected) {
    text(s, 16, 56, "AI ON", -1);
    for (unsigned i = 0; i < selected.count; ++i) {
        const auto& b = selected.boxes[i];
        const int thickness = std::min({2, b.x2 - b.x1, b.y2 - b.y1});
        for (int t = 0; t < thickness; ++t) {
            for (int x = b.x1; x < b.x2; ++x) { pixel(s, x, b.y1 + t, b.level); pixel(s, x, b.y2 - 1 - t, b.level); }
            for (int y = b.y1; y < b.y2; ++y) { pixel(s, b.x1 + t, y, b.level); pixel(s, b.x2 - 1 - t, y, b.level); }
        }
        text(s, b.x1, b.y1 >= 16 ? b.y1 - 16 : b.y1 + 3, b.label, b.level);
    }
}

// Private scalar metadata from the exact, separately sealed CAMERA_RAW HUD.
// The AI element runs BEFORE stereo_final/HUD and preserves the selected Pair
// on its copied header. No second consumer touches the recorder output ring.
struct MonoInput { uint64_t pts,token,session,epoch,sequence,camera,jpeg_session,slot,generation,received; };
struct MonoPoint { uint16_t x,y; };
struct MonoCurve { uint32_t count,label; MonoPoint points[542]; };
struct MonoLane { uint32_t count; MonoCurve curves[2]; };
struct MonoPair { MonoInput camera[2]; uint64_t layout,revision; MonoLane lane; };
static_assert(sizeof(MonoInput)==80 && sizeof(MonoPair)==4536, "selected CAMERA_RAW Pair ABI");
static GQuark mono_pair_key() { return g_quark_from_static_string("u3-stereo-selected-pair-v1"); }
static void mono_register_selected(State& s, GstBuffer *buffer) {
    const auto p=static_cast<const MonoPair*>(gst_mini_object_get_qdata(GST_MINI_OBJECT(buffer),mono_pair_key()));
    if(!p || p->layout!=1 || !p->camera[0].token || p->camera[1].token || p->camera[0].camera ||
       p->camera[0].sequence>UINT32_MAX || GST_BUFFER_PTS(buffer)==GST_CLOCK_TIME_NONE)return;
    std::unique_lock<std::mutex> guard(s.mutex,std::try_to_lock);
    if(!guard.owns_lock()) { s.stats.lock_misses.fetch_add(1);return; }
    // kind/format/role are taken only from the enabled, validated plain-CAM0
    // context; epoch/session must match the actually composed output exactly.
    if(!s.enabled || !s.context_valid || s.context.camera || s.context.kind!=1 ||
       s.context.format!=1 || s.context.role || s.context.session!=p->camera[0].session ||
       s.context.epoch!=p->camera[0].epoch)return;
    for(auto& f:s.frames)if(f.used && f.pts==GST_BUFFER_PTS(buffer))return;
    auto& f=s.frames[s.next];
    if(f.used)s.stats.overwrites.fetch_add(1);else ++s.table_size;
    f.used=true;f.pts=GST_BUFFER_PTS(buffer);f.generation=s.generation;
    f.sequence=uint32_t(p->camera[0].sequence);f.context=s.context;
    s.next=(s.next+1)%s.frames.size();
}
static void mono_copy_selected(GstBuffer *to,GstBuffer *from) {
    const auto p=static_cast<const MonoPair*>(gst_mini_object_get_qdata(GST_MINI_OBJECT(from),mono_pair_key()));
    if(p)gst_mini_object_set_qdata(GST_MINI_OBJECT(to),mono_pair_key(),g_memdup2(p,sizeof(*p)),g_free);
}
extern "C" int y26_mono_selected_source_abi() { return 1; }

static GstFlowReturn prepare(GstBaseTransform *base, GstBuffer *input, GstBuffer **output) {
    auto s = reinterpret_cast<Y26AsyncOverlay*>(base)->state;
    s->stats.frames.fetch_add(1);
    auto passthrough = [&]() {
        // GstBaseTransform transfers its existing input reference when output
        // equals input; default_generate_output only unrefs input for a distinct
        // output. Adding a ref here leaks every passthrough DMA buffer.
        // Official 1.20.1 gstbasetransform.c: default_prepare_output_buffer and
        // default_generate_output (GStreamer/GStreamer release source).
        *output = input; s->stats.passes.fetch_add(1); return GST_FLOW_OK;
    };
    mono_register_selected(*s,input);
    Selection selected;
    if (!select_overlay(*s, GST_BUFFER_PTS(input), selected)) return passthrough();
    if (!s->supported_caps) { s->stats.unsupported.fetch_add(1); return passthrough(); }
    DmaReadGuard dma_read(s->stats);
    if (!dma_read.start(input)) { s->stats.map_failures.fetch_add(1); return passthrough(); }
    GstVideoFrame original{};
    if (!gst_video_frame_map(&original, &s->info, input, GST_MAP_READ)) {
        dma_read.finish();
        s->stats.map_failures.fetch_add(1); return passthrough();
    }
    if (!usable_frame(original)) {
        gst_video_frame_unmap(&original); dma_read.finish(); s->stats.map_failures.fetch_add(1); return passthrough();
    }
    GstBuffer *copy = gst_buffer_new_allocate(nullptr, COMPACT_BYTES, nullptr);
#ifdef Y26_ASYNC_TESTING
    if (copy) {
        test_copies_created.fetch_add(1);
        gst_mini_object_weak_ref(GST_MINI_OBJECT(copy), test_copy_finalized, nullptr);
    }
#endif
    GstVideoInfo compact{}; gst_video_info_set_format(&compact, GST_VIDEO_FORMAT_NV12, W, H);
    gsize offsets[GST_VIDEO_MAX_PLANES] = {0, W * H, 0, 0};
    gint strides[GST_VIDEO_MAX_PLANES] = {int(W), int(W), 0, 0};
    GstVideoFrame target{};
    bool mapped = false;
    bool good = copy && gst_buffer_add_video_meta_full(copy, GST_VIDEO_FRAME_FLAG_NONE,
        GST_VIDEO_FORMAT_NV12, W, H, 2, offsets, strides);
    if (good) { mapped = gst_video_frame_map(&target, &compact, copy, GST_MAP_WRITE); good = mapped; }
    if (good) good = gst_video_frame_copy(&target, &original);
    gst_video_frame_unmap(&original);
    if (!dma_read.finish()) good = false;
    if (!good) {
        if (mapped) gst_video_frame_unmap(&target);
        if (copy) gst_buffer_unref(copy);
        s->stats.map_failures.fetch_add(1); return passthrough();
    }
    const uint64_t begin = monotonic_ns();
    Surface surface{static_cast<unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&target, 0)),
        static_cast<unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&target, 1)),
        GST_VIDEO_FRAME_PLANE_STRIDE(&target, 0), GST_VIDEO_FRAME_PLANE_STRIDE(&target, 1)};
    draw(surface, selected);
    gst_video_frame_unmap(&target);
#ifdef Y26_ASYNC_TESTING
    // Deterministic real control call after drawing and before commit; absent
    // from production. Regression covers the discard-new-copy passthrough path.
    if (s->cancel_before_commit.exchange(false))
        y26_async_enable(base, 0, nullptr, selected.generation, 0);
#endif
    // A control change during map/copy/draw must invalidate the prepared copy.
    // Never wait for a control lock on the streaming path.
    std::unique_lock<std::mutex> guard(s->mutex, std::try_to_lock);
    if (!guard.owns_lock() || !s->enabled || s->generation != selected.generation ||
        s->revision != selected.revision || !same(s->context, selected.context) ||
        (selected.count && (monotonic_ns() < selected.received || monotonic_ns() - selected.received >= selected.max_age))) {
        if (!guard.owns_lock()) s->stats.lock_misses.fetch_add(1);
        gst_buffer_unref(copy); return passthrough();
    }
    // Preserve timing/flags only. Input VideoMeta has padded offsets/stride and
    // must never replace the newly attached compact output VideoMeta.
    gst_buffer_copy_into(copy, input, GstBufferCopyFlags(GST_BUFFER_COPY_FLAGS | GST_BUFFER_COPY_TIMESTAMPS), 0, -1);
    mono_copy_selected(copy,input);
    s->stats.overlays.fetch_add(1); s->stats.bytes.fetch_add(COMPACT_BYTES);
    s->stats.draw_ns.fetch_add(monotonic_ns() - begin);
    *output = copy;
    return GST_FLOW_OK;
}
static GstFlowReturn transform(GstBaseTransform *, GstBuffer *, GstBuffer *) { return GST_FLOW_OK; }
static gboolean copy_metadata(GstBaseTransform *, GstBuffer *, GstBuffer *) { return TRUE; }
static gboolean transform_meta(GstBaseTransform *, GstBuffer *, GstMeta *, GstBuffer *) { return FALSE; }
static void finalize(GObject *object) {
    delete reinterpret_cast<Y26AsyncOverlay*>(object)->state;
    G_OBJECT_CLASS(y26_async_overlay_parent_class)->finalize(object);
}
static void y26_async_overlay_class_init(Y26AsyncOverlayClass *klass) {
    auto element = GST_ELEMENT_CLASS(klass);
    gst_element_class_set_static_metadata(element, "Async latest AI NV12 overlay", "Filter/Video",
        "Nonblocking metadata and copy-before-draw; original video survives overlay failures", "Linux AI/application");
    static GstStaticPadTemplate sink = GST_STATIC_PAD_TEMPLATE("sink", GST_PAD_SINK, GST_PAD_ALWAYS, GST_STATIC_CAPS_ANY);
    static GstStaticPadTemplate src = GST_STATIC_PAD_TEMPLATE("src", GST_PAD_SRC, GST_PAD_ALWAYS, GST_STATIC_CAPS_ANY);
    gst_element_class_add_static_pad_template(element, &sink);
    gst_element_class_add_static_pad_template(element, &src);
    auto base = GST_BASE_TRANSFORM_CLASS(klass);
    base->set_caps = set_caps; base->prepare_output_buffer = prepare; base->transform = transform;
    base->copy_metadata = copy_metadata; base->transform_meta = transform_meta;
    base->passthrough_on_same_caps = FALSE;
    G_OBJECT_CLASS(klass)->finalize = finalize;
}
static void y26_async_overlay_init(Y26AsyncOverlay *self) {
    self->state = new State;
    gst_base_transform_set_in_place(GST_BASE_TRANSFORM(self), FALSE);
    gst_base_transform_set_passthrough(GST_BASE_TRANSFORM(self), FALSE);
}

extern "C" int y26_async_register_element() {
    static std::once_flag once;
    static bool registered = false;
    std::call_once(once, [] { registered = gst_element_register(nullptr, "y26asyncoverlay", GST_RANK_NONE, y26_async_overlay_get_type()); });
    return registered;
}
extern "C" void *y26_async_get_handle(void *element) { return get_state(element) ? element : nullptr; }
extern "C" int y26_async_enable(void *handle, int enabled, const Y26AsyncContext *context, uint64_t generation, uint64_t max_age_ns) {
    auto s = get_state(handle);
    if (!s || (enabled != 0 && enabled != 1) || (enabled && (!generation || !valid_context(context)))) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    if (generation < s->generation) return 0;
    const bool changed = generation != s->generation || bool(enabled) != s->enabled ||
        (enabled && (!s->context_valid || !same(*context, s->context)));
    if (changed) { s->clear_frames(); s->clear_result(); s->have_result_sequence = false; ++s->revision; }
    s->generation = generation; s->enabled = enabled;
    s->max_age = max_age_ns ? max_age_ns : Y26_ASYNC_DEFAULT_MAX_AGE_NS;
    if (enabled && (!s->context_valid || !same(*context, s->context))) s->change_context(*context);
    return 1;
}
extern "C" int y26_async_register_frame(void *handle, uint64_t pts, const Y26AsyncContext *context, uint32_t sequence) {
    auto s = get_state(handle);
    if (!s || pts == GST_CLOCK_TIME_NONE || !valid_context(context)) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    if (!s->enabled) return 1;
    if (!s->context_valid || !same(s->context, *context)) s->change_context(*context);
    for (auto& frame : s->frames) if (frame.used && frame.pts == pts) {
        return frame.sequence == sequence && frame.generation == s->generation && same(frame.context, *context);
    }
    auto& frame = s->frames[s->next];
    if (frame.used) s->stats.overwrites.fetch_add(1); else ++s->table_size;
    frame.used = true; frame.pts = pts; frame.generation = s->generation; frame.sequence = sequence; frame.context = *context;
    s->next = (s->next + 1) % s->frames.size();
    return 1;
}
extern "C" int y26_async_update_latest(void *handle, uint64_t generation, const Y26AsyncContext *context,
    uint32_t sequence, uint64_t received_ns, const Y26AsyncBox *boxes, uint32_t count) {
    auto s = get_state(handle);
    if (!s) return 0;
    auto reject = [&]() { s->stats.rejects.fetch_add(1); return 0; };
    if (!valid_context(context) || !received_ns || count > Y26_ASYNC_BOX_CAPACITY || (count && !boxes)) return reject();
    const uint64_t now = monotonic_ns();
    if (received_ns > now) return reject();
    for (unsigned i = 0; i < count; ++i) if (!valid_box(boxes[i])) return reject();
    std::lock_guard<std::mutex> lock(s->mutex);
    if (!s->enabled || generation != s->generation || !same(*context, s->context) ||
        (s->have_result_sequence && (sequence < s->result_sequence || received_ns < s->received))) return reject();
    // A normal async update may take effect on the next video frame. Empty
    // results must revoke already selected old boxes before they can commit.
    if (!count && s->count) ++s->revision;
    s->count = count; s->received = received_ns; s->result_sequence = sequence;
    s->have_result_sequence = s->result_valid = true;
    if (count) std::copy_n(boxes, count, s->boxes.begin());
    s->stats.updates.fetch_add(1);
    return 1;
}
extern "C" int y26_async_clear(void *handle, uint64_t generation) {
    auto s = get_state(handle); if (!s) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    if (generation < s->generation) return 0;
    if (generation != s->generation) { s->generation = generation; s->clear_frames(); s->have_result_sequence = false; }
    s->clear_result(); ++s->revision;
    return 1;
}
extern "C" int y26_async_stats(void *handle, Y26AsyncStats *out) {
    auto s = get_state(handle); if (!s || !out) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    *out = Y26AsyncStats{Y26_ASYNC_ABI_VERSION, s->stats.frames.load(), s->stats.overlays.load(), s->stats.passes.load(),
        s->stats.map_failures.load(), s->stats.unsupported.load(), s->stats.lock_misses.load(), s->stats.overwrites.load(),
        s->stats.frame_misses.load(), s->stats.updates.load(), s->stats.rejects.load(), s->stats.expired.load(),
        s->stats.resets.load(), s->table_size, uint64_t(s->enabled), s->generation, s->result_sequence,
        s->count, s->stats.bytes.load(), s->stats.draw_ns.load()};
    return 1;
}
extern "C" int y26_async_dma_stats(void *handle, Y26AsyncDmaStats *out) {
    auto s = get_state(handle); if (!s || !out) return 0;
    *out = Y26AsyncDmaStats{s->stats.sync_starts.load(), s->stats.sync_ends.load(),
        s->stats.sync_failures.load(), s->stats.dmabuf_frames.load()};
    return 1;
}

#ifdef Y26_ASYNC_TESTING
extern "C" int y26_async_test_nv12_format() { return GST_VIDEO_FORMAT_NV12; }
extern "C" void y26_async_test_dma_mode(int mode) { test_dma_ioctl_mode.store(mode); }
extern "C" void y26_async_test_set_pts(GstBuffer *buffer, uint64_t pts) { GST_BUFFER_PTS(buffer) = pts; }
extern "C" int y26_async_test_process(void *handle, GstBuffer *input, GstCaps *caps, GstBuffer **output) {
    auto self = static_cast<Y26AsyncOverlay*>(handle);
    set_caps(GST_BASE_TRANSFORM(self), caps, caps);
    const auto flow = prepare(GST_BASE_TRANSFORM(self), input, output);
    // This direct test helper borrows input from the test and returns a separate
    // owned output reference. Real GstBaseTransform itself transfers ownership.
    if (flow == GST_FLOW_OK && *output == input) gst_buffer_ref(*output);
    return flow;
}
extern "C" void y26_async_test_cancel_next(void *handle) {
    if (auto s = get_state(handle)) s->cancel_before_commit.store(true);
}
extern "C" void y26_async_test_copy_counts(uint64_t *created, uint64_t *finalized) {
    *created = test_copies_created.load(); *finalized = test_copies_finalized.load();
}
extern "C" int y26_async_test_lock(void *handle, int lock) {
    auto s = get_state(handle); if (!s) return 0;
    if (lock) s->mutex.lock(); else s->mutex.unlock(); return 1;
}
#endif
