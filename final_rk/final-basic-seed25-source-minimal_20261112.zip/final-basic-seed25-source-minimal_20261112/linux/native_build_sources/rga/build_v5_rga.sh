#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
output_dir="${1:?Usage: bash build_v5_rga.sh OUTPUT_DIRECTORY}"
rga_include_dir="${RGA_INCLUDE_DIR:-/usr/include/rga}"
compiler="${CXX:-c++}"
if [[ ! -f "$rga_include_dir/im2d.h" ]]; then
    printf 'RGA header missing: %s/im2d.h\n' "$rga_include_dir" >&2
    exit 1
fi

rga_link_flags=()
if [[ -n "${RGA_LIBRARY_DIR:-}" ]]; then
    rga_link_flags=(-L"$RGA_LIBRARY_DIR")
fi
mkdir -p -- "$output_dir"
"$compiler" -O3 -std=c++17 -fPIC -shared -ffp-contract=off -fno-fast-math \
    -I"$rga_include_dir" "$source_dir/prepared_rga_required.cpp" \
    -o "$output_dir/liby26_prepared_rgb2.so" "${rga_link_flags[@]}" -lrga
