// Sparse candidate-only RK experiment. Portable C++17; no image/GPU/NPU input.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <numeric>
#include <vector>

#ifdef _WIN32
#define API extern "C" __declspec(dllexport)
#else
#define API extern "C" __attribute__((visibility("default")))
#endif

struct Point { int x, y, strength, cls, width; };
struct Curve {
    int n, support, label, track_id;
    double y[6], x[6], tangent[6];
    double median_error, p90_error, score;
};
struct State { double score, velocity; int node, parent, length; };
struct Path { Curve curve{}; std::vector<int> indices; };
struct History {
    bool valid=false, pending=false;
    Curve curve{}, proposed{};
    double time=0, velocity=0, proposed_time=0;
    int confirmations=0;
};
struct Tracker {
    std::array<History,2> history{};
    bool initialized=false;
    uint32_t session=0, epoch=0, sequence=0;
    int camera=0;
    double time=0;
};

static double clamp(double x, double a, double b) { return std::max(a,std::min(b,x)); }
static double median(std::vector<double> v) {
    if(v.empty()) return 0;
    std::sort(v.begin(),v.end());
    return v[v.size()/2];
}
static void derivatives(Curve& c) {
    double h[5], d[5];
    for(int i=0;i<c.n-1;++i) { h[i]=c.y[i+1]-c.y[i]; d[i]=(c.x[i+1]-c.x[i])/h[i]; }
    if(c.n==2) { c.tangent[0]=c.tangent[1]=d[0]; return; }
    for(int i=1;i<c.n-1;++i) {
        if(d[i-1]*d[i]<=0) c.tangent[i]=0;
        else { double a=2*h[i]+h[i-1], b=h[i]+2*h[i-1]; c.tangent[i]=(a+b)/(a/d[i-1]+b/d[i]); }
    }
    auto endpoint=[](double a,double b,double da,double db) {
        double v=((2*a+b)*da-a*db)/(a+b);
        if(v*da<=0) return 0.;
        if(da*db<0 && std::abs(v)>3*std::abs(da)) return 3*da;
        return v;
    };
    c.tangent[0]=endpoint(h[0],h[1],d[0],d[1]);
    c.tangent[c.n-1]=endpoint(h[c.n-2],h[c.n-3],d[c.n-2],d[c.n-3]);
}
static double evaluate(const Curve& c,double y) {
    if(c.n<2 || y<c.y[0] || y>c.y[c.n-1]) return std::numeric_limits<double>::quiet_NaN();
    int i=0; while(i<c.n-2 && c.y[i+1]<y) ++i;
    double h=c.y[i+1]-c.y[i], t=(y-c.y[i])/h, t2=t*t, t3=t2*t;
    return (2*t3-3*t2+1)*c.x[i]+(t3-2*t2+t)*h*c.tangent[i]
         +(-2*t3+3*t2)*c.x[i+1]+(t3-t2)*h*c.tangent[i+1];
}
static double distance(const Curve& a,const Curve& b,double* signed_distance=nullptr) {
    double lo=std::max(a.y[0],b.y[0]), hi=std::min(a.y[a.n-1],b.y[b.n-1]);
    if(hi-lo<60) return 1e9;
    std::vector<double> errors, signed_errors;
    for(int i=0;i<5;++i) { double y=lo+(hi-lo)*i/4, d=evaluate(a,y)-evaluate(b,y); errors.push_back(std::abs(d)); signed_errors.push_back(d); }
    if(signed_distance) *signed_distance=median(signed_errors);
    return median(errors);
}
static void error_metrics(Curve& c,const std::vector<int>& indices,const Point* points) {
    std::vector<double> errors;
    for(int index:indices) errors.push_back(std::abs(evaluate(c,points[index].y)-points[index].x));
    std::sort(errors.begin(),errors.end());
    c.median_error=errors[errors.size()/2];
    c.p90_error=errors[std::min(errors.size()-1,errors.size()*9/10)];
}
static double local_estimate(double y,const std::vector<int>& path,const Point* points) {
    std::vector<int> order=path;
    std::stable_sort(order.begin(),order.end(),[&](int a,int b){return std::abs(points[a].y-y)<std::abs(points[b].y-y);});
    if(order.size()>11) order.resize(11);
    double intercept=points[order[0]].x, slope=0;
    for(int iteration=0;iteration<3;++iteration) {
        double sw=0,sy=0,sx=0,syy=0,syx=0;
        for(int index:order) {
            double dy=points[index].y-y, x=points[index].x;
            double weight=.7+.3*clamp(points[index].strength/400.,0,1);
            if(iteration) weight*=std::min(1.,6/std::max(1e-6,std::abs(x-intercept-slope*dy)));
            sw+=weight;sy+=weight*dy;sx+=weight*x;syy+=weight*dy*dy;syx+=weight*dy*x;
        }
        double determinant=sw*syy-sy*sy;
        if(determinant<1e-9) break;
        intercept=(sx*syy-sy*syx)/determinant;
        slope=(sw*syx-sy*sx)/determinant;
    }
    return intercept;
}
static bool fit_path(Path& path,const Point* points) {
    std::sort(path.indices.begin(),path.indices.end(),[&](int a,int b){return points[a].y<points[b].y;});
    auto& c=path.curve;
    int span=0;
    for(int iteration=0;iteration<2;++iteration) {
        span=points[path.indices.back()].y-points[path.indices.front()].y;
        double density=4.*path.indices.size()/(span+4);
        if(path.indices.size()<16 || span<96 || density<.35 || (span<140 && density<.65)) return false;
        c.n=std::min(6,std::max(3,span/70+1));c.support=static_cast<int>(path.indices.size());
        for(int k=0;k<c.n;++k) {
            int index=path.indices[(path.indices.size()-1)*k/(c.n-1)];
            c.y[k]=points[index].y;c.x[k]=local_estimate(c.y[k],path.indices,points);
        }
        derivatives(c);error_metrics(c,path.indices,points);
        if(iteration==0) {
            std::vector<int> filtered;
            for(int index:path.indices) if(std::abs(evaluate(c,points[index].y)-points[index].x)<=20) filtered.push_back(index);
            if(filtered.size()==path.indices.size()) break;
            if(filtered.size()<.8*path.indices.size()) return false;
            path.indices=std::move(filtered);
        }
    }
    double density=4.*c.support/(span+4);
    c.score=c.support+.03*span+8*density-c.p90_error;
    return c.median_error<=8 && c.p90_error<=16;
}
static std::vector<Path> extract_paths(const Point* points,int count) {
    std::vector<int> order(count);std::iota(order.begin(),order.end(),0);
    std::stable_sort(order.begin(),order.end(),[&](int a,int b){return points[a].y!=points[b].y?points[a].y>points[b].y:points[a].x<points[b].x;});
    std::vector<State> states;states.reserve(count*3);
    std::vector<std::vector<int>> ends(count);
    for(int i=0;i<count;++i) {
        const auto& current=points[order[i]];
        double reward=1+.1*clamp(current.strength/400.,0,1);
        std::vector<State> options{{reward,0,i,-1,1}};
        for(int j=i-1;j>=0;--j) {
            const auto& previous=points[order[j]];int dy=previous.y-current.y;
            if(dy>64) break;
            if(dy<=0) continue;
            double dx=current.x-previous.x;
            if(std::abs(dx)>6*dy+8) continue;
            for(int previous_state:ends[j]) {
                const auto& old=states[previous_state];double velocity=dx/dy, cost=0;
                if(old.length>1) {
                    double scale=5+.06*dy+.005*dy*dy;
                    double residual=dx-old.velocity*dy;
                    if(std::abs(residual)>std::max(14.,3*scale)) continue;
                    cost=.22*std::abs(residual)/scale;
                    velocity=.6*old.velocity+.4*velocity;
                }
                cost+=.12*(dy/4.-1);
                options.push_back({old.score+reward-cost,velocity,i,previous_state,old.length+1});
            }
        }
        std::stable_sort(options.begin(),options.end(),[](const State& a,const State& b){return a.score>b.score;});
        for(const auto& candidate:options) {
            bool duplicate=false;
            for(int other:ends[i]) if(candidate.parent==states[other].parent) duplicate=true;
            if(duplicate) continue;
            ends[i].push_back(static_cast<int>(states.size()));states.push_back(candidate);
            if(ends[i].size()==3) break;
        }
    }
    std::vector<int> ranking(states.size());std::iota(ranking.begin(),ranking.end(),0);
    std::stable_sort(ranking.begin(),ranking.end(),[&](int a,int b){return states[a].score>states[b].score;});
    std::vector<Path> paths;
    // At most303*3 states, six retained paths; reject duplicate prefixes before fit.
    for(int state:ranking) {
        if(states[state].length<16) continue;
        Path path;
        for(int s=state;s>=0;s=states[s].parent) path.indices.push_back(order[states[s].node]);
        int span=std::abs(points[path.indices.front()].y-points[path.indices.back()].y);
        double density=4.*path.indices.size()/(span+4);
        if(span<96 || density<.35 || (span<140 && density<.65)) continue;
        bool duplicate=false;
        for(const auto& old:paths) {
            int common=0;
            for(int a:path.indices) if(std::find(old.indices.begin(),old.indices.end(),a)!=old.indices.end()) ++common;
            if(common>.35*std::min(path.indices.size(),old.indices.size())) {duplicate=true;break;}
        }
        if(duplicate || !fit_path(path,points)) continue;
        for(const auto& old:paths) if(distance(path.curve,old.curve)<24) {duplicate=true;break;}
        if(duplicate) continue;
        paths.push_back(path);
        if(paths.size()==6) break;
    }
    return paths;
}
static bool valid_pair(const Path& a,const Path& b,int& left,int ai,int bi) {
    double lo=std::max(a.curve.y[0],b.curve.y[0]), hi=std::min(a.curve.y[a.curve.n-1],b.curve.y[b.curve.n-1]);
    if(hi-lo<80) return false;
    left=evaluate(a.curve,(lo+hi)/2)<evaluate(b.curve,(lo+hi)/2)?ai:bi;
    for(int i=0;i<=8;++i) {
        double y=lo+(hi-lo)*i/8;
        double gap=evaluate(b.curve,y)-evaluate(a.curve,y); if(left==bi) gap=-gap;
        if(gap<24 || gap>1850) return false;
    }
    if(std::abs(evaluate(b.curve,hi)-evaluate(a.curve,hi))<120) return false;
    int common=0;for(int aindex:a.indices) if(std::find(b.indices.begin(),b.indices.end(),aindex)!=b.indices.end()) ++common;
    return common<=.1*std::min(a.indices.size(),b.indices.size()) &&
           std::min(a.curve.support,b.curve.support)>=.30*std::max(a.curve.support,b.curve.support);
}
static double prior_penalty(const Curve& c,const History& h,double time) {
    if(!h.valid || time-h.time>.2) return 0;
    return std::min(30.,distance(c,h.curve)/3);
}
static bool update_history(History& h,Curve& c,double time,const std::vector<int>& indices,const Point* points) {
    if(!h.valid || time-h.time>.2) { h=History{};h.valid=true;h.curve=c;h.time=time;return true; }
    double signed_shift=0,d=distance(c,h.curve,&signed_shift),dt=time-h.time;
    double gate=40+450*dt;
    if(d>gate) {
        if(h.pending && time-h.proposed_time<.1 && distance(c,h.proposed)<40) ++h.confirmations;
        else h.confirmations=1;
        h.pending=true;h.proposed=c;h.proposed_time=time;
        if(h.confirmations<2) return false;
        h=History{};h.valid=true;h.curve=c;h.time=time;return true;
    }
    h.pending=false;h.confirmations=0;
    Curve measured=c;
    double alpha=clamp(.55+d/50,.55,.95);
    for(int i=0;i<c.n;++i) {
        double previous=evaluate(h.curve,c.y[i]);
        if(std::isfinite(previous)) {
            double prediction=previous+h.velocity*dt;
            c.x[i]+=(1-alpha)*clamp(prediction-c.x[i],-8,8);
        }
    }
    derivatives(c);error_metrics(c,indices,points);
    if(c.p90_error>16) c=measured;
    h.velocity=.6*h.velocity+.4*clamp(signed_shift/std::max(dt,.001),-1800,1800);
    h.curve=c;h.time=time;
    return true;
}

API void* lane_create() {return new Tracker;}
API void lane_destroy(void* handle) {delete static_cast<Tracker*>(handle);}
API double lane_evaluate(const Curve* curve,double y) {return evaluate(*curve,y);}
API int lane_process(void* handle,const Point* points,int count,uint32_t session,uint32_t epoch,
                     uint32_t sequence,int camera,double time,Curve* output,int* assignments,int* path_count) {
    if(!handle || count<0 || count>303 || !std::isfinite(time)) return -1;
    for(int i=0;i<count;++i) {
        if(points[i].x<0 || points[i].x>=1920 || points[i].y<676 || points[i].y>1076 ||
           points[i].y%4 || (points[i].cls!=1 && points[i].cls!=2)) return -2;
        assignments[i]=0;
    }
    Tracker& t=*static_cast<Tracker*>(handle);
    if(t.initialized && (session!=t.session || epoch!=t.epoch || camera!=t.camera || sequence<=t.sequence || time<=t.time || time-t.time>.2)) t=Tracker{};
    t.initialized=true;t.session=session;t.epoch=epoch;t.sequence=sequence;t.camera=camera;t.time=time;
    *path_count=0;
    if(count<16) return 0; // Never publish a historical-only curve.
    auto paths=extract_paths(points,count);*path_count=static_cast<int>(paths.size());
    if(paths.empty()) return 0;
    int selected[2]={-1,-1};double best=-1e9;
    for(size_t i=0;i<paths.size();++i) for(size_t j=i+1;j<paths.size();++j) {
        int left=-1;if(!valid_pair(paths[i],paths[j],left,i,j)) continue;
        int right=left==static_cast<int>(i)?j:i;
        double score=paths[left].curve.score+paths[right].curve.score-
            prior_penalty(paths[left].curve,t.history[0],time)-prior_penalty(paths[right].curve,t.history[1],time);
        if(score>best) {best=score;selected[0]=left;selected[1]=right;}
    }
    int single=0;double single_score=-1e9;
    for(size_t i=0;i<paths.size();++i) {
        double penalty=std::min(prior_penalty(paths[i].curve,t.history[0],time),prior_penalty(paths[i].curve,t.history[1],time));
        double score=paths[i].curve.score-penalty;
        if(score>single_score) {single=i;single_score=score;}
    }
    if(selected[0]<0 || best<1.25*single_score) {
        selected[0]=single;selected[1]=-1;
    }
    int output_count=0;
    for(int position=0;position<2;++position) {
        int index=selected[position];if(index<0) continue;
        Curve curve=paths[index].curve;
        int label=position;
        if(selected[1]<0) {
            double a=t.history[0].valid && time-t.history[0].time<=.2?distance(curve,t.history[0].curve):1e9;
            double b=t.history[1].valid && time-t.history[1].time<=.2?distance(curve,t.history[1].curve):1e9;
            label=std::min(a,b)<100?(a<=b?0:1):2;
        }
        curve.label=label;curve.track_id=label;
        if(label<2 && !update_history(t.history[label],curve,time,paths[index].indices,points)) continue;
        for(int point:paths[index].indices) assignments[point]=label+1;
        output[output_count++]=curve;
    }
    // Bounded smoothing cannot introduce an invalid pair into the display.
    if(output_count==2) {
        double lo=std::max(output[0].y[0],output[1].y[0]);
        double hi=std::min(output[0].y[output[0].n-1],output[1].y[output[1].n-1]);
        bool crossed=false;
        for(int i=0;i<=8;++i) if(evaluate(output[1],lo+(hi-lo)*i/8)-evaluate(output[0],lo+(hi-lo)*i/8)<20) crossed=true;
        if(crossed) {
            for(int i=0;i<2;++i) { Curve raw=paths[selected[i]].curve;raw.label=i;raw.track_id=i;output[i]=raw;t.history[i].curve=raw; }
        }
    }
    // A lone observed boundary is displayed as single, even when an internal
    // association exists. Do not present an unpaired observation as two sides.
    if(output_count==1) {
        output[0].label=2;
        for(int i=0;i<count;++i) if(assignments[i]) assignments[i]=3;
    }
    return output_count;
}
