#define _POSIX_C_SOURCE 200809L
#define MODULE_TAG "dehaze_private_mpp"
#include "dehaze_mpp_native.h"
#ifdef DEHAZE_MPP_MOCK
#include "mock_mpp.h"
#else
#include "rk_mpi.h"
#include "mpp_buffer.h"
#include "mpp_frame.h"
#include "mpp_packet.h"
#include "mpp_task.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define JPEG_LIMIT ((size_t)4 * 1024 * 1024)
#define JPEG_GUARD ((size_t)1024)
#define OUTPUT_SIZE ((size_t)2048 * 1088 * 4)
#define NV12_LIMIT ((size_t)2048 * 1088 * 3 / 2)

typedef struct {
    MppCtx ctx;
    MppApi *api;
    MppBufferGroup input_group, output_group;
    MppBuffer input_buffer, output_buffer;
    MppPacket packet;
    MppFrame frame;
    int frame_local, timeout_ms, poisoned;
    char error[256];
} dehaze_mpp_context;

static double now_ms(void)
{
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) return 0.0;
    return (double)t.tv_sec * 1000.0 + (double)t.tv_nsec / 1000000.0;
}

static int fail(dehaze_mpp_context *d, const char *phase, int code)
{
    d->poisoned = 1;
    snprintf(d->error, sizeof(d->error), "%s failed (%d); context poisoned", phase, code);
    return code ? code : -1;
}

uint32_t dehaze_mpp_result_size(void) { return (uint32_t)sizeof(dehaze_mpp_result); }
const char *dehaze_mpp_error(void *handle)
{
    dehaze_mpp_context *d = handle;
    return d ? d->error : "private MPP context is not open";
}

int dehaze_mpp_close(void *handle)
{
    dehaze_mpp_context *d = handle;
    int ret;
    if (!d) return 0;
    d->poisoned = 1;
    /* Context teardown must finish before touching possibly in-flight storage.
     * A failed destroy has no quiescence guarantee: retain every allocation. */
    if (d->ctx) {
        ret = mpp_destroy(d->ctx);
        if (ret) return fail(d, "context destroy; all storage retained", ret);
        d->ctx = NULL;
    }
#define RELEASE(phase, call) do { ret = (call); if (ret) return fail(d, phase, ret); } while (0)
    if (d->packet) RELEASE("packet close", mpp_packet_deinit(&d->packet));
    /* A submitted frame still queued in MPP is retired by context teardown.
     * Calling frame_deinit on that stale pointer would release it twice. */
    if (d->frame && d->frame_local) RELEASE("frame close", mpp_frame_deinit(&d->frame));
    if (d->input_buffer) {
        RELEASE("input allocation close", mpp_buffer_put(d->input_buffer));
        d->input_buffer = NULL;
    }
    if (d->output_buffer) {
        RELEASE("output allocation close", mpp_buffer_put(d->output_buffer));
        d->output_buffer = NULL;
    }
    if (d->input_group) {
        RELEASE("input group close", mpp_buffer_group_put(d->input_group));
        d->input_group = NULL;
    }
    if (d->output_group) {
        RELEASE("output group close", mpp_buffer_group_put(d->output_group));
        d->output_group = NULL;
    }
#undef RELEASE
    free(d);
    return 0;
}

int dehaze_mpp_open(void **out, int timeout_ms)
{
    dehaze_mpp_context *d;
    MppFrameFormat format = MPP_FMT_YUV420SP;
    int ret;
    if (!out) return -1;
    *out = NULL;
    if (timeout_ms <= 0 || timeout_ms >= MPP_POLL_MAX) return -1;
    d = calloc(1, sizeof(*d));
    if (!d) return -1;
    d->timeout_ms = timeout_ms;
#define OPEN(phase, call) do { ret = (call); if (ret) { fail(d, phase, ret); goto error; } } while (0)
    OPEN("context create", mpp_create(&d->ctx, &d->api));
    if (!d->ctx || !d->api || !d->api->control || !d->api->poll ||
        !d->api->dequeue || !d->api->enqueue) {
        ret = fail(d, "context API validation", -1); goto error;
    }
    OPEN("decoder init", mpp_init(d->ctx, MPP_CTX_DEC, MPP_VIDEO_CodingMJPEG));
    OPEN("NV12 configuration", d->api->control(d->ctx, MPP_DEC_SET_OUTPUT_FORMAT, &format));
    OPEN("input group", mpp_buffer_group_get_internal(&d->input_group, MPP_BUFFER_TYPE_DRM));
    OPEN("output group", mpp_buffer_group_get_internal(&d->output_group, MPP_BUFFER_TYPE_DRM));
    OPEN("input allocation", mpp_buffer_get(d->input_group, &d->input_buffer, JPEG_LIMIT + JPEG_GUARD));
    OPEN("output allocation", mpp_buffer_get(d->output_group, &d->output_buffer, OUTPUT_SIZE));
#undef OPEN
    *out = d;
    return 0;
error:
    if (dehaze_mpp_close(d)) *out = d;
    return ret ? ret : -1;
}

int dehaze_mpp_decode(void *handle, const uint8_t *jpeg, size_t length,
                      int64_t pts, uint8_t *dest, size_t capacity,
                      dehaze_mpp_result *result)
{
    dehaze_mpp_context *d = handle;
    MppTask task = NULL, input_task = NULL;
    MppFrame output = NULL;
    MppPacket returned = NULL;
    MppBuffer buffer;
    uint8_t *ptr;
    size_t bytes;
    double start, input_done, copy_start, copy_done;
    int ret;
    if (!d || d->poisoned) return -1;
    if (!result || !dest || !jpeg || length < 4 || length > JPEG_LIMIT || pts <= 0 ||
        jpeg[0] != 0xff || jpeg[1] != 0xd8 ||
        jpeg[length - 2] != 0xff || jpeg[length - 1] != 0xd9)
        return fail(d, "JPEG/PTS/output arguments", -1);
    memset(result, 0, sizeof(*result));
    result->abi_version = 1;
    start = now_ms();
#define CALL(phase, call) do { ret = (call); if (ret) return fail(d, phase, ret); } while (0)
#define POLL(phase, port) do { \
    ret = d->api->poll(d->ctx, port, (MppPollType)d->timeout_ms); \
    /* MPP poll may report the positive ready-task count. */ \
    if (ret < 0) return fail(d, phase, ret); \
} while (0)
    ptr = mpp_buffer_get_ptr(d->input_buffer);
    if (!ptr) return fail(d, "input buffer map", -1);
    CALL("input CPU sync begin", mpp_buffer_sync_begin(d->input_buffer));
    memcpy(ptr, jpeg, length);
    memset(ptr + length, 0, JPEG_GUARD);
    CALL("input CPU sync end", mpp_buffer_sync_end(d->input_buffer));
    input_done = now_ms();
    result->input_copy_ms = input_done - start;
    CALL("packet init", mpp_packet_init_with_buffer(&d->packet, d->input_buffer));
    mpp_packet_set_pos(d->packet, ptr);
    mpp_packet_set_length(d->packet, length);
    mpp_packet_set_pts(d->packet, pts);
    CALL("frame init", mpp_frame_init(&d->frame));
    d->frame_local = 1;
    mpp_frame_set_buffer(d->frame, d->output_buffer);
    /* Only decoder propagation can establish correspondence. */
    mpp_frame_set_pts(d->frame, -1);
    POLL("input poll", MPP_PORT_INPUT);
    CALL("input dequeue", d->api->dequeue(d->ctx, MPP_PORT_INPUT, &task));
    if (!task) return fail(d, "missing input task", -1);
    input_task = task;
    CALL("set input packet", mpp_task_meta_set_packet(task, KEY_INPUT_PACKET, d->packet));
    CALL("set output frame", mpp_task_meta_set_frame(task, KEY_OUTPUT_FRAME, d->frame));
    CALL("input enqueue", d->api->enqueue(d->ctx, MPP_PORT_INPUT, task));
    d->frame_local = 0;
    task = NULL;
    POLL("output poll", MPP_PORT_OUTPUT);
    CALL("output dequeue", d->api->dequeue(d->ctx, MPP_PORT_OUTPUT, &task));
    if (!task) return fail(d, "missing output task", -1);
    /* This output task is now caller-held; its originally supplied frame can
     * no longer be retired by MPP port teardown, even if metadata access fails. */
    d->frame_local = 1;
    CALL("get output frame", mpp_task_meta_get_frame(task, KEY_OUTPUT_FRAME, &output));
    if (output != d->frame) return fail(d, "output frame identity", -1);
    result->width = mpp_frame_get_width(output);
    result->height = mpp_frame_get_height(output);
    result->hor_stride = mpp_frame_get_hor_stride(output);
    result->ver_stride = mpp_frame_get_ver_stride(output);
    result->format = mpp_frame_get_fmt(output);
    result->errinfo = mpp_frame_get_errinfo(output);
    result->discard = mpp_frame_get_discard(output);
    result->info_change = mpp_frame_get_info_change(output);
    result->color_range = mpp_frame_get_color_range(output);
    result->colorspace = mpp_frame_get_colorspace(output);
    result->color_primaries = mpp_frame_get_color_primaries(output);
    result->color_trc = mpp_frame_get_color_trc(output);
    result->pts = mpp_frame_get_pts(output);
    buffer = mpp_frame_get_buffer(output);
    result->buffer_size = buffer ? mpp_buffer_get_size(buffer) : 0;
    if (buffer != d->output_buffer || result->errinfo || result->discard || result->info_change ||
        result->width != 1920 || result->height != 1080 ||
        result->format != (uint32_t)MPP_FMT_YUV420SP || result->pts != pts ||
        result->hor_stride < 1920 || result->hor_stride > 2048 || (result->hor_stride & 1) ||
        result->ver_stride < 1080 || result->ver_stride > 1088 || (result->ver_stride & 1))
        return fail(d, "decoded frame validation", -1);
    bytes = (size_t)result->hor_stride * result->ver_stride * 3 / 2;
    if (bytes > NV12_LIMIT || bytes > result->buffer_size || bytes > capacity)
        return fail(d, "NV12 copy bounds", -1);
    ptr = mpp_buffer_get_ptr(buffer);
    if (!ptr) return fail(d, "output buffer map", -1);
    copy_start = now_ms();
    CALL("output CPU sync begin", mpp_buffer_sync_begin(buffer));
    memcpy(dest, ptr, bytes);
    CALL("output CPU sync end", mpp_buffer_sync_end(buffer));
    copy_done = now_ms();
    result->output_copy_ms = copy_done - copy_start;
    result->copied_bytes = bytes;
    CALL("output recycle", d->api->enqueue(d->ctx, MPP_PORT_OUTPUT, task));
    task = NULL;
    POLL("input return poll", MPP_PORT_INPUT);
    CALL("input return dequeue", d->api->dequeue(d->ctx, MPP_PORT_INPUT, &task));
    if (!task || task != input_task) return fail(d, "returned input task identity", -1);
    CALL("returned packet", mpp_task_meta_get_packet(task, KEY_INPUT_PACKET, &returned));
    if (returned != d->packet || mpp_packet_get_pts(returned) != pts)
        return fail(d, "returned packet identity/PTS", -1);
    CALL("clear input packet", mpp_task_meta_set_packet(task, KEY_INPUT_PACKET, NULL));
    CALL("clear output frame", mpp_task_meta_set_frame(task, KEY_OUTPUT_FRAME, NULL));
    /* Return the empty task before releasing wrappers or allowing reuse. */
    CALL("input empty recycle", d->api->enqueue(d->ctx, MPP_PORT_INPUT, task));
    CALL("packet release", mpp_packet_deinit(&d->packet));
    CALL("frame release", mpp_frame_deinit(&d->frame));
    d->frame_local = 0;
#undef CALL
#undef POLL
    result->total_ms = now_ms() - start;
    /* Decode scope includes setup, polls, validation and ownership retirement;
     * the separately reported input/output CPU copy scopes are excluded. */
    result->mpp_decode_ms = result->total_ms - result->input_copy_ms - result->output_copy_ms;
    return 0;
}
