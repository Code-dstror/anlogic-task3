#ifndef DEHAZE_MPP_NATIVE_H
#define DEHAZE_MPP_NATIVE_H
#include <stddef.h>
#include <stdint.h>

/* Private ABI, version 1. One caller and one frame per context. Pixels are
 * copied to caller-owned storage before any MPP output task is recycled. */
typedef struct {
    uint32_t abi_version, width, height, hor_stride, ver_stride, format;
    uint32_t errinfo, discard, info_change;
    uint32_t color_range, colorspace, color_primaries, color_trc;
    uint64_t buffer_size, copied_bytes;
    int64_t pts;
    double input_copy_ms, mpp_decode_ms, output_copy_ms, total_ms;
} dehaze_mpp_result;

uint32_t dehaze_mpp_result_size(void);
/* On failed partial initialization, *out can be non-NULL if teardown failed.
 * Such a handle is poisoned and must be retained, never automatically retried. */
int dehaze_mpp_open(void **out, int timeout_ms);
int dehaze_mpp_decode(void *handle, const uint8_t *jpeg, size_t length,
                      int64_t pts, uint8_t *dest, size_t capacity,
                      dehaze_mpp_result *result);
/* A nonzero return retains the poisoned handle and unreleased allocations.
 * No reset, device-wide cleanup, or automatic retry is performed. */
int dehaze_mpp_close(void *handle);
const char *dehaze_mpp_error(void *handle);
#endif
