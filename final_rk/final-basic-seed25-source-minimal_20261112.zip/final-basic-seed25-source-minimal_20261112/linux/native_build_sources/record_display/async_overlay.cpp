#include "async_overlay.h"
#include <cstdlib>
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#include "fps_hud_core.h"
#pragma GCC diagnostic pop
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>
#include <gst/allocators/gstdmabuf.h>
#include <linux/dma-buf.h>
#include <sys/ioctl.h>
#include <cerrno>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <mutex>
#include <new>
#include <time.h>

static_assert(sizeof(Y26AsyncContext) == Y26_ASYNC_CONTEXT_BYTES, "context ABI");
static_assert(sizeof(Y26AsyncBox) == Y26_ASYNC_BOX_BYTES, "box ABI");
static_assert(sizeof(Y26AsyncStats) == Y26_ASYNC_STATS_BYTES, "stats ABI");
static_assert(sizeof(Y26AsyncDmaStats) == Y26_ASYNC_DMA_STATS_BYTES, "DMA stats ABI");

namespace {
constexpr unsigned W = 1920, H = 1080;
constexpr size_t COMPACT_BYTES = W * H * 3 / 2;
uint64_t monotonic_ns() {
    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return uint64_t(ts.tv_sec) * 1000000000 + ts.tv_nsec;
}
bool valid_context(const Y26AsyncContext *c) {
    if (!c || !c->session || !c->epoch || !c->cohort_len || c->cohort_len > 64) return false;
    for (unsigned i = 0; i < c->cohort_len; ++i)
        if (static_cast<unsigned char>(c->cohort[i]) < 33 || static_cast<unsigned char>(c->cohort[i]) > 126) return false;
    return true;
}
bool same(const Y26AsyncContext& a, const Y26AsyncContext& b) {
    return a.session == b.session && a.epoch == b.epoch && a.camera == b.camera &&
        a.kind == b.kind && a.format == b.format && a.role == b.role &&
        a.cohort_len == b.cohort_len && !memcmp(a.cohort, b.cohort, a.cohort_len);
}
bool valid_box(const Y26AsyncBox& b) {
    if (b.x1 < 0 || b.y1 < 0 || b.x2 <= b.x1 || b.y2 <= b.y1 || b.x2 > int(W) || b.y2 > int(H) || b.level < -3 || b.level > 2) return false;
    for (unsigned i = 0; i < sizeof b.label; ++i) {
        unsigned c = static_cast<unsigned char>(b.label[i]);
        if (!c) return true;
        if (c < 32 || c > 126) return false;
    }
    return false;
}
struct DisplayVideo {
    bool used = false;
    uint64_t pts = 0;
    uint32_t sequence = 0;
    Y26AsyncContext context{};
};
struct DisplayLane : DisplayVideo {
    uint32_t count = 0;
    std::array<Y26LaneCurve, 2> curves{};
};
struct DisplayCounters {
    std::atomic<uint64_t> video_registered{0}, video_rejected{0}, video_matches{0}, video_misses{0};
    std::atomic<uint64_t> lane_registered{0}, lane_rejected{0}, lane_matches{0}, lane_frames{0}, lane_empty{0};
    std::atomic<uint64_t> lane_missing{0}, lane_dropped{0}, fps_frames{0}, fps_valid{0}, fps_tenths{0}, fps_total{0}, fps_faults{0};
};
struct DisplayState {
    std::mutex mutex;
    std::array<DisplayVideo, Y26_DISPLAY_CAPACITY> videos{};
    std::array<DisplayLane, Y26_DISPLAY_CAPACITY> lanes{};
    unsigned video_pending = 0, lane_pending = 0;
    DisplayCounters stats;
    fps_hud_counter fps{}; // streaming thread only; public snapshots are atomic
    GstBufferPool *output_pool = nullptr; // optional, streaming thread only
    bool reuse_pool = g_strcmp0(g_getenv("R5_DISPLAY_REUSE_POOL"),"1")==0;
    unsigned pool_limit = g_strcmp0(g_getenv("R5_DISPLAY_POOL_MAX"),"12")==0 ? 12 : 4;
    std::atomic<uint64_t> pool_acquired{0},pool_exhausted{0};
    ~DisplayState() {
        if(output_pool) { gst_buffer_pool_set_active(output_pool,FALSE);gst_object_unref(output_pool); }
    }
};
struct DisplaySelection {
    uint32_t count = 0;
    std::array<Y26LaneCurve, 2> curves{};
};
bool video_context(const Y26AsyncContext *c) {
    if (!c || !c->session || !c->cohort_len || c->cohort_len > 64 || c->camera != 0 ||
        c->kind != 1 || c->format != 1 || c->role > 1) return false;
    for (unsigned i = 0; i < c->cohort_len; ++i)
        if (static_cast<unsigned char>(c->cohort[i]) < 33 || static_cast<unsigned char>(c->cohort[i]) > 126) return false;
    return true;
}
void erase_lane(DisplayState& d, uint64_t pts) {
    for (auto& e : d.lanes) if (e.used && e.pts == pts) {
        e.used = false; --d.lane_pending; d.stats.lane_dropped.fetch_add(1);
    }
}

struct FrameEntry {
    bool used = false;
    uint64_t pts = 0, generation = 0;
    uint32_t sequence = 0;
    Y26AsyncContext context{};
};
struct Counters {
    std::atomic<uint64_t> frames{0}, overlays{0}, passes{0}, map_failures{0}, unsupported{0};
    std::atomic<uint64_t> lock_misses{0}, overwrites{0}, frame_misses{0}, updates{0}, rejects{0};
    std::atomic<uint64_t> expired{0}, resets{0}, bytes{0}, draw_ns{0};
    std::atomic<uint64_t> sync_starts{0}, sync_ends{0}, sync_failures{0}, dmabuf_frames{0};
};
#ifdef Y26_ASYNC_TESTING
std::atomic<int> test_dma_ioctl_mode{0}; // host fixtures only; absent in production
std::atomic<uint64_t> test_copies_created{0}, test_copies_finalized{0};
void test_copy_finalized(gpointer, GstMiniObject *) { test_copies_finalized.fetch_add(1); }
#endif
int dma_sync_ioctl(int fd, uint64_t flags) {
#ifdef Y26_ASYNC_TESTING
    const int mode = test_dma_ioctl_mode.load();
    if (mode == 1) return 0;
    if (mode == 2) return flags & DMA_BUF_SYNC_END ? -1 : 0;
#endif
    dma_buf_sync sync{}; sync.flags = flags;
    int rc;
    do { rc = ioctl(fd, DMA_BUF_IOCTL_SYNC, &sync); } while (rc < 0 && errno == EINTR);
    return rc;
}
struct DmaReadGuard {
    Counters& stats;
    std::array<int, 64> fds{};
    unsigned count = 0;
    bool saw_dma = false;
    explicit DmaReadGuard(Counters& s): stats(s) {}
    bool finish() {
        bool ok = true;
        while (count) {
            const int fd = fds[--count]; // no destructor retry on unknown END
            if (dma_sync_ioctl(fd, DMA_BUF_SYNC_END | DMA_BUF_SYNC_READ) < 0) {
                stats.sync_failures.fetch_add(1); ok = false;
            } else stats.sync_ends.fetch_add(1);
        }
        return ok;
    }
    bool start(GstBuffer *buffer) {
        for (unsigned i = 0; i < gst_buffer_n_memory(buffer); ++i) {
            GstMemory *memory = gst_buffer_peek_memory(buffer, i);
            if (!gst_is_dmabuf_memory(memory)) continue;
            if (!saw_dma) { saw_dma = true; stats.dmabuf_frames.fetch_add(1); }
            const int fd = gst_dmabuf_memory_get_fd(memory); // borrowed; never close
            if (std::find(fds.begin(), fds.begin() + count, fd) != fds.begin() + count) continue;
            if (fd < 0 || count == fds.size() || dma_sync_ioctl(fd, DMA_BUF_SYNC_START | DMA_BUF_SYNC_READ) < 0) {
                stats.sync_failures.fetch_add(1); finish(); return false;
            }
            fds[count++] = fd; stats.sync_starts.fetch_add(1);
        }
        return true;
    }
    ~DmaReadGuard() { finish(); }
};
struct State {
    std::mutex mutex;
    Counters stats;
    DisplayState display;
    bool enabled = false, context_valid = false, result_valid = false;
    bool have_result_sequence = false;
    uint64_t generation = 0, revision = 0, max_age = Y26_ASYNC_DEFAULT_MAX_AGE_NS, received = 0;
    uint32_t result_sequence = 0, count = 0;
    Y26AsyncContext context{};
    std::array<Y26AsyncBox, Y26_ASYNC_BOX_CAPACITY> boxes{};
    std::array<FrameEntry, Y26_ASYNC_FRAME_CAPACITY> frames{};
    unsigned next = 0, table_size = 0;
    GstVideoInfo info{}; // caps and prepare are serialized by GstBaseTransform
    bool supported_caps = false;
#ifdef Y26_ASYNC_TESTING
    std::atomic<bool> cancel_before_commit{false};
#endif
    void clear_frames() {
        for (auto& f : frames) f.used = false;
        table_size = next = 0;
    }
    void clear_result() { result_valid = false; count = 0; }
    void change_context(const Y26AsyncContext& c) {
        if (context_valid && !same(context, c)) stats.resets.fetch_add(1);
        context = c; context_valid = true;
        clear_frames(); clear_result(); have_result_sequence = false; ++revision;
    }
};
struct Selection {
    uint64_t generation = 0, revision = 0, received = 0, max_age = 0;
    Y26AsyncContext context{};
    uint32_t count = 0;
    std::array<Y26AsyncBox, Y26_ASYNC_BOX_CAPACITY> boxes{};
};
}

typedef struct _Y26AsyncOverlay { GstBaseTransform parent; State *state; } Y26AsyncOverlay;
typedef struct _Y26AsyncOverlayClass { GstBaseTransformClass parent; } Y26AsyncOverlayClass;
G_DEFINE_TYPE(Y26AsyncOverlay, y26_async_overlay, GST_TYPE_BASE_TRANSFORM)

static State *get_state(void *handle) {
    if (!handle || !G_TYPE_CHECK_INSTANCE_TYPE(static_cast<GTypeInstance*>(handle), y26_async_overlay_get_type())) return nullptr;
    return reinterpret_cast<Y26AsyncOverlay*>(handle)->state;
}
static gboolean set_caps(GstBaseTransform *base, GstCaps *input, GstCaps *) {
    auto s = reinterpret_cast<Y26AsyncOverlay*>(base)->state;
    gst_video_info_init(&s->info);
    s->supported_caps = gst_video_info_from_caps(&s->info, input) &&
        GST_VIDEO_INFO_FORMAT(&s->info) == GST_VIDEO_FORMAT_NV12 &&
        GST_VIDEO_INFO_WIDTH(&s->info) == int(W) && GST_VIDEO_INFO_HEIGHT(&s->info) == int(H);
    // A newly allocated compact system-memory buffer must not masquerade as
    // memory:DMABuf or AFBC. Mappable MPP memory under ordinary raw caps works.
    if (gst_caps_get_size(input)) {
        const auto features = gst_caps_get_features(input, 0);
        const auto structure = gst_caps_get_structure(input, 0);
        gint afbc = 0;
        if (gst_caps_features_is_any(features) ||
            !gst_caps_features_contains(features, GST_CAPS_FEATURE_MEMORY_SYSTEM_MEMORY) ||
            (gst_structure_has_field(structure, "arm-afbc") &&
             (!gst_structure_get_int(structure, "arm-afbc", &afbc) || afbc != 0))) s->supported_caps = false;
    }
    return TRUE; // unsupported input remains on the original video route
}
static bool plane_valid(const GstVideoFrame& frame, unsigned p, unsigned rows) {
    const auto data = static_cast<const unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&frame, p));
    const int stride = GST_VIDEO_FRAME_PLANE_STRIDE(&frame, p);
    if (!data || stride < int(W)) return false;
    const size_t span = size_t(rows - 1) * unsigned(stride) + W;
    const uintptr_t address = reinterpret_cast<uintptr_t>(data);
    for (unsigned i = 0; i < GST_VIDEO_MAX_PLANES; ++i) {
        const auto start = reinterpret_cast<uintptr_t>(frame.map[i].data);
        const size_t size = frame.map[i].size;
        if (start && address >= start && address - start <= size && span <= size - (address - start)) return true;
    }
    return false;
}
static bool usable_frame(const GstVideoFrame& f) {
    if (GST_VIDEO_FRAME_FORMAT(&f) != GST_VIDEO_FORMAT_NV12 || GST_VIDEO_FRAME_WIDTH(&f) != int(W) ||
        GST_VIDEO_FRAME_HEIGHT(&f) != int(H) || !plane_valid(f, 0, H) || !plane_valid(f, 1, H / 2)) return false;
    const uintptr_t y = reinterpret_cast<uintptr_t>(GST_VIDEO_FRAME_PLANE_DATA(&f, 0));
    const uintptr_t uv = reinterpret_cast<uintptr_t>(GST_VIDEO_FRAME_PLANE_DATA(&f, 1));
    const size_t ys = size_t(H - 1) * unsigned(GST_VIDEO_FRAME_PLANE_STRIDE(&f, 0)) + W;
    const size_t uvs = size_t(H / 2 - 1) * unsigned(GST_VIDEO_FRAME_PLANE_STRIDE(&f, 1)) + W;
    return y < uv ? uv - y >= ys : y - uv >= uvs;
}
static DisplaySelection select_display(State& state, uint64_t pts) {
    auto& d = state.display;
    DisplaySelection result;
    std::unique_lock<std::mutex> lock(d.mutex, std::try_to_lock);
    if (!lock.owns_lock()) { state.stats.lock_misses.fetch_add(1); return result; }
    // The video owner uses monotonic PTS tokens; stale metadata is never a
    // substitute for the current PTS. Dropped input queues can leave old rows.
    for (auto& e : d.videos) if (e.used && e.pts < pts) { e.used = false; --d.video_pending; }
    for (auto& e : d.lanes) if (e.used && e.pts < pts) {
        e.used = false; --d.lane_pending; d.stats.lane_dropped.fetch_add(1);
    }
    DisplayVideo frame;
    bool found = false;
    for (auto& e : d.videos) if (e.used && e.pts == pts) {
        frame = e; found = true; e.used = false; --d.video_pending; break;
    }
    if (found) d.stats.video_matches.fetch_add(1); else d.stats.video_misses.fetch_add(1);
    bool lane_found = false;
    for (auto& e : d.lanes) if (e.used && e.pts == pts) {
        lane_found = true; e.used = false; --d.lane_pending;
        if (found && e.sequence == frame.sequence && same(e.context, frame.context)) {
            result.count = e.count; result.curves = e.curves;
            d.stats.lane_matches.fetch_add(1);
            if (!e.count) d.stats.lane_empty.fetch_add(1);
        } else d.stats.lane_dropped.fetch_add(1);
        break;
    }
    if (!lane_found) d.stats.lane_missing.fetch_add(1);
    return result;
}

static bool select_overlay(State& s, uint64_t pts, Selection& selected) {
    std::unique_lock<std::mutex> lock(s.mutex, std::try_to_lock);
    if (!lock.owns_lock()) { s.stats.lock_misses.fetch_add(1); return false; }
    if (!s.enabled || !s.context_valid) return false;
    FrameEntry frame{}; bool found = false;
    for (auto& f : s.frames) if (f.used && f.pts == pts) {
        frame = f; f.used = false; --s.table_size; found = true; break;
    }
    if (!found || frame.generation != s.generation || !same(frame.context, s.context)) {
        s.stats.frame_misses.fetch_add(1); return false;
    }
    selected.generation = s.generation; selected.revision = s.revision; selected.context = s.context;
    const uint64_t now = monotonic_ns();
    if (s.result_valid && (now < s.received || now - s.received >= s.max_age)) {
        s.clear_result(); s.stats.expired.fetch_add(1);
    }
    if (s.result_valid && s.result_sequence <= frame.sequence) {
        selected.count = s.count;
        selected.received = s.received; selected.max_age = s.max_age;
        std::copy_n(s.boxes.begin(), s.count, selected.boxes.begin());
    }
    return true; // enabled indicator is independent of result availability
}
struct Surface { unsigned char *y, *uv; int ys, uvs; };
static void pixel(Surface& s, int x, int y, int level) {
    if (x < 0 || x >= int(W) || y < 0 || y >= int(H)) return;
    unsigned char yy = 235, u = 128, v = 128;
    if (level == 2) { yy = 76; u = 85; v = 255; }
    else if (level == 1) { yy = 226; u = 0; v = 149; }
    else if (level == 0) { yy = 179; u = 171; v = 0; }
    s.y[size_t(y) * s.ys + x] = yy;
    const size_t offset = size_t(y / 2) * s.uvs + unsigned(x & ~1);
    s.uv[offset] = u; s.uv[offset + 1] = v;
}
static const unsigned char FONT[36][7] = {
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,30},
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
};
static void text(Surface& s, int x, int y, const char *label, int level) {
    for (unsigned n = 0; n < 47 && label[n]; ++n, x += 12) {
        unsigned c = static_cast<unsigned char>(label[n]);
        if (c >= 'a' && c <= 'z') c -= 'a' - 'A';
        for (unsigned row = 0; row < 7; ++row) {
            const unsigned bits = c >= '0' && c <= '9' ? FONT[c - '0'][row] :
                c >= 'A' && c <= 'Z' ? FONT[10 + c - 'A'][row] :
                c == '-' ? (row == 3 ? 31 : 0) : c == '.' ? (row == 6 ? 4 : 0) :
                c == ':' ? (row == 2 || row == 5 ? 4 : 0) : 0;
            for (unsigned col = 0; col < 5; ++col) if (bits & (1u << (4 - col)))
                for (int dy = 0; dy < 2; ++dy) for (int dx = 0; dx < 2; ++dx)
                    pixel(s, x + int(col) * 2 + dx, y + int(row) * 2 + dy, level);
        }
    }
}
static void draw(Surface& s, const Selection& selected) {
    text(s, 16, 56, "AI ON", -1);
    for (unsigned i = 0; i < selected.count; ++i) {
        const auto& b = selected.boxes[i];
        const int thickness = std::min({2, b.x2 - b.x1, b.y2 - b.y1});
        for (int t = 0; t < thickness; ++t) {
            for (int x = b.x1; x < b.x2; ++x) { pixel(s, x, b.y1 + t, b.level); pixel(s, x, b.y2 - 1 - t, b.level); }
            for (int y = b.y1; y < b.y2; ++y) { pixel(s, b.x1 + t, y, b.level); pixel(s, b.x2 - 1 - t, y, b.level); }
        }
        text(s, b.x1, b.y1 >= 16 ? b.y1 - 16 : b.y1 + 3, b.label, b.level);
    }
}
static void lane_pixel(Surface& s, int x, int y, unsigned label) {
    static const unsigned char color[3][3] = {{210,16,146},{170,166,16},{220,16,166}};
    if (x < 0 || x >= int(W) || y < 0 || y >= int(H)) return;
    s.y[size_t(y) * s.ys + x] = color[label][0];
    const size_t at = size_t(y / 2) * s.uvs + unsigned(x & ~1);
    s.uv[at] = color[label][1]; s.uv[at+1] = color[label][2];
}
static void lane_dot(Surface& s, int x, int y, unsigned label, int r) {
    for (int dy=-r; dy<=r; ++dy) for (int dx=-r; dx<=r; ++dx)
        if (dx*dx+dy*dy<=r*r) lane_pixel(s,x+dx,y+dy,label);
}
static void lane_line(Surface& s, int x, int y, int xx, int yy, unsigned label) {
    int dx=std::abs(xx-x), sx=x<xx?1:-1, dy=-std::abs(yy-y), sy=y<yy?1:-1, err=dx+dy;
    for (;;) {
        lane_dot(s,x,y,label,2); if (x==xx && y==yy) break;
        int e=2*err; if (e>=dy) {err+=dy;x+=sx;} if (e<=dx) {err+=dx;y+=sy;}
    }
}
static void draw_lane(Surface& s, const DisplaySelection& selected) {
    for (unsigned c=0;c<selected.count;++c) {
        const auto& curve=selected.curves[c];
        for (unsigned i=0;i<curve.count;++i) {
            const auto p=curve.points[i];
            if (i) lane_line(s,curve.points[i-1].x,curve.points[i-1].y,p.x,p.y,curve.label);
            lane_dot(s,p.x,p.y,curve.label,3);
        }
    }
}

static GstBuffer *display_output(State *s) {
    auto& d=s->display;
    if(!d.reuse_pool)return gst_buffer_new_allocate(nullptr,COMPACT_BYTES,nullptr);
    if(!d.output_pool) {
        GstBufferPool *pool=gst_video_buffer_pool_new();
        GstStructure *config=gst_buffer_pool_get_config(pool);
        GstVideoInfo info{};gst_video_info_set_format(&info,GST_VIDEO_FORMAT_NV12,W,H);
        GstCaps *caps=gst_video_info_to_caps(&info);
        gst_buffer_pool_config_set_params(config,caps,COMPACT_BYTES,2,d.pool_limit);
        gst_buffer_pool_config_add_option(config,GST_BUFFER_POOL_OPTION_VIDEO_META);
        gst_caps_unref(caps);
        if(!gst_buffer_pool_set_config(pool,config) || !gst_buffer_pool_set_active(pool,TRUE)) {
            gst_object_unref(pool);d.pool_exhausted.fetch_add(1);return nullptr;
        }
        d.output_pool=pool;
    }
    GstBuffer *buffer=nullptr;GstBufferPoolAcquireParams params{};
    params.flags=GST_BUFFER_POOL_ACQUIRE_FLAG_DONTWAIT;
    if(gst_buffer_pool_acquire_buffer(d.output_pool,&buffer,&params)!=GST_FLOW_OK) {
        d.pool_exhausted.fetch_add(1);return nullptr;
    }
    d.pool_acquired.fetch_add(1);return buffer;
}
extern "C" int y26_display_pool_stats(void *handle,uint64_t *values) {
    if(!handle || !values)return 0;
    auto& d=reinterpret_cast<Y26AsyncOverlay*>(handle)->state->display;
    values[0]=d.reuse_pool;values[1]=d.pool_acquired.load();values[2]=d.pool_exhausted.load();return 1;
}
extern "C" unsigned y26_display_pool_limit(void *handle) {
    return handle?reinterpret_cast<Y26AsyncOverlay*>(handle)->state->display.pool_limit:0;
}
static GstFlowReturn prepare(GstBaseTransform *base, GstBuffer *input, GstBuffer **output) {
    auto s = reinterpret_cast<Y26AsyncOverlay*>(base)->state;
    const uint64_t serial=s->stats.frames.fetch_add(1)+1;
    auto passthrough = [&]() {
        // Keep the original BaseTransform transfer contract: no extra ref.
        *output = input; s->stats.passes.fetch_add(1); return GST_FLOW_OK;
    };
    Selection selected;
    const bool ai_selected=select_overlay(*s,GST_BUFFER_PTS(input),selected);
    const DisplaySelection lane=select_display(*s,GST_BUFFER_PTS(input));
    auto& display=s->display;
    const uint64_t stamp=monotonic_ns();
    if (!serial || !fps_hud_observe(&display.fps,stamp,serial,1)) display.stats.fps_faults.store(1);
    display.stats.fps_valid.store(display.fps.valid);
    display.stats.fps_tenths.store(display.fps.fps_tenths);
    display.stats.fps_total.store(display.fps.total);
    char fps_text[48];
    if (!fps_hud_format(fps_text,sizeof fps_text,0,&display.fps)) return passthrough();
    if (!s->supported_caps) { s->stats.unsupported.fetch_add(1); return passthrough(); }
    DmaReadGuard dma_read(s->stats);
    if (!dma_read.start(input)) { s->stats.map_failures.fetch_add(1); return passthrough(); }
    GstVideoFrame original{};
    if (!gst_video_frame_map(&original, &s->info, input, GST_MAP_READ)) {
        dma_read.finish();
        s->stats.map_failures.fetch_add(1); return passthrough();
    }
    if (!usable_frame(original)) {
        gst_video_frame_unmap(&original); dma_read.finish(); s->stats.map_failures.fetch_add(1); return passthrough();
    }
    GstBuffer *copy = display_output(s);
#ifdef Y26_ASYNC_TESTING
    if (copy) {
        test_copies_created.fetch_add(1);
        gst_mini_object_weak_ref(GST_MINI_OBJECT(copy), test_copy_finalized, nullptr);
    }
#endif
    GstVideoInfo compact{}; gst_video_info_set_format(&compact, GST_VIDEO_FORMAT_NV12, W, H);
    gsize offsets[GST_VIDEO_MAX_PLANES] = {0, W * H, 0, 0};
    gint strides[GST_VIDEO_MAX_PLANES] = {int(W), int(W), 0, 0};
    GstVideoFrame target{};
    bool mapped = false;
    bool good = copy && (gst_buffer_get_video_meta(copy) || gst_buffer_add_video_meta_full(copy, GST_VIDEO_FRAME_FLAG_NONE,
        GST_VIDEO_FORMAT_NV12, W, H, 2, offsets, strides));
    if (good) { mapped = gst_video_frame_map(&target, &compact, copy, GST_MAP_WRITE); good = mapped; }
    if (good) good = gst_video_frame_copy(&target, &original);
    gst_video_frame_unmap(&original);
    if (!dma_read.finish()) good = false;
    if (!good) {
        if (mapped) gst_video_frame_unmap(&target);
        if (copy) gst_buffer_unref(copy);
        s->stats.map_failures.fetch_add(1); return passthrough();
    }
    const uint64_t begin=monotonic_ns();
    Surface surface{static_cast<unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&target,0)),
        static_cast<unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&target,1)),
        GST_VIDEO_FRAME_PLANE_STRIDE(&target,0),GST_VIDEO_FRAME_PLANE_STRIDE(&target,1)};
#ifdef Y26_ASYNC_TESTING
    if (s->cancel_before_commit.exchange(false)) y26_async_enable(base,0,nullptr,selected.generation,0);
#endif
    // Map/copy/DMA operations remain outside all metadata locks. If AI changed
    // meanwhile, omit only AI pixels; independent same-frame lane/FPS survive.
    std::unique_lock<std::mutex> guard(s->mutex,std::defer_lock);
    if (ai_selected) guard.try_lock();
    bool show_ai=ai_selected && guard.owns_lock() && s->enabled && s->generation==selected.generation &&
        s->revision==selected.revision && same(s->context,selected.context) &&
        (!selected.count || (monotonic_ns()>=selected.received && monotonic_ns()-selected.received<selected.max_age));
    if (ai_selected && !guard.owns_lock()) s->stats.lock_misses.fetch_add(1);
    if (!show_ai && guard.owns_lock()) guard.unlock();
    // Only bounded CPU drawing is protected when AI is valid, so an OFF/clear
    // cannot race an already-painted old AI result into the committed copy.
    if (show_ai) draw(surface,selected);
    if (lane.count) draw_lane(surface,lane);
    fps_hud_surface hud{surface.y,surface.uv,surface.ys,surface.uvs,W,H,size_t(W)*H,size_t(W)*H/2};
    if (!fps_hud_draw(&hud,16,16,fps_text)) {
        gst_video_frame_unmap(&target);gst_buffer_unref(copy);s->stats.map_failures.fetch_add(1);return passthrough();
    }
    gst_video_frame_unmap(&target);
    // Preserve timing/flags, never input's padded VideoMeta on compact output.
    gst_buffer_copy_into(copy,input,GstBufferCopyFlags(GST_BUFFER_COPY_FLAGS|GST_BUFFER_COPY_TIMESTAMPS),0,-1);
    if (show_ai) s->stats.overlays.fetch_add(1); else s->stats.passes.fetch_add(1);
    if (lane.count) display.stats.lane_frames.fetch_add(1);
    display.stats.fps_frames.fetch_add(1);
    s->stats.bytes.fetch_add(COMPACT_BYTES);s->stats.draw_ns.fetch_add(monotonic_ns()-begin);
    *output=copy;return GST_FLOW_OK;
}
static GstFlowReturn transform(GstBaseTransform *, GstBuffer *, GstBuffer *) { return GST_FLOW_OK; }
static gboolean copy_metadata(GstBaseTransform *, GstBuffer *, GstBuffer *) { return TRUE; }
static gboolean transform_meta(GstBaseTransform *, GstBuffer *, GstMeta *, GstBuffer *) { return FALSE; }
static void finalize(GObject *object) {
    delete reinterpret_cast<Y26AsyncOverlay*>(object)->state;
    G_OBJECT_CLASS(y26_async_overlay_parent_class)->finalize(object);
}
static void y26_async_overlay_class_init(Y26AsyncOverlayClass *klass) {
    auto element = GST_ELEMENT_CLASS(klass);
    gst_element_class_set_static_metadata(element, "Async latest AI NV12 overlay", "Filter/Video",
        "Nonblocking metadata and copy-before-draw; original video survives overlay failures", "Linux AI/application");
    static GstStaticPadTemplate sink = GST_STATIC_PAD_TEMPLATE("sink", GST_PAD_SINK, GST_PAD_ALWAYS, GST_STATIC_CAPS_ANY);
    static GstStaticPadTemplate src = GST_STATIC_PAD_TEMPLATE("src", GST_PAD_SRC, GST_PAD_ALWAYS, GST_STATIC_CAPS_ANY);
    gst_element_class_add_static_pad_template(element, &sink);
    gst_element_class_add_static_pad_template(element, &src);
    auto base = GST_BASE_TRANSFORM_CLASS(klass);
    base->set_caps = set_caps; base->prepare_output_buffer = prepare; base->transform = transform;
    base->copy_metadata = copy_metadata; base->transform_meta = transform_meta;
    base->passthrough_on_same_caps = FALSE;
    G_OBJECT_CLASS(klass)->finalize = finalize;
}
static void y26_async_overlay_init(Y26AsyncOverlay *self) {
    self->state = new State;
    gst_base_transform_set_in_place(GST_BASE_TRANSFORM(self), FALSE);
    gst_base_transform_set_passthrough(GST_BASE_TRANSFORM(self), FALSE);
}

extern "C" int y26_async_register_element() {
    static std::once_flag once;
    static bool registered = false;
    std::call_once(once, [] { registered = gst_element_register(nullptr, "y26asyncoverlay", GST_RANK_NONE, y26_async_overlay_get_type()); });
    return registered;
}
extern "C" void *y26_async_get_handle(void *element) { return get_state(element) ? element : nullptr; }
extern "C" int y26_async_enable(void *handle, int enabled, const Y26AsyncContext *context, uint64_t generation, uint64_t max_age_ns) {
    auto s = get_state(handle);
    if (!s || (enabled != 0 && enabled != 1) || (enabled && (!generation || !valid_context(context)))) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    if (generation < s->generation) return 0;
    const bool changed = generation != s->generation || bool(enabled) != s->enabled ||
        (enabled && (!s->context_valid || !same(*context, s->context)));
    if (changed) { s->clear_frames(); s->clear_result(); s->have_result_sequence = false; ++s->revision; }
    s->generation = generation; s->enabled = enabled;
    s->max_age = max_age_ns ? max_age_ns : Y26_ASYNC_DEFAULT_MAX_AGE_NS;
    if (enabled && (!s->context_valid || !same(*context, s->context))) s->change_context(*context);
    return 1;
}
extern "C" int y26_async_register_frame(void *handle, uint64_t pts, const Y26AsyncContext *context, uint32_t sequence) {
    auto s = get_state(handle);
    if (!s || pts == GST_CLOCK_TIME_NONE || !valid_context(context)) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    if (!s->enabled) return 1;
    if (!s->context_valid || !same(s->context, *context)) s->change_context(*context);
    for (auto& frame : s->frames) if (frame.used && frame.pts == pts) {
        return frame.sequence == sequence && frame.generation == s->generation && same(frame.context, *context);
    }
    auto& frame = s->frames[s->next];
    if (frame.used) s->stats.overwrites.fetch_add(1); else ++s->table_size;
    frame.used = true; frame.pts = pts; frame.generation = s->generation; frame.sequence = sequence; frame.context = *context;
    s->next = (s->next + 1) % s->frames.size();
    return 1;
}
extern "C" int y26_async_update_latest(void *handle, uint64_t generation, const Y26AsyncContext *context,
    uint32_t sequence, uint64_t received_ns, const Y26AsyncBox *boxes, uint32_t count) {
    auto s = get_state(handle);
    if (!s) return 0;
    auto reject = [&]() { s->stats.rejects.fetch_add(1); return 0; };
    if (!valid_context(context) || !received_ns || count > Y26_ASYNC_BOX_CAPACITY || (count && !boxes)) return reject();
    const uint64_t now = monotonic_ns();
    if (received_ns > now) return reject();
    for (unsigned i = 0; i < count; ++i) if (!valid_box(boxes[i])) return reject();
    std::lock_guard<std::mutex> lock(s->mutex);
    if (!s->enabled || generation != s->generation || !same(*context, s->context) ||
        (s->have_result_sequence && (sequence < s->result_sequence || received_ns < s->received))) return reject();
    // A normal async update may take effect on the next video frame. Empty
    // results must revoke already selected old boxes before they can commit.
    if (!count && s->count) ++s->revision;
    s->count = count; s->received = received_ns; s->result_sequence = sequence;
    s->have_result_sequence = s->result_valid = true;
    if (count) std::copy_n(boxes, count, s->boxes.begin());
    s->stats.updates.fetch_add(1);
    return 1;
}
extern "C" int y26_async_clear(void *handle, uint64_t generation) {
    auto s = get_state(handle); if (!s) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    if (generation < s->generation) return 0;
    if (generation != s->generation) { s->generation = generation; s->clear_frames(); s->have_result_sequence = false; }
    s->clear_result(); ++s->revision;
    return 1;
}
extern "C" int y26_async_stats(void *handle, Y26AsyncStats *out) {
    auto s = get_state(handle); if (!s || !out) return 0;
    std::lock_guard<std::mutex> lock(s->mutex);
    *out = Y26AsyncStats{Y26_ASYNC_ABI_VERSION, s->stats.frames.load(), s->stats.overlays.load(), s->stats.passes.load(),
        s->stats.map_failures.load(), s->stats.unsupported.load(), s->stats.lock_misses.load(), s->stats.overwrites.load(),
        s->stats.frame_misses.load(), s->stats.updates.load(), s->stats.rejects.load(), s->stats.expired.load(),
        s->stats.resets.load(), s->table_size, uint64_t(s->enabled), s->generation, s->result_sequence,
        s->count, s->stats.bytes.load(), s->stats.draw_ns.load()};
    return 1;
}
extern "C" int y26_async_dma_stats(void *handle, Y26AsyncDmaStats *out) {
    auto s = get_state(handle); if (!s || !out) return 0;
    *out = Y26AsyncDmaStats{s->stats.sync_starts.load(), s->stats.sync_ends.load(),
        s->stats.sync_failures.load(), s->stats.dmabuf_frames.load()};
    return 1;
}

extern "C" int y26_display_register_video(void *handle, uint64_t pts, const Y26AsyncContext *context, uint32_t sequence) {
    auto s=get_state(handle); if (!s) return 0;
    auto& d=s->display;
    if (pts==GST_CLOCK_TIME_NONE || !video_context(context)) { d.stats.video_rejected.fetch_add(1);return 0; }
    std::lock_guard<std::mutex> lock(d.mutex);
    for (const auto& e:d.videos) if (e.used && e.pts==pts) {
        const bool equal=e.sequence==sequence && same(e.context,*context);
        if (!equal) { erase_lane(d,pts); d.stats.video_rejected.fetch_add(1); }
        return equal;
    }
    for (auto& e:d.videos) if (!e.used) {
        e.used=true;e.pts=pts;e.sequence=sequence;e.context=*context;++d.video_pending;
        d.stats.video_registered.fetch_add(1);return 1;
    }
    d.stats.video_rejected.fetch_add(1);return 0;
}
extern "C" int y26_display_register_lane(void *handle, uint64_t pts, const Y26AsyncContext *context,
                                        uint32_t sequence, const Y26LaneCurve *curves, uint32_t count) {
    auto s=get_state(handle);if (!s) return 0;auto& d=s->display;
    std::lock_guard<std::mutex> lock(d.mutex);
    auto reject=[&]() {erase_lane(d,pts);d.stats.lane_rejected.fetch_add(1);return 0;};
    if (pts==GST_CLOCK_TIME_NONE || !video_context(context) || count>2 || (count && !curves)) return reject();
    const DisplayVideo *video=nullptr;
    for (const auto& e:d.videos) if (e.used && e.pts==pts) {video=&e;break;}
    if (!video || video->sequence!=sequence || !same(video->context,*context)) return reject();
    for (const auto& e:d.lanes) if (e.used && e.pts==pts) return reject();
    for (unsigned c=0;c<count;++c) {
        if (curves[c].count<2 || curves[c].count>Y26_DISPLAY_MAX_CURVE_POINTS || curves[c].label>2) return reject();
        for (unsigned i=0;i<curves[c].count;++i) {
            const auto p=curves[c].points[i];
            if (p.x>=W || p.y>=H || (i && p.y<=curves[c].points[i-1].y)) return reject();
        }
    }
    for (auto& e:d.lanes) if (!e.used) {
        e.used=true;e.pts=pts;e.sequence=sequence;e.context=*context;e.count=count;
        if (count) std::copy_n(curves,count,e.curves.begin());
        ++d.lane_pending;d.stats.lane_registered.fetch_add(1);return 1;
    }
    return reject();
}
extern "C" int y26_display_clear_lane(void *handle, uint64_t pts) {
    auto s=get_state(handle);if (!s) return 0;
    std::lock_guard<std::mutex> lock(s->display.mutex);erase_lane(s->display,pts);return 1;
}
extern "C" int y26_display_stats(void *handle, Y26DisplayStats *out) {
    auto s=get_state(handle);if (!s || !out) return 0;auto& d=s->display;auto& v=d.stats;
    std::lock_guard<std::mutex> lock(d.mutex);
    *out=Y26DisplayStats{Y26_DISPLAY_ABI_VERSION,v.video_registered.load(),v.video_rejected.load(),v.video_matches.load(),v.video_misses.load(),
        v.lane_registered.load(),v.lane_rejected.load(),v.lane_matches.load(),v.lane_frames.load(),v.lane_empty.load(),v.lane_missing.load(),
        v.lane_dropped.load(),v.fps_frames.load(),v.fps_valid.load(),v.fps_tenths.load(),v.fps_total.load(),v.fps_faults.load(),
        d.video_pending,d.lane_pending};return 1;
}

// Recording taps the one post-overlay tee. Only the record branch is retimed;
// display/AI SOURCE and original PTS are untouched. No pixel map/copy here.
struct Y26RecordEvent {
    uint64_t kind, ordinal, original_pts, monotonic, pts, size, duration, flags;
};
struct Y26RecordAnchor { uint64_t ordinal, original_pts, monotonic, pts; };
struct Y26RecordMeta { GstMeta meta;Y26RecordAnchor anchor; };
static const GstMetaInfo *y26_record_meta_info();
static gboolean y26_record_meta_init(GstMeta *meta,gpointer,GstBuffer*) {
    reinterpret_cast<Y26RecordMeta*>(meta)->anchor={};return TRUE;
}
static gboolean y26_record_meta_copy(GstBuffer *dest,GstMeta *meta,GstBuffer*,GQuark type,gpointer) {
    if(!GST_META_TRANSFORM_IS_COPY(type))return FALSE;
    auto out=reinterpret_cast<Y26RecordMeta*>(gst_buffer_add_meta(dest,y26_record_meta_info(),nullptr));
    if(!out)return FALSE;
    out->anchor=reinterpret_cast<Y26RecordMeta*>(meta)->anchor;return TRUE;
}
static GType y26_record_meta_api() {
    static gsize api=0;
    if(g_once_init_enter(&api)) {
        static const gchar *tags[]={nullptr};
        GType type=g_type_from_name("Y26FinalRecordMetaAPI");
        if(!type)type=gst_meta_api_type_register("Y26FinalRecordMetaAPI",tags);
        g_once_init_leave(&api,type);
    }
    return api;
}
static const GstMetaInfo *y26_record_meta_info() {
    static const GstMetaInfo *info=nullptr;
    if(g_once_init_enter(&info)) {
        auto p=gst_meta_get_info("Y26FinalRecordMeta");
        if(!p)p=gst_meta_register(y26_record_meta_api(),"Y26FinalRecordMeta",sizeof(Y26RecordMeta),y26_record_meta_init,nullptr,y26_record_meta_copy);
        g_once_init_leave(&info,p);
    }
    return info;
}
struct Y26RecordState {
    std::mutex mutex;
    std::array<Y26RecordEvent,4096> events{};
    std::array<Y26RecordAnchor,32> pending{};
    unsigned head=0,count=0;
    uint64_t first=0,common=0,record=0,encoded=0,display=0;
    std::atomic<uint64_t> error{0},closing{0},finish_requested{0};
    GstPad *queue_sink=nullptr,*common_sink=nullptr;
    std::array<GstPad*,4> probe_pads{};
    std::array<gulong,4> probe_ids{};
    void fail(uint64_t code) { uint64_t zero=0;error.compare_exchange_strong(zero,code); }
    bool event(const Y26RecordEvent& e) {
        if(count==events.size()) { fail(1);return false; }
        events[(head+count)%events.size()]=e;++count;return true;
    }
};
static GstPadProbeReturn y26_record_common(GstPad*,GstPadProbeInfo *info,gpointer opaque) {
    auto& s=*static_cast<Y26RecordState*>(opaque);
    if(s.error.load() || s.closing.load())return GST_PAD_PROBE_DROP;
    GstBuffer *b=GST_PAD_PROBE_INFO_BUFFER(info);
    if(!b || !GST_CLOCK_TIME_IS_VALID(GST_BUFFER_PTS(b))) { s.fail(2);return GST_PAD_PROBE_DROP; }
    std::lock_guard<std::mutex> lock(s.mutex);
    if(s.error.load() || s.closing.load())return GST_PAD_PROBE_DROP;
    const uint64_t now=monotonic_ns();if(!s.first)s.first=now;
    b=gst_buffer_make_writable(b);GST_PAD_PROBE_INFO_DATA(info)=b;
    if(!b) { s.fail(11);return GST_PAD_PROBE_DROP; }
    auto meta=reinterpret_cast<Y26RecordMeta*>(gst_buffer_add_meta(b,y26_record_meta_info(),nullptr));
    if(!meta) { s.fail(12);return GST_PAD_PROBE_DROP; }
    auto a=&meta->anchor;
    *a=Y26RecordAnchor{++s.common,GST_BUFFER_PTS(b),now,now-s.first+1};
    if(!s.event(Y26RecordEvent{1,a->ordinal,a->original_pts,a->monotonic,a->pts,gst_buffer_get_size(b),0,0}))return GST_PAD_PROBE_DROP;
    return GST_PAD_PROBE_OK;
}
static GstPadProbeReturn y26_record_input(GstPad*,GstPadProbeInfo *info,gpointer opaque) {
    auto& s=*static_cast<Y26RecordState*>(opaque);
    if(s.error.load())return GST_PAD_PROBE_DROP;
    GstBuffer *b=GST_PAD_PROBE_INFO_BUFFER(info);
    auto meta=b?reinterpret_cast<Y26RecordMeta*>(gst_buffer_get_meta(b,y26_record_meta_api())):nullptr;
    if(!meta) { s.fail(3);return GST_PAD_PROBE_DROP; }
    const Y26RecordAnchor a=meta->anchor;
    // A shallow metadata copy keeps the original NV12 memory shared/read-only.
    b=gst_buffer_make_writable(b);GST_PAD_PROBE_INFO_DATA(info)=b;
    if(!b) { s.fail(4);return GST_PAD_PROBE_DROP; }
    GST_BUFFER_PTS(b)=a.pts;GST_BUFFER_DTS(b)=a.pts;GST_BUFFER_DURATION(b)=GST_CLOCK_TIME_NONE;
    std::lock_guard<std::mutex> lock(s.mutex);
    if(a.ordinal!=s.record+1) { s.fail(5);return GST_PAD_PROBE_DROP; }
    bool stored=false;
    for(auto& slot:s.pending)if(!slot.ordinal) { slot=a;stored=true;break; }
    if(!stored) { s.fail(6);return GST_PAD_PROBE_DROP; }
    ++s.record;
    if(!s.event(Y26RecordEvent{2,a.ordinal,a.original_pts,a.monotonic,a.pts,gst_buffer_get_size(b),0,0}))return GST_PAD_PROBE_DROP;
    return GST_PAD_PROBE_OK;
}
static GstPadProbeReturn y26_record_encoded(GstPad*,GstPadProbeInfo *info,gpointer opaque) {
    auto& s=*static_cast<Y26RecordState*>(opaque);
    if(s.error.load())return GST_PAD_PROBE_DROP;
    GstBuffer *b=GST_PAD_PROBE_INFO_BUFFER(info);
    if(!b || !GST_CLOCK_TIME_IS_VALID(GST_BUFFER_PTS(b)) || !gst_buffer_get_size(b)) { s.fail(7);return GST_PAD_PROBE_DROP; }
    std::lock_guard<std::mutex> lock(s.mutex);
    Y26RecordAnchor a{};
    for(auto& slot:s.pending)if(slot.ordinal && slot.pts==GST_BUFFER_PTS(b)) { a=slot;slot={};break; }
    if(!a.ordinal || a.ordinal!=s.encoded+1) { s.fail(8);return GST_PAD_PROBE_DROP; }
    ++s.encoded;
    if(!s.event(Y26RecordEvent{3,a.ordinal,a.original_pts,a.monotonic,a.pts,gst_buffer_get_size(b),GST_BUFFER_DURATION(b),GST_BUFFER_FLAGS(b)}))return GST_PAD_PROBE_DROP;
    return GST_PAD_PROBE_OK;
}
static GstPadProbeReturn y26_record_display(GstPad*,GstPadProbeInfo *info,gpointer opaque) {
    auto& s=*static_cast<Y26RecordState*>(opaque);
    GstBuffer *b=GST_PAD_PROBE_INFO_BUFFER(info);
    auto meta=b?reinterpret_cast<Y26RecordMeta*>(gst_buffer_get_meta(b,y26_record_meta_api())):nullptr;
    auto a=meta?&meta->anchor:nullptr;
    std::lock_guard<std::mutex> lock(s.mutex);
    if(!a || a->ordinal!=s.display+1) { s.fail(9);return GST_PAD_PROBE_DROP; }
    ++s.display;return GST_PAD_PROBE_OK;
}
extern "C" void *y26_record_attach(GstElement *common,GstElement *stamp,GstElement *encoded,GstElement *sink,GstElement *queue) {
    if(!common || !stamp || !encoded || !sink || !queue)return nullptr;
    GstPad *pads[]={gst_element_get_static_pad(common,"sink"),gst_element_get_static_pad(stamp,"src"),
        gst_element_get_static_pad(encoded,"src"),gst_element_get_static_pad(sink,"sink"),gst_element_get_static_pad(queue,"sink")};
    for(auto p:pads)if(!p) { for(auto q:pads)if(q)gst_object_unref(q);return nullptr; }
    auto s=new Y26RecordState();s->queue_sink=pads[4];s->common_sink=GST_PAD(gst_object_ref(pads[0]));
    GstPadProbeCallback callbacks[]={y26_record_common,y26_record_input,y26_record_encoded,y26_record_display};
    for(unsigned i=0;i<4;++i) {
        s->probe_pads[i]=pads[i];
        s->probe_ids[i]=gst_pad_add_probe(pads[i],GST_PAD_PROBE_TYPE_BUFFER,callbacks[i],s,nullptr);
    }
    // Deliberately retained with the admitted target graph. No automatic teardown.
    return s;
}
extern "C" unsigned y26_record_read(void *handle,Y26RecordEvent *out,unsigned maximum) {
    if(!handle || !out || !maximum || maximum>4096)return 0;
    auto& s=*static_cast<Y26RecordState*>(handle);std::lock_guard<std::mutex> lock(s.mutex);
    const unsigned n=std::min(maximum,s.count);
    for(unsigned i=0;i<n;++i)out[i]=s.events[(s.head+i)%s.events.size()];
    s.head=(s.head+n)%s.events.size();s.count-=n;return n;
}
extern "C" int y26_record_stats(void *handle,uint64_t *out) {
    if(!handle || !out)return 0;
    auto& s=*static_cast<Y26RecordState*>(handle);std::lock_guard<std::mutex> lock(s.mutex);
    const uint64_t values[]={1,s.error.load(),s.closing.load(),s.common,s.record,s.encoded,s.display,s.count,s.first};
    std::copy_n(values,9,out);return 1;
}
extern "C" int y26_record_fail(void *handle,uint64_t code) {
    if(!handle || !code)return 0;
    static_cast<Y26RecordState*>(handle)->fail(code);return 1;
}
static GstPadProbeReturn y26_record_end_idle(GstPad*,GstPadProbeInfo*,gpointer opaque) {
    auto& s=*static_cast<Y26RecordState*>(opaque);s.closing.store(1);
    // IDLE runs only after an in-flight tee push has queued both branches.
    if(!gst_pad_send_event(s.queue_sink,gst_event_new_eos()))s.fail(10);
    return GST_PAD_PROBE_REMOVE;
}
extern "C" int y26_record_finish(void *handle) {
    if(!handle)return 0;
    auto& s=*static_cast<Y26RecordState*>(handle);
    if(s.finish_requested.exchange(1))return 0;
    auto id=gst_pad_add_probe(s.common_sink,GST_PAD_PROBE_TYPE_IDLE,y26_record_end_idle,&s,nullptr);
    return id!=0 || s.closing.load();
}

/* Normal session rebuild only: recorder joined, all AUs sealed, graph NULL.
 * Caller serializes this with read/stats; no DMA/receiver resource is freed. */
extern "C" int y26_record_retire(void *handle,GstElement *pipeline) {
    if(!handle || !pipeline)return 0;
    auto s=static_cast<Y26RecordState*>(handle);
    GstState state,pending;
    if(!gst_object_has_as_ancestor(GST_OBJECT(s->common_sink),GST_OBJECT(pipeline)) ||
       gst_element_get_state(pipeline,&state,&pending,0)!=GST_STATE_CHANGE_SUCCESS ||
       state!=GST_STATE_NULL || pending!=GST_STATE_VOID_PENDING)return 0;
    {
        std::lock_guard<std::mutex> guard(s->mutex);
        if(s->error.load() || !s->closing.load() || !s->finish_requested.load() || s->count ||
           s->common!=s->record || s->common!=s->encoded || s->common!=s->display)return 0;
        for(const auto& slot:s->pending)if(slot.ordinal)return 0;
    }
    for(unsigned i=0;i<4;i++) {
        if(s->probe_ids[i])gst_pad_remove_probe(s->probe_pads[i],s->probe_ids[i]);
        gst_object_unref(s->probe_pads[i]);
    }
    gst_object_unref(s->queue_sink);gst_object_unref(s->common_sink);delete s;return 1;
}

#ifdef Y26_ASYNC_TESTING
extern "C" int y26_async_test_nv12_format() { return GST_VIDEO_FORMAT_NV12; }
extern "C" void y26_async_test_dma_mode(int mode) { test_dma_ioctl_mode.store(mode); }
extern "C" void y26_async_test_set_pts(GstBuffer *buffer, uint64_t pts) { GST_BUFFER_PTS(buffer) = pts; }
extern "C" int y26_async_test_process(void *handle, GstBuffer *input, GstCaps *caps, GstBuffer **output) {
    auto self = static_cast<Y26AsyncOverlay*>(handle);
    set_caps(GST_BASE_TRANSFORM(self), caps, caps);
    const auto flow = prepare(GST_BASE_TRANSFORM(self), input, output);
    // This direct test helper borrows input from the test and returns a separate
    // owned output reference. Real GstBaseTransform itself transfers ownership.
    if (flow == GST_FLOW_OK && *output == input) gst_buffer_ref(*output);
    return flow;
}
extern "C" void y26_async_test_cancel_next(void *handle) {
    if (auto s = get_state(handle)) s->cancel_before_commit.store(true);
}
extern "C" void y26_async_test_copy_counts(uint64_t *created, uint64_t *finalized) {
    *created = test_copies_created.load(); *finalized = test_copies_finalized.load();
}
extern "C" int y26_async_test_lock(void *handle, int lock) {
    auto s = get_state(handle); if (!s) return 0;
    if (lock) s->mutex.lock(); else s->mutex.unlock(); return 1;
}
#endif
