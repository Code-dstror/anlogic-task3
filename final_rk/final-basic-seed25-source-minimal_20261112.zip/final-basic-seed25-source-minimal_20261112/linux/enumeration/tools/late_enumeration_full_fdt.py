"""Read-only RK PCIe classification and explicitly admitted one-shot RC bind.

No DMA node, PCI configuration space, BAR, serial port or hardware reset is opened.
Evidence objects are operator attestations, not measurements or cryptographic proof.
See LATE_ENUMERATION.md before integrating the intentionally separate apply API.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import sys
import threading
import time
from typing import Protocol
import uuid


STATES = ("RC_DISABLED", "RC_UNBOUND", "RC_BOUND_NO_ENDPOINT", "ENDPOINT_UNBOUND",
          "ENDPOINT_DRIVER_BOUND", "UNKNOWN")
BOOT_PATH = "/proc/sys/kernel/random/boot_id"
DT_BASE = "/sys/firmware/devicetree/base"
DT_NODES = ("pcie@2a210000", "usb@23400000", "phy@2b060000")
NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}\Z")
BDF = re.compile(r"[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")


def _name(value: str) -> str:
    if type(value) is not str or not NAME.fullmatch(value) or value in (".", ".."):
        raise ValueError("invalid exact device/driver name")
    return value


def _boot(value: str) -> str:
    if type(value) is not str or str(uuid.UUID(value)) != value:
        raise ValueError("expected a canonical boot UUID")
    return value


def _short(value: str, label: str) -> None:
    if type(value) is not str or not 1 <= len(value) <= 1024 or "\0" in value:
        raise ValueError(f"{label} must be a bounded nonempty evidence reference")


def _sha(value: str) -> None:
    if type(value) is not str or not SHA.fullmatch(value):
        raise ValueError("expected lowercase SHA256")


def _json(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


@dataclass(frozen=True)
class Target:
    controller: str
    driver: str
    vendor: int
    device: int

    def __post_init__(self) -> None:
        prefix = "/sys/bus/platform/devices/"
        if type(self.controller) is not str or not self.controller.startswith(prefix):
            raise ValueError("controller must be an explicit /sys/bus/platform/devices/<name>")
        _name(self.controller[len(prefix):])
        _name(self.driver)
        for value in (self.vendor, self.device):
            if type(value) is not int or not 0 <= value <= 65535:
                raise ValueError("PCI IDs must be uint16")

    @property
    def name(self) -> str:
        return self.controller.rsplit("/", 1)[1]

    @property
    def bind_path(self) -> str:
        return f"/sys/bus/platform/drivers/{self.driver}/bind"


@dataclass(frozen=True)
class FpgaReadyEvidence:
    """FPGA-side preparation independent of RC probe, PHY, PERST or link-up.

    The unbound RC may still hold PERST asserted. Its bind/probe is responsible
    for releasing it; no pre-bind RC PHY/user-clock/link proof is required here.
    """
    boot_id: str
    controller: str
    image_sha256: str
    reference: str
    configured: bool = False
    pcie_mode_ready: bool = False
    external_refclock_ready: bool = False
    board_power_ready: bool = False
    app_disabled: bool = False


@dataclass(frozen=True)
class ColdProbeEvidence:
    """Caller-trusted operator history, including the FPGA ownership-reset lineage.

    An absent module/device or a new Linux boot cannot synthesize these assertions.
    No field is automatically populated from inspect(). A JSON file is not trusted
    merely because it exists; the operator must review and explicitly provide it.
    """
    boot_id: str
    controller: str
    evidence_id: str
    operator_attestation: str
    no_prior_dma_exposure: bool = False
    no_owner_or_quarantine: bool = False
    no_probe_in_progress: bool = False
    exclusive_control: bool = False
    autoload_policy_reviewed: bool = False
    autoload_reference: str = ""
    # None explicitly means the endpoint must remain unbound.
    allowed_endpoint_driver: str | None = None
    # Only an independently qualified profile can replace USB1=disabled.
    qualified_dt_sha256: str | None = None
    qualified_profile_reference: str = ""


class Filesystem(Protocol):
    def read(self, path: str, maximum: int) -> bytes: ...
    def exists(self, path: str) -> bool: ...
    def resolve(self, path: str) -> str: ...
    def children(self, path: str, maximum: int) -> list[str]: ...


class Clock(Protocol):
    def monotonic(self) -> float: ...
    def sleep(self, seconds: float) -> None: ...


class Writer(Protocol):
    def write_bind(self, target: Target) -> int: ...


class SysFilesystem:
    """Bounded metadata reads; deliberately has no generic write method."""
    def read(self, path: str, maximum: int) -> bytes:
        # kernfs may return one page per raw read even before EOF. Buffered
        # read completes those short chunks while retaining the size bound.
        with open(path, "rb") as stream:
            data = stream.read(maximum + 1)
        if len(data) > maximum:
            raise ValueError(f"metadata exceeds bound: {path}")
        return data

    def exists(self, path: str) -> bool:
        return os.path.lexists(path)

    def resolve(self, path: str) -> str:
        return str(Path(path).resolve(strict=True))

    def children(self, path: str, maximum: int) -> list[str]:
        names = []
        with os.scandir(path) as entries:
            for entry in entries:
                names.append(entry.name)
                if len(names) > maximum:
                    raise ValueError(f"directory exceeds bound: {path}")
        return sorted(names)


class MonotonicClock:
    monotonic = staticmethod(time.monotonic)
    sleep = staticmethod(time.sleep)


class SysfsBindWriter:
    def write_bind(self, target: Target) -> int:
        # No shell, no arbitrary sysfs attribute, no short-write retry.
        if sys.platform != "linux":
            raise RuntimeError("real bind is Linux-only")
        directory = target.bind_path.rsplit("/", 1)[0]
        if str(Path(directory).resolve(strict=True)) != directory:
            raise ValueError("driver directory changed or contains symlink aliases")
        flags = os.O_WRONLY | os.O_CLOEXEC | os.O_NOFOLLOW
        fd = os.open(target.bind_path, flags)
        try:
            return os.write(fd, target.name.encode("ascii"))
        finally:
            os.close(fd)


@dataclass(frozen=True)
class PciDevice:
    bdf: str
    path: str
    vendor: int
    device: int
    class_code: int
    driver: str | None
    link_speed: str
    link_width: str

    @property
    def bridge(self) -> bool:
        return self.class_code >> 16 == 6

    @property
    def link_observed(self) -> bool:
        speed = re.match(r"([0-9]+(?:\.[0-9]+)?) GT/s(?: PCIe)?\Z", self.link_speed)
        return bool(speed and float(speed[1]) > 0 and self.link_width.isdecimal()
                    and 1 <= int(self.link_width) <= 32)


@dataclass(frozen=True)
class Snapshot:
    state: str
    boot_id: str | None
    dt_sha256: str | None
    fdt_sha256: str | None
    pcie_status: str | None
    usb1_status: str | None
    controller_realpath: str | None
    controller_driver: str | None
    driver_available: bool
    pci_devices: tuple[PciDevice, ...]
    probe_threads: tuple[int, ...]
    modules: tuple[str, ...]
    issues: tuple[str, ...]


def inspect(target: Target, *, filesystem: Filesystem | None = None) -> Snapshot:
    """Read only. Classification is not DMA admission or an absence-of-owner proof."""
    fs = filesystem or SysFilesystem()
    issues: list[str] = []
    boot_id = dt_hash = fdt_hash = pcie_status = usb1_status = root = driver = None
    available = False
    nodes: list[PciDevice] = []
    threads: list[int] = []
    modules: tuple[str, ...] = ()

    def text(path: str, maximum: int = 4096) -> str:
        return fs.read(path, maximum).decode("ascii").rstrip("\0\n")

    def driver_at(path: str, bus: str) -> str | None:
        if not fs.exists(path + "/driver"):
            return None
        resolved = fs.resolve(path + "/driver")
        prefix = f"/sys/bus/{bus}/drivers/"
        if not resolved.startswith(prefix):
            raise ValueError("driver symlink outside expected bus")
        return _name(resolved[len(prefix):])

    try:
        boot_id = _boot(text(BOOT_PATH, 64))
        fdt_hash = hashlib.sha256(fs.read("/sys/firmware/fdt", 2 * 1024 * 1024)).hexdigest()
        properties: dict[str, dict[str, str | None]] = {}
        for node in DT_NODES:
            directory = f"{DT_BASE}/{node}"
            if not fs.exists(directory):
                raise ValueError(f"active DT node missing: {node}")
            properties[node] = {}
            for prop in ("status", "compatible"):
                path = f"{directory}/{prop}"
                properties[node][prop] = fs.read(path, 4096).hex() if fs.exists(path) else None
        def status(node: str) -> str | None:
            value = properties[node]["status"]
            return bytes.fromhex(value).decode("ascii").rstrip("\0\n") if value else None
        pcie_status, usb1_status = status(DT_NODES[0]), status(DT_NODES[1])
        dt_hash = hashlib.sha256(_json({"fdt_sha256": fdt_hash, "active": properties})).hexdigest()
        if fs.exists(target.controller):
            root = fs.resolve(target.controller)
            if not root.startswith("/sys/devices/") or "/../" in root:
                raise ValueError("controller symlink outside /sys/devices")
            if fs.resolve(target.controller + "/of_node") != f"{DT_BASE}/{DT_NODES[0]}":
                raise ValueError("controller does not reference the expected active PCIe DT node")
            driver = driver_at(target.controller, "platform")
        bind_directory = target.bind_path.rsplit("/", 1)[0]
        available = fs.exists(target.bind_path) and fs.resolve(bind_directory) == bind_directory
        # Resolve every bounded PCI entry before filtering: an unreadable topology
        # cannot be silently treated as an empty selected controller subtree.
        for name in fs.children("/sys/bus/pci/devices", 512):
            if not BDF.fullmatch(name):
                raise ValueError("unexpected PCI directory entry")
            path = "/sys/bus/pci/devices/" + name
            resolved = fs.resolve(path)
            if not resolved.startswith("/sys/devices/"):
                raise ValueError("PCI device outside /sys/devices")
            if root and resolved.startswith(root + "/"):
                nodes.append(PciDevice(name, resolved, int(text(path + "/vendor"), 16),
                                       int(text(path + "/device"), 16), int(text(path + "/class"), 16),
                                       driver_at(path, "pci"),
                                       text(path + "/current_link_speed", 128) if fs.exists(path + "/current_link_speed") else "",
                                       text(path + "/current_link_width", 32) if fs.exists(path + "/current_link_width") else ""))
        # The known RK threaded initializer is a kernel task named rk-pcie.
        # Absence is only supporting metadata; admission still requires an explicit
        # exclusive operator assertion that no probe is underway.
        for pid in fs.children("/proc", 4096):
            if pid.isdecimal():
                try:
                    if text(f"/proc/{pid}/comm", 256) == "rk-pcie":
                        threads.append(int(pid))
                except FileNotFoundError:
                    pass  # A task that exits during this non-atomic observation.
        module_lines = text("/proc/modules", 256 * 1024).splitlines()
        modules = tuple(_name(line.split()[0]) for line in module_lines if line.strip())
        if _boot(text(BOOT_PATH, 64)) != boot_id:
            raise ValueError("boot changed during observation")
    except (OSError, ValueError, UnicodeError) as exc:
        issues.append(str(exc)[:512])

    endpoints = [node for node in nodes if not node.bridge]
    matched = [node for node in endpoints if (node.vendor, node.device) == (target.vendor, target.device)]
    if issues:
        state = "UNKNOWN"
    elif pcie_status == "disabled" and not driver and not nodes:
        state = "RC_DISABLED"
    elif pcie_status not in ("okay", "ok") or not root:
        state = "UNKNOWN"
    elif not driver:
        state = "RC_UNBOUND" if not nodes else "UNKNOWN"
    elif driver != target.driver:
        state = "UNKNOWN"
    elif not endpoints:
        state = "RC_BOUND_NO_ENDPOINT"
    elif len(endpoints) != 1 or len(matched) != 1:
        state = "UNKNOWN"
    else:
        state = "ENDPOINT_DRIVER_BOUND" if matched[0].driver else "ENDPOINT_UNBOUND"
    return Snapshot(state, boot_id, dt_hash, fdt_hash, pcie_status, usb1_status, root,
                    driver, available, tuple(nodes), tuple(threads), modules, tuple(issues))


@dataclass(frozen=True)
class Plan:
    snapshot: Snapshot
    admitted: bool
    missing: tuple[str, ...]
    notes: tuple[str, ...]


def plan(target: Target, *, expected_boot_id: str | None = None,
         fpga: FpgaReadyEvidence | None = None, cold: ColdProbeEvidence | None = None,
         filesystem: Filesystem | None = None, snapshot: Snapshot | None = None) -> Plan:
    sample = snapshot or inspect(target, filesystem=filesystem)
    missing: list[str] = []
    if expected_boot_id is None or sample.boot_id != _boot(expected_boot_id):
        missing.append("explicit expected_boot_id must equal current boot")
    if sample.state != "RC_UNBOUND" or sample.controller_driver is not None or sample.pci_devices:
        missing.append("controller must be unbound with no PCI subtree devices")
    if not sample.driver_available:
        missing.append("selected registered platform driver bind attribute is unavailable")
    if sample.pcie_status != "okay" or sample.dt_sha256 is None:
        missing.append("active PCIe DT status must be explicit okay with measured DT identity")
    if sample.probe_threads or sample.issues:
        missing.append("observation incomplete or RK probe task still present")
    if fpga is None:
        missing.append("FPGA preparation evidence absent; link-up is insufficient")
    else:
        _boot(fpga.boot_id)
        _sha(fpga.image_sha256)
        _short(fpga.reference, "FPGA reference")
        if fpga.boot_id != sample.boot_id or fpga.controller != target.controller:
            missing.append("FPGA evidence boot/controller mismatch")
        if any(value is not True for value in (fpga.configured, fpga.pcie_mode_ready,
                                               fpga.external_refclock_ready, fpga.board_power_ready, fpga.app_disabled)):
            missing.append("FPGA configured/PCIe-mode/external-refclock/board-power/APP-disabled preparation incomplete")
    if cold is None:
        missing.append("ColdProbeEvidence absent: prior DMA exposure/owner/probe/autoload UNKNOWN")
    else:
        _boot(cold.boot_id)
        _short(cold.evidence_id, "evidence_id")
        _short(cold.operator_attestation, "operator attestation")
        if cold.boot_id != sample.boot_id or cold.controller != target.controller:
            missing.append("cold attestation boot/controller mismatch")
        if any(value is not True for value in (cold.no_prior_dma_exposure, cold.no_owner_or_quarantine,
                                               cold.no_probe_in_progress, cold.exclusive_control)):
            missing.append("never-exposed, no owner/quarantine, probe-idle and exclusive-control attestation required")
        if cold.autoload_policy_reviewed is not True or not cold.autoload_reference:
            missing.append("endpoint autoload policy has not been explicitly reviewed")
        else:
            _short(cold.autoload_reference, "autoload reference")
        if cold.allowed_endpoint_driver is not None:
            _name(cold.allowed_endpoint_driver)
        if cold.qualified_dt_sha256 is not None:
            _sha(cold.qualified_dt_sha256)
            _short(cold.qualified_profile_reference, "qualified hardware profile")
    qualified = (cold is not None and cold.qualified_dt_sha256 is not None
                 and cold.qualified_dt_sha256 == sample.dt_sha256
                 and bool(cold.qualified_profile_reference))
    if sample.usb1_status != "disabled" and not qualified:
        missing.append("entire conflicting USB1 must be disabled or an exact qualified DT profile supplied")
    return Plan(sample, not missing, tuple(missing), (
        "No endpoint/module does not prove no previous DMA exposure; ownership history stays UNKNOWN without attestation.",
        "Autoload/udev policy must be reviewed; enumeration can bind a PCI driver automatically.",
        "A bind return/temporary controller driver link is not asynchronous enumeration completion.",
        "This is cold late enumeration only, never recovery of an exposed or quarantined DMA owner.",
    ))


class ReceiptStore:
    """Persistent one-request-per-boot/controller journal; never deletes receipts.

    The operator must keep one authoritative directory, including across process
    restarts. An existing receipt blocks every subsequent apply in that scope.
    """
    def __init__(self, directory: str | Path):
        self.directory = Path(directory).absolute()

    def _path(self, target: Target, boot_id: str) -> Path:
        if self.directory.is_symlink() or self.directory.resolve() != self.directory:
            raise ValueError("receipt directory must have no symlink aliases")
        if not self.directory.is_dir():
            raise ValueError("explicit receipt directory must already exist")
        key = hashlib.sha256(_json([boot_id, target.controller])).hexdigest()
        return self.directory / (key + ".json")

    def existing(self, target: Target, boot_id: str) -> bool:
        return os.path.lexists(self._path(target, boot_id))

    def create(self, target: Target, boot_id: str, receipt: dict) -> Path:
        path = self._path(target, boot_id)
        with path.open("xb") as stream:
            stream.write(_json(receipt))
            stream.flush()
            os.fsync(stream.fileno())
        return path

    def update(self, path: Path, receipt: dict) -> None:
        if path.parent != self.directory or path.is_symlink():
            raise ValueError("receipt path changed")
        # Keep the fixed lock file in place. A crash during this update leaves a
        # malformed existing journal that still blocks another apply.
        with path.open("r+b") as stream:
            stream.seek(0)
            stream.write(_json(receipt))
            stream.truncate()
            stream.flush()
            os.fsync(stream.fileno())


def explicit_apply(target: Target, *, expected_boot_id: str, fpga: FpgaReadyEvidence,
                   cold: ColdProbeEvidence, receipt_store: ReceiptStore, timeout_s: float,
                   execute: bool = False, filesystem: Filesystem | None = None,
                   clock: Clock | None = None, writer: Writer | None = None,
                   poll_s: float = 0.05) -> dict:
    """Execute at most one bind write after a second full admission snapshot.

    A deadline also bounds waiting for a blocked write. Such a syscall is not
    cancellable here; the daemon writer may still be in the kernel and the receipt
    remains UNKNOWN_PENDING. No outcome here authorizes freeing DMA resources.
    """
    if type(timeout_s) not in (int, float) or not math.isfinite(timeout_s) or not 0 < timeout_s <= 120:
        raise ValueError("timeout_s must be explicit and in (0, 120]")
    if type(poll_s) not in (int, float) or not math.isfinite(poll_s) or not 0.005 <= poll_s <= 0.5:
        raise ValueError("poll_s must be in [0.005, 0.5]")
    fs, timer = filesystem or SysFilesystem(), clock or MonotonicClock()
    first = plan(target, expected_boot_id=expected_boot_id, fpga=fpga, cold=cold, filesystem=fs)
    if not execute:
        return {"status": "PLAN_ONLY", "plan": asdict(first), "write_count": 0}
    if execute is not True:
        raise ValueError("execute must be exactly True")
    if not first.admitted:
        raise ValueError("apply denied: " + "; ".join(first.missing))
    if receipt_store.existing(target, expected_boot_id):
        raise FileExistsError("a request receipt already exists for this boot/controller; no retry")
    second = plan(target, expected_boot_id=expected_boot_id, fpga=fpga, cold=cold, filesystem=fs)
    if (not second.admitted or second.snapshot.dt_sha256 != first.snapshot.dt_sha256
            or second.snapshot.controller_realpath != first.snapshot.controller_realpath):
        raise ValueError("apply denied: boot/DT/controller or admission changed before write")
    receipt = {"schema": 1, "status": "REQUESTED", "write_count": 0,
               "target": asdict(target), "boot_id": expected_boot_id,
               "dt_sha256": second.snapshot.dt_sha256, "fpga": asdict(fpga), "cold": asdict(cold),
               "ownership": "NO_DMA_SAFETY_OR_RECLAIM_PROOF", "snapshot": asdict(second.snapshot)}
    path = receipt_store.create(target, expected_boot_id, receipt)
    deadline = timer.monotonic() + timeout_s
    # The writer cannot update the journal after the caller times out.
    result: list[object] = []
    done = threading.Event()

    def issue_once() -> None:
        try:
            result.append((writer or SysfsBindWriter()).write_bind(target))
        except BaseException as exc:
            result.append(exc)
        finally:
            done.set()

    receipt["write_count"] = 1  # request issued, including an unknown/failed syscall
    receipt_store.update(path, receipt)
    worker = threading.Thread(target=issue_once, name="task3-one-rc-bind", daemon=True)
    worker.start()

    def finish(status: str, reason: str, sample: Snapshot | None = None) -> dict:
        receipt.update(status=status, reason=reason)
        if sample is not None:
            receipt["snapshot"] = asdict(sample)
        receipt_store.update(path, receipt)
        return dict(receipt, receipt_path=str(path))

    while not done.is_set():
        remaining = deadline - timer.monotonic()
        if remaining <= 0:
            return finish("UNKNOWN_PENDING", "bind write has not returned; no cancellation or retry")
        timer.sleep(min(poll_s, remaining))
    if isinstance(result[0], BaseException):
        return finish("FAILED", f"bind write error; effects unknown: {result[0]}"[:512])
    receipt["bind_return_bytes"] = result[0]
    if result[0] != len(target.name.encode("ascii")):
        return finish("FAILED", "short/invalid bind write return; no retry")
    last_sample = second.snapshot
    while timer.monotonic() < deadline:
        sample = inspect(target, filesystem=fs)
        last_sample = sample
        if sample.boot_id != expected_boot_id or sample.dt_sha256 != second.snapshot.dt_sha256:
            return finish("UNKNOWN_PENDING", "boot/DT changed; retain and review", sample)
        if sample.controller_driver not in (None, target.driver):
            return finish("ERROR_RETAIN", "unexpected controller driver; no unbind", sample)
        endpoints = [node for node in sample.pci_devices if not node.bridge]
        if any(node.driver is not None and node.driver != cold.allowed_endpoint_driver for node in endpoints):
            return finish("ERROR_RETAIN", "endpoint automatically bound unexpected driver; retain, never unbind", sample)
        if len(endpoints) > 1 or any((node.vendor, node.device) != (target.vendor, target.device) for node in endpoints):
            return finish("ERROR_RETAIN", "unexpected/ambiguous endpoint topology; retain", sample)
        if (not sample.issues and not sample.probe_threads and sample.controller_driver == target.driver
                and len(endpoints) == 1 and endpoints[0].link_observed
                and endpoints[0].driver == cold.allowed_endpoint_driver):
            return finish("COMPLETED_ENUMERATION_ONLY", "controller, unique endpoint topology, link and driver state observed; no DMA test", sample)
        timer.sleep(min(poll_s, max(0.0, deadline - timer.monotonic())))
    return finish("UNKNOWN_PENDING", "enumeration deadline expired; async probe may remain active; no retry", last_sample)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", nargs="?", choices=("inspect", "plan", "apply"), default="inspect")
    parser.add_argument("--controller", required=True)
    parser.add_argument("--driver", required=True)
    parser.add_argument("--vendor", required=True, type=lambda value: int(value, 0))
    parser.add_argument("--device", required=True, type=lambda value: int(value, 0))
    parser.add_argument("--expected-boot-id")
    parser.add_argument("--evidence", help="explicit reviewed JSON with fpga and cold attestations")
    parser.add_argument("--receipt-dir", help="existing authoritative persistent directory; apply only")
    parser.add_argument("--timeout-s", type=float, help="explicit apply observation budget, 0 < seconds <= 120")
    parser.add_argument("--execute-bind", action="store_true", help="required in addition to action=apply")
    args = parser.parse_args(argv)
    if sys.platform != "linux":
        parser.error("host inspection/apply is Linux-only; --help and mock tests are portable")
    try:
        target = Target(args.controller, args.driver, args.vendor, args.device)
        fpga = cold = None
        if args.evidence:
            # No model, credential, SDK or command is loaded from the evidence.
            raw = SysFilesystem().read(args.evidence, 16384)
            evidence = json.loads(raw)
            if type(evidence) is not dict or set(evidence) != {"fpga", "cold"}:
                raise ValueError("evidence JSON must contain exactly fpga and cold objects")
            fpga, cold = FpgaReadyEvidence(**evidence["fpga"]), ColdProbeEvidence(**evidence["cold"])
        if args.action == "inspect":
            if args.execute_bind:
                raise ValueError("--execute-bind is only valid with explicit apply")
            output = asdict(inspect(target))
        elif args.action == "plan":
            if args.execute_bind:
                raise ValueError("plan never executes a bind")
            output = asdict(plan(target, expected_boot_id=args.expected_boot_id, fpga=fpga, cold=cold))
        else:
            if not all((args.execute_bind, args.expected_boot_id, fpga, cold, args.receipt_dir, args.timeout_s)):
                raise ValueError("apply requires --execute-bind, boot, reviewed evidence, receipt directory and timeout")
            output = explicit_apply(target, expected_boot_id=args.expected_boot_id, fpga=fpga, cold=cold,
                                    receipt_store=ReceiptStore(args.receipt_dir), timeout_s=args.timeout_s, execute=True)
        print(json.dumps(output, indent=2, sort_keys=True, allow_nan=False))
        return 0 if output.get("status") not in ("UNKNOWN_PENDING", "FAILED", "ERROR_RETAIN") else 2
    except (OSError, ValueError, TypeError) as exc:
        parser.error(str(exc))
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
