#!/usr/bin/env python3
"""RK3576 J4/USB0 + EC200A: 手动恢复4G，Python标准库，无自启动配置。

板端用法：python3 /userdata/4g/recover_4g.py
沿用模组CID 1的APN及系统现有DHCP配置；只执行一次临时ECM拨号。
"""

import argparse
import copy
import fcntl
import json
import os
from pathlib import Path
import re
import select
import shutil
import subprocess
import sys
import termios
import time
import tty


class RecoveryError(RuntimeError):
    pass


def log(message):
    print(message, flush=True)


def run(argv, timeout=5):
    return subprocess.run(argv, capture_output=True, text=True, timeout=timeout)


def discover(sysroot=Path('/sys'), devroot=Path('/dev')):
    """按USB0控制器、VID/PID和接口名发现设备，不依赖tty/网卡编号。"""
    found = []
    for usb in (sysroot / 'bus/usb/devices').glob('*'):
        try:
            if (usb / 'idVendor').read_text().strip() != '2c7c':
                continue
            if (usb / 'idProduct').read_text().strip() != '6005':
                continue
            if '23000000.usb' not in usb.resolve().parts:
                continue
            at_interfaces = [p.resolve() for p in usb.glob(usb.name + ':*')
                             if (p / 'interface').exists()
                             and ' AT ' in ' ' + (p / 'interface').read_text().upper() + ' ']
            ports = {devroot / p.name for p in (sysroot / 'class/tty').glob('ttyUSB*')
                     if any(i in p.resolve().parents for i in at_interfaces)
                     and (devroot / p.name).exists()}
            nets = {p.name for p in (sysroot / 'class/net').glob('*')
                    if usb.resolve() in p.resolve().parents}
            if len(ports) == 1 and len(nets) == 1:
                found.append((ports.pop(), nets.pop()))
        except FileNotFoundError:
            continue  # USB枚举/拔插可能正在进行。
    if len(found) > 1:
        raise RecoveryError('USB0上发现多个EC200A，停止以避免选错设备。')
    return found[0] if found else None


class ATPort:
    def __init__(self, path):
        self.path = path
        self.fd = None
        self.original = None
        self.exclusive = False

    def __enter__(self):
        busy = run(['fuser', str(self.path)])
        if busy.returncode != 1 or busy.stderr.strip():
            raise RecoveryError('AT串口被占用或无法确认空闲：' + str(self.path))
        self.fd = os.open(self.path, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.ioctl(self.fd, termios.TIOCEXCL)
            self.exclusive = True
            self.original = copy.deepcopy(termios.tcgetattr(self.fd))
            tty.setraw(self.fd)
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *_):
        if self.fd is not None:
            try:
                if self.original is not None:
                    termios.tcsetattr(self.fd, termios.TCSANOW, self.original)
            finally:
                try:
                    if self.exclusive:
                        fcntl.ioctl(self.fd, termios.TIOCNXCL)
                finally:
                    os.close(self.fd)
                    self.fd = None
                    self.exclusive = False

    def command(self, command, timeout=3):
        # 丢弃前一次命令之后到达的URC，随后仍通过查询确认实际状态。
        drain_end = time.monotonic() + .2
        while time.monotonic() < drain_end and select.select([self.fd], [], [], 0)[0]:
            if not os.read(self.fd, 8192):
                raise RecoveryError('AT串口断开。')
        payload = (command + '\r').encode('ascii')
        deadline = time.monotonic() + timeout
        while payload:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise RecoveryError(command + ' 写入超时。')
            if select.select([], [self.fd], [], min(.2, remaining))[1]:
                payload = payload[os.write(self.fd, payload):]
        data = b''
        while time.monotonic() < deadline:
            if not select.select([self.fd], [], [], min(.2, max(0, deadline - time.monotonic())))[0]:
                continue
            chunk = os.read(self.fd, 8192)
            if not chunk:
                raise RecoveryError('AT串口断开。')
            data += chunk
            if len(data) > 65536:
                raise RecoveryError('AT响应超长。')
            text = data.decode('ascii', errors='replace')
            lines = [line.strip() for line in text.splitlines()]
            if any(line == 'ERROR' or line.startswith(('+CME ERROR:', '+CMS ERROR:')) for line in lines):
                raise RecoveryError(command + ' 返回错误：' + text.strip())
            if re.search(rb'(?:^|[\r\n])OK\r?\n', data):
                return text
        raise RecoveryError(command + ' 响应超时。')


def connection_state(response):
    match = re.search(r'\+QNETDEVCTL:\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([01])\s*(?:\r?$)', response, re.M)
    if not match:
        raise RecoveryError('无法解析USB数据连接状态：' + response.strip())
    return tuple(map(int, match.groups()))


def connect(at, deadline):
    if 'EC200A' not in at.command('AT+GMM'):
        raise RecoveryError('模组型号不是EC200A，停止。')
    while True:
        try:
            pin = at.command('AT+CPIN?')
        except RecoveryError as exc:
            if '+CME ERROR: 14' not in str(exc) and 'SIM busy' not in str(exc):
                raise
            pin = ''
        if '+CPIN: READY' in pin:
            registration = at.command('AT+CEREG?')
            match = re.search(r'\+CEREG:\s*\d+\s*,\s*(\d+)\b', registration)
            if match and match.group(1) in ('1', '5'):
                break
            if match and match.group(1) == '3':
                raise RecoveryError('运营商拒绝注册，请核对SIM激活及使用限制。')
        elif re.search(r'\+CPIN:\s*(?:SIM PIN|SIM PUK|PH-)', pin):
            raise RecoveryError('SIM需要解锁：' + pin.strip())
        if time.monotonic() >= deadline:
            raise RecoveryError('等待SIM/LTE注册超时，请检查卡和天线。')
        log('等待SIM就绪及LTE注册……')
        time.sleep(1)
    state = connection_state(at.command('AT+QNETDEVCTL?'))
    if state[3] == 1:
        if state[1] != 1:
            raise RecoveryError('模组已连接其他CID，保留现有连接并停止。')
        log('ECM已经连接，保留当前连接。')
        return
    log('沿用CID 1的APN，发起一次临时ECM拨号……')
    at.command('AT+QNETDEVCTL=1,1,1')
    while True:
        state = connection_state(at.command('AT+QNETDEVCTL?'))
        if state[3] == 1 and state[1] == 1:
            log('ECM拨号成功。')
            return
        if time.monotonic() >= deadline:
            raise RecoveryError('ECM拨号未成功，请核对该SIM的APN及数据业务。')
        time.sleep(1)


def recover(wait_seconds, *, defer_https=False):
    for name in ('ip', 'curl', 'fuser'):
        if shutil.which(name) is None:
            raise RecoveryError('缺少现有命令：' + name + '；脚本不会安装软件。')
    deadline = time.monotonic() + wait_seconds
    mode = Path('/sys/kernel/debug/usb/23000000.usb/mode')
    if mode.exists() and mode.read_text().strip() != 'host':
        log('切换USB0到Host（本次运行生效）……')
        mode.write_text('host\n')
    while True:
        device = discover()
        if device:
            break
        if time.monotonic() >= deadline:
            raise RecoveryError('未发现USB0上的EC200A AT接口及网卡，请检查J4接线、供电和USB0 Host状态。')
        time.sleep(.5)
    port, interface = device
    log('已发现 AT口=' + str(port) + '，网卡=' + interface)
    with ATPort(port) as at:
        connect(at, deadline)
    while True:
        addresses = run(['ip', '-j', '-4', 'addr', 'show', 'dev', interface])
        ipv4 = [a['local'] for d in json.loads(addresses.stdout or '[]')
                for a in d.get('addr_info', []) if a.get('scope') == 'global']
        if ipv4:
            break
        if time.monotonic() >= deadline:
            raise RecoveryError('ECM已连接，但系统未取得IPv4地址，请检查现有NetworkManager/DHCP配置。')
        time.sleep(1)
    log('USB网卡IPv4：' + ', '.join(ipv4))
    route = run(['ip', '-4', 'route', 'get', '223.5.5.5'])
    log('当前默认出口：' + route.stdout.strip())
    if shutil.which('ping'):
        ping = run(['ping', '-I', interface, '-c', '3', '-W', '2', '223.5.5.5'], timeout=10)
        log(ping.stdout.strip())
    if defer_https:
        # The reproduction entry checks independent NTP references and then
        # performs the same interface-bound strict TLS check. Never use -k.
        log('4G数据连接就绪；HTTPS待校时后验证。')
        return
    # 绑定USB接口并禁用环境代理，避免由其他网卡或代理误判为4G成功。
    check = run(['curl', '--noproxy', '*', '--interface', interface,
                 '--silent', '--show-error', '--head', '--output', '/dev/null',
                 '--write-out', '%{http_code}', '--connect-timeout', '5',
                 '--max-time', '12', 'https://www.baidu.com'], timeout=15)
    if check.returncode or not re.fullmatch(r'[23]\d\d', check.stdout.strip()):
        raise RecoveryError('ECM已连接，但HTTPS检查失败：' + check.stderr.strip() + ' HTTP=' + check.stdout.strip())
    log('4G联网恢复成功：USB接口HTTPS返回 ' + check.stdout.strip())
    if not re.search(r'\bdev\s+' + re.escape(interface) + r'\b', route.stdout):
        log('提示：当前默认路由指向其他接口；本次4G请求已绑定USB接口验证。')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wait-seconds', type=float, default=90,
                        help='等待USB枚举、SIM注册、ECM及DHCP的总预算，默认90秒')
    parser.add_argument('--defer-https', action='store_true',
                        help='仅供复现入口：先建立数据连接，由入口校时后严格验证HTTPS')
    args = parser.parse_args(argv)
    if not 1 <= args.wait_seconds <= 600:
        parser.error('--wait-seconds 应为1～600秒')
    try:
        if os.geteuid() != 0:
            raise RecoveryError('请在RK的root终端运行此命令。')
        with open('/run/lock/rk4g-ec200a.lock', 'a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            recover(args.wait_seconds, defer_https=args.defer_https)
        return 0
    except (RecoveryError, OSError, subprocess.SubprocessError, ValueError) as exc:
        print('4G恢复未完成：' + str(exc), file=sys.stderr, flush=True)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
