"""Bounded viewer for peer-owned JPEG indexes; no native/BAR/reset access.

Reuses the existing gst_observer executable and factory MPP/X11 pipeline.
New frames only. Retains the player and its input on all outcomes, no EOS/kill.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import threading
import time


def latest_frame(records):
    indexes = sorted(Path(records).glob('seg-*/frames.jsonl'))
    if not indexes:
        return None
    index = indexes[-1]
    try:
        with index.open('rb') as stream:
            stream.seek(0, 2)
            stream.seek(max(0, stream.tell()-16384))
            lines = stream.read(16384).split(b'\n')[:-1]
        for line in reversed(lines):
            try:
                row = json.loads(line)
            except (ValueError, UnicodeError):
                continue
            size, offset = row['length'], row['offset']
            if type(size) is not int or not 4 <= size <= 4194304 or type(offset) is not int or offset < 0:
                raise ValueError('invalid bounded JPEG index')
            if (row['width'], row['height']) != (1920, 1080):
                raise ValueError('unexpected video geometry')
            with (index.parent/'video.mjpeg').open('rb') as stream:
                stream.seek(offset)
                body = stream.read(size)
            if len(body) != size or hashlib.sha256(body).hexdigest() != row['jpeg_sha256']:
                raise ValueError('complete published JPEG differs from index')
            header = bytes.fromhex(row['wire_header_hex'])
            if len(header) != 448 or hashlib.sha256(header+body).hexdigest() != row['wire_sha256']:
                raise ValueError('AJPG identity differs from preserved header and JPEG')
            return row, body, header
    except FileNotFoundError:
        return None  # The recorder may evict its own older sealed segment.
    return None


def write_bounded(fd, body, *, timeout=2, clock=time.monotonic, writer=os.write, waiter=select.select):
    deadline = clock()+timeout
    offset = 0
    while offset < len(body):
        remaining = deadline-clock()
        if remaining <= 0:
            raise TimeoutError('JPEG pipe deadline; partial_bytes='+str(offset))
        if not waiter([], [fd], [], min(.05, remaining))[1]:
            continue
        try:
            count = writer(fd, memoryview(body)[offset:])
        except BlockingIOError:
            continue
        if count <= 0:
            raise RuntimeError('JPEG pipe returned zero write')
        offset += count
    return offset


def atomic_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False)+'\n')
    temp.replace(path)


class ObserverLog:
    def __init__(self, process, output):
        self.process, self.output = process, output
        self.ready = threading.Event()
        self.failure = None
        self.counts, self.last_ns = [0, 0], [None, None]
        self.log_bytes = 0
        self.last_heartbeat = None
        self.clock_seen = False
        self.paused = False
        self.stop_reading = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)

    def extra_line(self, line):
        pass

    def run(self):
        pending = b''
        try:
            with self.output.open('xb', buffering=0) as stream:
                while not self.stop_reading.is_set():
                    if not select.select([self.process.stdout.fileno()], [], [], .1)[0]:
                        continue
                    block = os.read(self.process.stdout.fileno(), 8192)
                    if not block:
                        raise RuntimeError('observer output ended')
                    self.log_bytes += len(block)
                    if self.log_bytes > 32*1024*1024:
                        raise RuntimeError('observer log exceeds 32MiB budget')
                    stream.write(block)
                    pending += block
                    lines = pending.split(b'\n')
                    pending = lines.pop()
                    if len(pending) > 8192:
                        raise RuntimeError('observer line over budget')
                    for line in lines:
                        self.extra_line(line)
                        if line == b'Setting pipeline to PAUSED ...':
                            self.paused = True
                        if line == b'Pipeline is PREROLLING ...' and self.paused:
                            self.ready.set()
                        if line.startswith(b'ERROR:'):
                            self.failure = line.decode(errors='replace')[:512]
                        parts = line.split()
                        if parts[:3] == [b'R5D1', b'CLOCK', b'CLOCK_MONOTONIC']:
                            if len(parts) != 5 or int(parts[4]) != self.process.pid or self.clock_seen:
                                raise ValueError('observer clock identity')
                            self.clock_seen = True
                        elif parts[:2] == [b'R5D1', b'E']:
                            if len(parts) != 5:
                                raise ValueError('observer event format')
                            channel, count, ns = map(int, parts[2:])
                            if channel not in (0, 1) or count != self.counts[channel]+1:
                                raise ValueError('observer event loss')
                            if self.last_ns[channel] is not None and ns < self.last_ns[channel]:
                                raise ValueError('observer clock regression')
                            self.counts[channel], self.last_ns[channel] = count, ns
                        elif parts[:2] == [b'R5D1', b'H']:
                            if len(parts) != 10:
                                raise ValueError('observer heartbeat format')
                            values = list(map(int, parts[2:]))
                            if any(values[3:]):
                                raise ValueError('observer callback/ring/output error')
                            self.last_heartbeat = time.monotonic_ns()
        except BaseException as error:
            self.failure = self.failure or type(error).__name__+': '+str(error)[:512]


def run(args):
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != args.expected_boot:
        raise ValueError('actual boot differs')
    if hashlib.sha256(args.observer.read_bytes()).hexdigest() != args.observer_sha256:
        raise ValueError('observer differs')
    spec = json.loads(args.display_baseline.read_text())
    for item in spec['plugin_files']:
        if hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('system plugin differs: '+item['path'])
    parents = {str(Path(item['path']).parent) for item in spec['plugin_files']}
    if len(parents) != 1:
        raise ValueError('fixed system plugin directory required')
    args.output.mkdir(exist_ok=False)
    env = {k:os.environ[k] for k in ('HOME','USER','LOGNAME','XDG_RUNTIME_DIR') if k in os.environ}
    registry = str(args.output/'gst-registry.bin')
    env.update(PATH='/usr/bin:/bin', DISPLAY=spec['display'], XAUTHORITY=spec['xauthority'],
        GST_PLUGIN_PATH='', GST_PLUGIN_PATH_1_0='', GST_PLUGIN_SYSTEM_PATH=next(iter(parents)),
        GST_PLUGIN_SYSTEM_PATH_1_0=next(iter(parents)), GST_REGISTRY=registry,
        GST_REGISTRY_1_0=registry, LANG='C', LC_ALL='C', GST_DEBUG_NO_COLOR='1', GST_DEBUG='2')
    stopping = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stopping.set())
    start = time.monotonic()
    process = log = None
    status = dict(expected_boot=args.expected_boot, frames_submitted=0, failure=None,
        complete=False, pipeline='peer_owned_files_to_existing_gst_observer_MPP_X11',
        source_to_decoded_mapping='UNKNOWN', sink_is_physical_presentation=False,
        full_video_archive=False, resources_retained=False)
    last_key = None
    samples = {}
    sample_bytes = 0
    last_status = 0
    sample_dir = args.output/'samples'
    sample_dir.mkdir()
    try:
        with (args.output/'jpeg-submissions.jsonl').open('x') as submitted:
            while not stopping.is_set() and time.monotonic()-start < args.seconds:
                tick = time.monotonic()
                if log and log.failure:
                    raise RuntimeError(log.failure)
                if process and process.poll() is not None:
                    raise RuntimeError('observer exited '+str(process.returncode))
                if (args.output.parent/'result.json').exists():
                    status['end_reason'] = 'OWNER_RESULT_PRESENT'
                    break
                item = latest_frame(args.records)
                if item:
                    row, body, header = item
                    key = json.dumps(row['source'], sort_keys=True)
                    if key != last_key:
                        if process is None:
                            process = subprocess.Popen([str(args.observer)], stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, bufsize=0)
                            os.set_blocking(process.stdin.fileno(), False)
                            log = ObserverLog(process, args.output/'gstreamer.log')
                            log.thread.start()
                            status.update(observer_pid=process.pid, resources_retained=True)
                            if not log.ready.wait(5) or log.failure:
                                raise RuntimeError(log.failure or 'observer startup deadline')
                        before = time.monotonic_ns()
                        write_bounded(process.stdin.fileno(), body)
                        after = time.monotonic_ns()
                        last_key = key
                        status['frames_submitted'] += 1
                        status['latest_source'] = row['source']
                        status['last_submission_ns'] = after
                        submitted.write(json.dumps(dict(source=row['source'], jpeg_sha256=row['jpeg_sha256'],
                            write_start_ns=before, complete_ns=after, recorder_received_ns=row['received_monotonic_ns']))+'\n')
                        submitted.flush()
                        identity = row['source']
                        epoch = str(identity.get('epoch'))
                        prior = samples.get(epoch)
                        # Three original samples/epoch: first, >=1s, >=10s. Quota is explicit.
                        needed = prior is None or (len(prior)<3 and after-prior[0] >= (1 if len(prior)==1 else 10)*10**9)
                        if needed and len(samples) <= 16 and sample_bytes+len(body)+448 <= 128*1024*1024:
                            seq = len(prior or [])+1
                            name = 'epoch-'+epoch+'-'+str(seq)
                            (sample_dir/(name+'.ajpg')).write_bytes(header+body)
                            (sample_dir/(name+'.json')).write_text(json.dumps(row)+'\n')
                            samples.setdefault(epoch, []).append(after)
                            sample_bytes += len(body)+448
                if log:
                    status.update(mpp_src_count=log.counts[0], sink_input_count=log.counts[1],
                        mpp_last_ns=log.last_ns[0], sink_last_ns=log.last_ns[1],
                        heartbeat_received_ns=log.last_heartbeat, log_bytes=log.log_bytes)
                status.update(monotonic_ns=time.monotonic_ns(), elapsed_s=time.monotonic()-start,
                    saved_samples=sum(map(len,samples.values())), sample_bytes=sample_bytes)
                if time.monotonic()-last_status >= 1:
                    atomic_json(args.output/'preview-state.json', status)
                    last_status = time.monotonic()
                stopping.wait(max(0, 1/30-(time.monotonic()-tick)))
        status.update(complete=True, end_monotonic_ns=time.monotonic_ns())
    except BaseException as error:
        status['failure'] = type(error).__name__+': '+str(error)[:512]
        status['end_monotonic_ns'] = time.monotonic_ns()
    finally:
        if log:
            time.sleep(1)  # Preserve a short post-window callback/heartbeat tail.
            log.stop_reading.set()
            log.thread.join(1)
            status['observer_log_sealed'] = not log.thread.is_alive()
            status['observer_log_failure'] = log.failure
            status['log_bytes'] = log.log_bytes
        atomic_json(args.output/'preview-state.json', status)
        (args.output/'preview-final.json').write_text(json.dumps(status, indent=2)+'\n')
    if process is not None:
        # Same policy as the existing display trial: no EOS/kill/native cleanup.
        # Log was sealed after the bounded postlude; retain without file growth.
        # The observer output is nonblocking, so eventual output loss after sealing
        # does not retroactively change the sealed video-window evidence.
        while True:
            try:
                time.sleep(1)
            except BaseException:
                pass
    return status


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--records', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--observer', type=Path, required=True)
    parser.add_argument('--observer-sha256', required=True)
    parser.add_argument('--display-baseline', type=Path, required=True)
    parser.add_argument('--expected-boot', required=True)
    parser.add_argument('--seconds', type=int, default=1830)
    args=parser.parse_args()
    if not 1 <= args.seconds <= 1860:
        parser.error('bounded 1..1860 seconds required')
    run(args)

if __name__ == '__main__':
    main()
