"""Derive the opt-in C1 observer from one frozen historical observer source.

The old source stays byte-identical for builders that bind its tested ELF.
This adapter only inserts C1 macro/include/banner/probe selections. It performs
no compilation, filesystem access, target execution or pipeline lifecycle work.
"""
import hashlib

SOURCE_SHA256 = '2844037a8c20c32004b13c30d6288b9ee9d06512227044bcf0004c586b9318de'
GENERATED_SHA256 = '49df16c126eabd742c6d7d50ef15d423023f1a52a8faacb1e9ec748062f723a2'


def adapt(source: bytes) -> bytes:
    """Return the C1 C source, rejecting unknown inputs and changed anchors."""
    if type(source) is not bytes or hashlib.sha256(source).hexdigest() != SOURCE_SHA256:
        raise ValueError('C1 observer requires the frozen original source SHA256')
    replacements = (
        (b'#ifndef R5_H265_60FPS',
         b'#ifndef R5_C1_LANE_OVERLAY\n#define R5_C1_LANE_OVERLAY 0\n#endif\n'
         b'#if R5_C1_LANE_OVERLAY && !R5_LANE_OVERLAY\n'
         b'#error "C1 lane overlay requires R5_LANE_OVERLAY=1"\n#endif\n'
         b'#ifndef R5_H265_60FPS'),
        (b'#include "gst_lane_overlay.h"',
         b'#if R5_C1_LANE_OVERLAY\n#include "gst_c1_lane_overlay.h"\n#else\n'
         b'#include "gst_lane_overlay.h"\n#endif'),
        (b'#elif R5_LANE_OVERLAY\n        emit("AUTOF21_',
         b'#elif R5_C1_LANE_OVERLAY\n'
         b'        emit("DUAL_HDR_SEED1_C1_SAME_PTS_CURVES_NV12_KMS_SINK_INPUT_RETAIN_V1\\n");\n'
         b'#elif R5_LANE_OVERLAY\n        emit("AUTOF21_'),
        (b'if(!offline && (!gst_pad_add_probe(pads[4],16,r5_lane_probe,NULL,NULL) ||\n'
         b'        !r5_lane_start',
         b'if(!offline && (!gst_pad_add_probe(pads[4],16,r5_lane_probe,NULL,NULL) ||\n'
         b'#if R5_C1_LANE_OVERLAY\n'
         b'        !gst_pad_add_probe(pads[1],16,r5_lane_sink_probe,NULL,NULL) ||\n'
         b'        !gst_pad_add_probe(pads[4],32,r5_lane_list_probe,NULL,NULL) ||\n'
         b'        !gst_pad_add_probe(pads[1],32,r5_lane_list_probe,NULL,NULL) ||\n'
         b'#endif\n        !r5_lane_start'),
    )
    for before, after in replacements:
        if source.count(before) != 1:
            raise ValueError('C1 observer source anchor differs')
        source = source.replace(before, after, 1)
    if hashlib.sha256(source).hexdigest() != GENERATED_SHA256:
        raise ValueError('C1 observer generated source SHA256 differs')
    return source
