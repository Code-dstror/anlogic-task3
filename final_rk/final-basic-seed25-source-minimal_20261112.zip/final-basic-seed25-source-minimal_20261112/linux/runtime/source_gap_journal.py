"""Bounded evidence of peer native SOURCE anomalies before display selection.

Only GAP/REPEAT/BACKWARD summaries are queued. The receive callback never opens,
serializes, hashes or writes files and never touches event.product or JPEG/wire
bytes. A gap is evidence, not a stop policy; journal failure is explicit.
"""
from collections import deque
import json
import math
import os
from pathlib import Path
import threading
import time

MAX_QUEUE_DEPTH = 512
MAX_EVENTS = 1024
MAX_BYTES = 1024 * 1024
SUMMARY_RESERVE = 4096
MAX_LINE_BYTES = 4096
TIME_SCOPE = 'HOST_INSPECTION_TIME_NOT_ABSOLUTE_FPGA_EVENT_TIME'


class SourceGapJournalError(RuntimeError):
    pass


def _integer(value, name, *, optional=False):
    if value is None and optional:
        return None
    if type(value) is not int or not 0 <= value < 1 << 64:
        raise ValueError('invalid bounded '+name)
    return value


def _hash(value, name):
    if value is None:
        return None
    if type(value) is not str or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
        raise ValueError('invalid existing '+name)
    return value


def _small_text(value, name, limit=32):
    if type(value) is not str or not 1 <= len(value) <= limit:
        raise ValueError('invalid bounded '+name)
    return value


def _copy_anomaly(event):
    """Fixed whitelist only. No reference to the original event survives."""
    summary = event.summary
    if type(summary) is not dict:
        raise ValueError('peer event summary must be a dict')
    sequence = summary.get('sequence')
    if sequence is None:
        return None
    if type(sequence) is not dict:
        raise ValueError('peer sequence summary must be a dict')
    status = sequence.get('status')
    if status in ('FIRST', 'NEXT'):
        return None
    if status not in ('GAP', 'REPEAT', 'BACKWARD'):
        raise ValueError('unknown peer sequence status')
    previous = _integer(sequence.get('previous'), 'previous sequence')
    current = _integer(sequence.get('current'), 'current sequence')
    if ((status == 'GAP' and current <= previous+1) or
            (status == 'REPEAT' and current != previous) or
            (status == 'BACKWARD' and current >= previous)):
        raise ValueError('peer sequence status/identity differs')
    source = summary.get('source') or {}
    metadata = summary.get('metadata') or {}
    header = summary.get('header') or {}
    if any(type(value) is not dict for value in (source, metadata, header)):
        raise ValueError('invalid peer SOURCE/metadata/header summary')
    identity = summary.get('transport_identity', ())
    if type(identity) not in (tuple, list) or len(identity) > 16:
        raise ValueError('invalid bounded transport identity')
    source_copy = {name: _integer(source.get(name), 'SOURCE '+name, optional=True)
                   for name in ('session', 'epoch', 'sequence', 'camera', 'kind', 'format', 'role')}
    for name, fallback in (('session', summary.get('source_session')),
                           ('epoch', summary.get('source_epoch')),
                           ('camera', header.get('camera'))):
        if source_copy[name] is None:
            source_copy[name] = _integer(fallback, 'SOURCE '+name, optional=True)
    if source_copy['sequence'] is None:
        source_copy['sequence'] = current
    if source_copy['sequence'] != current:
        raise ValueError('same-event SOURCE and sequence.current differ')
    mode = _integer(metadata.get('processing_mode'), 'processing mode', optional=True)
    missing = (dict(first=previous+1, last=current-1, count=current-previous-1)
               if status == 'GAP' else None)
    return dict(format='SOURCE_GAP_JOURNAL_V1', kind=_small_text(event.kind, 'event kind'),
        product_status=_small_text(event.status, 'product status'),
        sequence=dict(status=status, previous=previous, current=current),
        source=source_copy, host_ns=_integer(summary.get('host_ns'), 'host_ns'),
        index=_integer(summary.get('index'), 'event index'),
        transport_identity=[_integer(value, 'transport identity word') for value in identity],
        wire_bytes=_integer(summary.get('wire_bytes'), 'wire byte count', optional=True),
        wire_sha256=_hash(summary.get('wire_sha256'), 'wire SHA256'),
        jpeg_sha256=_hash(summary.get('jpeg_sha256'), 'JPEG SHA256'),
        header_sha256=_hash(summary.get('header_sha256'), 'header SHA256'),
        wire_header_sha256=_hash(summary.get('wire_header_sha256'), 'wire header SHA256'),
        processing_mode=mode,
        # Selected peer record-v2 schema2 tag=0x80, independent enable mask=0x3f.
        schema2_processing_enables=(mode & 0x3f) if mode is not None and mode & 0x80 else None,
        record_flags=_integer(metadata.get('record_flags'), 'record flags', optional=True),
        missing_sequence_range=missing, time_scope=TIME_SCOPE,
        cause='UNKNOWN_NOT_ATTRIBUTED_TO_DMA_OR_FPGA')


class SourceGapJournal:
    """One ordinary-file worker, <=512 waiting rows, <=1024 accepted anomalies.

    max_bytes covers both the JSONL and final summary; 4KiB is reserved for the
    summary. Overflow latches failure and raises, never silently evicts a row.
    Already accepted rows drain after queue/event overflow if disk remains usable.
    close() only joins this worker and closes its ordinary files, never hardware.
    """
    def __init__(self, output, *, queue_depth=256, max_events=MAX_EVENTS, max_bytes=MAX_BYTES):
        if type(queue_depth) is not int or not 1 <= queue_depth <= MAX_QUEUE_DEPTH:
            raise ValueError('queue_depth requires 1..512')
        if type(max_events) is not int or not 1 <= max_events <= MAX_EVENTS:
            raise ValueError('max_events requires 1..1024')
        if type(max_bytes) is not int or not SUMMARY_RESERVE+MAX_LINE_BYTES <= max_bytes <= MAX_BYTES:
            raise ValueError('max_bytes requires 8192..1048576')
        self.output = Path(output)
        self.depth, self.max_events, self.max_bytes = queue_depth, max_events, max_bytes
        self._cv, self._queue = threading.Condition(), deque()
        self._started = self._closing = self._done = False
        self._failure = None
        self._ready = threading.Event()
        self._seen = self._accepted = self._written = self._normal = 0
        self._log_bytes = self._summary_bytes = self._inflight = 0
        self._thread = threading.Thread(target=self._run, name='native-source-gap-journal', daemon=True)

    def _fail(self, error):
        with self._cv:
            if self._failure is None:
                self._failure = (type(error).__name__+': '+str(error))[:512]
            self._closing = True
            self._cv.notify_all()

    def start(self):
        with self._cv:
            if self._started:
                raise SourceGapJournalError('journal start is single use')
            self._started = True
        self._thread.start()
        if not self._ready.wait(5):
            self._fail(TimeoutError('journal ordinary-file startup deadline'))
        self.check()
        return self

    def check(self):
        with self._cv:
            failure = self._failure
        if failure:
            raise SourceGapJournalError(failure)

    def observe(self, event):
        self.check()
        try:
            row = _copy_anomaly(event)
            with self._cv:
                if not self._started or self._closing:
                    raise SourceGapJournalError('journal is not accepting observations')
                if row is None:
                    self._normal += 1
                    return False
                self._seen += 1
                if self._failure:
                    raise SourceGapJournalError(self._failure)
                if self._accepted >= self.max_events:
                    raise SourceGapJournalError('journal anomaly event limit reached; no silent evidence loss')
                if len(self._queue) >= self.depth:
                    raise SourceGapJournalError('journal queue full; no silent evidence loss')
                self._queue.append(row)
                self._accepted += 1
                self._cv.notify()
            return True
        except BaseException as error:
            self._fail(error)
            raise SourceGapJournalError(self._failure) from error

    def snapshot(self):
        with self._cv:
            alive = self._thread.is_alive()
            return dict(format='SOURCE_GAP_JOURNAL_SUMMARY_V1', time_scope=TIME_SCOPE,
                state='FAILED' if self._failure else 'CLOSED' if self._done and not alive else
                      'DRAINING' if self._closing else 'RUNNING' if self._started else 'NEW',
                failure=self._failure,
                complete=self._done and not alive and self._failure is None and self._written==self._accepted,
                observed_anomalies=self._seen, accepted_events=self._accepted,
                written_events=self._written, ignored_normal_events=self._normal,
                unpersisted_accepted_events=self._accepted-self._written,
                pending=len(self._queue), inflight=self._inflight,
                queue_depth=self.depth, max_events=self.max_events, max_total_bytes=self.max_bytes,
                max_log_bytes=self.max_bytes-SUMMARY_RESERVE, max_line_bytes=MAX_LINE_BYTES,
                log_bytes=self._log_bytes, summary_bytes=self._summary_bytes,
                worker_done=self._done and not alive, worker_alive=alive,
                native_or_mpp_resources_touched=False, full_frame_archive=False)

    def close(self, timeout_s=3):
        if type(timeout_s) not in (int, float) or not math.isfinite(timeout_s) or not 0 <= timeout_s <= 10:
            raise ValueError('close timeout requires finite 0..10 seconds')
        with self._cv:
            self._closing = True
            self._cv.notify_all()
            started = self._started
        if started:
            self._thread.join(timeout_s)
        return self.snapshot()

    def _open_log(self):
        self.output.mkdir(mode=0o700, exist_ok=True)
        return (self.output/'source-gaps.jsonl').open('xb', buffering=0)

    @staticmethod
    def _write_all(stream, body):
        offset = 0
        while offset < len(body):
            count = stream.write(memoryview(body)[offset:])
            if type(count) is not int or count <= 0 or count > len(body)-offset:
                raise OSError('journal short/invalid ordinary-file write')
            offset += count

    def _final_summary(self):
        summary = self.snapshot()
        # This means the serialized evidence is terminal; API worker_done remains
        # false until the final write and actual thread termination have finished.
        summary.pop('worker_done')
        summary.pop('worker_alive')
        summary.update(evidence_sealed=True, sealed_host_ns=time.monotonic_ns(),
            complete=summary['failure'] is None and summary['written_events']==summary['accepted_events'],
            state='FAILED' if summary['failure'] else 'SEALED',
            worker_completion='CONSULT_API_AFTER_BOUNDED_JOIN')
        body = b''
        for _ in range(4):
            body = (json.dumps(summary, sort_keys=True, allow_nan=False)+'\n').encode()
            if summary['summary_bytes'] == len(body):
                break
            summary['summary_bytes'] = len(body)
        if len(body) > SUMMARY_RESERVE:
            raise ValueError('journal final summary exceeds reserved bytes')
        with (self.output/'source-gaps-final.json').open('xb', buffering=0) as stream:
            self._write_all(stream, body)
            os.fsync(stream.fileno())
        with self._cv:
            self._summary_bytes = len(body)

    def _run(self):
        try:
            with self._open_log() as stream:
                self._ready.set()
                while True:
                    with self._cv:
                        self._cv.wait_for(lambda: self._queue or self._closing)
                        if not self._queue:
                            break
                        row = self._queue.popleft()
                        self._inflight = 1
                    body = (json.dumps(row, sort_keys=True, allow_nan=False)+'\n').encode()
                    if len(body) > MAX_LINE_BYTES or self._log_bytes+len(body) > self.max_bytes-SUMMARY_RESERVE:
                        raise SourceGapJournalError('journal byte limit reached; no silent evidence loss')
                    self._write_all(stream, body)
                    with self._cv:
                        self._log_bytes += len(body)
                        self._written += 1
                        self._inflight = 0
                os.fsync(stream.fileno())
        except BaseException as error:
            self._fail(error)
        finally:
            self._ready.set()
            try:
                self._final_summary()
            except BaseException as error:
                self._fail(error)
            with self._cv:
                self._queue.clear()
                self._inflight = 0
                self._done = True
                self._cv.notify_all()
