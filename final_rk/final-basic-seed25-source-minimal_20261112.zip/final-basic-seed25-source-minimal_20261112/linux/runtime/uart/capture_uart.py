"""Portable FPGA RX-only capture. USB identity is checked before port open.

No UART write or control command exists. RK's CH9102 is not an allowed device.
Offline decoding remains available in uart_observer.py without pyserial.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import time


def capture(args, *, serial_module=None, ports=None, clock=time.monotonic):
    if serial_module is None:
        import serial as serial_module
    if ports is None:
        from serial.tools import list_ports
        ports = list_ports.comports()
    matches = [p for p in ports if os.path.normcase(os.path.realpath(p.device)) ==
               os.path.normcase(os.path.realpath(args.port))]
    if len(matches) != 1:
        raise ValueError('Choose one listed physical serial device; no fallback')
    observed = matches[0]
    if (observed.vid, observed.pid) != (0x0403, 0x6042) or observed.serial_number != args.expected_serial:
        raise ValueError('Not the explicitly selected FPGA FTDI identity; no port opened')
    if not 0 < args.seconds <= 600:
        raise ValueError('seconds must be in (0,600]')
    from uart_observer import FrameDecoder, ProgressView
    decoder, view = FrameDecoder(), ProgressView()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    serial = serial_module.Serial(port=None, baudrate=115200, bytesize=8, parity='N', stopbits=1,
        timeout=.25, xonxoff=False, rtscts=False, dsrdtr=False)
    serial.dtr = False
    serial.rts = False
    serial.port = observed.device
    meta = dict(port=observed.device, vid=observed.vid, pid=observed.pid,
        serial_number=observed.serial_number, baud=115200, mode='RX_ONLY_NO_WRITES',
        start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        event_timestamp_proof=False, finished=False)
    try:
        with (args.output_dir/'fpga.bin').open('xb') as raw, (args.output_dir/'decoded.jsonl').open('x',encoding='utf-8') as out:
            serial.open()
            deadline = clock()+args.seconds
            while clock() < deadline:
                data = serial.read(256)
                raw.write(data)
                for frame in decoder.feed(data):
                    out.write(json.dumps(view.annotate(frame),ensure_ascii=False)+'\n')
                    out.flush()
            meta['finished'] = True
    finally:
        serial.close()
        meta['decoder'] = decoder.summary()
        (args.output_dir/'capture.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(meta))
    return meta


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--list',action='store_true')
    p.add_argument('--port')
    p.add_argument('--expected-serial')
    p.add_argument('--seconds',type=float,default=60)
    p.add_argument('--output-dir',type=Path)
    args=p.parse_args()
    if args.list:
        from serial.tools import list_ports
        print(json.dumps([dict(port=x.device,vid=x.vid,pid=x.pid,serial=x.serial_number,
                               description=x.description) for x in list_ports.comports()],ensure_ascii=False,indent=2))
        return
    if not args.port or not args.expected_serial or not args.output_dir:
        p.error('--port, --expected-serial and --output-dir are required')
    capture(args)


if __name__=='__main__':
    main()
