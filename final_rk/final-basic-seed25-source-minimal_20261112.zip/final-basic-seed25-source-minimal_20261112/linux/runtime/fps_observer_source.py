"""Generate independent FPS observer variants; preserve historical C inputs."""
import hashlib

try:
    from .c1_observer_source import adapt as c1_adapt,SOURCE_SHA256
except ImportError:
    from c1_observer_source import adapt as c1_adapt,SOURCE_SHA256

VARIANTS=('mono','lane','dual')


def adapt(source,variant):
    if variant not in VARIANTS or hashlib.sha256(source).hexdigest()!=SOURCE_SHA256:
        raise ValueError('fixed observer source and FPS variant required')
    if variant=='lane':source=c1_adapt(source)
    if variant=='dual':
        source=source.replace(b'#include "gst_dual_pipeline.h"',b'#include "gst_fps_dual_pipeline.h"')
    replacements=[
        (b'#if R5_LANE_OVERLAY || R5_H265_RECORD || R5_DUAL\nstatic _Atomic uint64_t telemetry_lost;',
         b'#if 1 /* FPS probes emit from the streaming thread too. */\nstatic _Atomic uint64_t telemetry_lost;'),
        (b'static void remember_failure(const char *line) {',b'#include "gst_fps_hud.h"\nstatic void remember_failure(const char *line) {'),
        (b'    if (check_runtime) { emit(',b'    if(!fps_symbols(lib)) { emit("ERROR: FPS public symbols unavailable\\n");return 2; }\n    if (check_runtime) { emit('),
        (b'    const char *pipeline = offline ?',b'#if R5_DUAL\n    if(!r3_alternating && !fps_register_compositor()) { emit("ERROR: FPS compositor registration failed\\n");return 2; }\n#endif\n    const char *pipeline = offline ?'),
        (b'    char line[256];\n    snprintf(line,sizeof line,"R5D1 CLOCK',b'''#if R5_DUAL
    if(!r3_alternating) {
        fps_mix=gst_bin_get_by_name(pipe,"r3mix");
        for(unsigned i=0;i<2;i++) {
            fps_mix_pads[i]=fps_mix?gst_element_get_static_pad(fps_mix,i?"sink_1":"sink_0"):NULL;
            if(!fps_mix_pads[i] || !gst_pad_add_probe(fps_mix_pads[i],16,fps_tag_input,(void*)(uintptr_t)i,NULL)) {
                emit("ERROR: FPS composed input identity setup failed\\n");return 2;
            }
        }
    }
#endif
    if(!gst_pad_add_probe(pads[1],16,fps_hud_probe,NULL,NULL) ||
       !gst_pad_add_probe(pads[1],32,fps_list_probe,NULL,NULL)) {
        emit("ERROR: FPS final NV12 probe setup failed\\n");return 2;
    }
    char line[256];
    snprintf(line,sizeof line,"R5D1 CLOCK'''),
        (b'        uint64_t now=now_ns();',b'        uint64_t now=now_ns();\n        if(!failed && fps_error()) { remember_failure("ERROR: FPS identity/clock/NV12 mapping fault; retained\\n");failed=1; }'),
    ]
    for before,after in replacements:
        if source.count(before)!=1:raise ValueError('FPS observer anchor differs: '+repr(before))
        source=source.replace(before,after,1)
    # The banner belongs to this independent executable, not its old profile.
    marker=b'if (argc == 2 && !strcmp(argv[1], "--describe-profile")) {'
    if marker not in source:
        marker=b'if(argc == 2 && !strcmp(argv[1], "--describe-profile")) {'
    if source.count(marker)!=1:raise ValueError('FPS descriptor anchor differs')
    source=source.replace(marker,marker+b'\n        emit("R5_FPS_HUD_'+variant.upper().encode()+b'_FRAME_DRIVEN_NV12_RETAIN_V1\\n");return 0;\n',1)
    return source


def dual_pipeline(source):
    if hashlib.sha256(source).hexdigest()!='dcf03dfc30ae89a04f9b359a7e179519fb8bc0471486b0110dc2c4b821ff8b56':
        raise ValueError('fixed dual pipeline source SHA required')
    old=b'"compositor name=r3mix background=black "'
    if source.count(old)!=1:raise ValueError('fixed dual compositor layout anchor differs')
    return source.replace(old,b'"r5fpscompositor name=r3mix background=black "',1)
