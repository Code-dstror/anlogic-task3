/* Derived from gst_observer.c at de29e7ef (original remains unchanged).
 * R5_QUEUE1=0 is the measured serial baseline; =1 adds ONE nonleaky raw
 * buffer between decoder and conversion. Never switches pipelines or closes
 * MPP. Extra opaque-pad timestamps are ordinal stages, not SOURCE identities.
 */
#ifndef R5_DUAL
#define R5_DUAL 0
#endif
#define STREAM_COUNT (R5_DUAL ? 7 : 5)
#ifndef R5_QUEUE1
#define R5_QUEUE1 0
#endif
#ifndef R5_CONVERT2
#define R5_CONVERT2 0
#endif
#ifndef R5_CONVERT3
#define R5_CONVERT3 0
#endif
#ifndef R5_DISPLAY_OBSERVE
#define R5_DISPLAY_OBSERVE 0
#endif
#ifndef R5_MPP_BGRX
#define R5_MPP_BGRX 0
#endif
#ifndef R5_KMS_NV12
#define R5_KMS_NV12 0
#endif
#ifndef R5_LANE_OVERLAY
#define R5_LANE_OVERLAY 0
#endif
#ifndef R5_H265_60FPS
#define R5_H265_60FPS 0
#endif
#if R5_H265_60FPS
#define R5_H265_TAIL 1
#endif
#ifndef R5_H265_TAIL
#define R5_H265_TAIL 0
#endif
#if R5_H265_TAIL
#define R5_H265_RECORD 1
#endif
#ifndef R5_H265_RECORD
#define R5_H265_RECORD 0
#endif
#if R5_DUAL && (!R5_KMS_NV12 || R5_LANE_OVERLAY || R5_H265_RECORD)
#error "dual requires a dedicated NV12 build without recording/overlay"
#endif
#if R5_H265_RECORD && (!R5_KMS_NV12 || R5_LANE_OVERLAY)
#error "recording requires KMS NV12 without overlay"
#endif
#if R5_LANE_OVERLAY && !R5_KMS_NV12
#error "lane overlay requires KMS NV12 profile"
#endif
#if R5_KMS_NV12 && (!R5_DISPLAY_OBSERVE || R5_MPP_BGRX || R5_CONVERT2 || R5_CONVERT3 || R5_QUEUE1)
#error "KMS NV12 requires observation and no CPU converter or queue"
#endif
#if R5_MPP_BGRX && (!R5_DISPLAY_OBSERVE || R5_CONVERT2 || R5_CONVERT3 || R5_QUEUE1)
#error "MPP BGRx requires observation and no CPU converter or queue"
#endif
#if R5_DISPLAY_OBSERVE && !R5_MPP_BGRX && !R5_KMS_NV12 && (!R5_CONVERT2 || R5_CONVERT3 || R5_QUEUE1)
#error "display observation requires unchanged two-thread serial pipeline"
#endif
#if (R5_QUEUE1 && (R5_CONVERT2 || R5_CONVERT3)) || (R5_CONVERT2 && R5_CONVERT3)
#error "queue and conversion candidates must remain separate"
#endif
/* Optional GStreamer launcher observer. No native/DRM/MPP opens of its own.
 * Public Gst 1.x functions via dlsym; all Gst structs remain opaque. Constants
 * checked with installed Gst-1.0 typelib. No Gst buffer/layout dereference.
 * Observation-only probes never map or change stream flow. The opt-in
 * R5_LANE_OVERLAY application probe maps NV12 and draws bounded strokes;
 * it can copy on write and drops subsequent buffers on a sticky failure.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <signal.h>
#include <errno.h>

#if R5_DUAL
#include "gst_fps_dual_pipeline.h"
#endif
#define CAP 1024u
struct event { uint64_t seq, ns; };
struct stream {
    atomic_flag busy;
    _Atomic unsigned head, tail;
    _Atomic uint64_t total, dropped;
    struct event ring[CAP];
};
static struct stream streams[STREAM_COUNT];
static _Atomic uint64_t clock_errors, buffer_lists;
#if 1 /* FPS probes emit from the streaming thread too. */
static _Atomic uint64_t telemetry_lost;
#else
static uint64_t telemetry_lost;
#endif
static char first_failure[512];
/* Public GLib GError layout: glib/gerror.h, GLib2 stable ABI. No Gst struct layout. */
struct public_gerror { unsigned domain; int code; char *message; };
static uint64_t now_ns(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) {
        atomic_fetch_add(&clock_errors, 1); return 0;
    }
    return (uint64_t)t.tv_sec * 1000000000u + (uint64_t)t.tv_nsec;
}
static int probe(void *pad, void *info, void *data) {
    (void)pad; (void)info;
    struct stream *s = data;
    uint64_t seq = atomic_fetch_add(&s->total, 1) + 1;
    if (atomic_flag_test_and_set_explicit(&s->busy, memory_order_acquire)) {
        atomic_fetch_add(&s->dropped, 1); return 1; /* GST_PAD_PROBE_OK */
    }
    unsigned h = atomic_load_explicit(&s->head, memory_order_relaxed);
    unsigned next = (h + 1) % CAP;
    if (next == atomic_load_explicit(&s->tail, memory_order_acquire)) {
        atomic_fetch_add(&s->dropped, 1);
    } else {
        s->ring[h] = (struct event){seq, now_ns()};
        atomic_store_explicit(&s->head, next, memory_order_release);
    }
    atomic_flag_clear_explicit(&s->busy, memory_order_release);
    return 1;
}
static int list_probe(void *pad, void *info, void *data) {
    (void)pad; (void)info; (void)data;
    atomic_fetch_add(&buffer_lists, 1); return 1;
}
/* Single bounded nonblocking write per line (< PIPE_BUF). No write retry.
 * Any EAGAIN/short write is sticky-invalid and exposed in the next heartbeat.
 */
static void emit(const char *line) {
    size_t n = strlen(line);
    if (write(STDOUT_FILENO, line, n) != (ssize_t)n) telemetry_lost++;
}
#if R5_DUAL
/* A qdata tag belongs to the decoded GstBuffer, destroyed with that buffer.
 * No PTS matching or Gst structure layout access. If an element copies a
 * buffer without preserving this identity, fail closed at selector/sink.
 */
struct r3_identity { unsigned camera; uint64_t serial; int segment; uint64_t selected_ns; };
static int r3_alternating, r3_control=-1, r3_next_segment;
static unsigned r3_identity_key;
static void *r3_selector, *r3_pads[2];
static _Atomic unsigned r3_selection, r3_first_selector, r3_first_sink, r3_invalid;
static _Atomic uint64_t r3_serial[2];
static void *(*r3_probe_buffer)(void *);
static void (*r3_set_qdata)(void *, unsigned, void *, void (*)(void *));
static void *(*r3_get_qdata)(void *, unsigned);
static void (*r3_object_set)(void *, const char *, ...);
static void (*r3_object_get)(void *, const char *, ...);
static void (*r3_object_unref)(void *);
static unsigned (*r3_quark)(const char *);
static void r3_bad(const char *reason) {
    atomic_store(&r3_invalid,1);
    char line[192];snprintf(line,sizeof line,"ERROR: alternating %s\n",reason);emit(line);
}
static int r3_select_symbols(void *lib) {
#define R3_SYM(variable,name) do { void *symbol=dlsym(lib,name); \
    _Static_assert(sizeof variable==sizeof symbol,"POSIX function pointer width"); \
    memcpy(&variable,&symbol,sizeof variable);if(!variable)return 0; } while(0)
    R3_SYM(r3_probe_buffer,"gst_pad_probe_info_get_buffer");
    R3_SYM(r3_set_qdata,"gst_mini_object_set_qdata");
    R3_SYM(r3_get_qdata,"gst_mini_object_get_qdata");
    R3_SYM(r3_object_set,"g_object_set");
    R3_SYM(r3_object_get,"g_object_get");
    R3_SYM(r3_object_unref,"gst_object_unref");
    R3_SYM(r3_quark,"g_quark_from_static_string");
#undef R3_SYM
    r3_identity_key=r3_quark("dual-r3-decoded-camera-identity-v1");
    return r3_identity_key!=0;
}
static int r3_camera_probe(void *pad, void *info, void *data) {
    (void)pad;
    if(atomic_load(&r3_invalid))return 0;
    unsigned camera=(unsigned)(uintptr_t)data;
    void *buffer=r3_probe_buffer(info);
    struct r3_identity *tag=malloc(sizeof *tag);
    if(!buffer || !tag) { free(tag);r3_bad("cannot tag decoded buffer");return 0; }
    *tag=(struct r3_identity){camera,atomic_fetch_add(&r3_serial[camera],1)+1,-1,0};
    r3_set_qdata(buffer,r3_identity_key,tag,free);
    return 1;
}
static int r3_identity_probe(void *pad, void *info, void *data) {
    (void)pad;
    if(atomic_load(&r3_invalid))return 0;
    unsigned selected=atomic_load(&r3_selection);
    if(!selected)return 0; /* No displayed input before explicit segment0. */
    int sink=data!=NULL;
    void *buffer=r3_probe_buffer(info);
    struct r3_identity *tag=buffer?r3_get_qdata(buffer,r3_identity_key):NULL;
    if(!tag || tag->camera>1) { r3_bad("decoded buffer camera identity missing");return 0; }
    uint64_t stamp=now_ns();
    if(!sink) {
        if(tag->segment!=-1) { r3_bad("selector repeated a tagged buffer");return 0; }
        tag->segment=(int)(selected>>1)-1;
        tag->selected_ns=stamp;
    } else if(tag->segment<0 || !tag->selected_ns) {
        r3_bad("sink buffer bypassed selector identity");return 0;
    }
    char line[192];
    snprintf(line,sizeof line,"R3SW BUFFER %c %d %u %llu %llu\n",sink?'K':'S',
        tag->segment,tag->camera,(unsigned long long)tag->serial,(unsigned long long)stamp);emit(line);
    /* Tag carries the selection at selector crossing, even if the control
     * thread changes active-pad while this exact buffer is in flight. */
    if(tag->camera==(unsigned)(tag->segment%2)) {
        unsigned bit=1u<<(unsigned)tag->segment;
        unsigned prior=sink?atomic_fetch_or(&r3_first_sink,bit):atomic_fetch_or(&r3_first_selector,bit);
        if(!(prior&bit)) {
            snprintf(line,sizeof line,"R3SW FIRST %c %d %u %llu %llu\n",sink?'K':'S',
                tag->segment,tag->camera,(unsigned long long)tag->serial,(unsigned long long)stamp);emit(line);
        }
    }
    return 1;
}
static int r3_control_fd(void) {
    const char *value=getenv("R3_CONTROL_FD");char *end=NULL;
    if(!value || !*value || strspn(value,"0123456789")!=strlen(value))return 0;
    errno=0;long fd=strtol(value,&end,10);
    if(errno || *end || fd<3 || fd>1048575)return 0;
    const char *camera1=getenv("R3_CAM1_FD");
    if(camera1 && strtol(camera1,NULL,10)==fd)return 0;
    int flags=fcntl((int)fd,F_GETFL);
    if(flags<0 || (flags&O_ACCMODE)!=O_RDONLY || fcntl((int)fd,F_SETFL,flags|O_NONBLOCK))return 0;
    r3_control=(int)fd;return 1;
}
static void r3_command(const char *command) {
    unsigned camera=0,segment=0;int consumed=0;
    char canonical[64];
    if(sscanf(command,"SELECT %u %u%n",&camera,&segment,&consumed)!=2 ||
       command[consumed] || camera>1 || segment>5 || segment!=(unsigned)r3_next_segment || camera!=segment%2 ||
       (segment && !(atomic_load(&r3_first_sink)&(1u<<(segment-1))))) {
        r3_bad("invalid/repeated/out-of-order selection command");return;
    }
    snprintf(canonical,sizeof canonical,"SELECT %u %u",camera,segment);
    if(strcmp(command,canonical)) { r3_bad("non-canonical selection command");return; }
    char line[160];
    snprintf(line,sizeof line,"R3SW REQUEST %u %u %llu\n",segment,camera,(unsigned long long)now_ns());emit(line);
    r3_next_segment++;
    atomic_store(&r3_selection,((segment+1)<<1)|camera);
    r3_object_set(r3_selector,"active-pad",r3_pads[camera],NULL);
    void *active=NULL;r3_object_get(r3_selector,"active-pad",&active,NULL);
    int matches=active==r3_pads[camera];if(active)r3_object_unref(active);
    if(!matches) { r3_bad("active-pad readback differs");return; }
    snprintf(line,sizeof line,"R3SW CONFIRM %u %u %llu\n",segment,camera,(unsigned long long)now_ns());emit(line);
}
static void r3_control_poll(void) {
    static char command[64];static size_t used;
    char bytes[256];ssize_t count=read(r3_control,bytes,sizeof bytes);
    if(count<0) { if(errno!=EAGAIN && errno!=EWOULDBLOCK && errno!=EINTR)r3_bad("control read failed");return; }
    if(!count) { r3_bad("control EOF; no replay/restart");return; }
    for(ssize_t i=0;i<count && !atomic_load(&r3_invalid);i++) {
        if(bytes[i]=='\n') { command[used]=0;r3_command(command);used=0; }
        else if(bytes[i]<32 || bytes[i]>126 || used>=sizeof command-1)r3_bad("malformed control line");
        else command[used++]=bytes[i];
    }
}
#endif
#if R5_LANE_OVERLAY
#include "gst_lane_overlay.h"
#endif
#if R5_H265_RECORD
#include "gst_h265_record.h"
#endif
#if R5_DISPLAY_OBSERVE
#include "gst_display_observe.h"
#endif
#if R5_H265_TAIL
#include "gst_h265_tail.h"
#endif
#include "gst_fps_hud.h"
static void remember_failure(const char *line) {
    if (!first_failure[0]) snprintf(first_failure,sizeof first_failure,"%s",line);
    emit(first_failure);
}
static void drain(void) {
    char line[256];
    for (unsigned i = 0; i < STREAM_COUNT; i++) {
        struct stream *s = &streams[i];
        unsigned t = atomic_load_explicit(&s->tail, memory_order_relaxed);
        unsigned h = atomic_load_explicit(&s->head, memory_order_acquire);
        while (t != h) {
            struct event e = s->ring[t];
            snprintf(line, sizeof line, "%s E %u %llu %llu\n", R5_DUAL ? "R3D2" : (i < 2 ? "R5D1" : "R5P1"), i,
                (unsigned long long)e.seq, (unsigned long long)e.ns);
            emit(line); t = (t + 1) % CAP;
            atomic_store_explicit(&s->tail, t, memory_order_release);
        }
    }
#if R5_DISPLAY_OBSERVE
    r5_observe_drain();
#endif
}
static void heartbeat(void) {
    char line[256];
    uint64_t stamp=now_ns(); /* Must precede total loads for STOP watermark. */
#if R5_DUAL
    uint64_t lost=0;
    for(unsigned i=0;i<STREAM_COUNT;i++) lost+=atomic_load(&streams[i].dropped);
    snprintf(line,sizeof line,"R3D2 H %llu %llu %llu %llu %llu %llu %llu\n",
        (unsigned long long)stamp,(unsigned long long)atomic_load(&streams[0].total),
        (unsigned long long)atomic_load(&streams[5].total),(unsigned long long)atomic_load(&streams[1].total),
        (unsigned long long)lost,(unsigned long long)clock_errors,(unsigned long long)telemetry_lost);
    emit(line);
#endif
    snprintf(line, sizeof line, "R5D1 H %llu %llu %llu %llu %llu %llu %llu %llu\n",
        (unsigned long long)stamp,
        (unsigned long long)atomic_load(&streams[0].total),
        (unsigned long long)atomic_load(&streams[1].total),
        (unsigned long long)(atomic_load(&streams[0].dropped)+atomic_load(&streams[2].dropped)+atomic_load(&streams[3].dropped)+atomic_load(&streams[4].dropped)
#if R5_DISPLAY_OBSERVE
            +r5_observe_invalid()
#endif
        ),
        (unsigned long long)atomic_load(&streams[1].dropped),
        (unsigned long long)clock_errors, (unsigned long long)buffer_lists,
        (unsigned long long)telemetry_lost);
    emit(line);
#if R5_DISPLAY_OBSERVE
    r5_observe_heartbeat(stamp);
#endif
#if R5_H265_RECORD
    r5_record_heartbeat(stamp);
#endif
}
#define LOAD(ret, name, ...) \
    ret (*name)(__VA_ARGS__) = (ret (*)(__VA_ARGS__))dlsym(lib, #name); \
    if (!name) { emit("ERROR: observer missing public Gst symbol\n"); return 2; }
int main(int argc, char **argv) {
    int flags = fcntl(STDOUT_FILENO, F_GETFL);
    if (flags < 0 || fcntl(STDOUT_FILENO, F_SETFL, flags | O_NONBLOCK)) return 2;
    signal(SIGPIPE, SIG_IGN);
    for (unsigned i=0;i<STREAM_COUNT;i++) {
        atomic_flag_clear(&streams[i].busy);
        if (!atomic_is_lock_free(&streams[i].total) || !atomic_is_lock_free(&streams[i].head)) {
            emit("ERROR: lock-free atomics unavailable\n"); return 2;
        }
    }
    if (argc == 2 && !strcmp(argv[1], "--test-ring")) {
        for (unsigned i=0;i<CAP+9;i++) probe(NULL,NULL,&streams[0]);
        /* Test ring overflow without hardware or loading GStreamer. */
        heartbeat(); return 0;
    }
    if (argc == 2 && !strcmp(argv[1], "--test-backpressure")) {
        for (unsigned i=0;i<100000;i++) emit("R5D1 TEST BACKPRESSURE\n");
        return telemetry_lost ? 0 : 3;
    }
    int offline = argc == 2 && !strcmp(argv[1], "--offline-test");
#if R5_DUAL
    const char *alternating=getenv("R3_ALTERNATING");
    if(alternating && strcmp(alternating,"1")) { emit("ERROR: invalid alternating mode\n");return 2; }
    r3_alternating=alternating!=NULL;
#endif
#if R5_LANE_OVERLAY
    int lane_software = argc == 2 && !strcmp(argv[1], "--lane-software-test");
#endif
#if R5_H265_RECORD
    int record_software = argc == 2 && (!strcmp(argv[1], "--record-software-test")
#if R5_H265_TAIL
        || !strcmp(argv[1], "--tail-software-test")
#endif
        );
#endif
    int check_runtime = argc == 2 && !strcmp(argv[1], "--check-runtime");
    if (argc == 2 && !strcmp(argv[1], "--describe-profile")) {
        emit("R5_FPS_HUD_DUAL_FRAME_DRIVEN_NV12_RETAIN_V1\n");return 0;

#if R5_KMS_NV12
#if R5_DUAL
        emit(r3_alternating?"DUAL_R3_N2_TWO_MPP_SELECTOR_SINGLE_KMS_ALTERNATING60_RETAIN_V1\n":
            "DUAL_R3_N2_TWO_MPP_CPU_NV12_COMPOSITOR_SINGLE_KMS_RETAIN_V1\n");
#elif R5_H265_60FPS
        emit("AUTOF21_H265_1080P60_8M_10M_START60S_SD_BRANCH_TAIL_RETAIN_V1\n");
#elif R5_H265_TAIL
        emit("AUTOF21_H265_KMS30_BRANCH_TAIL_NO_ENCODER_RESET_RETAIN_V1\n");
#elif R5_H265_RECORD
        emit("AUTOF21_COLOR_HOST_MONOTONIC_H265_1080P30_4M_6M_HVC1_SPLIT5_KMS60_RETAIN\n");
#elif R5_LANE_OVERLAY
        emit("AUTOF21_F23_SAME_PTS_NV12_CANDIDATE_OVERLAY_KMS_SKIP_VSYNC_RETAIN_DRM\n");
#else
#if R5_KMS_SKIP_VSYNC
        emit("CALFIX_KMS_NV12_SKIP_VSYNC_RETAIN_DRM\n");
#else
        emit("CALFIX_KMS_NV12_NO_CPU_CONVERTER_RETAIN_DRM\n");
#endif
#endif
#elif R5_MPP_BGRX
        emit("CALFIX_MPP_BGRX_CAPSFILTER_NO_CPU_CONVERTER\n");
#elif R5_DISPLAY_OBSERVE
        emit("CALFIX_OBSERVE2_PUSH_RETURN_CAPS_NO_PIPELINE_CHANGE\n");
#elif R5_CONVERT3
        emit("CALFIX_CONVERT3_SERIAL_NO_EXTRA_QUEUE\n");
#elif R5_CONVERT2
        emit("CALFIX_CONVERT2_SERIAL_NO_EXTRA_QUEUE\n");
#else
        emit(R5_QUEUE1 ? "CALFIX_QUEUE1_NO_LEAK_MAX_RAW_WAITING_1\n" : "CALFIX_SERIAL_BASELINE\n");
#endif
        return 0;
    }
    if (argc != 1 && !offline && !check_runtime
#if R5_LANE_OVERLAY
        && !lane_software
#endif
#if R5_H265_RECORD
        && !record_software
#endif
        ) return 2;
#if R5_KMS_NV12
    unsigned connector = 0, plane = 0;
    if (!offline && !check_runtime
#if R5_LANE_OVERLAY
        && !lane_software
#endif
#if R5_H265_RECORD
        && !record_software
#endif
        ) {
        const char *names[] = {"R5_KMS_CONNECTOR_ID", "R5_KMS_PLANE_ID"};
        unsigned *ids[] = {&connector, &plane};
        for (unsigned i=0; i<2; i++) {
            const char *value = getenv(names[i]); char *end = NULL;
            if (!value || !*value || strspn(value,"0123456789") != strlen(value)) {
                emit("ERROR: explicit numeric KMS selection required\n"); return 2;
            }
            errno = 0; unsigned long id = strtoul(value,&end,10);
            if (errno || *end || !id || id > 2147483647UL) {
                emit("ERROR: invalid KMS object id\n"); return 2;
            }
            *ids[i] = (unsigned)id;
        }
    }
#endif
    void *lib = dlopen("libgstreamer-1.0.so.0", RTLD_NOW | RTLD_GLOBAL);
    if (!lib) { emit("ERROR: system libgstreamer unavailable\n"); return 2; }
    LOAD(int, gst_init_check, int*, char***, void**);
    LOAD(void*, gst_parse_launch, const char*, void**);
    LOAD(void*, gst_bin_get_by_name, void*, const char*);
    LOAD(void*, gst_element_get_static_pad, void*, const char*);
    LOAD(unsigned long, gst_pad_add_probe, void*, unsigned, int(*)(void*,void*,void*), void*, void*);
    LOAD(int, gst_element_set_state, void*, int);
    LOAD(int, gst_element_get_state, void*, int*, int*, uint64_t);
    LOAD(void*, gst_element_get_bus, void*);
    LOAD(void*, gst_bus_timed_pop_filtered, void*, uint64_t, unsigned);
    LOAD(void, gst_message_parse_error, void*, void**, char**);
    LOAD(void, gst_mini_object_unref, void*);
    LOAD(void*, gst_pad_get_current_caps, void*);
    LOAD(char*, gst_caps_to_string, void*);
    LOAD(void, g_free, void*);
#if R5_DUAL
    if(r3_alternating && !r3_select_symbols(lib)) { emit("ERROR: alternating public symbols unavailable\n");return 2; }
    if(r3_alternating && !check_runtime && !r3_control_fd()) {
        emit("ERROR: alternating requires a distinct read-only control fd\n");return 2;
    }
#endif
#if R5_DISPLAY_OBSERVE
    if(!r5_observe_symbols(lib)) return 2;
#endif
#if R5_LANE_OVERLAY
    if(!r5_lane_symbols(lib)) { emit("ERROR: lane overlay public symbols unavailable\n");return 2; }
#endif
#if R5_H265_RECORD
    if(!r5_record_symbols(lib)) { emit("ERROR: recording public symbols unavailable\n");return 2; }
#endif
#if R5_H265_TAIL
    if(!r5_tail_symbols(lib)) { emit("ERROR: tail public symbols unavailable\n");return 2; }
#endif
    if(!fps_symbols(lib)) { emit("ERROR: FPS public symbols unavailable\n");return 2; }
    if (check_runtime) { emit("OBSERVER_RUNTIME_PUBLIC_SYMBOLS_READY_NO_GST_INIT_NO_PIPELINE\n"); return 0; }
    void *error = NULL;
    if (!gst_init_check(NULL, NULL, &error)) return 2;
#if R5_DUAL
    if(!r3_alternating && !fps_register_compositor()) { emit("ERROR: FPS compositor registration failed\n");return 2; }
#endif
    const char *pipeline = offline ?
#if R5_KMS_NV12
        "videotestsrc num-buffers=32 ! video/x-raw,format=NV12,width=1920,height=1080 ! "
        "identity name=r5decoder ! capsfilter name=r5convert caps=video/x-raw,format=NV12 ! "
        "identity name=r5sink ! fakesink async=false" :
#elif R5_MPP_BGRX
        /* Host-only RGB transport fixture: no JPEG decode, MPP or RGA. */
        "videotestsrc num-buffers=32 ! video/x-raw,format=BGRx,width=1920,height=1080 ! "
        "identity name=r5decoder ! capsfilter name=r5convert caps=video/x-raw,format=BGRx ! "
        "identity name=r5sink ! fakesink async=false" :
#elif R5_CONVERT3
        "videotestsrc num-buffers=32 ! video/x-raw,format=NV12,width=1920,height=1080 ! "
        "identity name=r5decoder ! videoconvert n-threads=3 name=r5convert ! "
        "video/x-raw,format=BGRx ! identity name=r5sink ! fakesink async=false" :
#elif R5_CONVERT2
        "videotestsrc num-buffers=32 ! video/x-raw,format=NV12,width=1920,height=1080 ! "
        "identity name=r5decoder ! videoconvert n-threads=2 name=r5convert ! "
        "video/x-raw,format=BGRx ! identity name=r5sink ! "
#if R5_DISPLAY_OBSERVE
        "identity sleep-time=20000 ! " /* Host-only known downstream wait. */
#endif
        "fakesink async=false" :
#else
        "fakesrc num-buffers=32 ! identity name=r5decoder ! "
#if R5_QUEUE1
        "queue max-size-buffers=1 max-size-bytes=0 max-size-time=0 leaky=no ! "
#endif
        "identity name=r5convert ! identity name=r5sink ! fakesink async=false" :
#endif
#if R5_KMS_NV12
#if R5_H265_RECORD
        "appsrc name=r5source format=time is-live=false block=true max-bytes=4194304 "
        "caps=\"image/jpeg,framerate=0/1\" ! jpegparse ! "
#elif R5_LANE_OVERLAY
        "appsrc name=r5source format=time is-live=false block=true max-bytes=4194304 "
        "caps=\"image/jpeg,framerate=60/1\" ! jpegparse ! "
#else
        "fdsrc fd=0 do-timestamp=true ! image/jpeg,framerate=60/1 ! jpegparse ! "
#endif
        "mppjpegdec name=r5decoder format=NV12 ! "
        "capsfilter name=r5convert caps=video/x-raw,format=NV12,width=1920,height=1080 ! "
        "kmssink name=r5sink driver-name=rockchip sync=false force-modesetting=true"
#if R5_KMS_SKIP_VSYNC
        " skip-vsync=true"
#endif
        ;
#else
#if R5_MPP_BGRX
        "fdsrc fd=0 do-timestamp=true ! image/jpeg,framerate=30/1 ! jpegparse ! "
        "mppjpegdec name=r5decoder format=BGRx ! "
        "capsfilter name=r5convert caps=video/x-raw,format=BGRx,width=1920,height=1080 ! "
        "ximagesink name=r5sink sync=false force-aspect-ratio=true handle-events=false";
#else
        "fdsrc fd=0 do-timestamp=true ! image/jpeg,framerate=30/1 ! jpegparse ! mppjpegdec name=r5decoder ! "
#if R5_QUEUE1
        "queue max-size-buffers=1 max-size-bytes=0 max-size-time=0 leaky=no ! "
#endif
#if R5_CONVERT3
        "videoconvert n-threads=3 name=r5convert ! ximagesink name=r5sink sync=false force-aspect-ratio=true handle-events=false";
#elif R5_CONVERT2
        "videoconvert n-threads=2 name=r5convert ! ximagesink name=r5sink sync=false force-aspect-ratio=true handle-events=false";
#else
        "videoconvert name=r5convert ! ximagesink name=r5sink sync=false force-aspect-ratio=true handle-events=false";
#endif
#endif
#endif
#if R5_KMS_NV12
    char kms_pipeline[1024];
    if (!offline
#if R5_LANE_OVERLAY
        && !lane_software
#endif
#if R5_H265_RECORD
        && !record_software
#endif
        ) {
        int length = snprintf(kms_pipeline,sizeof kms_pipeline,"%s connector-id=%u plane-id=%u",pipeline,connector,plane);
        if (length < 0 || (size_t)length >= sizeof kms_pipeline) return 2;
        pipeline = kms_pipeline;
    }
#endif
#if R5_LANE_OVERLAY
    if(lane_software) pipeline="appsrc name=r5source format=time is-live=false block=true max-bytes=4194304 "
        "caps=\"image/jpeg,framerate=60/1\" ! jpegparse ! jpegdec ! videoconvert ! "
        "video/x-raw,format=NV12,width=1920,height=1080 ! identity name=r5decoder ! "
        "capsfilter name=r5convert caps=video/x-raw,format=NV12 ! "
        "identity name=r5sink ! fakesink async=false";
#endif
#if R5_H265_RECORD
    char record_pipeline[4096];
    if(record_software) {
        pipeline="appsrc name=r5source format=time is-live=false block=true max-bytes=4194304 "
            "caps=\"image/jpeg,framerate=0/1\" ! jpegparse ! jpegdec ! videoconvert ! "
            "video/x-raw,format=NV12,width=1920,height=1080 ! identity name=r5decoder ! "
            "capsfilter name=r5convert caps=video/x-raw,format=NV12 ! tee name=r5tee "
            "r5tee. ! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 ! "
            "identity name=r5sink ! fakesink async=false "
            #if R5_H265_TAIL
            "r5tee. ! queue name=r5recordqueue flush-on-eos=false max-size-buffers=3 max-size-bytes=0 max-size-time=0 leaky=downstream ! "
#else
            "r5tee. ! queue max-size-buffers=3 max-size-bytes=0 max-size-time=0 leaky=downstream ! "
#endif
            "capssetter caps=\"video/x-raw,framerate=60/1\" ! "
            "videorate name=r5rate drop-only=true skip-to-first=true ! "
            "video/x-raw,format=NV12,framerate=30/1 ! identity name=r5encoded ! fakesink async=false";
#if R5_H265_TAIL
        const char *directory=getenv("R5_H265_DIRECTORY");
        if(!directory || directory[0]!='/' || strlen(directory)>1500 ||
           strspn(directory,"/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-")!=strlen(directory))return 2;
        int n=snprintf(record_pipeline,sizeof record_pipeline,
            "appsrc name=r5source format=time is-live=false block=true max-bytes=4194304 "
            "caps=\"image/jpeg,framerate=0/1\" ! jpegparse ! jpegdec ! videoconvert ! "
            "video/x-raw,format=NV12,width=1920,height=1080 ! identity name=r5decoder ! "
            "capsfilter name=r5convert caps=video/x-raw,format=NV12 ! tee name=r5tee "
            "r5tee. ! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 ! "
            "identity name=r5sink ! fakesink async=false "
            "r5tee. ! queue name=r5recordqueue flush-on-eos=false max-size-buffers=3 max-size-bytes=0 max-size-time=0 leaky=downstream ! "
            #if R5_H265_60FPS
            "capssetter caps=\"video/x-raw,framerate=60/1\" ! identity name=r5rate ! "
            "video/x-raw,format=NV12,framerate=60/1 ! videoconvert ! video/x-raw,format=I420 ! "
            "vp8enc name=r5encoder deadline=1 cpu-used=8 threads=2 target-bitrate=8000000 lag-in-frames=0 keyframe-max-dist=8 ! "
#else
            "identity sleep-time=15000 ! capssetter caps=\"video/x-raw,framerate=60/1\" ! videorate name=r5rate drop-only=true skip-to-first=true ! "
            "video/x-raw,format=NV12,framerate=30/1 ! videoconvert ! video/x-raw,format=I420 ! "
            "vp8enc name=r5encoder deadline=1 cpu-used=8 threads=2 target-bitrate=4000000 lag-in-frames=0 keyframe-max-dist=8 ! "
#endif
            "identity name=r5parser ! identity name=r5encoded ! splitmuxsink name=r5record muxer=webmmux "
            "async-finalize=false max-size-time=250000000 max-size-bytes=0 location=%s/segment-%%05d.partial.mp4",directory);
        if(n<0 || (size_t)n>=sizeof record_pipeline)return 2;
        pipeline=record_pipeline;
#endif
    } else if(!offline) {
        const char *directory=getenv("R5_H265_DIRECTORY");
        if(!directory || directory[0]!='/' || strlen(directory)>1500 ||
            strspn(directory,"/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-")!=strlen(directory)) {
            emit("ERROR: recording requires explicit safe absolute directory\n");return 2;
        }
        int n=snprintf(record_pipeline,sizeof record_pipeline,
            "appsrc name=r5source format=time is-live=false block=true max-bytes=4194304 "
            "caps=\"image/jpeg,framerate=0/1\" ! jpegparse ! mppjpegdec name=r5decoder format=NV12 ! "
            "capsfilter name=r5convert caps=video/x-raw,format=NV12,width=1920,height=1080 ! tee name=r5tee "
            "r5tee. ! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 ! "
            "kmssink name=r5sink driver-name=rockchip sync=false force-modesetting=true skip-vsync=true connector-id=%u plane-id=%u "
            #if R5_H265_TAIL
            "r5tee. ! queue name=r5recordqueue flush-on-eos=false max-size-buffers=3 max-size-bytes=0 max-size-time=0 leaky=downstream ! "
#else
            "r5tee. ! queue max-size-buffers=3 max-size-bytes=0 max-size-time=0 leaky=downstream ! "
#endif
            "capssetter caps=\"video/x-raw,framerate=60/1\" ! "
            #if R5_H265_60FPS
            "identity name=r5rate ! video/x-raw,format=NV12,framerate=60/1 ! "
            "mpph265enc name=r5encoder rc-mode=vbr bps=8000000 bps-min=2000000 bps-max=10000000 gop=120 max-pending=2 ! "
#else
            "videorate name=r5rate drop-only=true skip-to-first=true ! video/x-raw,format=NV12,framerate=30/1 ! "
            "mpph265enc name=r5encoder rc-mode=vbr bps=4000000 bps-min=1000000 bps-max=6000000 gop=60 max-pending=2 ! "
#endif
            #if R5_H265_TAIL
            "h265parse name=r5parser config-interval=-1 ! video/x-h265,stream-format=hvc1,alignment=au,profile=main ! identity name=r5encoded ! "
#else
            "h265parse config-interval=-1 ! video/x-h265,stream-format=hvc1,alignment=au,profile=main ! identity name=r5encoded ! "
#endif
            "splitmuxsink name=r5record async-finalize=false max-files=0 "
            #if R5_H265_60FPS
            "max-size-time=5000000000 max-size-bytes=8388608 send-keyframe-requests=true "
#else
            "max-size-time=5000000000 max-size-bytes=4194304 send-keyframe-requests=true "
#endif
            "location=%s/segment-%%05d.partial.mp4",connector,plane,directory);
        if(n<0 || (size_t)n>=sizeof record_pipeline)return 2;
        pipeline=record_pipeline;
    }
#endif
#if R5_DUAL
    char dual_pipeline[4096];
    if(!r3_dual_pipeline(dual_pipeline,sizeof dual_pipeline,offline,connector,plane)) {
        emit("ERROR: dual pipeline requires a distinct readable camera1 fd\n");return 2;
    }
    pipeline=dual_pipeline;
#endif
    void *pipe = gst_parse_launch(pipeline, &error);
    if (!pipe || error) { emit("ERROR: observer parse_launch failed\n"); return 2; }
    void *decoder=gst_bin_get_by_name(pipe,"r5decoder"), *sink=gst_bin_get_by_name(pipe,"r5sink");
    if (!decoder || !sink) { emit("ERROR: observer named elements missing\n"); return 2; }
    void *convert=gst_bin_get_by_name(pipe,"r5convert");
    if (!convert) { emit("ERROR: converter missing\n"); return 2; }
#if R5_KMS_NV12
#if R5_DUAL
    emit(r3_alternating?"R3PATH TWO_MPP_SELECTOR_SINGLE_KMS_QDATA_CAMERA_NO_EXPOSURE_PAIRING\n":
        "R3PATH TWO_MPP_CPU_NV12_COMPOSITION_SINGLE_KMS_NO_EXPOSURE_PAIRING\n");
#else
    emit("R5PATH KMS_NV12_CAPSFILTER_NO_CPU_CONVERSION_RETAIN_DRM\n");
#endif
#elif R5_MPP_BGRX
    /* Reuse channels 3/4 for a pass-through capsfilter, NOT a converter.
     * The plugin owns PP/RGA, allocation and sync. No app buffer reuse. */
    emit("R5PATH MPP_BGRX_CAPSFILTER_NO_CPU_CONVERSION\n");
#endif
    /* 0=decoder src,1=sink input; 2=decoder sink,3=converter sink,4=converter src. */
    void *pads[STREAM_COUNT] = {gst_element_get_static_pad(decoder,"src"), gst_element_get_static_pad(sink,"sink"),
        gst_element_get_static_pad(decoder,"sink"), gst_element_get_static_pad(convert,"sink"),
        gst_element_get_static_pad(convert,"src")};
#if R5_DUAL
    void *decoder1=gst_bin_get_by_name(pipe,"r3decoder1");
    if(!decoder1) {emit("ERROR: second decoder missing\n");return 2;}
    pads[5]=gst_element_get_static_pad(decoder1,"src");
    pads[6]=gst_element_get_static_pad(decoder1,"sink");
#endif
    for (unsigned i=0;i<STREAM_COUNT;i++) {
        if (!pads[i] || !gst_pad_add_probe(pads[i],16,probe,&streams[i],NULL) ||
            !gst_pad_add_probe(pads[i],32,list_probe,&streams[i],NULL)) {
            emit("ERROR: observer pad probe installation failed\n"); return 2;
        }
    }
#if R5_DUAL
    if(r3_alternating) {
        r3_selector=gst_bin_get_by_name(pipe,"r3mix");
        r3_pads[0]=r3_selector?gst_element_get_static_pad(r3_selector,"sink_0"):NULL;
        r3_pads[1]=r3_selector?gst_element_get_static_pad(r3_selector,"sink_1"):NULL;
        void *output=r3_selector?gst_element_get_static_pad(r3_selector,"src"):NULL;
        if(!r3_pads[0] || !r3_pads[1] || !output ||
           !gst_pad_add_probe(pads[0],16,r3_camera_probe,(void*)(uintptr_t)0,NULL) ||
           !gst_pad_add_probe(pads[5],16,r3_camera_probe,(void*)(uintptr_t)1,NULL) ||
           !gst_pad_add_probe(output,16,r3_identity_probe,NULL,NULL) ||
           !gst_pad_add_probe(pads[1],16,r3_identity_probe,(void*)(uintptr_t)1,NULL)) {
            emit("ERROR: alternating camera identity probes unavailable\n");return 2;
        }
        r3_object_set(r3_pads[0],"always-ok",1,NULL);
        r3_object_set(r3_pads[1],"always-ok",1,NULL);
    }
#endif
#if R5_LANE_OVERLAY
    if(!offline && (!gst_pad_add_probe(pads[4],16,r5_lane_probe,NULL,NULL) ||
        !r5_lane_start(gst_bin_get_by_name(pipe,"r5source")))) {
        emit("ERROR: lane overlay setup failed\n");return 2;
    }
#endif
#if R5_H265_RECORD
    if(!offline) {
        if((!record_software || R5_H265_TAIL) && !r5_record_limits(gst_bin_get_by_name(pipe,"r5record"),getenv("R5_H265_DIRECTORY"))) {
            emit("ERROR: recording file limits unavailable\n");return 2;
        }
        void *rate=gst_bin_get_by_name(pipe,"r5rate"),*encoded=gst_bin_get_by_name(pipe,"r5encoded");
        void *ratepad=rate?gst_element_get_static_pad(rate,"src"):NULL;
        void *encodedpad=encoded?gst_element_get_static_pad(encoded,"src"):NULL;
        if(!ratepad || !encodedpad || !gst_pad_add_probe(pads[4],16,r5_record_raw,NULL,NULL) ||
           !gst_pad_add_probe(ratepad,16,r5_record_rate_probe,NULL,NULL) ||
           !gst_pad_add_probe(encodedpad,16,r5_record_encoded_probe,NULL,NULL)
#if !R5_H265_TAIL
           || !r5_record_start(gst_bin_get_by_name(pipe,"r5source"))
#endif
           ) {
            emit("ERROR: recording setup failed\n");return 2;
        }
    }
#endif
#if R5_DISPLAY_OBSERVE
    if(!r5_observe_start(pads[4])) { emit("ERROR: public push tracer setup failed\n");return 2; }
#endif
#if R5_H265_TAIL
    if(!offline && (!r5_tail_setup(pipe,gst_bin_get_by_name,gst_element_get_static_pad,gst_pad_add_probe) ||
       !r5_record_start(gst_bin_get_by_name(pipe,"r5source")))) {
        emit("ERROR: tail setup failed\n");return 2;
    }
#endif
#if R5_DUAL
    if(!r3_alternating) {
        fps_mix=gst_bin_get_by_name(pipe,"r3mix");
        for(unsigned i=0;i<2;i++) {
            fps_mix_pads[i]=fps_mix?gst_element_get_static_pad(fps_mix,i?"sink_1":"sink_0"):NULL;
            if(!fps_mix_pads[i] || !gst_pad_add_probe(fps_mix_pads[i],16,fps_tag_input,(void*)(uintptr_t)i,NULL)) {
                emit("ERROR: FPS composed input identity setup failed\n");return 2;
            }
        }
    }
#endif
    if(!gst_pad_add_probe(pads[1],16,fps_hud_probe,NULL,NULL) ||
       !gst_pad_add_probe(pads[1],32,fps_list_probe,NULL,NULL)) {
        emit("ERROR: FPS final NV12 probe setup failed\n");return 2;
    }
    char line[256];
    snprintf(line,sizeof line,"R5D1 CLOCK CLOCK_MONOTONIC %llu %ld\n",(unsigned long long)now_ns(),(long)getpid()); emit(line);
    emit("Setting pipeline to PAUSED ...\n");
    int ret=gst_element_set_state(pipe,3);
    int initial_failed = !ret;
    if (!ret) remember_failure("ERROR: Failed to set pipeline to PAUSED.\n");
    emit("Pipeline is PREROLLING ...\n");
    void *bus = gst_element_get_bus(pipe);
    int playing=0, failed=initial_failed;
#if R5_DISPLAY_OBSERVE
    int observed_caps=0;
#endif
    uint64_t start=now_ns(), hb=0;
    for (;;) {
        uint64_t now=now_ns();
        if(!failed && fps_error()) { remember_failure("ERROR: FPS identity/clock/NV12 mapping fault; retained\n");failed=1; }
#if R5_DUAL
        if(r3_alternating && !failed) {
            r3_control_poll();
            if(atomic_load(&r3_invalid)) { remember_failure("ERROR: alternating terminal control/identity fault\n");failed=1; }
        }
#endif
#if R5_LANE_OVERLAY
        if(!failed && r5_lane_error()) {
            remember_failure("ERROR: lane overlay PTS/input/NV12 mapping invalid; subsequent frames dropped\n");
            failed=1;
        }
#endif
#if R5_H265_RECORD
#if R5_H265_TAIL
        r5_tail_poll();
#endif
        if(!failed && r5_record_error()) {
            remember_failure("ERROR: recording input/PTS/byte budget invalid; subsequent frames dropped\n");failed=1;
        }
#endif
#if R5_H265_TAIL
        { /* Continue collecting late CLOSED after failure; never revive DONE. */
#else
        if (!failed) {
#endif
            void *msg=gst_bus_timed_pop_filtered(bus,0,
#if R5_H265_RECORD
                2|32768); /* ERROR or ELEMENT; public SDK GstMessage layout. */
            if(msg && GST_MESSAGE_TYPE((GstMessage*)msg)==GST_MESSAGE_ELEMENT) {
                r5_record_message(msg);gst_mini_object_unref(msg);msg=NULL;
            }
#else
                2); /* ERROR only: no struct access */
#endif
            if (msg) {
                char *debug=NULL; struct public_gerror *gerror=NULL;
                gst_message_parse_error(msg,(void**)&gerror,&debug);
                snprintf(line,sizeof line,"ERROR: Gst bus domain=%u code=%d message=%.100s debug=%.60s\n",gerror?gerror->domain:0,gerror?gerror->code:0,gerror&&gerror->message?gerror->message:"unavailable",debug?debug:"unavailable"); remember_failure(line);
                gst_mini_object_unref(msg); failed=1; /* Retain pipeline and refs, no NULL/restart. */
#if R5_H265_TAIL
                r5_tail_fail(19); /* Stop further tail actions after the first bus ERROR. */
#endif
            }
            if (!playing && !failed) {
                int state=0,pending=0;
                ret=gst_element_get_state(pipe,&state,&pending,0);
                if (!ret) { remember_failure("ERROR: GStreamer PAUSED transition failed\n"); failed=1; }
                else if (state==3 && (ret==1
#if R5_DUAL
                    || (r3_alternating && ret==3) /* live-source NO_PREROLL */
#endif
                )) {
                    emit("Pipeline is PREROLLED ...\nSetting pipeline to PLAYING ...\n");
                    if (!gst_element_set_state(pipe,4)) { remember_failure("ERROR: GStreamer PLAYING transition failed\n"); failed=1; }
                    playing=1;
                    for (unsigned i=0;i<2;i++) {
                        void *caps=gst_pad_get_current_caps(pads[i]);
                        if (caps) {
                            char *text=gst_caps_to_string(caps);
                            snprintf(line,sizeof line,"R5CAPS %u %.220s\n",i,text?text:"unknown"); emit(line);
                            g_free(text); gst_mini_object_unref(caps);
                        }
                    }
                }
            }
        }
        drain();
#if R5_DISPLAY_OBSERVE
        /* One bounded sample after actual data, not premature PAUSED caps.
         * Null remains UNKNOWN; never poll plugins or change negotiation.
         */
        if(!observed_caps && atomic_load(&streams[1].total)) {
            for(unsigned i=0;i<2;i++) {
                void *caps=gst_pad_get_current_caps(pads[i]);
                r5_observe_caps(i,caps);
                if(caps)gst_mini_object_unref(caps);
            }
            observed_caps=1;
        }
#endif
        if (now-hb>=250000000u) { if(first_failure[0]) emit(first_failure); heartbeat(); hb=now; }
        if (offline && now-start>
#if R5_DISPLAY_OBSERVE
            2000000000u
#else
            1000000000u
#endif
        ) { drain(); heartbeat(); return 0; }
        struct timespec pause={0,10000000}; nanosleep(&pause,NULL);
    }
}
