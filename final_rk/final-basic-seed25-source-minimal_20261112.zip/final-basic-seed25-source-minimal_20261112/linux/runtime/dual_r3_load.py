"""Explicit one-attempt DUAL R3 loader; no native open, unload or recovery.

Default is read-only. --execute is only for a separately approved current cold
trial. A bind/probe allocates DMA memory and enables BME. Timed-out operations
remain UNKNOWN and are NOT killed/retried; retain their PID and evidence.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

if __package__:
    from . import dual_r3_driver as driver
    from .handoff import save_new
    from .launch_calfix_algorithm_trial import trial_guards
else:
    import dual_r3_driver as driver
    from handoff import save_new
    from launch_calfix_algorithm_trial import trial_guards


def operation(argv, directory, name, timeout=15):
    """Launch at most once; leave pending kernel work untouched on timeout."""
    save_new(directory / (name + '-intent.json'), dict(argv=argv, monotonic_s=time.monotonic()))
    with (directory / (name + '.log')).open('xb') as log:
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log,
            stderr=subprocess.STDOUT, start_new_session=True,
            env=dict(PATH='/usr/sbin:/usr/bin:/sbin:/bin', LC_ALL='C', PYTHONDONTWRITEBYTECODE='1'))
    save_new(directory / (name + '-pid.json'), dict(pid=process.pid))
    try:
        result = process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        save_new(directory / (name + '-pending.json'), dict(pid=process.pid,
            status='UNKNOWN_PENDING_NO_KILL_NO_RETRY', monotonic_s=time.monotonic()))
        raise RuntimeError(name + ' pending; retain state, do not retry')
    save_new(directory / (name + '-return.json'), dict(returncode=result, monotonic_s=time.monotonic()))
    if result:
        raise RuntimeError(name + ' failed; retain state, do not retry')


def load_once(ko, expected_boot, run_dir, programming_note, *, execute=False, guard_root=Path('/run'), identity='mono'):
    ko = Path(ko).absolute()
    artifact = driver.verify_ko(ko, identity=identity)
    before = driver.inspect_target(expected_boot, identity=identity)
    if not programming_note.strip():
        raise ValueError('current programming confirmation required')
    own_guard = guard_root / ('dual-r3-driver-' + expected_boot + '.started')
    if any(os.path.lexists(p) for p in trial_guards(expected_boot, guard_root) + [own_guard]):
        raise ValueError('prior attempt; no same-boot takeover')
    plan = dict(status='PREPARED_NO_LOAD_OR_BIND', artifact=artifact, target=before,
        programming_note=programming_note, sram_identity='OPERATOR_RECEIPT_NOT_READBACK',
        probe_effects=['BAR mapping', 'coherent DMA pool/fence allocation', 'PCI bus master enable'],
        native_opened=False)
    if not execute:
        return plan
    directory = Path(run_dir)
    if (not directory.is_absolute() or '..' in directory.parts or os.path.lexists(directory)
            or not directory.parent.is_dir() or any(p.is_symlink() for p in directory.parents)):
        raise ValueError('fresh absolute evidence directory required')
    directory.mkdir(mode=0o700)
    save_new(directory / 'plan.json', plan)
    # Claim before either system action. Any later failure leaves this receipt.
    save_new(own_guard, dict(boot_id=expected_boot, directory=str(directory), bdf=before['bdf']))
    try:
        current = driver.inspect_target(expected_boot, expected_bdf=before['bdf'], identity=identity)
        driver.verify_ko(ko, identity=identity)
        if current['status'] == 'MODULE_ABSENT_ENDPOINT_UNBOUND':
            parameters = dict(driver.PARAMETERS, target_bdf=current['bdf'])
            operation(['/sbin/insmod', str(ko)] + [str(k)+'='+str(v) for k,v in parameters.items()],
                      directory, 'insmod')
            current = driver.inspect_target(expected_boot, expected_bdf=before['bdf'], identity=identity)
            save_new(directory / 'after-insmod.json', current)
        if current['status'] == 'MATCHED_MODULE_ENDPOINT_UNBOUND':
            # No shell; only the fixed dynamic ID is written. Probe may block.
            code = ("import os; p='/sys/bus/pci/drivers/ph1a_c2h_candidate/new_id';"
                    "f=os.open(p,os.O_WRONLY|os.O_CLOEXEC);"
                    "n=os.write(f,b'1edb abcd\\n');os.close(f);"
                    "assert n==10, 'short new_id write'")
            operation(['/usr/bin/python3', '-B', '-c', code], directory, 'new-id')
        after = driver.check_target(expected_boot, expected_bdf=before['bdf'], identity=identity)
        result = dict(status='NEW_MODULE_BOUND_NOT_VIDEO_ACCEPTANCE', target=after,
                      artifact=artifact, native_opened=False)
        save_new(directory / 'result.json', result)
        return result
    except BaseException as error:
        save_new(directory / 'failure.json', dict(type=type(error).__name__, detail=str(error),
            status='RETAIN_NO_RETRY_NO_UNLOAD', native_opened=False))
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ko', type=Path, required=True)
    parser.add_argument('--expected-boot', required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--programming-note', required=True)
    parser.add_argument('--joint-cold-confirmed', action='store_true', required=True)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--identity', choices=('mono', 'stereo-n2'), default='mono')
    args = parser.parse_args(argv)
    print(json.dumps(load_once(args.ko, args.expected_boot, args.run_dir,
                               args.programming_note, execute=args.execute, identity=args.identity), indent=2))


if __name__ == '__main__':
    main()
