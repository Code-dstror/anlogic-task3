"""Explicit fixed-CALFIX measurement/candidate identities; never default profiles."""
import hashlib
from pathlib import Path

CALFIX_BIT = '3146bfb92b6089dcdbff7ae26d2eff44b58ef56f12bc2ed28aed89d22a4f46f4'
AUTOF21_BIT = '52a9cc36c0e5112e325e9fb9559a041cc6c5ee76be191794156a078573db8295'
AUTOF21_SOURCE = '77a0d36befb697dd9cbd5f0a8e56cfc5aeb491b1'
AUTOF21_PROFILE = 'autof21-f21-kms30'
AUTOF21_HDR_PROFILE = 'autof21-color-hdr-3s'
AUTOF21_LANE_PROFILE = 'autof21-lane-kms60'
AUTOF21_LANE_OVERLAY_PROFILE = 'autof21-lane-overlay-kms60'
AUTOF21_H265_PROFILE = 'autof21-h265-kms30'
AUTOF21_H265_TAIL_PROFILE = 'autof21-h265-tail-kms30'
AUTOF21_H265_60FPS_PROFILE = 'autof21-h265-60fps-kms60'
PROFILES = {
    'dual-hdr-seed1-cam0-sdr-hdr-sdr-3x10': dict(duration=90, dwell=10, nominal_dwell_s=30, queue1=False,
        config_timeout_s=10, command_timeout_s=12,
        bit_sha256='0e4de42629bd48f000782feeec65493dda8cf9126749b80dcc44e62211e4230e',
        fpga_source='06a122ee7060d56c5a4f783112cb727209c54ed5',
        dual_hdr_seed1=True, dual_r3_mono=True, hdr_allowed=True,
        record_version=4, header_bytes=2112,
        modes=(('color_sdr', 0, 10), ('color_hdr', 0, 10), ('color_sdr_restore', 0, 10)),
        startup_jpeg_gate=True, kms_nv12=True, kms_skip_vsync=True,
        lightweight_health=True, observe_display=True, runtime_date='20261101',
        scope='DUAL_HDR_SEED1_CAM0_COLOR_SDR_HDR_SDR_FIRST_VALID_3X10S_RETAIN_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'dual-sdr-seed51-mono-basic120': dict(duration=120, dwell=20, queue1=False,
        bit_sha256='12320a74248fba27c74d86f1709f9799b9c18ee0182a4f047ec6a67af72e2213',
        fpga_source='6f9c72762bd88abdc13e3a0ee31fd7dc97e4ccb7',
        seed51_mono_basic=True, dual_r3_mono=True, dual_r3_basic=True,
        hdr_allowed=False, dual_r3_hdr=False, dual_r3_lane=False,
        record_version=4, header_bytes=2112,
        modes=(('color', 0, 20), ('gray', 1, 20), ('gaussian', 4, 20),
               ('histogram', 8, 20), ('color_restore', 0, 20)),
        startup_jpeg_gate=True, kms_nv12=True, kms_skip_vsync=True,
        lightweight_health=True, observe_display=True, runtime_date='20261101',
        scope='DUAL_SDR_SEED51_MONO_BASIC5X20S_V4_NV12_KMS_START120S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'dual-r3-mono-hdr-cfg10-30': dict(duration=30, dwell=10, config_timeout_s=10, command_timeout_s=12, queue1=False,
        bit_sha256='7e9c32ac7a45813bb035d98a3145e319a3d3d63c8b5865c84bc6434e6b126150',
        fpga_source='e081883222a7cd342d6d1ffcc5836a443334fe11',
        dual_r3_mono=True, dual_r3_hdr=True, dual_r3_lane=False,
        record_version=4, header_bytes=2112, enables=0, mode_name='hdr',
        startup_jpeg_gate=True, single_cfg=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261031',
        scope='DUAL_R3_SEED2_MONO_HDR_CFG10_V4_NV12_KMS_START30S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'dual-r3-mono-hdr30': dict(duration=30, dwell=10, queue1=False,
        bit_sha256='7e9c32ac7a45813bb035d98a3145e319a3d3d63c8b5865c84bc6434e6b126150',
        fpga_source='e081883222a7cd342d6d1ffcc5836a443334fe11',
        dual_r3_mono=True, dual_r3_hdr=True, dual_r3_lane=False,
        record_version=4, header_bytes=2112, enables=0, mode_name='hdr',
        startup_jpeg_gate=True, single_cfg=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261031',
        scope='DUAL_R3_SEED2_MONO_HDR_V4_NV12_KMS_START30S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'dual-r3-mono-lane30': dict(duration=30, dwell=10, queue1=False,
        bit_sha256='7e9c32ac7a45813bb035d98a3145e319a3d3d63c8b5865c84bc6434e6b126150',
        fpga_source='e081883222a7cd342d6d1ffcc5836a443334fe11',
        dual_r3_mono=True, dual_r3_hdr=False, dual_r3_lane=True,
        record_version=4, header_bytes=2112, enables=48, mode_name='lane_data',
        startup_jpeg_gate=True, single_cfg=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261031',
        scope='DUAL_R3_SEED2_MONO_LANE_DATA_V4_NV12_KMS_START30S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'dual-r3-mono-basic120': dict(duration=120, dwell=20, queue1=False,
        bit_sha256='7e9c32ac7a45813bb035d98a3145e319a3d3d63c8b5865c84bc6434e6b126150',
        fpga_source='e081883222a7cd342d6d1ffcc5836a443334fe11',
        dual_r3_mono=True, dual_r3_basic=True, record_version=4, header_bytes=2112,
        modes=(('color', 0, 20), ('gray', 1, 20), ('gaussian', 4, 20),
               ('histogram', 8, 20), ('color_restore', 0, 20)),
        startup_jpeg_gate=True, kms_nv12=True, kms_skip_vsync=True,
        lightweight_health=True, observe_display=True, runtime_date='20261031',
        scope='DUAL_R3_SEED2_MONO_BASIC5X20S_V4_NV12_KMS_START120S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'dual-r3-mono-kms30': dict(duration=30, dwell=10, queue1=False,
        bit_sha256='7e9c32ac7a45813bb035d98a3145e319a3d3d63c8b5865c84bc6434e6b126150',
        fpga_source='e081883222a7cd342d6d1ffcc5836a443334fe11',
        dual_r3_mono=True, record_version=4, header_bytes=2112, enables=0,
        mode_name='color', startup_jpeg_gate=True, single_cfg=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261031',
        scope='DUAL_R3_SEED2_MONO_COLOR_V4_NV12_KMS_START30S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'autof21-remote-sdr300': dict(duration=300, dwell=280, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=0,
        mode_name='color', startup_jpeg_gate=True, remote_control=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_REMOTE_SDR_OWNER_KMS_START300S_MAX8_WEB_CFG_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    AUTOF21_H265_60FPS_PROFILE: dict(duration=60, dwell=40, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=0,
        mode_name='color', startup_jpeg_gate=True, single_cfg=True,
        h265_record=True, h265_tail=True, h265_60fps=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_COLOR_NV12_KMS_H265_1080P60_START60S_SD_BOUNDED_TAIL_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='8aa05e469bc74d9db23800f944f17fb95915bc5e5960e76f93cbfe7719162cd1'),
    AUTOF21_H265_TAIL_PROFILE: dict(duration=30, dwell=10, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=0,
        mode_name='color', startup_jpeg_gate=True, single_cfg=True,
        h265_record=True, h265_tail=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_COLOR_NV12_KMS_H265_START30S_BOUNDED_TAIL_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='3d5779c03ba033041e472f973a2c139a14f57680e00cad41f2648e5a4c1dd072'),
    AUTOF21_H265_PROFILE: dict(duration=30, dwell=10, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=0,
        mode_name='color', startup_jpeg_gate=True, single_cfg=True, h265_record=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_COLOR_NV12_KMS_H265_1080P30_START30S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='e636f8730febf56432f2a208e1ee1a9de4b57edd150b5e53f60db994e7b02be4'),
    AUTOF21_LANE_OVERLAY_PROFILE: dict(duration=60, dwell=40, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=48,
        mode_name='lane', startup_jpeg_gate=True, single_cfg=True, lane_overlay=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_F22_F23_NV12_LANE_OVERLAY_START60S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='31c88e9ea1bfa6e26fb0d3f42401917f3e7fe7861d5c0e140376b719394d7b20'),
    AUTOF21_LANE_PROFILE: dict(duration=60, dwell=40, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=48,
        mode_name='lane', startup_jpeg_gate=True, single_cfg=True,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_F22_F23_KMS_START60S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    AUTOF21_HDR_PROFILE: dict(duration=90, dwell=3, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE,
        alternating_color_hdr=True, segments=20, nominal_dwell_s=60,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True,
        observe_display=True, runtime_date='20261030',
        scope='AUTOF21_COLOR_HDR_20X3S_START90S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    AUTOF21_PROFILE: dict(duration=30, dwell=10, queue1=False,
        bit_sha256=AUTOF21_BIT, fpga_source=AUTOF21_SOURCE, enables=2,
        auto_f21_generation=1, kms_nv12=True, kms_skip_vsync=True,
        lightweight_health=True, observe_display=True, runtime_date='20261030',
        scope='AUTOF21_F21_KMS_30S_V1',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'calfix-perf-kms-combined360': dict(duration=360, dwell=30, queue1=False,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True, observe_display=True,
        combined_sdr=True, runtime_date='20261030',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        scope='CALFIX_SEED6_KMS_ALL_SDR_ALGORITHMS_360S_V1',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'calfix-perf-kms-health1800': dict(duration=1800, dwell=10, queue1=False,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True, observe_display=True,
        runtime_date='20261030', long_run_evidence=True, trace_bytes=32*1024*1024,
        kms_sync_trace_sha256='3cab643352d438bf3eb86a6e2d84bbb27b8e4be5b9dfacc00ba79f528668da4f',
        scope='CALFIX_SEED6_KMS_LIGHTWEIGHT_HEALTH_1800S_V1',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'calfix-perf-kms-health180': dict(duration=180, dwell=10, queue1=False,
        kms_nv12=True, kms_skip_vsync=True, lightweight_health=True, observe_display=True,
        runtime_date='20261030',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        scope='CALFIX_SEED6_KMS_LIGHTWEIGHT_HEALTH_180S_V1',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'calfix-perf-kms-skip180': dict(duration=180, dwell=10, queue1=False,
        kms_nv12=True, kms_skip_vsync=True, observe_display=True, runtime_date='20261030',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        scope='CALFIX_SEED6_KMS_SKIP_VSYNC_180S_V1',
        observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7'),
    'calfix-perf-kms-sync-30': dict(duration=30, dwell=10, queue1=False,
        kms_nv12=True, observe_display=True, runtime_date='20261030',
        kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
        scope='CALFIX_SEED6_KMS_SYNC_OBSERVE_30S_V1',
        observer_sha256='53ec18dbfe7112f1e6e6fc4aee6eb5dd6f7fb6e3d7a82c1d6c2f75d283aedc38'),
    'calfix-perf-kms-nv12-30flow180': dict(duration=180, dwell=10, queue1=False,
        kms_nv12=True, observe_display=True,
        scope='CALFIX_SEED6_PERF_KMS_NV12_30FLOW180S_V1',
        observer_sha256='53ec18dbfe7112f1e6e6fc4aee6eb5dd6f7fb6e3d7a82c1d6c2f75d283aedc38'),
    'calfix-perf-kms-nv12-180': dict(duration=180, dwell=160, queue1=False,
        kms_nv12=True, observe_display=True,
        scope='CALFIX_SEED6_PERF_KMS_NV12_180S_V1',
        observer_sha256='53ec18dbfe7112f1e6e6fc4aee6eb5dd6f7fb6e3d7a82c1d6c2f75d283aedc38'),
    'calfix-perf-kms-nv12-30': dict(duration=30, dwell=10, queue1=False,
        kms_nv12=True, observe_display=True,
        scope='CALFIX_SEED6_PERF_KMS_NV12_30S_V1',
        observer_sha256='53ec18dbfe7112f1e6e6fc4aee6eb5dd6f7fb6e3d7a82c1d6c2f75d283aedc38'),
    'calfix-perf-serial30': dict(duration=30, dwell=10, queue1=False,
        scope='CALFIX_SEED6_PERF_SERIAL_30S_V1',
        observer_sha256='a9849732db9632425d565dcd391b9fc6004bdae66496a06ff2a1cf7783597fa5'),
    'calfix-perf-queue180': dict(duration=180, dwell=160, queue1=True,
        scope='CALFIX_SEED6_PERF_QUEUE1_180S_V1',
        observer_sha256='8c52f6ee056e593ab1b4733bf0d0bda6e840fbfedb8e19cb8b0b40a00f495c77'),
    'calfix-perf-convert2-180': dict(duration=180, dwell=160, queue1=False, convert_threads=2,
        scope='CALFIX_SEED6_PERF_CONVERT2_180S_V1',
        observer_sha256='0152e04957f441d398cef922b1627e02021c501b75198963b9dbbb03ad46da3c'),
    'calfix-perf-convert3-30': dict(duration=30, dwell=10, queue1=False, convert_threads=3,
        scope='CALFIX_SEED6_PERF_CONVERT3_30S_V1',
        observer_sha256='a3b203e5fd90f59de8623c94e9fb6fc35ccf344341067d7092dd0e6654a446ea'),
    'calfix-perf-convert3-180': dict(duration=180, dwell=160, queue1=False, convert_threads=3,
        scope='CALFIX_SEED6_PERF_CONVERT3_180S_V1',
        observer_sha256='a3b203e5fd90f59de8623c94e9fb6fc35ccf344341067d7092dd0e6654a446ea'),
    'calfix-perf-observe2-30': dict(duration=30, dwell=10, queue1=False, convert_threads=2,
        observe_display=True, measurement_only=True,
        scope='CALFIX_SEED6_PERF_OBSERVE2_30S_V1',
        observer_sha256='fc7cf113aaf4b399b98bd5f2a3539064c26cf21d4f4ae8b40a90e9c919ea5d40'),
    'calfix-perf-mpp-bgrx-30': dict(duration=30, dwell=10, queue1=False,
        mpp_bgrx=True, observe_display=True,
        scope='CALFIX_SEED6_PERF_MPP_BGRX_30S_V1',
        observer_sha256='0346a0aa8af76998ac048c3a2f7209c6fb41085fab07a90d3f2b67fac88eea77'),
}

# Static files only. Do not initialize plugins/MPP/RGA to run this check.
RGB_LIBRARIES = {
    '/usr/lib/aarch64-linux-gnu/gstreamer-1.0/libgstrockchipmpp.so':
        '3d8ba46034f29d638736e77f66f7dd9f5dafa56c1b28245998ce3aede6862865',
    '/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.1':
        '5fb91f82869ef7823c1111dbc9ef39452e00ff4464c97010091db18d625e5d1a',
    '/usr/lib/aarch64-linux-gnu/librga.so.2':
        'ba8744397f126c87dc2d637ddea35cca562aa8f323631bb4b9883816b3dcb714',
}

# Read-only verified against this RK boot and the SDK providing public headers.
LANE_LIBRARIES = {
    '/usr/lib/aarch64-linux-gnu/libgstreamer-1.0.so.0':
        '1159cec4173951f42c39f9143610a44579204eb218f101a6ad858649ead8348f',
    '/usr/lib/aarch64-linux-gnu/libgstvideo-1.0.so.0':
        '2610e2a21524e1c8b3230dbe4a67e796678ad6bd9e0d3b06a547283d1d3330a1',
    '/usr/lib/aarch64-linux-gnu/libgstapp-1.0.so.0':
        '503af96e59ff9c9c575c1efbd4501d611bb2f87e97293e073de8309bdcf47f92',
}

# SDK plugin identities also read-only matched on boot 84dddcc3 (2026-10-30).
# Recheck board files before initialization; this is not encoding acceptance.
H265_PLUGINS = {
    'libgstapp.so': 'fccfec52ebf106d8f9db37452917ee314d7cf263406d128b888a25174adbe0b5',
    'libgstdebug.so': '5746120055181f7493cbfc2d90926483296be6069a38096bb95a7015f4e83cdb',
    'libgstvideorate.so': 'd0c7bb6d478fb1ac13887861672d6319112809b0f39d64880dde284aaf3d4ea0',
    'libgstvideoparsersbad.so': '196b658d04cce86a34fe878ca8682a3e5ced0e5292a7300bdbc8db90e235e939',
    'libgstisomp4.so': 'd6f28225c1fcbccf2b5f660cee51942a29eced1dc2846339986172992ea0cbb5',
    'libgstmultifile.so': '71b439ecca82c738fe9b2c5d57477b3f3eabdaaf14dd6aae0e8105b82011ece3',
    'libgstcoreelements.so': '25ea75f12bc1dc8082a450c8f58d6f84358a65835574bd9cd5a3716bb3941a65',
}


def verify_profile_libraries(profile):
    if PROFILES.get(profile,{}).get('fps_hud_variant'):
        if __package__:
            from .fps_hud import verify_libraries
        else:
            from fps_hud import verify_libraries
        verify_libraries(PROFILES[profile]['fps_hud_variant'])
    if PROFILES.get(profile, {}).get('lane_overlay') or PROFILES.get(profile, {}).get('h265_record'):
        for name, expected in LANE_LIBRARIES.items():
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
                raise ValueError('public SDK dependency differs: '+name)
    if PROFILES.get(profile, {}).get('h265_record'):
        libraries = dict(RGB_LIBRARIES)
        libraries.update({str(Path('/usr/lib/aarch64-linux-gnu/gstreamer-1.0')/name): value
                          for name, value in H265_PLUGINS.items()})
        for name, expected in libraries.items():
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
                raise ValueError('H.265 candidate dependency differs: '+name)
    if PROFILES.get(profile, {}).get('mpp_bgrx'):
        for name, expected in RGB_LIBRARIES.items():
            if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
                raise ValueError('MPP BGRx dependency differs: '+name)


def observer_identity(profile):
    row = PROFILES[profile]
    return 'gst_perf_observer', row['observer_sha256']


# Explicit phase recipes. Nominal observation excludes bounded configuration
# and warmup, and a fresh cold boot is required for every phase.
_seed1_common = dict(queue1=False,config_timeout_s=10,command_timeout_s=12,
    bit_sha256='0e4de42629bd48f000782feeec65493dda8cf9126749b80dcc44e62211e4230e',
    fpga_source='06a122ee7060d56c5a4f783112cb727209c54ed5',
    seed1_recipe=True,dual_r3_mono=True,record_version=4,header_bytes=2112,
    startup_jpeg_gate=True,kms_nv12=True,kms_skip_vsync=True,
    lightweight_health=True,observe_display=True,runtime_date='20261101',lane_overlay=False,
    kms_sync_trace_sha256='cf1db17ba6777adb1dd6f24654e8a7514d1a12070f7de5a4abd7891f47de28dd',
    observer_sha256='b3ad812812b4613b8b7739cb1e6132b4b9efa5cd24fba958de406e4cb77058f7')
PROFILES.update({
    'dual-hdr-seed1-mono-six-stage':dict(_seed1_common,duration=240,dwell=10,
        nominal_dwell_s=110,hdr_allowed=True,
        modes=(('color_sdr',0,10),('color_hdr',0,60),('color_sdr_restore',0,10),
               ('gaussian',4,10),('gray',1,10),('histogram',8,10)),
        scope='DUAL_HDR_SEED1_PHASE_A_SDR_HDR60_SDR_GAUSS_GRAY_HE_FIRST_VALID_RETAIN_V1'),
    'dual-hdr-seed1-mono-lane-data':dict(_seed1_common,duration=60,dwell=10,
        nominal_dwell_s=20,hdr_allowed=False,lane_data_only=True,
        modes=(('color_sdr',0,10),('lane_data',48,10)),
        scope='DUAL_HDR_SEED1_PHASE_C_SDR_LANE_DATA_FIRST_VALID_2X10S_NO_OVERLAY_RETAIN_V1'),
    'dual-hdr-seed1-mono-lane-overlay-10-60-10':dict(_seed1_common,duration=150,dwell=10,
        nominal_dwell_s=80,hdr_allowed=False,lane_data_only=False,lane_overlay=True,c1_lane_overlay=True,
        modes=(('color_sdr',0,10),('lane_overlay',48,60),('color_sdr_restore',0,10)),
        observer_sha256='f86105e6309fcc5c077c438c3df6470b591fc2546873381090c54534ec73e418',
        core_library_sha256='63a21cd68f5ac126c5365e041afa02ae2625d3dd5b3c9220511c6d1397e0b2aa',
        scope='DUAL_HDR_SEED1_CAM0_SDR10_C1_CURVES60_SDR10_FIRST_MATCHED_SINK_RETAIN_V1'),
})
del _seed1_common
