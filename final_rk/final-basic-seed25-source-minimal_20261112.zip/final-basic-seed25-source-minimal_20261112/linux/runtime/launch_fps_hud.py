"""Select the fixed FPS package's guarded entry; never starts by default."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def main(argv=None):
    argv=list(sys.argv[1:] if argv is None else argv)
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--index-sha256',required=True)
    parser.add_argument('--profile')
    args,_=parser.parse_known_args(argv)
    raw=(args.root/'runtime-index.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=args.index_sha256:raise ValueError('FPS index differs')
    index=json.loads(raw);profile=index['profile']
    if __package__:
        from .fps_hud import verify_feature
    else:
        from fps_hud import verify_feature
    info=verify_feature(args.root,index,profile)
    if args.profile is not None and args.profile!=profile:raise ValueError('FPS profile differs')
    if args.profile is None:argv+=['--profile',profile]
    if info['variant']=='dual':
        if __package__:
            from .launch_dual_r3_alternating import main as launch
        else:
            from launch_dual_r3_alternating import main as launch
    else:
        if __package__:
            from .launch_calfix_algorithm_trial import main as launch
        else:
            from launch_calfix_algorithm_trial import main as launch
    return launch(argv,required_profile=profile)


if __name__=='__main__':main()
