"""Opt-in bounded worker timing. No native callback work, devices or cleanup.

Pipe waits include downstream backpressure/scheduling; write syscall time is
not JPEG decode time. /proc snapshots are at most once/sec on the preview worker.
"""
import os
from pathlib import Path
import select
import time

if __package__:
    from .algorithm_preview import ObserverLog
else:
    from algorithm_preview import ObserverLog


class Aggregate:
    def __init__(self):
        self.count = self.total_ns = self.max_ns = 0

    def add(self, value):
        if value < 0:
            raise ValueError('negative performance interval')
        self.count += 1
        self.total_ns += value
        self.max_ns = max(self.max_ns, value)

    def snapshot(self):
        return dict(count=self.count, total_ns=self.total_ns, max_ns=self.max_ns,
                    mean_ns=self.total_ns / self.count if self.count else None)


def measured_write(fd, body, *, timeout=2, clock=time.monotonic,
                   ns=time.monotonic_ns, writer=os.write, waiter=select.select):
    """Same whole-JPEG deadline/partial-error rule as write_bounded; no resend."""
    deadline, offset = clock() + timeout, 0
    result = dict(wait_ns=0, syscall_ns=0, waits=0, writes=0, eagain=0)
    while offset < len(body):
        remaining = deadline - clock()
        if remaining <= 0:
            raise TimeoutError('JPEG pipe deadline; partial_bytes=' + str(offset))
        start = ns()
        ready = waiter([], [fd], [], min(.05, remaining))[1]
        result['wait_ns'] += ns() - start
        result['waits'] += 1
        if not ready:
            continue
        start = ns()
        try:
            count = writer(fd, memoryview(body)[offset:])
        except BlockingIOError:
            result['eagain'] += 1
            continue
        finally:
            result['syscall_ns'] += ns() - start
            result['writes'] += 1
        if count <= 0 or count > len(body) - offset:
            raise RuntimeError('JPEG pipe invalid write count')
        offset += count
    return dict(result, bytes=offset)


def process_counters(pid, proc=Path('/proc')):
    """Ordinary proc files only; per-thread ticks/wait values need interval deltas."""
    result = dict(pid=pid, threads={}, errors=[])
    try:
        for task in sorted((proc / str(pid) / 'task').iterdir()):
            try:
                raw = (task / 'stat').read_text()
                fields = raw[raw.rfind(')') + 2:].split()
                sched = [int(x) for x in (task / 'schedstat').read_text().split()]
                result['threads'][task.name] = dict(name=raw[raw.find('(')+1:raw.rfind(')')],
                    state=fields[0], user_ticks=int(fields[11]), system_ticks=int(fields[12]),
                    last_cpu=int(fields[36]), run_ns=sched[0], runqueue_wait_ns=sched[1],
                    timeslices=sched[2])
            except (OSError, ValueError, IndexError) as error:
                result['errors'].append(task.name + ':' + str(error)[:120])
    except OSError as error:
        result['errors'].append(str(error)[:120])
    return result


class Performance:
    def __init__(self):
        self.spans = {}
        self.pipe_calls = dict(waits=0, writes=0, eagain=0, bytes=0)
        self.last_complete = None
        self.last_sample = None
        self.cpu_first = self.cpu_last = None

    def add(self, **spans):
        for key, value in spans.items():
            self.spans.setdefault(key, Aggregate()).add(value)

    def write(self, fd, body):
        result = measured_write(fd, body, timeout=2)
        self.add(pipe_wait_ns=result['wait_ns'], pipe_syscall_ns=result['syscall_ns'])
        for key in self.pipe_calls:
            self.pipe_calls[key] += result[key]
        return result

    def snapshot(self, observer_pid):
        now = time.monotonic_ns()
        if self.last_sample is None or now - self.last_sample >= 10**9:
            self.last_sample = now
            freq = {}
            for path in sorted(Path('/sys/devices/system/cpu/cpufreq').glob('policy*/scaling_cur_freq')):
                try:
                    freq[path.parent.name] = int(path.read_text())
                except (OSError, ValueError):
                    freq[path.parent.name] = None
            row = dict(monotonic_ns=now, ticks_per_second=os.sysconf('SC_CLK_TCK'),
                owner=process_counters(os.getpid()), observer=process_counters(observer_pid),
                scaling_cur_freq_khz=freq)
            self.cpu_first = self.cpu_first or row
            self.cpu_last = row
        return dict(scope='WORKER_HOST_TIME_NOT_SENSOR_OR_PHYSICAL_PRESENTATION',
            spans={k:v.snapshot() for k,v in self.spans.items()}, pipe_calls=dict(self.pipe_calls),
            cpu_first=self.cpu_first, cpu_last=self.cpu_last,
            cpu_scope='CUMULATIVE_THREAD_COUNTERS_INTERVAL_DELTA_REQUIRED_SCHEDSTAT_MAY_BE_DISABLED')


class PerformanceLog(ObserverLog):
    def __init__(self, *args):
        super().__init__(*args)
        self.stage_counts = [0, 0, 0]
        self.stage_last_ns = [None, None, None]

    def extra_line(self, line):
        parts = line.split()
        if parts[:1] != [b'R5P1']:
            return
        if parts[:2] != [b'R5P1', b'E']:
            raise ValueError('unknown performance telemetry')
        if len(parts) != 5:
            raise ValueError('performance stage format')
        channel, count, stamp = map(int, parts[2:])
        if channel not in (2, 3, 4):
            raise ValueError('performance stage channel')
        i = channel - 2
        if count != self.stage_counts[i] + 1 or stamp <= 0:
            raise ValueError('performance stage loss')
        if self.stage_last_ns[i] is not None and stamp < self.stage_last_ns[i]:
            raise ValueError('performance stage clock regression')
        self.stage_counts[i], self.stage_last_ns[i] = count, stamp
