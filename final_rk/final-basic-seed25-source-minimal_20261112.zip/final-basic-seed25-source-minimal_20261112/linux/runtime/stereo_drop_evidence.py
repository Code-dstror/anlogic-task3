"""Bounded first-DROP evidence made only from independently owned records.

Writes are exclusive and synchronously read back before SAVED is reported.
This is application-level write/hash verification, without fsync or a promise
of survival across power loss. A failed writer is terminal and never retries.
"""
from collections import deque
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import time

if __package__:
    from .stereo_source_order import SourceOrderDrop
else:
    from stereo_source_order import SourceOrderDrop


MAX_CAPACITY = 4194304
COMPLETION_FIELDS = ('host_slot', 'transport_generation', 'transport_result',
                     'wire_length', 'record_identity', 'batch_sequence', 'batch_position')
REASONS = ('DROP_DUPLICATE_SOURCE', 'DROP_BACKWARD_SOURCE')


class SourceDropEvidenceError(RuntimeError):
    """First-DROP evidence could not be completely written and verified."""


def _identity(value):
    if value is None:
        return None
    if (type(value) not in (tuple, list) or len(value) > 8 or
            any(type(x) is not int for x in value)):
        raise ValueError('identity must contain bounded integer scalars')
    return list(value)


def _completion(value):
    if value is not None and type(value) is not dict:
        raise ValueError('completion_metadata must be a scalar dictionary')
    value = {} if value is None else value
    result = {}
    for name in COMPLETION_FIELDS:
        item = value.get(name)
        if name == 'record_identity':
            item = _identity(item)
        elif item is not None and type(item) is not int:
            raise ValueError('completion scalar is not an integer: '+name)
        result[name] = item
    result['missing'] = [name for name in COMPLETION_FIELDS if result[name] is None]
    return result


def _previous(value, camera):
    if type(value) not in (tuple, list, deque) or len(value) > 2:
        raise ValueError('previous_accepted must contain at most two scalar summaries')
    summaries = []
    for item in value:
        if type(item) is not dict or len(item) > 32:
            raise ValueError('previous accepted summary is not a bounded dictionary')
        copied = {}
        for key, scalar in item.items():
            if type(key) is not str or len(key) > 80:
                raise ValueError('invalid previous accepted summary key')
            if scalar is None or type(scalar) in (bool, int):
                copied[key] = scalar
            elif type(scalar) is str and len(scalar) <= 256:
                copied[key] = scalar
            elif type(scalar) in (list, tuple):
                copied[key] = _identity(scalar)
            else:
                raise ValueError('previous accepted summaries must contain only scalars')
        if copied.get('camera', camera) != camera:
            raise ValueError('previous accepted summary belongs to another camera')
        summaries.append(copied)
    return summaries


class SourceDropEvidence:
    """Save no more than one native-capacity wire for each of CAM0 and CAM1."""

    def __init__(self, directory, *, run_id, capacity=MAX_CAPACITY):
        path = Path(directory)
        if not path.is_absolute():
            raise ValueError('DROP evidence requires an absolute fresh directory')
        if (type(run_id) is not str or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}', run_id)
                or run_id in ('.', '..')):
            raise ValueError('run_id must be a bounded filename-safe identifier')
        if type(capacity) is not int or not 1 <= capacity <= MAX_CAPACITY:
            raise ValueError('DROP evidence capacity must be at most four MiB per camera')
        # Atomic fresh-directory admission; a previous run or symlink is rejected.
        path.mkdir(mode=0o700)
        self.directory = path
        self.run_id, self.capacity = run_id, capacity
        self.failure = None
        self._cameras = [dict(camera=c, drop_duplicate_source=0, drop_backward_source=0,
            first_evidence=dict(status='NOT_SEEN')) for c in (0, 1)]

    @staticmethod
    def _write(path, data):
        with path.open('xb') as target:
            remaining = memoryview(data)
            try:
                while remaining:
                    written = target.write(remaining)
                    if type(written) is not int or written <= 0:
                        raise OSError('evidence write made no progress')
                    remaining = remaining[written:]
            finally:
                remaining.release()
        # Read back the entire bounded file: existence alone is not success.
        digest = hashlib.sha256()
        size = 0
        with path.open('rb') as source:
            while block := source.read(65536):
                digest.update(block)
                size += len(block)
        if size != len(data) or digest.digest() != hashlib.sha256(data).digest():
            raise OSError('evidence readback length/SHA256 mismatch')

    def record(self, drop, *, host_ns=None, transport_identity=None,
               completion_metadata=None, previous_accepted=()):
        if self.failure is not None:
            raise SourceDropEvidenceError('DROP evidence writer is terminal: '+self.failure)
        if not isinstance(drop, SourceOrderDrop) or type(drop.wire) is not bytes:
            raise TypeError('evidence requires SourceOrderDrop with independently owned bytes')
        if type(drop.camera) is not int or drop.camera not in (0, 1) or drop.reason not in REASONS:
            raise ValueError('invalid SOURCE DROP camera/reason')
        if not 0 < len(drop.wire) <= self.capacity:
            raise ValueError('DROP wire exceeds established evidence capacity')
        for name in ('session', 'epoch', 'sequence', 'previous_sequence', 'delta'):
            if type(getattr(drop, name)) is not int or not 0 <= getattr(drop, name) <= 0xffffffff:
                raise ValueError('invalid SOURCE DROP identity scalar: '+name)
        delta = (drop.sequence-drop.previous_sequence) & 0xffffffff
        if (delta != drop.delta or
                (drop.reason == REASONS[0] and delta != 0) or
                (drop.reason == REASONS[1] and not 0x80000000 < delta <= 0xffffffff)):
            raise ValueError('inconsistent SOURCE DROP decision')
        camera = self._cameras[drop.camera]
        counter = 'drop_duplicate_source' if drop.reason == REASONS[0] else 'drop_backward_source'
        camera[counter] += 1
        if camera['first_evidence']['status'] == 'SAVED':
            return deepcopy(camera['first_evidence'])
        wire_path = self.directory / f'{self.run_id}-cam{drop.camera}-first-drop.ajpg'
        json_path = wire_path.with_suffix('.json')
        first = camera['first_evidence'] = dict(status='WRITING', wire_path=str(wire_path),
            json_path=str(json_path), attempted_paths=[], partial_paths=[])
        try:
            from linux.task3_pipeline import pcie_protocol_v1 as protocol
            if host_ns is None:
                host_ns = time.monotonic_ns()
            if type(host_ns) is not int or host_ns < 0:
                raise ValueError('host_ns must be a nonnegative monotonic integer')
            header = dict(zip(protocol.FRAME_HEADER_FIELD_NAMES,
                              protocol.FRAME_HEADER_STRUCT.unpack_from(drop.wire), strict=True))
            metadata = drop.record.metadata
            source = metadata.source
            if ((source.camera, source.session, source.epoch, source.sequence) !=
                    (drop.camera, drop.session, drop.epoch, drop.sequence)):
                raise ValueError('DROP record and SOURCE decision identities differ')
            if (header['header_length'] + header['payload_length'] != len(drop.wire) or
                    drop.wire[header['header_length']:] != drop.record.jpeg):
                raise ValueError('DROP wire/record lengths or owned payload differ')
            wire_sha = hashlib.sha256(drop.wire).hexdigest()
            document = dict(schema='STEREO_FIRST_SOURCE_DROP_V1',
                save_status_scope='WRITER_SNAPSHOT_MARKS_SAVED_ONLY_AFTER_FULL_READBACK',
                policy='drop_stale', run_id=self.run_id, camera=drop.camera,
                host_ns=host_ns, host_clock='MONOTONIC_HOST_RECEIPT_NOT_FPGA_EVENT_TIME',
                source_session=drop.session, source_epoch=drop.epoch,
                source_sequence=drop.sequence, previous_accepted_sequence=drop.previous_sequence,
                delta=drop.delta, reason=drop.reason,
                jpeg_session=metadata.jpeg_session, jpeg_slot=metadata.jpeg_slot,
                jpeg_generation=metadata.jpeg_generation,
                wire_bytes=len(drop.wire), header_bytes=header['header_length'],
                payload_bytes=header['payload_length'], wire_sha256=wire_sha,
                wire_path=str(wire_path), transport_identity=_identity(transport_identity),
                completion_metadata=_completion(completion_metadata),
                previous_accepted=_previous(previous_accepted, drop.camera),
                durability='FULL_WRITE_AND_SHA256_READBACK_NO_FSYNC_POWER_LOSS_GUARANTEE',
                validation_scope='PREVALIDATED_SOURCE_DROP_NOT_IMAGE_CONTENT_OR_FPGA_ROOT_CAUSE')
            first['attempted_paths'].append(str(wire_path))
            self._write(wire_path, drop.wire)
            first['partial_paths'].append(str(wire_path))
            raw_json = (json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2)+'\n').encode()
            first['attempted_paths'].append(str(json_path))
            self._write(json_path, raw_json)
            first.update(status='SAVED', wire_sha256=wire_sha, wire_bytes=len(drop.wire),
                         json_sha256=hashlib.sha256(raw_json).hexdigest(), partial_paths=[])
            return deepcopy(first)
        except BaseException as error:
            # Lock terminal state before any further filesystem observation:
            # a broken filesystem can reject stat as well as the write itself.
            self.failure = f'{type(error).__name__}: {error}'[:512]
            first.update(status='FAILED', failure=self.failure, partial_paths=[],
                         partial_paths_unknown=[], partial_path_probe_errors=[])
            for attempted in first['attempted_paths']:
                try:
                    if Path(attempted).exists():
                        first['partial_paths'].append(attempted)
                except BaseException as probe_error:
                    first['partial_paths_unknown'].append(attempted)
                    first['partial_path_probe_errors'].append(dict(path=attempted,
                        error=f'{type(probe_error).__name__}: {probe_error}'[:512]))
            raise SourceDropEvidenceError(self.failure) from error

    def snapshot(self):
        return deepcopy(dict(policy='drop_stale', run_id=self.run_id,
            directory=str(self.directory), capacity_per_camera=self.capacity,
            maximum_wire_files=2, maximum_wire_bytes=2*self.capacity,
            state='FAILED' if self.failure is not None else 'READY', failure=self.failure,
            cameras=self._cameras, durability='WRITE_AND_READBACK_NO_FSYNC'))
