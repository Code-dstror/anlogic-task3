"""Fixed CALFIX/RUNTIME SDR trial using the existing peer owner and MPP.

No PCIe bind, insmod, reset, programming, or cleanup. Default prepares only.
The native owner creates its own bounded direct preview; no disk relay process.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess

if __package__:
    from .performance_profiles import PROFILES as PERF_PROFILES, observer_identity, verify_profile_libraries
else:
    from performance_profiles import PROFILES as PERF_PROFILES, observer_identity, verify_profile_libraries

BIT = '3146bfb92b6089dcdbff7ae26d2eff44b58ef56f12bc2ed28aed89d22a4f46f4'
OBSERVER = '91f11e411ae0bc3090c12e89bda39d55f6cf1a4a2c649feee2cb81078858f697'
SCOPE = 'CALFIX_SEED6_DIRECT_SDR_SWITCH_500S_V1'
DEFAULT_PROFILE = 'sdr-minimal'
PROFILE_SCOPES = {DEFAULT_PROFILE: SCOPE,
    'sdr-extended': 'CALFIX_SEED6_DIRECT_SDR_EXTENDED_500S_V1',
    'sdr-gap-observe': 'CALFIX_SEED6_DIRECT_SDR_GAP_OBSERVE_500S_V1',
    'runtime-sdr-baseline': 'RUNTIME_SEED5_DIRECT_SDR_BASELINE_180S_V1'}
PROFILE_BITS = {profile: BIT for profile in PROFILE_SCOPES}
PROFILE_BITS['runtime-sdr-baseline'] = 'b404956e812038939ef00d59357966c0795bfd5116c596276f0f946ca6708a7b'

for _profile, _spec in PERF_PROFILES.items():
    PROFILE_SCOPES[_profile] = _spec['scope']
    PROFILE_BITS[_profile] = _spec.get('bit_sha256', BIT)


def selected_observer(profile):
    return observer_identity(profile) if profile in PERF_PROFILES else ('gst_observer', OBSERVER)


def verify_runtime(root, expected, profile=DEFAULT_PROFILE):
    """Bind every ordinary runtime member, including the complete peer tree."""
    if profile not in PROFILE_SCOPES:
        raise ValueError('unknown fixed SDR profile')
    root = Path(root)
    index = root / 'runtime-index.json'
    data = index.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('runtime index differs')
    document = json.loads(data)
    if document.get('scope') != PROFILE_SCOPES[profile] or document.get('bit_sha256') != PROFILE_BITS[profile]:
        raise ValueError('runtime scope/bit differs')
    # The historical minimal scope may omit profile. Extended packages must
    # explicitly declare their profile as well as the distinct scope.
    if document.get('profile', DEFAULT_PROFILE) != profile:
        raise ValueError('runtime profile differs')
    expected_source = PERF_PROFILES.get(profile, {}).get('fpga_source')
    if expected_source is not None and document.get('fpga_source') != expected_source:
        raise ValueError('runtime FPGA source differs')
    rows = document['files']
    required = {'gst_observer', 'calfix_algorithm_owner.py', 'direct_algorithm_preview.py',
                'peer_algorithm_owner.py', 'algorithm_preview.py',
                'launch_calfix_algorithm_trial.py', 'peer/linux/rk_debug/cli.py'}
    if profile in PERF_PROFILES:
        required.add('performance_profiles.py')
        if PERF_PROFILES[profile].get('dual_r3_mono'):
            required.update(('dual_r3.py', 'peer/linux/task3_pipeline/record_v4.py',
                             'uart/uart_observer.py', 'uart/capture_uart.py',
                             'dual_r3_driver.py', 'dual_r3_load.py', 'handoff.py',
                             'ph1a_c2h.ko'))
            required.add('seed1-recipe-provenance.json' if PERF_PROFILES[profile].get('seed1_recipe') else 'hdr-seed1-provenance.json' if PERF_PROFILES[profile].get('dual_hdr_seed1') else 'seed51-mono-provenance.json'
                         if PERF_PROFILES[profile].get('seed51_mono_basic')
                         else 'dual-r3-provenance.json')
        if PERF_PROFILES[profile].get('dual_hdr_seed1'):
            required.update(('dual_hdr_seed1.py', 'dual_hdr_trial.py', 'cfg_deadline.py',
                             'launch_dual_hdr_seed1.py', 'hdr-seed1-debug-policy.json'))
        if PERF_PROFILES[profile].get('seed1_recipe'):
            required.update(('seed1_mode_recipe.py','dual_hdr_seed1.py','dual_hdr_trial.py',
                'cfg_deadline.py','dual_r3_lane.py','launch_seed1_mono_recipe.py','hdr-seed1-debug-policy.json'))
        if PERF_PROFILES[profile].get('seed51_mono_basic'):
            required.update(('dual_sdr_seed51.py', 'seed51-debug-policy.json'))
        if PERF_PROFILES[profile].get('remote_control'):
            required.update(('remote_algorithm_control.py', 'remote_algorithm_control.html'))
    if profile in ('sdr-gap-observe', 'runtime-sdr-baseline') or profile in PERF_PROFILES:
        required.add('source_gap_journal.py')
    if profile in PERF_PROFILES:
        required.update(('preview_performance.py', 'gst_perf_observer', 'gst_perf_observer.c'))
        if PERF_PROFILES[profile].get('combined_sdr'):
            required.update(('bounded_lut.py', 'combined_sdr.py'))
        if PERF_PROFILES[profile].get('long_run_evidence'):
            required.add('kms_long_run.py')
        if PERF_PROFILES[profile].get('lightweight_health'):
            required.add('health_snapshot.py')
        if PERF_PROFILES[profile].get('kms_nv12'):
            required.add('kms_display.py')
        if PERF_PROFILES[profile].get('kms_sync_trace_sha256'):
            required.update(('kms_sync_trace.so', 'kms_sync_trace.c'))
        if PERF_PROFILES[profile].get('observe_display'):
            required.add('gst_display_observe.h')
        if PERF_PROFILES[profile].get('lane_overlay'):
            if PERF_PROFILES[profile].get('c1_lane_overlay'):
                required.update(('c1_lane_core.py','c1_lane_preview.py','c1_lane_trial.py',
                    'gst_c1_lane_overlay.h','gst_c1_perf_observer.c','c1_observer_source.py',
                    'liblane_tracker.so','c1_core_source/lane_tracker.cpp',
                    'launch_seed1_lane_overlay.py','c1-lane-provenance.json'))
            else:
                required.update(('lane_overlay.py', 'gst_lane_overlay.h'))
        if PERF_PROFILES[profile].get('h265_record'):
            required.update(('h265_recording.py', 'h265_storage.py', 'gst_h265_record.h'))
        if PERF_PROFILES[profile].get('h265_tail'):
            required.update(('h265_tail.py', 'gst_h265_tail.h'))
        if PERF_PROFILES[profile].get('h265_60fps'):
            required.add('analyze_h265_60fps.py')
    if not required <= rows.keys():
        raise ValueError('runtime missing required entry')
    actual = set()
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('symlink in runtime')
        if path.is_dir():
            continue
        if not stat.S_ISREG(path.stat().st_mode):
            raise ValueError('nonregular runtime member')
        actual.add(path.relative_to(root).as_posix())
    if actual != set(rows) | {'runtime-index.json'}:
        raise ValueError('runtime closure differs')
    for name, row in rows.items():
        relative = Path(name)
        if relative.is_absolute() or '..' in relative.parts or relative.as_posix() != name:
            raise ValueError('unsafe runtime member')
        body = (root / name).read_bytes()
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('runtime file differs: ' + name)
    name, expected_observer = selected_observer(profile)
    if rows[name]['sha256'] != expected_observer:
        raise ValueError('observer identity differs')
    if PERF_PROFILES.get(profile,{}).get('fps_hud_variant'):
        if __package__:
            from .fps_hud import verify_feature
        else:
            from fps_hud import verify_feature
        verify_feature(root,document,profile)
    elif document.get('fps_hud') is not None:
        raise ValueError('FPS runtime requires its explicit profile overlay')
    if PERF_PROFILES.get(profile,{}).get('c1_lane_overlay'):
        expected_core=PERF_PROFILES[profile]['core_library_sha256']
        if (rows['liblane_tracker.so']['sha256']!=expected_core or
                rows['c1_core_source/lane_tracker.cpp']['sha256']!=
                '5191353846689bc32e7687bbc8a859191b27f4933edd214b587f93adcbb8b3fe'):
            raise ValueError('C1 delivered source or compiled library identity differs')
    trace_sha = PERF_PROFILES.get(profile, {}).get('kms_sync_trace_sha256')
    if trace_sha and rows['kms_sync_trace.so']['sha256'] != trace_sha:
        raise ValueError('KMS trace identity differs')
    if PERF_PROFILES.get(profile, {}).get('seed51_mono_basic'):
        if __package__:
            from .dual_sdr_seed51 import verify_policy
        else:
            from dual_sdr_seed51 import verify_policy
        verify_policy(root)
    if PERF_PROFILES.get(profile, {}).get('dual_hdr_seed1') or PERF_PROFILES.get(profile, {}).get('seed1_recipe'):
        if __package__:
            from .dual_hdr_seed1 import verify_policy
        else:
            from dual_hdr_seed1 import verify_policy
        verify_policy(root)
    return document


def owner_command(root, run, boot, baseline, profile=DEFAULT_PROFILE, *, kms_selection=None,
                  kms_sha256=None, recording_directory=None, bdf='0000:21:00.0'):
    if profile not in PROFILE_SCOPES:
        raise ValueError('unknown fixed SDR profile')
    if PERF_PROFILES.get(profile, {}).get('h265_60fps') and recording_directory is None:
        raise ValueError('60fps candidate requires explicit confirmed SD recording directory')
    name, expected_observer = selected_observer(profile)
    command = ['/usr/bin/python3', '-B', str(root / 'calfix_algorithm_owner.py'),
            '--peer-root', str(root / 'peer'), '--run-dir', str(run),
            '--expected-boot', boot, '--bit-sha256', PROFILE_BITS[profile],
            '--device', '/dev/ph1a_c2h_' + bdf, '--expected-bdf', bdf,
            '--observer', str(root / name), '--observer-sha256', expected_observer,
            '--display-baseline', str(baseline), '--profile', profile]
    if kms_selection is not None:
        command += ['--kms-selection', str(kms_selection), '--kms-selection-sha256', kms_sha256]
    if recording_directory is not None:
        if not PERF_PROFILES.get(profile, {}).get('h265_record'):
            raise ValueError('recording directory requires an H.265 recording profile')
        command += ['--recording-dir', str(recording_directory)]
    return command


def trial_guards(boot, run_root=Path('/run')):
    guards = [run_root / 'r6r2-p0-handoff' / (boot + '.started.json'),
              run_root / ('a-cfg-diagnostic-' + boot + '.started'),
              run_root / ('seed15-alg30-' + boot + '.started'),
              run_root / ('calfix-sdr-switch-' + boot + '.started')]
    guards += list(run_root.glob('a-cfgobs-*-' + boot + '.started'))
    return guards


def check_driver(root, boot, profile, bundle):
    """Select new target admission only for R3; historical gate stays intact."""
    if PERF_PROFILES.get(profile, {}).get('dual_r3_mono'):
        if __package__:
            from .dual_r3 import require_deployable
        else:
            from dual_r3 import require_deployable
        driver = require_deployable(root, boot)
        return driver['bdf'], None, driver
    check = subprocess.run(['/usr/bin/python3', '-B', str(bundle / 'tools/handoff.py'),
                            'driver-check'], capture_output=True, timeout=10, check=True)
    if b'MATCHED_ALREADY_BOUND_SKIP_INSMOD_AND_NEW_ID' not in check.stdout:
        raise ValueError('driver/kernel/endpoint not ready')
    return '0000:21:00.0', check.stdout.decode(), None


def main(argv=None, *, required_profile=None):
    if required_profile is not None and required_profile not in PROFILE_SCOPES:
        raise ValueError('unknown required fixed SDR profile')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--index-sha256', required=True)
    parser.add_argument('--expected-boot', required=True)
    parser.add_argument('--programming-note', required=True)
    parser.add_argument('--joint-cold-confirmed', action='store_true', required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--bundle', type=Path, default=Path('/userdata/r6r2-repro-20261027'))
    parser.add_argument('--profile', choices=tuple(PROFILE_SCOPES) if required_profile is None else (required_profile,),
                        default=DEFAULT_PROFILE if required_profile is None else required_profile)
    parser.add_argument('--kms-selection', type=Path)
    parser.add_argument('--kms-selection-sha256')
    parser.add_argument('--recording-dir', type=Path,
                        help='fresh directory on the confirmed SD; H.265 profiles only')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args(argv)
    if required_profile is not None and args.profile != required_profile:
        raise ValueError('launcher requires fixed profile '+required_profile)
    if args.recording_dir is not None or PERF_PROFILES.get(args.profile, {}).get('h265_60fps'):
        if __package__:
            from .h265_storage import recording_request
        else:
            from h265_storage import recording_request
        recording_request(args.profile, PERF_PROFILES, args.recording_dir)
    is_kms = PERF_PROFILES.get(args.profile, {}).get('kms_nv12', False)
    if is_kms != (args.kms_selection is not None and args.kms_selection_sha256 is not None):
        raise ValueError('KMS selection and SHA256 required exactly for KMS profile')
    if not is_kms and (args.kms_selection is not None or args.kms_selection_sha256 is not None):
        raise ValueError('KMS selection only valid for KMS profile')
    root = args.root.resolve(strict=True)
    runtime = verify_runtime(root, args.index_sha256, args.profile)
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if boot != args.expected_boot or not args.programming_note.strip():
        raise ValueError('actual boot and programming confirmation required')
    run = args.run_dir
    if not run.is_absolute() or '..' in run.parts or os.path.lexists(run) or not run.parent.is_dir():
        raise ValueError('fresh absolute run directory required')
    if any(parent.is_symlink() for parent in run.parents):
        raise ValueError('symlink run parent')
    spec = importlib.util.spec_from_file_location('verified_handoff', args.bundle / 'tools/handoff.py')
    handoff = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(handoff)
    verified = handoff.verify(args.bundle)
    scan = handoff.owner_scan()
    if scan['owners'] or scan['errors']:
        raise ValueError('existing or incompletely scanned owner')
    bdf, original_driver, r3_driver = check_driver(root, boot, args.profile, args.bundle)
    mpp = Path('/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0')
    if hashlib.sha256(mpp.read_bytes()).hexdigest() != '5fb91f82869ef7823c1111dbc9ef39452e00ff4464c97010091db18d625e5d1a':
        raise ValueError('factory MPP differs')
    baseline_path = args.bundle / 'assets/display-baseline.json'
    baseline = json.loads(baseline_path.read_text())
    for row in baseline['plugin_files']:
        if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('display plugin differs')
    if is_kms:
        if __package__:
            from .kms_display import load_selection, KMS_PLUGIN, KMS_SHA256
        else:
            from kms_display import load_selection, KMS_PLUGIN, KMS_SHA256
        load_selection(args.kms_selection, args.kms_selection_sha256, boot, live=args.execute)
        if hashlib.sha256(Path(KMS_PLUGIN).read_bytes()).hexdigest() != KMS_SHA256:
            raise ValueError('KMS plugin differs')
    else:
        cookie = Path(baseline['xauthority']).stat()
        if not stat.S_ISREG(cookie.st_mode) or cookie.st_mode & 0o022:
            raise ValueError('unsafe Xauthority')
    evidence = None
    if PERF_PROFILES.get(args.profile, {}).get('long_run_evidence'):
        if __package__:
            from .kms_long_run import check_free_space
        else:
            from kms_long_run import check_free_space
        evidence = check_free_space(run.parent, args.profile)
    else:
        space = os.statvfs(run.parent)
        if space.f_bavail * space.f_frsize < 256 * 1024 * 1024:
            raise ValueError('256MiB free required for bounded evidence')
    # Every profile shares this guard set and the same exclusive claim below.
    # A RUNTIME package cannot take over a CALFIX owner in the same boot.
    guards = trial_guards(boot)
    if any(g.exists() for g in guards):
        raise ValueError('prior trial guard; no same-boot takeover')
    observer_name, _ = selected_observer(args.profile)
    verify_profile_libraries(args.profile)
    if args.profile in PERF_PROFILES:
        description = subprocess.check_output([str(root / observer_name), '--describe-profile'], timeout=5)
        expected = (b'AUTOF21_H265_1080P60_8M_10M_START60S_SD_BRANCH_TAIL_RETAIN_V1\n' if PERF_PROFILES[args.profile].get('h265_60fps') else
                    b'AUTOF21_H265_KMS30_BRANCH_TAIL_NO_ENCODER_RESET_RETAIN_V1\n' if PERF_PROFILES[args.profile].get('h265_tail') else
                    b'AUTOF21_COLOR_HOST_MONOTONIC_H265_1080P30_4M_6M_HVC1_SPLIT5_KMS60_RETAIN\n' if PERF_PROFILES[args.profile].get('h265_record') else
                    b'DUAL_HDR_SEED1_C1_SAME_PTS_CURVES_NV12_KMS_SINK_INPUT_RETAIN_V1\n' if PERF_PROFILES[args.profile].get('c1_lane_overlay') else
                    b'AUTOF21_F23_SAME_PTS_NV12_CANDIDATE_OVERLAY_KMS_SKIP_VSYNC_RETAIN_DRM\n' if PERF_PROFILES[args.profile].get('lane_overlay') else
                    b'CALFIX_KMS_NV12_SKIP_VSYNC_RETAIN_DRM\n' if PERF_PROFILES[args.profile].get('kms_skip_vsync') else
                    b'CALFIX_KMS_NV12_NO_CPU_CONVERTER_RETAIN_DRM\n' if is_kms else
                    b'CALFIX_MPP_BGRX_CAPSFILTER_NO_CPU_CONVERTER\n' if PERF_PROFILES[args.profile].get('mpp_bgrx') else
                    b'CALFIX_OBSERVE2_PUSH_RETURN_CAPS_NO_PIPELINE_CHANGE\n' if PERF_PROFILES[args.profile].get('observe_display') else
                    b'CALFIX_CONVERT3_SERIAL_NO_EXTRA_QUEUE\n' if PERF_PROFILES[args.profile].get('convert_threads')==3 else
                    b'CALFIX_CONVERT2_SERIAL_NO_EXTRA_QUEUE\n' if PERF_PROFILES[args.profile].get('convert_threads')==2 else
                    b'CALFIX_QUEUE1_NO_LEAK_MAX_RAW_WAITING_1\n' if PERF_PROFILES[args.profile]['queue1']
                    else b'CALFIX_SERIAL_BASELINE\n')
        if PERF_PROFILES[args.profile].get('fps_hud_variant'):
            if __package__:
                from .fps_hud import banner
            else:
                from fps_hud import banner
            expected=banner(PERF_PROFILES[args.profile]['fps_hud_variant'])
        if description != expected:
            raise ValueError('performance observer profile differs')
    for flag in ('--test-ring', '--check-runtime'):
        result = subprocess.run([str(root / observer_name), flag], capture_output=True,
                                timeout=5, check=True)
        if flag == '--check-runtime' and result.stdout != b'OBSERVER_RUNTIME_PUBLIC_SYMBOLS_READY_NO_GST_INIT_NO_PIPELINE\n':
            raise ValueError('observer compatibility not confirmed')
    owner = owner_command(root, run, boot, baseline_path, args.profile,
                          kms_selection=args.kms_selection, kms_sha256=args.kms_selection_sha256,
                          recording_directory=args.recording_dir, bdf=bdf)
    plan = subprocess.run(owner + ['--prepare-only'], capture_output=True, timeout=10, check=True)
    prepared_plan = json.loads(plan.stdout)
    if (prepared_plan.get('profile') != args.profile or
            prepared_plan.get('runtime_scope') != runtime['scope']):
        raise ValueError('owner prepared profile/scope differs')
    ready = dict(status='PREPARED_NO_NATIVE_OPEN', boot=boot, bit_sha256=PROFILE_BITS[args.profile],
                 profile=args.profile, runtime_scope=runtime['scope'],
                 programming_basis=args.programming_note, no_sram_readback=True,
                 original_fixture=verified, runtime_index_sha256=args.index_sha256,
                 original_driver_check=original_driver,
                 r3_driver_check=r3_driver, run_dir=str(run),
                 plan=prepared_plan, evidence_budget=evidence, kms_selection_sha256=args.kms_selection_sha256,
                 display_restore='DEFERRED_RETAIN_MPP_DRM' if is_kms else 'UNCHANGED_X11')
    if not args.execute:
        print(json.dumps(ready))
        return
    launch = root.parent / ('calfix-sdr-switch-launch-' + boot)
    launch.mkdir(exist_ok=False)
    with guards[3].open('x') as stream:
        json.dump(ready, stream)
    (launch / 'preparation.json').write_text(json.dumps(ready, indent=2) + '\n')
    env = {k: os.environ[k] for k in ('HOME', 'USER', 'LOGNAME', 'LANG') if k in os.environ}
    env.update(PATH='/usr/bin:/bin', PYTHONDONTWRITEBYTECODE='1', LC_ALL='C')
    with (launch / 'owner.log').open('xb') as log:
        process = subprocess.Popen(owner + ['--run'], stdout=log, stderr=subprocess.STDOUT,
                                   stdin=subprocess.DEVNULL, start_new_session=True, env=env)
    state = dict(ready, status='OWNER_LAUNCHED_NOT_VIDEO_PASS', owner_pid=process.pid,
                 owner_argv=owner + ['--run'], launch_dir=str(launch))
    (launch / 'launch.json').write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(state))


if __name__ == '__main__':
    main()
