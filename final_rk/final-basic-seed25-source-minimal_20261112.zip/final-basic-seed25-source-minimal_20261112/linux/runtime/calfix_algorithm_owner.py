"""Fixed CALFIX seed6 and RUNTIME seed5 SDR profiles using the direct MPP trial.

Standalone entry. --prepare-only validates ordinary inputs without creating
output or opening devices. A retained peer owner holds native and MPP resources
on every outcome; STOP is single intent and never retried after unknown return.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
from types import ModuleType
import time
import threading
from uuid import uuid4

if __package__:
    from . import peer_algorithm_owner as peer_owner
    from .direct_algorithm_preview import DirectPreview, display_environment
else:
    import peer_algorithm_owner as peer_owner
    from direct_algorithm_preview import DirectPreview, display_environment

if __package__:
    from .performance_profiles import PROFILES as PERF_PROFILES, observer_identity, verify_profile_libraries
else:
    from performance_profiles import PROFILES as PERF_PROFILES, observer_identity, verify_profile_libraries

DURATION = 500
CALFIX_SHA256 = '3146bfb92b6089dcdbff7ae26d2eff44b58ef56f12bc2ed28aed89d22a4f46f4'
MODES = (('color', 0, 120), ('gray', 1, 120), ('gaussian', 4, 120), ('color_restore', 0, 120))
DEFAULT_PROFILE = 'sdr-minimal'
PROFILES = {DEFAULT_PROFILE: MODES,
    'sdr-extended': (('color', 0, 60), ('histogram', 8, 120),
        ('f22', 16, 120), ('f22_f23', 48, 120), ('color_restore', 0, 60))}
GAP_PROFILE = 'sdr-gap-observe'
RUNTIME_PROFILE = 'runtime-sdr-baseline'
KMS_30_PROFILE = 'calfix-perf-kms-nv12-30'
KMS_30FLOW_PROFILE = 'calfix-perf-kms-nv12-30flow180'
KMS_30FLOW_PROFILES = (KMS_30FLOW_PROFILE, 'calfix-perf-kms-skip180',
                       'calfix-perf-kms-health180', 'calfix-perf-kms-health1800')
RUNTIME_SHA256 = 'b404956e812038939ef00d59357966c0795bfd5116c596276f0f946ca6708a7b'
PROFILES[GAP_PROFILE] = PROFILES['sdr-extended']
# The final monitored 20s tail completes the 180s START budget, including CFG.
PROFILES[RUNTIME_PROFILE] = (('color', 0, 160),)
PROFILE_BITS = {profile: CALFIX_SHA256 for profile in PROFILES}
PROFILE_BITS[RUNTIME_PROFILE] = RUNTIME_SHA256
PROFILE_DURATIONS = {profile: DURATION for profile in PROFILES}
PROFILE_DURATIONS[RUNTIME_PROFILE] = 180
JOURNAL_PROFILES = (GAP_PROFILE, RUNTIME_PROFILE)
PROFILE_SCOPES = {DEFAULT_PROFILE: 'CALFIX_SEED6_DIRECT_SDR_SWITCH_500S_V1',
    'sdr-extended': 'CALFIX_SEED6_DIRECT_SDR_EXTENDED_500S_V1',
    GAP_PROFILE: 'CALFIX_SEED6_DIRECT_SDR_GAP_OBSERVE_500S_V1',
    RUNTIME_PROFILE: 'RUNTIME_SEED5_DIRECT_SDR_BASELINE_180S_V1'}
for _profile, _spec in PERF_PROFILES.items():
    PROFILES[_profile] = _spec.get('modes') or ((_spec.get('mode_name', 'dehaze' if _spec.get('auto_f21_generation') else 'color'),
                           _spec.get('enables', 0), _spec['dwell']),)
    PROFILE_BITS[_profile] = _spec.get('bit_sha256', CALFIX_SHA256)
    PROFILE_DURATIONS[_profile] = _spec['duration']
    PROFILE_SCOPES[_profile] = _spec['scope']
JOURNAL_PROFILES += tuple(PERF_PROFILES)
ALTERNATING_HDR_PROFILE = 'autof21-color-hdr-3s'
PROFILES[ALTERNATING_HDR_PROFILE] = (('color', 0, 3), ('hdr', 0, 3)) * 10
COMBINED_PROFILE = 'calfix-perf-kms-combined360'
PROFILES[COMBINED_PROFILE] = (('color', 0, 30), ('dehaze', 2, 30),
    ('combined63', 63, 180), ('color_restore', 0, 60))
# Peer FEATURE_MATRIX.md: F22/F23 are sparse analysis records, not overlays.
# Schema2 leaves GRAY/GAUSSIAN_IMAGE clear for their independent enables.


def profile_modes(profile):
    if profile not in PROFILES:
        raise ValueError('unknown fixed SDR profile: '+str(profile))
    return PROFILES[profile]


def validate_configuration(configuration, profile=DEFAULT_PROFILE):
    if PERF_PROFILES.get(profile, {}).get('remote_control'):
        if __package__:
            from .remote_algorithm_control import PRESETS, preset_config
        else:
            from remote_algorithm_control import PRESETS, preset_config
        if configuration not in [preset_config(name) for name in PRESETS]:
            raise ValueError('remote SDR preset required; no HDR, combinations or arbitrary parameters')
        return
    if PERF_PROFILES.get(profile, {}).get('dual_r3_hdr'):
        if configuration != peer_owner.configuration(hdr=True):
            raise ValueError('R3 first HDR requires the complete frozen HDR policy only')
        return
    if profile == ALTERNATING_HDR_PROFILE:
        if configuration not in (peer_owner.configuration(), peer_owner.configuration(hdr=True)):
            raise ValueError('fixed ordinary SDR/HDR enables0 generation0 configuration required')
        return
    if profile == COMBINED_PROFILE:
        if __package__:
            from .combined_sdr import validate_configuration as validate_combined
        else:
            from combined_sdr import validate_configuration as validate_combined
        return validate_combined(configuration)
    allowed = {mode[1] for mode in profile_modes(profile)}
    ext = configuration['extension']
    expected = peer_owner.configuration(ext['processing_enables'],
        generation=PERF_PROFILES.get(profile, {}).get('auto_f21_generation', 0))
    if (ext != expected['extension'] or ext['processing_enables'] not in allowed or
            (profile != DEFAULT_PROFILE and configuration != expected)):
        raise ValueError('fixed SDR configuration required for profile '+profile)


def build_plan(profile=DEFAULT_PROFILE):
    if profile == COMBINED_PROFILE:
        if __package__:
            from .combined_sdr import build_plan as combined_plan
        else:
            from combined_sdr import build_plan as combined_plan
        return combined_plan()
    steps = [{'op': 'discover'}]
    if PERF_PROFILES.get(profile, {}).get('startup_jpeg_gate'):
        steps.append(dict(op='wait-product', kind='JPEG', epoch='active', timeout_s=3, at_least=5))
    for name, enables, seconds in profile_modes(profile):
        steps.extend([{'op': 'configure', 'configuration': peer_owner.configuration(enables,
            hdr=(profile == ALTERNATING_HDR_PROFILE and name == 'hdr') or PERF_PROFILES.get(profile, {}).get('dual_r3_hdr', False),
            generation=PERF_PROFILES.get(profile, {}).get('auto_f21_generation', 0))},
            {'op': 'wait-product', 'kind': 'JPEG', 'epoch': 'active', 'timeout_s': 3, 'at_least': 5}])
        if profile == RUNTIME_PROFILE or profile in PERF_PROFILES:
            # The actual peer parser admits at most 60s per monitored wait.
            while seconds:
                chunk = min(60, seconds)
                steps.append({'op': 'wait', 'seconds': chunk})
                seconds -= chunk
        else:
            steps.extend([{'op': 'wait', 'seconds': seconds//2},
                          {'op': 'wait', 'seconds': seconds//2}])
        steps.append({'op': 'status'})
    if profile == ALTERNATING_HDR_PROFILE:
        return dict(version=1, steps=steps)
    # Covers residual time with StepRunner stream/preview watchdogs. CFG time
    # clips this tail. Its return sets stop, bypassing peer CLI's unmonitored tail.
    steps.append({'op': 'wait', 'seconds': 20})
    if profile in KMS_30FLOW_PROFILES:
        # Preserve the successful 30s plan, then delay only its STOP. The runner
        # clips that plan's tail to START+30 before these monitored extensions.
        remaining = PROFILE_DURATIONS[profile] - PROFILE_DURATIONS[KMS_30_PROFILE]
        while remaining:
            seconds = min(60, remaining)
            steps.append({'op': 'wait', 'seconds': seconds})
            remaining -= seconds
    return dict(version=1, steps=steps)


class BoundedRunner(peer_owner.StepRunner):
    def __init__(self, execute, budget, event, snapshot, *, profile=DEFAULT_PROFILE, **kwargs):
        profile_modes(profile)
        self.profile = profile
        auto_generation = PERF_PROFILES.get(profile, {}).get('auto_f21_generation')
        single_cfg = auto_generation is not None or PERF_PROFILES.get(profile, {}).get('single_cfg', False)
        self._auto_cfg_issued = False
        self._basic_steps = build_plan(profile)['steps'] if PERF_PROFILES.get(profile, {}).get('dual_r3_basic') else None
        self._basic_completed = 0
        self._basic_performed = False
        self._basic_dwell_s = 0.
        self._alternating_steps = (build_plan(profile)['steps']
                                   if profile == ALTERNATING_HDR_PROFILE else None)
        self._alternating_completed_steps = self._alternating_completed_segments = 0
        self._alternating_dwell_s = 0.
        self._alternating_performed = False
        self._alternating_incomplete_reason = None
        if profile == COMBINED_PROFILE:
            if __package__:
                from .combined_sdr import next_generation as combined_generation
            else:
                from combined_sdr import next_generation as combined_generation
            kwargs['generation_selector'] = combined_generation
        self.prefix_tail_step = (len(build_plan(KMS_30_PROFILE)['steps'])
                                 if profile in KMS_30FLOW_PROFILES else None)
        def guarded_execute(session, step, seconds, stop):
            if self._basic_steps is not None:
                self._check_basic_step(step)
            if self._alternating_steps is not None:
                self._check_alternating_step(step)
                if step['op'] == 'status':
                    self._require_alternating_preview()
            if single_cfg:
                if step['op'] in ('query-lut', 'load-lut'):
                    raise RuntimeError('AUTOF21 forbids host LUT commands')
                if step['op'] == 'configure':
                    validate_configuration(step['configuration'], profile)
                    if self._auto_cfg_issued:
                        raise RuntimeError('AUTOF21 permits only one CFG intent')
                    self._auto_cfg_issued = True
            self._check_analysis(session.snapshot())
            result = execute(session, step, seconds, stop)
            if self._basic_steps is not None:
                self._basic_performed = True
            self._check_analysis(session.snapshot())
            if self._alternating_steps is not None:
                self._alternating_performed = True
            return result
        super().__init__(guarded_execute if profile != DEFAULT_PROFILE else execute,
                         budget, event, snapshot, **kwargs)
        if auto_generation is not None:
            # Fixed new-bit contract, not a fabricated QUERY receipt. The
            # unchanged peer apply still reads LUT_VALID/ACTIVE_GENERATION and
            # rejects busy/loading/error before the ordinary CFG transaction.
            self.generation = auto_generation

    def _check_basic_step(self, step):
        expected = (self._basic_steps[self._basic_completed]
                    if self._basic_completed < len(self._basic_steps) else None)
        valid = step == expected
        if expected and expected['op'] == 'wait' and step.get('op') == 'wait':
            valid = set(step) == {'op', 'seconds'} and 0 <= step['seconds'] <= expected['seconds']
        if not valid or self.sequence != self._basic_completed + 1:
            raise RuntimeError('R3_BASIC_STEP_ORDER: fixed plan only; no retries or LUT commands')

    def basic_summary(self):
        return dict(planned_steps=len(self._basic_steps),completed_steps=self._basic_completed,
                    nominal_dwell_s=100,actual_completed_dwell_s=self._basic_dwell_s,
                    plan_complete=self._basic_completed==len(self._basic_steps) and not self.failed,
                    time_scope='HOST_MONITORED_WAIT_NOT_PHYSICAL_ALGORITHM_OR_HDMI_PROOF')

    def _check_alternating_step(self, step):
        number = self._alternating_completed_steps
        expected = self._alternating_steps[number] if number < len(self._alternating_steps) else None
        # The unchanged peer CLI can clip a wait at its own deadline. Admit
        # only a shortened requested dwell, then require the actual full 3s.
        valid = step == expected
        if expected and expected['op'] == 'wait' and step.get('op') == 'wait':
            valid = set(step) == {'op', 'seconds'} and 0 <= step['seconds'] <= expected['seconds']
        if not valid or self.sequence != number + 1:
            self._alternating_incomplete_reason = 'unexpected step/order; no retry or LUT command permitted'
            raise RuntimeError('AUTOF21_ALTERNATION_STEP_ORDER: '+self._alternating_incomplete_reason)

    def alternation_summary(self):
        return dict(planned_segments=20, completed_segments=self._alternating_completed_segments,
            planned_steps=len(self._alternating_steps), completed_steps=self._alternating_completed_steps,
            nominal_dwell_s=60, actual_completed_dwell_s=self._alternating_dwell_s,
            plan_complete=self._alternating_completed_segments == 20 and
                self._alternating_completed_steps == len(self._alternating_steps),
            incomplete_reason=self._alternating_incomplete_reason,
            time_scope='HOST_MONITORED_WAIT_NOT_PHYSICAL_HDR_EXPOSURE_TIME',
            preview_scope='MPP_SINK_PROGRESS_AFTER_HOST_EPOCH_BOUNDARY_NOT_EXACT_SOURCE_BUFFER_ID',
            physical_hdr_exposure='UNQUALIFIED')

    def _require_alternating_preview(self):
        if self.preview_state is None or self.preview_epoch_boundary_ns is None:
            raise RuntimeError('AUTOF21_ALTERNATION_PREVIEW: current epoch evidence missing')
        self._check_preview()  # Preserve failure/heartbeat/watchdog checks.
        state = json.loads(self.preview_state.read_text())
        now = round(self.clock() * 1e9)
        for key in ('mpp_last_ns', 'sink_last_ns'):
            stamp = state.get(key)
            if (type(stamp) is not int or stamp <= 0 or stamp < self.preview_epoch_boundary_ns
                    or not 0 <= now - stamp < 3_000_000_000):
                self._alternating_incomplete_reason = 'no fresh current-epoch MPP/sink progress: '+key
                raise RuntimeError('AUTOF21_ALTERNATION_PREVIEW: '+self._alternating_incomplete_reason)

    def _check_analysis(self, snapshot):
        gap = snapshot.get('source_gap_journal') or {}
        if gap.get('failure'):
            raise RuntimeError('SOURCE_GAP_JOURNAL_FAILED: '+str(gap['failure']))
        # Peer ProductInspector counts sparse ok/error and frame_error flags,
        # while continuing JPEG. frame_valid=0 alone is a valid no-candidate
        # outcome and is deliberately not an algorithm failure condition.
        counters = (snapshot.get('products') or {}).get('counters') or {}
        for name in ('analysis_negative_terminals', 'analysis_frame_errors'):
            if counters.get(name, 0):
                raise RuntimeError('ANALYSIS_TERMINAL_ERROR: '+name+'='+str(counters[name]))

    def _wait(self, session, seconds, stop):
        if self.profile == DEFAULT_PROFILE:
            return super()._wait(session, seconds, stop)
        if self._alternating_steps is not None:
            self._check_alternating_step(dict(op='wait', seconds=seconds))
        begin = self.clock()
        basic_dwell = self._basic_steps is not None and self._basic_completed < len(self._basic_steps)-1
        if self._basic_steps is not None:
            self._check_basic_step(dict(op='wait', seconds=seconds))
        check = self._check_analysis
        take_snapshot = session.snapshot
        if PERF_PROFILES.get(self.profile, {}).get('lightweight_health'):
            if __package__:
                from .health_snapshot import snapshot_health
            else:
                from health_snapshot import snapshot_health
            take_snapshot = lambda: snapshot_health(session)
        class CachedSnapshotGate:
            def snapshot(self):
                value = take_snapshot()
                check(value)
                return value
        # Only cached snapshots are wrapped; super.__call__ still owns the real
        # session's FIRST_FAILURE, stop.set and _fault retention path.
        guarded = CachedSnapshotGate()
        guarded.snapshot()
        result = super()._wait(guarded, seconds, stop)
        guarded.snapshot()
        if basic_dwell and (seconds < 20 - 1e-9 or self.clock()-begin < 20 - 1e-9 or stop.is_set()):
            raise TimeoutError('R3_BASIC_INCOMPLETE_DWELL: full 20 seconds required')
        if self._basic_steps is not None:
            self._basic_performed = True
            if basic_dwell:
                self._basic_dwell_s += self.clock()-begin
        if self._alternating_steps is not None:
            elapsed = self.clock() - begin
            if seconds < 3 - 1e-9 or elapsed < 3 - 1e-9 or stop.is_set():
                self._alternating_incomplete_reason = 'dwell clipped/interrupted before full 3 seconds'
                raise TimeoutError('AUTOF21_ALTERNATION_INCOMPLETE_DWELL: '+self._alternating_incomplete_reason)
            self._alternating_dwell_s += elapsed
            self._alternating_performed = True
        return result

    def __call__(self, session, step, budget, stop):
        self._basic_performed = False
        self._alternating_performed = False
        if self.profile in KMS_30FLOW_PROFILES and step['op'] == 'wait':
            remaining = self.budget.remaining()
            if self.sequence + 1 == self.prefix_tail_step:
                remaining = min(remaining, max(0., self.budget.started +
                    PROFILE_DURATIONS[KMS_30_PROFILE] - self.clock()))
            # The peer CLI may already have clipped this request. Clip again
            # against START, recording the actual bound in both step events.
            step = dict(step, seconds=min(step['seconds'], remaining))
        result = super().__call__(session, step, budget, stop)
        if self._basic_steps is not None:
            if not self._basic_performed:
                error=TimeoutError('R3_BASIC_INCOMPLETE_PLAN: START budget expired before step execution')
                self.failed=True
                stop.set()
                self.event(dict(kind='FIRST_FAILURE',step=self.sequence,monotonic_s=self.clock(),
                                type=type(error).__name__,detail=str(error)))
                session._fault('ALGORITHM_TRIAL',error)
                self.save_snapshot(self.sequence,peer_owner.bounded_snapshot(session.snapshot()))
                raise error
            self._basic_completed += 1
        if self._alternating_steps is not None and self._alternating_performed:
            self._alternating_completed_steps += 1
            if step['op'] == 'status':
                self._alternating_completed_segments += 1
                self.event(dict(kind='ALTERNATION_PROGRESS', monotonic_s=self.clock(),
                                **self.alternation_summary()))
            if self._alternating_completed_steps == len(self._alternating_steps):
                stop.set()  # Last HDR status: no unmonitored CLI tail to START+90.
        if ((self._basic_steps is not None and self._basic_completed == len(self._basic_steps))
                or (self._basic_steps is None and self.profile not in KMS_30FLOW_PROFILES and self.profile != COMBINED_PROFILE
                and step == {'op': 'wait', 'seconds': 20})
                or (self.profile == COMBINED_PROFILE and
                    self.sequence >= len(build_plan(self.profile)['steps']))
                or (self.profile in KMS_30FLOW_PROFILES and
                    self.sequence >= len(build_plan(self.profile)['steps']))
                or self.budget.remaining() <= 0):
            stop.set()
        return result


class SourceGapSessionMixin:
    """Observe every parsed native product before the display queue can drop it."""
    source_gap_journal = None

    def _observe_product(self, product_event):
        if self.source_gap_journal is not None:
            self.source_gap_journal.observe(product_event)
        return super()._observe_product(product_event)

    def snapshot(self):
        result = super().snapshot()
        if self.source_gap_journal is not None:
            result['source_gap_journal'] = self.source_gap_journal.snapshot()
        return result


def logged_single_stop(syscall, event, clock=time.monotonic):
    def actual():
        event(dict(kind='STOP_CALL', monotonic_s=clock()))
        try:
            result = syscall()
        except BaseException as error:
            event(dict(kind='STOP_RAISED', monotonic_s=clock(),
                type=type(error).__name__, detail=str(error)[:512], acceptance='UNKNOWN_NO_RETRY'))
            raise
        event(dict(kind='STOP_RETURN', monotonic_s=clock(),
            return_value=result if result is None or type(result) in (str, int, bool, float) else repr(result)[:512]))
        return result
    return peer_owner.SingleStop(actual)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('peer-root', 'run-dir', 'observer', 'display-baseline'):
        parser.add_argument('--'+name, type=Path, required=True)
    for name in ('expected-boot', 'bit-sha256', 'device', 'expected-bdf', 'observer-sha256'):
        parser.add_argument('--'+name, required=True)
    parser.add_argument('--profile', choices=tuple(PROFILES), default=DEFAULT_PROFILE)
    parser.add_argument('--kms-selection', type=Path)
    parser.add_argument('--kms-selection-sha256')
    parser.add_argument('--recording-dir', type=Path,
                        help='fresh directory on the confirmed SD; H.265 profiles only')
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--prepare-only', action='store_true')
    action.add_argument('--run', action='store_true')
    args = parser.parse_args(argv)
    if args.run and PERF_PROFILES.get(args.profile, {}).get('dual_r3_mono'):
        if __package__:
            from .dual_r3 import require_deployable
        else:
            from dual_r3 import require_deployable
        admitted = require_deployable(Path(__file__).resolve().parent, args.expected_boot, args.expected_bdf)
        if args.device != admitted['device']:
            raise ValueError('R3 owner device differs from observed native character node')
    recording_storage = None
    if args.recording_dir is not None or PERF_PROFILES.get(args.profile, {}).get('h265_60fps'):
        if __package__:
            from .h265_storage import recording_request
        else:
            from h265_storage import recording_request
        recording_storage = recording_request(args.profile, PERF_PROFILES, args.recording_dir)
    if args.bit_sha256 != PROFILE_BITS[args.profile]:
        parser.error('fixed profile bit SHA256 required')
    if args.profile in PERF_PROFILES and args.observer_sha256 != observer_identity(args.profile)[1]:
        parser.error('fixed performance observer SHA256 required')
    duration = PROFILE_DURATIONS[args.profile]
    cfg_seconds = PERF_PROFILES.get(args.profile, {}).get('config_timeout_s', 3)
    command_seconds = PERF_PROFILES.get(args.profile, {}).get('command_timeout_s', 5)
    allow_hdr = args.profile == ALTERNATING_HDR_PROFILE or PERF_PROFILES.get(args.profile, {}).get('dual_r3_hdr', False)
    long_evidence = PERF_PROFILES.get(args.profile, {}).get('long_run_evidence', False)
    evidence = None
    if long_evidence:
        if __package__:
            from .kms_long_run import check_free_space
        else:
            from kms_long_run import check_free_space
        evidence = check_free_space(args.run_dir.parent, args.profile)
    if not re.fullmatch('[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', args.expected_boot):
        parser.error('expected-boot requires canonical boot UUID')
    if not args.device.startswith('/dev/') or '..' in Path(args.device).parts:
        parser.error('device requires explicit /dev path')
    if args.profile in JOURNAL_PROFILES:
        if __package__:
            from .source_gap_journal import SourceGapJournal
        else:
            from source_gap_journal import SourceGapJournal
    is_kms = PERF_PROFILES.get(args.profile, {}).get('kms_nv12', False)
    selection = None
    if is_kms:
        if __package__:
            from .kms_display import load_selection, environment
        else:
            from kms_display import load_selection, environment
        if args.kms_selection is None:
            raise ValueError('KMS selection required')
        selection = load_selection(args.kms_selection, args.kms_selection_sha256,
                                   args.expected_boot, live=not args.prepare_only)
        env = environment(args.observer, args.observer_sha256, args.display_baseline,
                          selection, verify_plugins=not args.prepare_only)
        if PERF_PROFILES[args.profile].get('kms_sync_trace_sha256'):
            if __package__:
                from .kms_display import trace_environment
            else:
                from kms_display import trace_environment
            env = trace_environment(env, args.observer, args.run_dir,
                                    PERF_PROFILES[args.profile]['kms_sync_trace_sha256'])
    else:
        if args.kms_selection is not None or args.kms_selection_sha256 is not None:
            raise ValueError('KMS selection only valid for KMS profile')
        env = display_environment(args.observer, args.observer_sha256, args.display_baseline,
                                  verify_plugins=not args.prepare_only)
    display_path = ('PEER_OWNED_JPEG_LATEST_TO_MPP_NV12_KMS_RETAIN_DRM' if is_kms else
                    'PEER_OWNED_JPEG_LATEST_QUEUE_TO_EXISTING_GST_OBSERVER_MPP_X11')
    if not args.prepare_only:
        verify_profile_libraries(args.profile)
    if PERF_PROFILES.get(args.profile, {}).get('mpp_bgrx'):
        # INFO exposes format selection once; per-frame DEBUG stays disabled.
        env['GST_DEBUG'] = '2,mppjpegdec:4'
    if PERF_PROFILES.get(args.profile, {}).get('lane_overlay'):
        env['R5_LANE_OVERLAY'] = '1'
    if PERF_PROFILES.get(args.profile, {}).get('h265_record'):
        env['R5_H265_RECORD'] = '1'
    if PERF_PROFILES.get(args.profile, {}).get('h265_tail'):
        env['R5_H265_TAIL'] = '1'
    if PERF_PROFILES.get(args.profile, {}).get('h265_60fps'):
        env['R5_H265_60FPS'] = '1'
    # The peer uses a namespace linux package. Pin it before importing so a
    # workspace cwd's regular linux/__init__.py cannot win namespace lookup.
    resolved_peer = args.peer_root.resolve(strict=True)
    if 'linux' not in sys.modules and (resolved_peer/'linux/rk_debug/cli.py').is_file():
        namespace = ModuleType('linux')
        namespace.__path__ = [str(resolved_peer/'linux')]
        sys.modules['linux'] = namespace
    cli, peer_session = peer_owner.import_peer(args.peer_root)
    cli._bdf(args.expected_bdf)
    record_version = PERF_PROFILES.get(args.profile, {}).get('record_version', 3)
    header_bytes = PERF_PROFILES.get(args.profile, {}).get('header_bytes', 448)
    modes = profile_modes(args.profile)
    plan = build_plan(args.profile)
    loader = cli.load_document
    try:
        cli.load_document = lambda _: plan
        cli.load_steps(None)
    finally:
        cli.load_document = loader
    run = cli._new_path(args.run_dir, directory=True)
    if args.prepare_only:
        print(json.dumps(dict(status='PREPARED_NO_DEVICE', plan=plan,
            nominal_dwell_s=sum(mode[2] for mode in modes), start_budget_s=duration, hdr_allowed=allow_hdr, cfg_seconds=cfg_seconds, command_seconds=command_seconds,
            profile=args.profile, runtime_scope=PROFILE_SCOPES[args.profile],
            record_version=record_version, header_bytes=header_bytes,
            path=display_path, evidence_budget=evidence,
            **(dict(recording_storage=recording_storage) if recording_storage else {}))))
        return 0
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip() != args.expected_boot:
        raise ValueError('actual boot differs')
    run.mkdir(mode=0o700)
    peer_owner.atomic_json(run/'plan.json', plan)
    if selection is not None:
        peer_owner.atomic_json(run/'kms-selection.json', selection)
    peer_owner.atomic_json(run/'trial-context.json', dict(expected_boot=args.expected_boot,
        declared_bit_sha256=args.bit_sha256, bit_identity_scope='OPERATOR_DECLARATION_NOT_READBACK',
        peer_root=str(args.peer_root.resolve()), device=args.device, expected_bdf=args.expected_bdf,
        global_seconds=duration, cfg_seconds=cfg_seconds, command_seconds=command_seconds, cold_timeout_s=3, drain_seconds=3,
        max_records=200000, nominal_modes=modes, hdr_allowed=allow_hdr,
        profile=args.profile, runtime_scope=PROFILE_SCOPES[args.profile],
        record_version=record_version, header_bytes=header_bytes,
        path=display_path,
        observer_sha256=args.observer_sha256,
        performance_profile=PERF_PROFILES.get(args.profile), evidence_budget=evidence,
        **(dict(recording_storage=recording_storage) if recording_storage else {}),
        safety=('RECORD_BRANCH_EOS_ONLY_ENCODER_EOS_BLOCKED_NO_RESET_OR_RELEASE'
                if PERF_PROFILES.get(args.profile, {}).get('h265_tail') else
                'NO_EOS_CLOSE_UNMAP_REOPEN_RESET_OR_RECOVERY')))
    events = (run/'steps.jsonl').open('x', buffering=1)
    event_lock = threading.Lock()
    def event(row):
        with event_lock:
            events.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+'\n')
            events.flush()
    budget = peer_owner.TrialBudget(duration=duration)
    lut_deadline = None
    original_lut_client = None
    if args.profile == COMBINED_PROFILE:
        if __package__:
            from .bounded_lut import LutDeadline
        else:
            from bounded_lut import LutDeadline
        from linux.rk_debug import controls as peer_controls
        from linux.task3_pipeline import pcie_protocol_v1 as peer_protocol
        lut_deadline = LutDeadline(event=event)
        original_lut_client = peer_controls.DehazeLutTransactions
        peer_controls.DehazeLutTransactions = lut_deadline.client_class(original_lut_client, peer_protocol)
    preview = None
    remote = remote_server = remote_bridge = None
    remote_session = None
    source_gaps = None
    runner = None
    if args.profile in JOURNAL_PROFILES:
        source_gaps = SourceGapJournal(run).start()
    class RetainingSession(SourceGapSessionMixin, peer_session.DebugSession):
        def _apply(self, document):
            if args.profile == 'dual-r3-mono-hdr-cfg10-30':
                if __package__:
                    from .cfg_deadline import transaction_deadline
                else:
                    from cfg_deadline import transaction_deadline
                tx = self.controls.transactions
                old_timeout = tx.timeout_s
                tx.timeout_s = cfg_seconds
                try:
                    with transaction_deadline(tx, seconds=cfg_seconds, event=event):
                        return super()._apply(document)
                finally:
                    tx.timeout_s = old_timeout
            return super()._apply(document)
        def prepare(self):
            if PERF_PROFILES.get(args.profile, {}).get('dual_r3_mono'):
                if __package__:
                    from .dual_r3 import cold_admission, controls_factory
                else:
                    from dual_r3 import cold_admission, controls_factory
                try:
                    admission = cold_admission(self.receiver.read32)
                    peer_owner.atomic_json(run/'r3-cold-admission.json', admission)
                    self.controls_factory = controls_factory(args.profile)
                except Exception as error:
                    self._fault('PREPARE', error)
                    raise
            return super().prepare()
        def snapshot(self):
            result = super().snapshot()
            now = time.monotonic()
            result['trial_timing'] = dict(start_call_monotonic_s=budget.started,
                sampled_monotonic_s=now, budget_s=duration,
                elapsed_s=None if budget.started is None else now-budget.started,
                remaining_s=None if budget.started is None else budget.remaining(),
                scope='HOST_START_CALL_BUDGET_INCLUDES_CFG_NOT_PHYSICAL_HDMI_TIME')
            result.update(global_quiet_proven=False, native_closed=False, safe_reopen=False)
            if lut_deadline is not None:
                result['lut_operation'] = lut_deadline.snapshot()
            if args.profile == ALTERNATING_HDR_PROFILE and runner is not None:
                result['alternation'] = runner.alternation_summary()
            if PERF_PROFILES.get(args.profile, {}).get('dual_r3_basic') and runner is not None:
                result['basic_algorithms'] = runner.basic_summary()
            return result
        def start(self):
            budget.start()
            event(dict(kind='START_CALL', monotonic_s=budget.started))
            result = super().start()
            event(dict(kind='START_RETURN', monotonic_s=time.monotonic()))
            return result
        def close(self):
            result = (peer_owner.close_retaining(self, consumer_timeout_s=12)
                      if PERF_PROFILES.get(args.profile, {}).get('h265_tail') else
                      peer_owner.close_retaining(self))
            if source_gaps is not None:
                receiving = self._receive_thread is not None and self._receive_thread.is_alive()
                result['source_gap_journal'] = (source_gaps.snapshot() if receiving
                                               else source_gaps.close(timeout_s=3))
                gap = result['source_gap_journal']
                result['source_gap_evidence_complete'] = bool(
                    not receiving and gap.get('complete') and not gap.get('failure'))
            result.update(global_quiet_proven=False, native_closed=False,
                safe_reopen=False, start_budget_s=duration)
            return result
    RetainingSession.source_gap_journal = source_gaps
    class Factory(cli.NativeFactory):
        def consumers(self, peer_args):
            nonlocal preview
            from linux.rk_debug.consumers import DebugConsumers
            from linux.task3_runtime.pipeline import SourceKey
            from linux.stream_diag.records import parse_record
            cohort = 'calfix-direct-' + uuid4().hex
            preview_options = dict(evidence_profile=args.profile) if long_evidence else {}
            if args.recording_dir is not None:
                preview_options['recording_directory'] = args.recording_dir
            preview = DirectPreview(run/'preview', args.observer, env,
                source_key=SourceKey, parse_record=parse_record,
                receiver_cohort=cohort, budget=budget, performance=args.profile in PERF_PROFILES,
                **preview_options)
            try:
                preview.start()
                return DebugConsumers(jpeg_recorder=preview, receiver_cohort=cohort,
                    jpeg_version=record_version, max_product_bytes=2*4194304+header_bytes)
            except BaseException as error:
                preview.request_stop()
                raise cli.StartupRetained(cli.ResourceOwner([('direct_preview', preview)], error)) from error
        def receiver(self, peer_args):
            receiver = super().receiver(peer_args)
            receiver.stop = logged_single_stop(receiver.stop, event)
            return receiver
        def session(self, receiver, peer_args, consumers):
            nonlocal remote_session
            remote_session = RetainingSession(receiver, jpeg_version=record_version, config_timeout_s=3,
                drain_timeout_s=3, consumers=consumers, allow_lab_hdr=allow_hdr,
                expected_bdf=peer_args.expected_bdf, max_records=200000)
            return remote_session
    execute = cli._execute
    def checked_execute(session, step, seconds, stop):
        if preview is not None:
            preview.check()
        if step['op'] == 'query-lut' and lut_deadline is not None:
            lut_deadline.arm(min(4., seconds-.25, budget.remaining()-.25))
        if step['op'] == 'configure':
            validate_configuration(step['configuration'], args.profile)
            if lut_deadline is not None and step['configuration']['extension']['processing_enables'] & 2:
                if lut_deadline.state != 'CONFIRMED':
                    raise RuntimeError('F21 CFG requires whole LUT operation CONFIRMED')
        return execute(session, step, seconds, stop)
    def save_step(number, value):
        if lut_deadline is not None:
            value['lut_operation'] = lut_deadline.snapshot()
        if source_gaps is not None:
            value['source_gap_journal'] = source_gaps.snapshot()
        peer_owner.atomic_json(run/f'step-{number:03d}.json', value)
    runner = BoundedRunner(checked_execute, budget, event, save_step,
        preview_state=run/'preview'/'preview-state.json', profile=args.profile)
    if PERF_PROFILES.get(args.profile, {}).get('remote_control'):
        if __package__:
            from .remote_algorithm_control import Broker, OwnerBridge, ControlServer
        else:
            from remote_algorithm_control import Broker, OwnerBridge, ControlServer
        remote = Broker()
        remote_bridge = OwnerBridge(remote, runner.execute, budget, event,
            runner._preview_new_epoch, runner._check_preview, run/'preview'/'preview-state.json')
        runner.wait_hook = lambda stop: remote_bridge.poll(remote_session, stop)
        remote_server = ControlServer(remote)
        threading.Thread(target=remote_server.serve_forever, daemon=True).start()
    cli._execute = runner
    def hold(owner, report, *, output):
        if remote is not None:
            if remote.phase != 'FAULTED':
                remote.terminal('video trial stopped; native ownership retained', failed=bool(report.get('failure')))
            state = remote.state()
            state.pop('token', None)
            try:
                peer_owner.atomic_json(run/'remote-final.json', state)
            except Exception as error:
                # Evidence write failure must never bypass native retention.
                report['remote_evidence_error'] = type(error).__name__ + ': ' + str(error)[:256]
        if preview is not None:
            preview.close(timeout_s=12 if PERF_PROFILES.get(args.profile, {}).get('h265_tail') else 3)
        cli.hold_retained_owner(owner, report, output=output)
    try:
        return cli.main(['run', '--device', args.device, '--expected-bdf', args.expected_bdf,
            '--jpeg-version', str(record_version), '--config-timeout', '3', '--drain-timeout', '3',
            '--command-timeout', str(command_seconds), '--max-seconds', str(duration),
            *(['--allow-lab-hdr'] if allow_hdr else []),
            '--max-records', '200000', '--consumer-close-timeout', '3',
            '--report-output', str(run/'result.json'), '--script', str(run/'plan.json')],
            factory=Factory(), hold=hold)
    finally:
        if remote_server is not None:
            remote_server.shutdown()
            remote_server.server_close()
        cli._execute = execute
        if original_lut_client is not None:
            peer_controls.DehazeLutTransactions = original_lut_client
        events.close()


if __name__ == '__main__':
    raise SystemExit(main())
