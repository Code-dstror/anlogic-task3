"""Fixed RK-built R3 KO and read-only target admission; no native open/load."""
import errno
import gzip
import hashlib
import os
from pathlib import Path
import re
import stat
import struct
from uuid import UUID

KO_SHA256 = 'aa8336d17b670a6fbbaf705e59dc020c86cd9fc3a41197daca929e302602d822'
KO_BYTES = 172648
KO_BUILD_ID = 'f10669abaa7f5797007bb1f08164c7f3bf41eb58'
STEREO_KO_SHA256 = '61e2aa53f3c4a574744793c633292fcfd5ac83c1e372761e7372acd7c78766ec'
STEREO_KO_BYTES = 172920
STEREO_KO_BUILD_ID = 'db2c5b1de225ec72596863cd70de845e3e6d59c7'

def module_identity(profile):
    if profile == 'mono':
        return KO_SHA256, KO_BYTES, KO_BUILD_ID
    if profile == 'stereo-n2':
        return STEREO_KO_SHA256, STEREO_KO_BYTES, STEREO_KO_BUILD_ID
    raise ValueError('unknown fixed module identity')

KERNEL_RELEASE = '6.1.99'
KERNEL_BUILD_ID = '3029de626e5b93ec060106f70b361766bd9a7132'
CONFIG_SHA256 = '86900cf569565d74a2b6d5ca32a35d2ca68c25ea71ef9fc4e2816a0acb4e8956'
MODULE = '/sys/module/ph1a_c2h'
DRIVER = '/sys/bus/pci/drivers/ph1a_c2h_candidate'
PCI = '/sys/bus/pci/devices'
BDF_PATTERN = r'[0-9a-f]{4}:[0-9a-f]{2}:[0-1][0-9a-f]\.[0-7]'
ABSENT = 'MODULE_ABSENT_ENDPOINT_UNBOUND'
UNBOUND = 'MATCHED_MODULE_ENDPOINT_UNBOUND'
BOUND = 'MATCHED_ALREADY_BOUND_SKIP_INSMOD_AND_NEW_ID'
PARAMETERS = dict(slots=2, capacity=4194304, dma_bits=64, irq_hint=0, poll_ms=1, drain_ms=2000)


def note_build_id(body):
    offset=0;found=[]
    while offset+12<=len(body):
        names,size,kind=struct.unpack_from('<III',body,offset);offset+=12
        name=body[offset:offset+names];offset+=(names+3)&~3
        value=body[offset:offset+size];offset+=(size+3)&~3
        if offset>len(body):raise ValueError('truncated GNU notes')
        if name.rstrip(b'\0')==b'GNU' and kind==3:found.append(value.hex())
    if offset!=len(body) or len(found)!=1:raise ValueError('unique GNU build-id required')
    return found[0]


def verify_ko(path, *, identity="mono"):
    """Hash an ordinary pinned file without opening devices or following a leaf link."""
    sha, size, build_id = module_identity(identity)
    path=Path(path)
    pin=os.open(path,os.O_PATH|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        info=os.fstat(pin)
        if not stat.S_ISREG(info.st_mode) or info.st_size!=size:
            raise ValueError('fixed ordinary R3 KO file/size required')
        with open('/proc/self/fd/'+str(pin),'rb') as stream:body=stream.read(size+1)
    finally:os.close(pin)
    if len(body)!=size or hashlib.sha256(body).hexdigest()!=sha:
        raise ValueError('fixed RK R3 KO SHA differs')
    # The immutable SHA pins the independently reviewed ET_REL/AArch64 ELF,
    # real missing srcversion, NULL id_table and separately reviewed access policy.
    return dict(status='FIXED_RK_KO_FILE_VERIFIED_NOT_LOADED',path=str(path.absolute()),
        bytes=size,sha256=sha,build_id=build_id,identity=identity,
        vermagic='6.1.99 SMP mod_unload aarch64',srcversion=None)


class TargetFiles:
    def read_text(self,path):return Path(path).read_text()
    def read_bytes(self,path):return Path(path).read_bytes()
    def listdir(self,path):return sorted(item.name for item in Path(path).iterdir())
    def realpath(self,path):return str(Path(path).resolve(strict=True))
    def lstat(self,path):return Path(path).lstat()
    def kernel_release(self):return os.uname().release
    def machine(self):return os.uname().machine


def _optional(fs,path):
    try:return fs.lstat(path)
    except FileNotFoundError as error:
        if error.errno!=errno.ENOENT or error.filename!=path:raise
        return None


def _owner_check(scan):
    value=scan()
    if (type(value) is not dict or type(value.get('owners')) is not list or
            type(value.get('errors')) is not list or value['owners'] or value['errors']):
        raise ValueError('existing owner or incomplete owner scan')
    return value


def _default_owner_scan():
    if __package__:
        from .handoff import owner_scan
    else:
        from handoff import owner_scan
    return owner_scan()


def _snapshot(fs,boot,expected_bdf,identity="mono"):
    _, _, expected_module_id = module_identity(identity)
    if fs.read_text('/proc/sys/kernel/random/boot_id').strip()!=boot:
        raise ValueError('actual boot differs')
    if fs.machine()!='aarch64' or fs.kernel_release()!=KERNEL_RELEASE:
        raise ValueError('actual RK architecture/kernel release differs')
    notes=fs.read_bytes('/sys/kernel/notes')
    if note_build_id(notes)!=KERNEL_BUILD_ID:raise ValueError('actual kernel build-id differs')
    config=gzip.decompress(fs.read_bytes('/proc/config.gz'))
    if len(config)>2*1024*1024 or hashlib.sha256(config).hexdigest()!=CONFIG_SHA256:
        raise ValueError('actual running kernel config differs')
    matches=[]
    for bdf in fs.listdir(PCI):
        if not re.fullmatch(BDF_PATTERN,bdf):raise ValueError('invalid sysfs PCI identity')
        device=PCI+'/'+bdf
        if (fs.read_text(device+'/vendor').strip(),fs.read_text(device+'/device').strip())==('0x1edb','0xabcd'):
            matches.append(bdf)
    if len(matches)!=1:raise ValueError('exactly one enumerated 1edb:abcd endpoint required')
    bdf=matches[0]
    if expected_bdf is not None and expected_bdf!=bdf:raise ValueError('observed BDF differs from explicit target')
    device=PCI+'/'+bdf;physical=fs.realpath(device)
    # Parent directories must themselves exist; a missing module leaf cannot
    # hide a vanished/inaccessible sysfs tree.
    fs.listdir('/sys/module')
    module_present=_optional(fs,MODULE) is not None
    driver_present=_optional(fs,DRIVER) is not None
    attached=_optional(fs,device+'/driver') is not None
    binding=fs.realpath(device+'/driver') if attached else None
    if binding not in (None,DRIVER):raise ValueError('endpoint belongs to another driver')
    bound_entries=[]
    if driver_present:
        bound_entries=[name for name in fs.listdir(DRIVER) if re.fullmatch(BDF_PATTERN,name)]
        if any(name!=bdf for name in bound_entries):raise ValueError('same driver bound to another PCI device')
    node_names=[name for name in fs.listdir('/dev') if name.startswith('ph1a_c2h')]
    misc_names=[name for name in fs.listdir('/sys/class/misc') if name.startswith('ph1a_c2h')]
    parameters={};module_id=None;native_device=None;rdev=None
    if not module_present:
        if driver_present or attached or node_names or misc_names:
            raise ValueError('residual driver/binding/native node without expected module')
        status=ABSENT
    else:
        if (fs.realpath(MODULE)!=MODULE or not driver_present or
                fs.realpath(DRIVER+'/module')!=MODULE):
            raise ValueError('registered driver/module association differs')
        module_id=note_build_id(fs.read_bytes(MODULE+'/notes/.note.gnu.build-id'))
        if module_id!=expected_module_id:raise ValueError('loaded module build-id differs')
        if _optional(fs,MODULE+'/srcversion') is not None:
            raise ValueError('fixed loaded module requires actual missing srcversion')
        expected=dict(PARAMETERS,target_bdf=bdf)
        for name,value in expected.items():
            actual=fs.read_text(MODULE+'/parameters/'+name).strip()
            if (actual not in ('N','0') if name=='irq_hint' else actual!=str(value)):
                raise ValueError('loaded module parameter differs: '+name)
            parameters[name]=actual
        if not attached:
            if bound_entries or node_names or misc_names:
                raise ValueError('unbound module has residual binding/native node')
            status=UNBOUND
        else:
            if bound_entries!=[bdf] or fs.realpath(device+'/driver/module')!=MODULE:
                raise ValueError('PCI binding/registered module differs')
            name='ph1a_c2h_'+bdf
            if node_names!=[name] or misc_names!=[name]:
                raise ValueError('unique dynamically observed native node required')
            native_device='/dev/'+name;misc='/sys/class/misc/'+name
            node=fs.lstat(native_device)
            if not stat.S_ISCHR(node.st_mode):raise ValueError('native node is not a character device')
            major,minor=os.major(node.st_rdev),os.minor(node.st_rdev)
            if fs.read_text(misc+'/dev').strip()!=str(major)+':'+str(minor):
                raise ValueError('native rdev differs from misc sysfs')
            char='/sys/dev/char/'+str(major)+':'+str(minor)
            if (fs.realpath(misc+'/device')!=physical or
                    fs.realpath(char)!=fs.realpath(misc) or fs.realpath(char+'/device')!=physical):
                raise ValueError('native character/misc/PCI parent association differs')
            rdev=dict(major=major,minor=minor);status=BOUND
    return dict(status=status,bdf=bdf,device=native_device,boot_id=boot,
        kernel_release=KERNEL_RELEASE,kernel_build_id=KERNEL_BUILD_ID,
        running_config=dict(bytes=len(config),sha256=CONFIG_SHA256),
        module_build_id=module_id,module_srcversion=None,
        parameters=parameters,pci_device=device,pci_physical=physical,rdev=rdev,
        native_opened=False,hardware_writes=0)


def inspect_target(expected_boot,*,expected_bdf=None,filesystem=None,owner_scan=None,identity="mono"):
    """Discover one endpoint and classify exact module state without device opens.

    This grants no load/bind permission. Recheck immediately before a separately
    authorized operation; live PCI/module/owner changes cause a closed failure.
    """
    if type(expected_boot) is not str or str(UUID(expected_boot))!=expected_boot:
        raise ValueError('canonical expected boot UUID required')
    if expected_bdf is not None and not re.fullmatch(BDF_PATTERN,expected_bdf):
        raise ValueError('canonical explicit BDF required')
    fs=filesystem or TargetFiles();scan=owner_scan or _default_owner_scan
    first_scan=_owner_check(scan)
    before=_snapshot(fs,expected_boot,expected_bdf,identity)
    after=_snapshot(fs,expected_boot,expected_bdf,identity)
    second_scan=_owner_check(scan)
    if before!=after or fs.read_text('/proc/sys/kernel/random/boot_id').strip()!=expected_boot:
        raise ValueError('target identity changed during read-only admission')
    return dict(before,owner_scans=[first_scan,second_scan],
        scope='READ_ONLY_DRIVER_IDENTITY_NOT_NATIVE_DMA_OR_VIDEO_ACCEPTANCE')


def check_target(expected_boot,*,expected_bdf=None,filesystem=None,owner_scan=None,identity="mono"):
    value=inspect_target(expected_boot,expected_bdf=expected_bdf,filesystem=filesystem,owner_scan=owner_scan,identity=identity)
    if value['status']!=BOUND:raise ValueError('matching new module and endpoint binding required; no automatic load/bind')
    return value
