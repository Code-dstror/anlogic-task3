"""One bounded DUAL color trial core; caller retains native and display owners.

No executable device entry: target new-KO identity, fresh owner guard and KMS
admission must be completed by the reviewed deployment launcher first. This
module takes an already admitted Receiver and never opens/closes a device.
"""
import time
from collections import deque

if __package__:
    from .dual_r3_stereo import ColdStereoPreparation, StereoSourceRouter
else:
    from dual_r3_stereo import ColdStereoPreparation, StereoSourceRouter


class StereoTrial:
    def __init__(self, receiver, preview, *, clock=time.monotonic,
                 preparation_factory=ColdStereoPreparation, router_factory=StereoSourceRouter,
                 reader_factory=None, alternating=False, fixed_cam0=False, progress=None, cold_evidence=None,
                 source_order_policy='strict', record_evidence=None,
                 first_frame_segments=False, segment_count=6, side_by_side=False):
        if source_order_policy not in ('strict', 'drop_stale'):
            raise ValueError('unknown SOURCE order policy')
        if any(type(value) is not bool for value in (alternating, fixed_cam0, side_by_side)):
            raise ValueError('display modes require explicit bools')
        if sum((alternating, fixed_cam0, side_by_side)) > 1:
            raise ValueError('dual display modes are mutually exclusive')
        if (type(first_frame_segments) is not bool or type(segment_count) is not int
                or (first_frame_segments and (not alternating or segment_count != 2))
                or (not first_frame_segments and segment_count != 6)):
            raise ValueError('first-frame timing is only the explicit two-segment alternating recipe')
        if reader_factory is None:
            from linux.rk_debug.transport import OwnedRecordReader
            reader_factory = OwnedRecordReader
        self.progress = progress
        self.source_order_policy = source_order_policy
        self.record_evidence = record_evidence
        self.evidence_error = None
        self._drop_type = ()
        if source_order_policy == 'drop_stale':
            if __package__:
                from .stereo_source_order import SourceOrderDrop
            else:
                from stereo_source_order import SourceOrderDrop
            self._drop_type = SourceOrderDrop
        self.last_progress = None
        self.alternating = alternating
        self.fixed_cam0 = fixed_cam0
        self.side_by_side = side_by_side
        self.first_frame_segments, self.segment_count = first_frame_segments, segment_count
        self.segment_windows = []
        self.duration = 40 if first_frame_segments else 60 if alternating or fixed_cam0 or side_by_side else 30
        self.next_segment = 1
        self.receiver, self.preview = receiver, preview
        self.clock = clock
        self.preparation = (preparation_factory(receiver) if cold_evidence is None else
                            preparation_factory(receiver, evidence=cold_evidence))
        self.router_factory, self.reader_factory = router_factory, reader_factory
        self.router = self.reader = None
        self.state = 'NEW'
        self.events = []
        self.failure = None
        self.start_intent = self.stop_intent = False
        self.started = self.stopped = None
        self.last_camera = [None, None]
        self.accepted = [0, 0]
        self.drop_duplicate_source = [0, 0]
        self.drop_backward_source = [0, 0]
        self.previous_accepted = [deque(maxlen=2), deque(maxlen=2)]
        self.receipt = None
        self.final_preview = None
        self.transport = None

    def _event(self, name, **data):
        self.events.append(dict(event=name, monotonic_s=self.clock(), **data))

    def _stop_once(self):
        if self.stop_intent:
            return
        self.stop_intent = True
        self._event('STOP_CALL')
        self.receiver.stop()
        self.stopped = self.clock()
        self._event('STOP_RETURN')

    def feed(self, wire, *, host_ns=None, transport_identity=None, completion_metadata=None):
        item = self.router.accept(wire)
        if isinstance(item, self._drop_type):
            if item.reason == 'DROP_DUPLICATE_SOURCE':
                self.drop_duplicate_source[item.camera] += 1
            elif item.reason == 'DROP_BACKWARD_SOURCE':
                self.drop_backward_source[item.camera] += 1
            else:
                raise RuntimeError('unknown typed SOURCE drop reason')
            if self.record_evidence is not None:
                try:
                    self.record_evidence.record(item, host_ns=host_ns,
                        transport_identity=transport_identity, completion_metadata=completion_metadata,
                        previous_accepted=tuple(dict(row) for row in self.previous_accepted[item.camera]))
                except BaseException as error:
                    self.evidence_error = type(error).__name__+': '+str(error)[:512]
                    raise
            return item
        # Remember identities immediately: a later DROP in this same read batch
        # must see this ACCEPT even before poll_once returns. Never retain old
        # record/wire/mapping objects in the history.
        metadata = item.record.metadata
        completion = completion_metadata or {}
        self.previous_accepted[item.camera].append(dict(camera=item.camera,
            session=item.session, epoch=item.epoch, sequence=item.sequence,
            jpeg_session=metadata.jpeg_session, jpeg_slot=metadata.jpeg_slot,
            jpeg_generation=metadata.jpeg_generation, host_ns=host_ns,
            host_slot=completion.get('host_slot'),
            transport_generation=completion.get('transport_generation')))
        return item

    def _poll(self, display):
        for item in self.reader.poll_once(.01):
            if isinstance(item, dict):
                self._event('TRANSPORT_RESULT', detail=item)
                # STOP cancellation is recorded separately; no bad JPEG label.
                from linux.dma_c2h_candidate.c2h_abi import RESULT_CANCELLED
                if (display or item.get('kind') != 'TRANSPORT_RESULT' or
                        item.get('result') != RESULT_CANCELLED):
                    raise RuntimeError('unexpected negative transport result')
                continue
            if isinstance(item, self._drop_type):
                continue
            self.accepted[item.camera] += 1
            self.last_camera[item.camera] = self.clock()
            if display:
                self.preview.submit(item)
        if self.reader.limit_reached:
            raise RuntimeError('dual record budget exhausted')

    def _advance_first_frame_segments(self):
        """Ten seconds from each matching first selected decoded sink buffer.

        Both cameras continue receiving/decoding. Selector evidence binds the
        selected camera, segment and decoded-buffer serial, not physical scanout.
        """
        selected = self.preview.snapshot()['selections']
        index = self.next_segment-1
        if len(selected) != index+1:
            raise RuntimeError('unexpected first-frame segment selection order')
        first = selected[index].get('first_sink')
        if first is None:
            return False
        now_ns = round(self.clock()*1e9)
        stamp = first['monotonic_ns']
        if (first['segment'] != index or first['camera'] != index%2
                or type(stamp) is not int or not 0 < stamp <= now_ns):
            raise RuntimeError('first selected sink identity/time differs')
        if len(self.segment_windows) == index:
            self.segment_windows.append(dict(segment=index,camera=index%2,first_sink=first,
                first_host_ns=stamp,observation_end_ns=stamp+10_000_000_000,complete=False))
            self._event('SEGMENT_FIRST_VALID_SINK',**self.segment_windows[-1])
        window = self.segment_windows[index]
        if now_ns < window['observation_end_ns']:
            return False
        window.update(complete=True,completed_host_ns=now_ns)
        self._event('SEGMENT_OBSERVATION_COMPLETE',**window)
        if self.next_segment == self.segment_count:
            return True
        self.preview.select_camera(self.next_segment%2,self.next_segment)
        self._event('DISPLAY_SELECT_REQUEST',segment=self.next_segment,camera=self.next_segment%2,
                    timing='AFTER_PRIOR_FIRST_VALID_SINK_PLUS_10S')
        self.next_segment += 1
        return False

    def run(self):
        if self.state != 'NEW':
            raise RuntimeError('dual trial already attempted; no retry')
        self.state = 'PREPARING'
        preview_attempted = False
        try:
            self.receipt = self.preparation.prepare()
            self._event('COLD_APPLY_AND_SELECT_ACK')
            router_options = dict(source_sessions=self.receipt['source_sessions'],
                                  source_epochs=self.receipt['source_epochs'])
            if self.source_order_policy != 'strict':
                router_options['source_order_policy'] = self.source_order_policy
            self.router = self.router_factory(**router_options)
            self.reader = self.reader_factory(self.receiver, self, maximum_batch=2,
                record_budget=9600 if self.alternating or self.fixed_cam0 or self.side_by_side else 4800)
            preview_attempted = True
            self.preview.start()
            if self.alternating or self.fixed_cam0:
                self.preview.select_camera(0, 0)
                self._event("DISPLAY_SELECT_REQUEST", segment=0, camera=0)
            self.start_intent = True
            self.started = self.clock()
            self._event('START_CALL')
            self.receiver.start()
            self._event('START_RETURN')
            self.state = 'RUNNING'
            while self.clock()-self.started < self.duration:
                elapsed = self.clock()-self.started
                if self.first_frame_segments and self._advance_first_frame_segments():
                    break
                if not self.first_frame_segments and self.alternating and elapsed >= self.next_segment*10 and self.next_segment < 6:
                    if elapsed >= (self.next_segment+1)*10:
                        raise TimeoutError("display switch deadline missed; no catch-up burst")
                    self.preview.select_camera(self.next_segment % 2, self.next_segment)
                    self._event("DISPLAY_SELECT_REQUEST", segment=self.next_segment,
                                camera=self.next_segment % 2, scheduled_offset_s=self.next_segment*10)
                    self.next_segment += 1
                self._poll(display=True)
                self.preview.check()
                now = self.clock()
                if self.progress is not None and (self.last_progress is None or now-self.last_progress >= 1):
                    self.progress(dict(state=self.state,elapsed_s=now-self.started,
                        next_segment=self.next_segment,events=list(self.events),
                        router=self.router.snapshot(),preview=self.preview.snapshot(),
                        source_order_policy=self.source_order_policy,
                        source_order=self._source_order_snapshot()))
                    self.last_progress = now
                if now-self.started > 3:
                    if any(t is None or now-t > 3 for t in self.last_camera):
                        raise TimeoutError('individual camera receive did not progress for 3 seconds')
                    observation = self.preview.snapshot()
                    if any(not stamp or now-stamp/1e9 > 3 for stamp in observation['last_ns']):
                        raise TimeoutError('individual MPP or composite sink stalled for 3 seconds')
                    if now-observation['heartbeat_ns']/1e9 > 1:
                        raise TimeoutError('dual observer heartbeat stale')
            if self.first_frame_segments and (len(self.segment_windows) != 2
                    or not all(row['complete'] for row in self.segment_windows)):
                raise TimeoutError('two full ten-second selected-camera windows incomplete at START40 limit')
            self.state = 'DRAINING'
            self._stop_once()
            deadline = self.clock()+3
            while True:
                self._poll(display=False)
                if self.reader.drained():
                    break
                if self.clock() >= deadline:
                    raise TimeoutError('dual host transport drain deadline; retain owner')
            self.state = 'DRAINED_RETAINED'
        except BaseException as error:
            self.failure = type(error).__name__+': '+str(error)[:512]
            self.state = 'FAULTED_RETAINED'
            if self.start_intent and not self.stop_intent:
                try:
                    self._stop_once()
                except BaseException as stop_error:
                    self._event('STOP_UNKNOWN', error=str(stop_error)[:512])
        finally:
            if preview_attempted:
                try:
                    self.final_preview = self.preview.close()
                    if self.final_preview.get('failure'):
                        raise RuntimeError(self.final_preview['failure'])
                except BaseException as error:
                    self.failure = self.failure or 'preview seal: '+str(error)[:512]
                    self.state = 'FAULTED_RETAINED'
            if self.reader is not None:
                try:
                    self.transport = self.reader.snapshot()
                except BaseException as error:
                    self.failure = self.failure or 'final transport observation: '+str(error)[:512]
                    self.state = 'FAULTED_RETAINED'
        return self.snapshot()

    def _source_order_snapshot(self):
        now = self.clock()
        return dict(policy=self.source_order_policy,
            cameras=[dict(camera=c, accepted=self.accepted[c],
                drop_duplicate_source=self.drop_duplicate_source[c],
                drop_backward_source=self.drop_backward_source[c],
                last_accepted_sequence=(self.previous_accepted[c][-1]['sequence']
                                        if self.previous_accepted[c] else None),
                last_accepted_age_ms=(None if self.last_camera[c] is None
                                      else max(0., now-self.last_camera[c])*1000)) for c in (0, 1)],
            accepted_scope='VALID_ACCEPT_RESULTS_RETURNED_BY_READER_INCLUDING_STOP_TAIL_NOT_DECODE_OR_SCANOUT',
            drop_scope='INSPECTED_SOURCE_ORDER_DROPS_OTHER_VALIDATION_PASSED_NOT_PROVEN_FPGA_CAUSE',
            gap_semantics='N2_FORWARD_GAPS_ARE_NOT_TRANSPORT_LOSS_AND_NOT_ADDITIVE_WITH_SOURCE_DROPS',
            evidence_error=self.evidence_error,
            record_evidence=(None if self.record_evidence is None else self.record_evidence.snapshot()))

    def _completion_classification(self):
        if self.state == 'FAULTED_RETAINED':
            return 'FAULTED'
        if self.state != 'DRAINED_RETAINED':
            return 'IN_PROGRESS'
        if self.source_order_policy == 'strict':
            return 'STRICT_COMPLETED_NO_SOURCE_DROPS'
        drops = sum(self.drop_duplicate_source)+sum(self.drop_backward_source)
        return ('DROP_STALE_COMPLETED_WITH_SOURCE_DROPS' if drops
                else 'DROP_STALE_COMPLETED_NO_SOURCE_DROPS')

    def snapshot(self):
        return dict(state=self.state, failure=self.failure, events=list(self.events),
            source_order_policy=self.source_order_policy,
            completion_classification=self._completion_classification(),
            source_order=self._source_order_snapshot(),
            start_intent=self.start_intent, stop_intent=self.stop_intent,
            start_call_s=self.started, stop_return_s=self.stopped,
            cold=self.receipt,
            cold_diagnostics=(self.preparation.snapshot() if hasattr(self.preparation, 'snapshot') else None),
            router=None if self.router is None else self.router.snapshot(),
            transport=self.transport,
            preview=self.final_preview,
            release='NEVER_CLOSE_RECEIVER_OR_OBSERVER_NO_HOT_REOPEN',
            exposure_sync='NOT_QUALIFIED', duration_budget_s=self.duration,
            alternating=self.alternating, nominal_segment_s=10 if self.alternating else None,
            first_frame_segments=self.first_frame_segments,segment_windows=list(self.segment_windows),
            fixed_cam0=self.fixed_cam0,
            side_by_side=self.side_by_side,
            display_cameras=[0] if self.fixed_cam0 else ([0,1] if self.first_frame_segments else [0,1,0,1,0,1] if self.alternating else [0,1]),
            monitored_receive_and_mpp_cameras=[0,1],
            timing_scope=('FIRST_SELECTED_VALID_SINK_2X10S_WITH_START40S_LIMIT_NOT_PHYSICAL_SCANOUT'
                          if self.first_frame_segments else 'HOST_START_BUDGET_INCLUDES_STARTUP_NOT_60S_PHYSICAL_SCANOUT'),
            final_portrait_mode='1080x2560_NOT_IMPLEMENTED')
