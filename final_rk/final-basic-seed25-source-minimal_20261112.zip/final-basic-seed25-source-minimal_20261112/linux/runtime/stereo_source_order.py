"""Linux SOURCE ordering policy over complete owned SDK records.

The strict path delegates to the unmodified SDK. The explicit drop_stale path
uses the same parser/session/generation rules, with separate state for checked
JPEG identities and accepted SOURCE sequences. It never opens devices, clears
faults, reorders records, or changes the wire. The outer router still owns the
COLOR/Q75/camera-slot profile checks and terminal failure latch.
"""
from dataclasses import dataclass

POLICIES = ('strict', 'drop_stale')
_DROP_DUPLICATE = 'DROP_DUPLICATE_SOURCE'
_DROP_BACKWARD = 'DROP_BACKWARD_SOURCE'
_HALF = 0x80000000
_MASK = 0xffffffff


@dataclass(frozen=True)
class SourceOrderDrop:
    camera: int
    session: int
    epoch: int
    sequence: int
    previous_sequence: int
    delta: int
    reason: str
    record: object
    wire: bytes

    def __post_init__(self):
        if self.reason not in (_DROP_DUPLICATE, _DROP_BACKWARD):
            raise ValueError('unknown SOURCE drop reason')
        if type(self.wire) is not bytes:
            raise TypeError('SOURCE drop requires independently owned bytes')


class SourceOrderDemux:
    """One receiver's camera-local SOURCE and JPEG identity checks.

    As in the SDK, JPEG session is fixed for this demux and generations are
    keyed by (jpeg_session, jpeg_slot). The stereo router creates one instance
    per eye, preserving its existing JPEG namespaces. With drop_stale, an
    omitted source_epoch locks each camera to its first valid epoch. Strict
    without source_epoch preserves the SDK's original epoch behavior.

    Hard errors never commit state. They must reach the owning router's fault
    latch; this class has no recovery/reset API or independent lifecycle latch.
    """
    def __init__(self, *, record_version, source_session=None, source_epoch=None,
                 source_order_policy='strict'):
        if type(source_order_policy) is not str or source_order_policy not in POLICIES:
            raise ValueError('source_order_policy must be strict or drop_stale')
        if source_epoch is not None and (type(source_epoch) is not int
                or not 0 <= source_epoch <= _MASK):
            raise ValueError('source_epoch must be a u32')
        from dual_host.dual_records import DualRecordDemux
        # Reuse the SDK constructor's exact version/session admission. Its
        # strict state is retained only on the delegated strict path.
        sdk = DualRecordDemux(record_version=record_version, source_session=source_session)
        self.version, self.session = sdk.version, sdk.session
        self.source_epoch = source_epoch
        self.source_order_policy = source_order_policy
        self._strict = sdk if source_order_policy == 'strict' else None
        self.frames = sdk.frames if self._strict is not None else [0, 0]
        self.jpeg_bytes = sdk.jpeg_bytes if self._strict is not None else [0, 0]
        self._jpeg_session = None
        self._epochs = {}
        self._generations = {}
        self._last_accepted = [None, None]
        self._duplicate = [0, 0]
        self._backward = [0, 0]

    def accept(self, wire):
        if self._strict is not None:
            if self.source_epoch is not None:
                from linux.stream_diag.records import parse_record, RecordError
                wire = bytes(wire)
                record = parse_record(wire, expected_version=self.version)
                source = None if record.metadata is None else record.metadata.source
                if source is not None and source.epoch != self.source_epoch:
                    raise RecordError('source epoch changed inside selected receiver lifetime')
            item = self._strict.accept(wire)
            self.session = self._strict.session
            self._last_accepted[item.camera] = item.sequence
            return item

        from dual_host.dual_records import CameraRecord, forward32
        from linux.stream_diag.records import parse_record, RecordError
        owned = bytes(wire)
        record = parse_record(owned, expected_version=self.version)
        metadata = record.metadata
        if metadata is None or metadata.source is None:
            raise RecordError('dual record has no complete SOURCE identity')
        source = metadata.source
        if self.session is not None and source.session != self.session:
            raise RecordError('source session changed inside selected receiver lifetime')
        if self._jpeg_session is not None and metadata.jpeg_session != self._jpeg_session:
            raise RecordError('JPEG session changed inside selected receiver lifetime')
        epoch = (self.source_epoch if self.source_epoch is not None
                 else self._epochs.get(source.camera))
        if epoch is not None and source.epoch != epoch:
            raise RecordError('source epoch changed inside selected receiver lifetime')

        slot_key = metadata.jpeg_session, metadata.jpeg_slot
        generation = self._generations.get(slot_key)
        if generation is not None and not forward32(metadata.jpeg_generation, generation):
            raise RecordError('JPEG slot generation was reused or moved backwards')

        previous = self._last_accepted[source.camera]
        delta = None if previous is None else (source.sequence - previous) & _MASK
        if delta == _HALF:
            raise RecordError('ambiguous half-range SOURCE sequence for this camera')
        reason = (_DROP_DUPLICATE if delta == 0 else
                  _DROP_BACKWARD if delta is not None and delta > _HALF else None)
        # Construct the owned result before the state commit. A stale SOURCE is
        # eligible only after all independent integrity/identity checks above.
        if reason is None:
            item = CameraRecord(source.camera, source.session, source.epoch,
                                source.sequence, record, owned)
        else:
            item = SourceOrderDrop(source.camera, source.session, source.epoch,
                source.sequence, previous, delta, reason, record, owned)

        self._jpeg_session = metadata.jpeg_session
        self._generations[slot_key] = metadata.jpeg_generation
        if reason is None:
            self.session = source.session
            self._epochs[source.camera] = source.epoch
            self._last_accepted[source.camera] = source.sequence
            self.frames[source.camera] += 1
            self.jpeg_bytes[source.camera] += len(record.jpeg)
        elif reason == _DROP_DUPLICATE:
            self._duplicate[source.camera] += 1
        else:
            self._backward[source.camera] += 1
        return item

    def snapshot(self):
        return dict(source_order_policy=self.source_order_policy,
            record_version=self.version, source_session=self.session,
            accepted=list(self.frames), drop_duplicate_source=list(self._duplicate),
            drop_backward_source=list(self._backward),
            last_accepted_sequence=list(self._last_accepted),
            cameras=[dict(camera=c, accepted=self.frames[c], jpeg_bytes=self.jpeg_bytes[c],
                drop_duplicate_source=self._duplicate[c],
                drop_backward_source=self._backward[c],
                last_accepted_sequence=self._last_accepted[c]) for c in (0, 1)])
