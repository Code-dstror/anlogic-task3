"""One absolute software deadline across CFG proposal, PREPARE and COMMIT.

The caller serializes the transaction on its existing control worker. The
original BAR (including the session's COMMIT permit guard) handles every I/O.
Expiry poisons the transaction owner and never retries, cancels, resets, or
reclaims anything. A blocked kernel ioctl cannot be forcibly interrupted here.
"""
from contextlib import contextmanager
import math


class _DeadlineBar:
    def __init__(self, tx, original, seconds, event):
        self.tx, self.original, self.seconds, self.event = tx, original, seconds, event
        self.started = tx.clock()
        self.deadline = self.started + seconds
        self.observed = self.started
        self.expired = False

    def emit(self, kind, *, outcome=None, stage=None):
        if self.event is not None:
            self.event(dict(kind=kind, started_monotonic_s=self.started,
                deadline_monotonic_s=self.deadline, observed_monotonic_s=self.observed,
                elapsed_s=self.observed-self.started, budget_s=self.seconds,
                outcome=outcome, stage=stage,
                scope='SOFTWARE_OBSERVATION_NOT_KERNEL_IOCTL_CANCELLATION'))

    def check(self, stage):
        self.observed = self.tx.clock()
        if self.observed >= self.deadline:
            self.tx._terminal = True
            if not self.expired:
                self.expired = True
                self.emit('CFG_DEADLINE_EXPIRED', outcome='EXPIRED', stage=stage)
            raise TimeoutError('CFG absolute transaction deadline expired at '+stage+
                               '; pending hardware state and owner retained, no retry')

    def read32(self, offset):
        self.check('before-read')
        result = self.original.read32(offset)
        self.check('after-read')
        return result

    def write32(self, offset, value):
        self.check('before-write')
        result = self.original.write32(offset, value)
        self.check('after-write')
        return result


@contextmanager
def transaction_deadline(tx, seconds=10, event=None):
    """Bound the entire with-body using tx.clock; restore only its BAR adapter.

    Place around super()._apply(document), covering propose and apply together.
    READY/APPLIED/session waiting cannot restart this deadline. Restoring the
    adapter never clears tx._terminal or changes the pending hardware command.
    """
    if (type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds <= 0 or
            (event is not None and not callable(event))):
        raise ValueError('finite positive CFG seconds and optional callable event required')
    if not callable(tx.clock):
        raise TypeError('CFG transaction requires its monotonic clock')
    original = tx.bar
    guard = _DeadlineBar(tx, original, float(seconds), event)
    outcome = 'ERROR'
    tx.bar = guard
    try:
        guard.emit('CFG_DEADLINE_ARM', outcome='ARMED')
        yield guard
        guard.check('complete')
        outcome = 'COMPLETE'
    except BaseException:
        outcome = 'EXPIRED' if guard.expired else 'ERROR'
        raise
    finally:
        tx.bar = original
        guard.observed = tx.clock()
        guard.emit('CFG_DEADLINE_END', outcome=outcome)
