"""Fixed MONO first-HDR observation, no repeated switching or topology writes.

Timers reuse the existing explicit engineering policy. They are not inferred
sensor timings or new FPGA defaults. No timeout extension/retry after failure.
"""
def hdr_extension():
    from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
    return MonoConfiguration(product_mode=2, processing_enables=0,
        hdr_ratio=4,hdr_black_long=50,hdr_black_short=50,
        hdr_motion_base=64,hdr_motion_shift=3,hdr_qualification=15,
        hdr_max_delta_ns=50000000,hdr_max_wait_ns=100000000,
        hdr_max_age_ns=1000000000,dehaze_lut_generation=0)


def validate_hdr_record(record):
    from linux.task3_pipeline import pcie_protocol_v1 as p
    m,a = record.metadata,record.s07
    s = None if m is None else m.source
    if (s is None or s.camera != 0 or s.kind != p.PCIE_RECORD_V2_SOURCE_PHYSICAL or
            (record.width,record.height) != (1920,1080) or
            not 0 <= m.jpeg_slot <= 2 or not 4 <= len(record.jpeg) <= 4192192 or
            a is None or a.enabled or a.frame_error or
            any(getattr(a,n) is not None for n in ('f22','f23','f24','f25'))):
        raise ValueError('HDR trial requires bounded physical CAM0 v4 with no analysis')
    if s.epoch == 0:
        if (s.format,s.role,m.processing_mode,m.record_flags,m.processing_member) != (1,0,0,0,0):
            raise ValueError('HDR trial startup must be the unchanged SDR BOOT record')
    else:
        # Fixed raw_hdr_phase_scheduler4 keeps the original LONG RAW10 SOURCE
        # descriptor (member0) even though the pixel merge/ISP uses RAW14.
        # anlogic2026 passes that source and the HDR product flag into CTX2.
        if ((s.format,s.role,m.processing_mode,m.record_flags,m.processing_member) != (1,1,128,1,0)
                or not m.validity_flags & p.PCIE_RECORD_V2_FLAG_HDR_PRODUCT
                or not m.pair_id or m.job_id != m.pair_id or not m.qualified):
            raise ValueError('HDR target epoch lacks the qualified LONG source/pair/job/merged-product identity')
    return record
