"""Peer-owned JPEG callback to a single bounded MPP observer worker.

submit() only replaces one immutable owned reference. Disk, hashing and pipe
writes run on the worker. close() seals evidence and retains the observer and
its open input; it never sends EOS, terminates a process or closes native state.
"""
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

if __package__:
    from .algorithm_preview import ObserverLog, atomic_json, write_bounded
else:
    from algorithm_preview import ObserverLog, atomic_json, write_bounded

MAX_JPEG_BYTES = 4194304
MAX_SAMPLE_BYTES = 64 * 1024 * 1024
MAX_SUBMISSION_BYTES = 32 * 1024 * 1024


def display_environment(observer, observer_sha256, baseline, *, verify_plugins=True):
    if hashlib.sha256(Path(observer).read_bytes()).hexdigest() != observer_sha256:
        raise ValueError('observer differs')
    spec = json.loads(Path(baseline).read_text())
    plugins = spec['plugin_files']
    if not plugins:
        raise ValueError('explicit system plugin files required')
    parents = {str(Path(item['path']).parent) for item in plugins}
    if len(parents) != 1:
        raise ValueError('fixed system plugin directory required')
    if verify_plugins:
        for item in plugins:
            if hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() != item['sha256']:
                raise ValueError('system plugin differs: ' + item['path'])
    env = {key: os.environ[key] for key in ('HOME', 'USER', 'LOGNAME', 'XDG_RUNTIME_DIR') if key in os.environ}
    env.update(PATH='/usr/bin:/bin', DISPLAY=spec['display'], XAUTHORITY=spec['xauthority'],
        GST_PLUGIN_PATH='', GST_PLUGIN_PATH_1_0='', GST_PLUGIN_SYSTEM_PATH=next(iter(parents)),
        GST_PLUGIN_SYSTEM_PATH_1_0=next(iter(parents)), LANG='C', LC_ALL='C',
        GST_DEBUG_NO_COLOR='1', GST_DEBUG='2')
    return env


class DirectPreview:
    """Complete peer jpeg_recorder interface, with one latest waiting product.

    There can be one active product and one waiting product (each <=4MiB JPEG
    plus its 2112-byte AJPG header). A failure never retries a partial pipe write.
    SourceKey and parse_record are supplied from the same imported peer runtime.
    """
    def __init__(self, output, observer, env, *, source_key, parse_record,
                 receiver_cohort, budget, process_factory=subprocess.Popen,
                 log_factory=ObserverLog, pipe_writer=write_bounded, performance=False):
        self.performance = None
        if performance:
            if __package__:
                from .preview_performance import Performance, PerformanceLog
            else:
                from preview_performance import Performance, PerformanceLog
            self.performance = Performance()
            log_factory = PerformanceLog
        self.output, self.observer, self.env = Path(output), Path(observer), dict(env)
        self.source_key, self.parse_record = source_key, parse_record
        self.cohort, self.budget = receiver_cohort, budget
        self.process_factory, self.log_factory, self.pipe_writer = process_factory, log_factory, pipe_writer
        self.output.mkdir(mode=0o700)
        (self.output/'samples').mkdir(mode=0o700)
        registry = str(self.output/'gst-registry.bin')
        self.env.update(GST_REGISTRY=registry, GST_REGISTRY_1_0=registry)
        self._cv = threading.Condition()
        self._pending = None
        self._closing = self._done = False
        self._ready = threading.Event()
        self.process = self.log = None
        self._samples = {}
        self._submission_bytes = 0
        self._last_publish = None
        self._state = dict(failure=None, complete=False, worker_done=False, frames_submitted=0,
            received=0, dropped=0, pending=0, queue_depth=1, saved_samples=0, sample_bytes=0,
            sample_max_bytes=MAX_SAMPLE_BYTES, samples_per_epoch=3,
            max_jpeg_bytes=MAX_JPEG_BYTES, max_resident_products=2,
            pipeline='PEER_OWNED_JPEG_LATEST_QUEUE_TO_EXISTING_GST_OBSERVER_MPP_X11',
            source_to_decoded_mapping='UNKNOWN', sink_is_physical_presentation=False,
            full_video_archive=False, resources_retained=False, observer_input_closed=False)
        if self.performance:
            self._state['pipeline'] = 'PEER_OWNED_JPEG_LATEST_TO_PINNED_PERFORMANCE_OBSERVER'
        self._thread = threading.Thread(target=self._run, name='calfix-owned-jpeg-mpp', daemon=True)

    def start(self):
        self._thread.start()
        if not self._ready.wait(5.5):
            self._fail(TimeoutError('observer startup deadline'))
            raise TimeoutError('observer startup deadline')
        self.check()
        return self

    def _fail(self, error):
        with self._cv:
            self._state['failure'] = self._state['failure'] or type(error).__name__ + ': ' + str(error)[:512]
            self._closing = True
            self._cv.notify_all()

    def check(self):
        with self._cv:
            failure = self._state['failure']
        if failure:
            raise RuntimeError(failure)

    def submit(self, product):
        # The peer already owns these immutable bytes and validates complete
        # products before this callback. No parse/hash/disk/pipe calls here.
        wire, body = product.wire, product.record.jpeg
        if (type(wire) is not bytes or type(body) is not bytes or
                not 4 <= len(body) <= MAX_JPEG_BYTES or len(wire) != 2112 + len(body)):
            raise ValueError('bounded complete AJPG v4 owned bytes required')
        with self._cv:
            if self._state['failure']:
                raise RuntimeError(self._state['failure'])
            if self._closing or (self.budget.started is not None and self.budget.remaining() <= 0):
                self._state['dropped'] += 1
                return False
            self._state['received'] += 1
            if self._pending is not None:
                self._state['dropped'] += 1
            self._pending = product, time.monotonic_ns()
            self._state['pending'] = 1
            self._cv.notify()
        return True

    def request_stop(self):
        with self._cv:
            self._closing = True
            self._cv.notify_all()

    def close(self, timeout_s=3):
        self.request_stop()
        self._thread.join(timeout_s)
        return self.snapshot()

    def snapshot(self):
        with self._cv:
            return dict(self._state, worker_done=self._done and not self._thread.is_alive(),
                worker_alive=self._thread.is_alive(), closing=self._closing)

    def _observer_state(self):
        if self.log:
            if self.log.failure:
                raise RuntimeError(self.log.failure)
            if self.process.poll() is not None:
                raise RuntimeError('observer exited ' + str(self.process.returncode))
            return dict(mpp_src_count=self.log.counts[0], sink_input_count=self.log.counts[1],
                mpp_last_ns=self.log.last_ns[0], sink_last_ns=self.log.last_ns[1],
                heartbeat_received_ns=self.log.last_heartbeat, log_bytes=self.log.log_bytes,
                **(dict(performance_stage_counts=list(getattr(self.log,'stage_counts',[])))
                   if self.performance else {}))
        return {}

    def _publish(self, final=False):
        now = time.monotonic()
        if not final and self._last_publish is not None and now-self._last_publish < .5:
            return
        observation = self._observer_state()
        if self.performance and self.process:
            observation['performance'] = self.performance.snapshot(self.process.pid)
        with self._cv:
            self._state.update(observation, monotonic_ns=time.monotonic_ns())
            state = dict(self._state, worker_done=self._done)
        atomic_json(self.output/'preview-state.json', state)
        self._last_publish = now
        if final:
            atomic_json(self.output/'preview-final.json', state)

    def _sample(self, product, row, now):
        key = (row['source']['session'], row['source']['epoch'])
        prior = self._samples.get(key)
        if prior is None and len(self._samples) >= 16:
            return
        needed = prior is None or (len(prior) < 3 and now-prior[0] >= (1 if len(prior) == 1 else 10)*10**9)
        if not needed:
            return
        data = (json.dumps(row, sort_keys=True, allow_nan=False) + '\n').encode()
        size = len(product.wire) + len(data)
        if len(data) > 8192 or self._state['sample_bytes'] + size > MAX_SAMPLE_BYTES:
            return
        # Reserve before writes. Failed partial writes cannot recycle quota.
        with self._cv:
            self._state['sample_bytes'] += size
        count = len(prior or []) + 1
        name = f'session-{key[0]}-epoch-{key[1]}-{count}'
        with (self.output/'samples'/(name+'.ajpg')).open('xb') as stream:
            stream.write(product.wire)
        with (self.output/'samples'/(name+'.json')).open('xb') as stream:
            stream.write(data)
        self._samples.setdefault(key, []).append(now)
        with self._cv:
            self._state['saved_samples'] += 1

    def _send(self, item, submitted):
        product, received = item
        picked = time.monotonic_ns() if self.performance else None
        record = self.parse_record(product.wire, expected_version=4)
        if record != product.record or (record.width, record.height) != (1920, 1080):
            raise ValueError('owned JPEG differs from its wire or expected geometry')
        key = asdict(self.source_key.from_record(self.cohort, record))
        if type(key['session']) is not int or type(key['epoch']) is not int:
            raise ValueError('actual SOURCE session/epoch required')
        before = time.monotonic_ns()
        # START deadline gates new whole submissions. A write that already
        # owns this JPEG keeps the original two-second bounded drain budget.
        if self.performance:
            self.performance.write(self.process.stdin.fileno(), record.jpeg)
        else:
            self.pipe_writer(self.process.stdin.fileno(), record.jpeg, timeout=2)
        after = time.monotonic_ns()
        row = dict(source=key, jpeg_sha256=hashlib.sha256(record.jpeg).hexdigest(),
            wire_sha256=hashlib.sha256(product.wire).hexdigest(),
            wire_header_hex=product.wire[:2112].hex(), width=record.width, height=record.height,
            length=len(record.jpeg), received_monotonic_ns=received,
            write_start_ns=before, complete_ns=after)
        hashed = time.monotonic_ns() if self.performance else None
        submission = {key: value for key, value in row.items() if key != 'wire_header_hex'}
        line = (json.dumps(submission, sort_keys=True, allow_nan=False)+'\n').encode()
        if self._submission_bytes + len(line) > MAX_SUBMISSION_BYTES:
            raise ValueError('submission log exceeds 32MiB budget')
        self._submission_bytes += len(line)
        submitted.write(line)
        with self._cv:
            self._state['frames_submitted'] += 1
            self._state.update(latest_source=key, last_submission_ns=after,
                submission_log_bytes=self._submission_bytes)
        logged = time.monotonic_ns() if self.performance else None
        self._sample(product, row, after)
        if self.performance:
            finished = time.monotonic_ns()
            self.performance.add(queue_age_ns=picked-received, validation_ns=before-picked,
                pipe_total_ns=after-before, hashing_row_ns=hashed-after,
                log_state_ns=logged-hashed, sample_ns=finished-logged)
            if self.performance.last_complete is not None:
                self.performance.add(submission_gap_ns=before-self.performance.last_complete)
            self.performance.last_complete = after

    def _run(self):
        try:
            self.process = self.process_factory([str(self.observer)], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=self.env, bufsize=0)
            os.set_blocking(self.process.stdin.fileno(), False)
            self.log = self.log_factory(self.process, self.output/'gstreamer.log')
            self.log.thread.start()
            with self._cv:
                self._state.update(observer_pid=self.process.pid, resources_retained=True)
            if not self.log.ready.wait(5) or self.log.failure:
                raise RuntimeError(self.log.failure or 'observer startup deadline')
            self._publish()
            self._ready.set()
            with (self.output/'jpeg-submissions.jsonl').open('xb', buffering=0) as submitted:
                while True:
                    with self._cv:
                        self._cv.wait_for(lambda: self._pending is not None or self._closing, .1)
                        if self._closing or (self.budget.started is not None and self.budget.remaining() <= 0):
                            if self._pending is not None:
                                self._state['dropped'] += 1
                                self._pending = None
                                self._state['pending'] = 0
                            break
                        item, self._pending = self._pending, None
                        self._state['pending'] = 0
                    if item:
                        self._send(item, submitted)
                    self._publish()
            with self._cv:
                self._state.update(complete=True, end_monotonic_ns=time.monotonic_ns())
        except BaseException as error:
            self._fail(error)
        finally:
            self._ready.set()
            if self.log:
                # Bounded observation only: preserve the final callbacks without
                # submitting further business frames or closing observer input.
                time.sleep(1)
                self.log.stop_reading.set()
                self.log.thread.join(1)
                if self.log.thread.is_alive():
                    self._fail(RuntimeError('observer log worker remains active'))
                if self.log.failure:
                    self._fail(RuntimeError(self.log.failure))
            with self._cv:
                self._pending = None
                self._state['pending'] = 0
                self._state['observer_log_sealed'] = self.log is None or not self.log.thread.is_alive()
                self._done = True
            try:
                self._publish(final=True)
            except BaseException as error:
                self._fail(error)
                # Publish the failure even when the observer check itself failed.
                atomic_json(self.output/'preview-state.json', self.snapshot())
                atomic_json(self.output/'preview-final.json', self.snapshot())
