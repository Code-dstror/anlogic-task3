"""Bounded offline LZC1 parsing/reassembly; no MMIO, DMA or lease release.

Call only with bytes already obtained safely by the transport owner. A successful
parse proves neither SAFE_RESULT nor a matching fence. The caller retains every
DMA lease while any asynchronous consumer still references its mapping.
"""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping

from . import pcie_protocol_v1 as p
from .cfs_codec import (BlockIndex, CfsError, CfsFrame, FrameIdentity, StoredBlock,
                        align64, decode_block)

_VALIDITY_MASK = (p.PCIE_LZ_VALIDITY_IDENTITY | p.PCIE_LZ_VALIDITY_TIME | p.PCIE_LZ_VALIDITY_BAYER
                  | p.PCIE_LZ_VALIDITY_QUALIFIED | p.PCIE_LZ_VALIDITY_DIAGNOSTICS)
_FAILURE_CODES = (p.PCIE_LZ_ERRORS_SOURCE, p.PCIE_LZ_ERRORS_DDR, p.PCIE_LZ_ERRORS_CODEC,
                  p.PCIE_LZ_ERRORS_OUTPUT, p.PCIE_LZ_ERRORS_CANCELLED, p.PCIE_LZ_ERRORS_MODE_SWITCH)


class LzStreamError(ValueError):
    """The application frame is unusable; says nothing about DMA ownership."""


@dataclass(frozen=True)
class Chunk:
    header: Mapping[str, int | bytes]
    raw: bytes

    @property
    def key(self) -> tuple[int, ...]:
        return tuple(self.header[n] for n in ('source_session', 'camera', 'capture_sequence',
                                              'mode_epoch', 'generation'))


def _unpack(wire, layout, names, expected):
    result = dict(zip(names, layout.unpack(wire), strict=True))
    for name, value in expected.items():
        if result[name] != value:
            raise LzStreamError('invalid ' + name)
    return result


def _parse_header(wire: bytes) -> dict[str, int | bytes]:
    """Validate the bounded header before any owner change or decompression."""
    if (type(wire) is not bytes
            or not p.PCIE_LZ_HEADER_LENGTH <= len(wire) <= p.PCIE_LZ_MAX_RECORD_BYTES):
        raise LzStreamError('record length/type')
    h = _unpack(wire[:p.PCIE_LZ_HEADER_LENGTH], p.LZ_HEADER_STRUCT,
                p.LZ_HEADER_FIELD_NAMES, p.LZ_HEADER_EXPECTED_VALUES)
    if (h['record_length'] != len(wire) or not h['source_session'] or h['camera'] != 0
            or not h['generation'] or h['flags'] & ~p.PCIE_LZ_FLAGS_LAST
            or h['validity'] & ~_VALIDITY_MASK or not h['validity'] & p.PCIE_LZ_VALIDITY_IDENTITY
            or h['capture_status'] not in (p.PCIE_LZ_CAPTURE_STATUSES_OK, p.PCIE_LZ_CAPTURE_STATUSES_SOURCE_FAILED)
            or h['source_kind'] not in (p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY,
                                         p.PCIE_RECORD_V2_SOURCE_PHYSICAL)):
        raise LzStreamError('identity/flags/source/length')
    known_time = bool(h['validity'] & p.PCIE_LZ_VALIDITY_TIME)
    if ((known_time and h['time_quality'] not in (p.PCIE_RECORD_V2_TIME_LOCAL_PIXEL_COUNTER_NS,
                                                  p.PCIE_RECORD_V2_TIME_COMMON_FPGA_COUNTER_NS))
            or (not known_time and (h['time_quality'] or h['capture_timestamp_ns']))):
        raise LzStreamError('unknown/invalid capture time')
    known_bayer = bool(h['validity'] & p.PCIE_LZ_VALIDITY_BAYER)
    if ((known_bayer and h['bayer_phase'] not in (p.PCIE_LZ_BAYER_PHASES_RGGB, p.PCIE_LZ_BAYER_PHASES_GRBG,
                                                 p.PCIE_LZ_BAYER_PHASES_GBRG, p.PCIE_LZ_BAYER_PHASES_BGGR))
            or (not known_bayer and h['bayer_phase'])):
        raise LzStreamError('unknown/invalid Bayer phase')
    if not h['validity'] & p.PCIE_LZ_VALIDITY_DIAGNOSTICS and any(
            h[n] for n in ('selection_ordinal', 'admitted_ordinal', 'failed_total')):
        raise LzStreamError('unknown diagnostics must be zero')
    if (h['chunk_index'] >= p.PCIE_LZ_FRAME_CHUNKS
            or h['first_block_id'] != h['chunk_index'] * p.PCIE_LZ_BLOCKS_PER_CHUNK):
        raise LzStreamError('chunk/first block range')
    if h['product_type'] == p.PCIE_LZ_PRODUCT_TYPES_FAILURE:
        if (h['flags'] != p.PCIE_LZ_FLAGS_LAST or h['error'] not in _FAILURE_CODES
                or any(h[n] for n in ('block_count', 'descriptors_bytes', 'data_bytes'))
                or len(wire) != p.PCIE_LZ_HEADER_LENGTH):
            raise LzStreamError('invalid failure terminal')
        return h
    count = min(p.PCIE_LZ_BLOCKS_PER_CHUNK, p.PCIE_LZ_FRAME_BLOCKS - h['first_block_id'])
    if (h['product_type'] != p.PCIE_LZ_PRODUCT_TYPES_DATA or h['error'] or h['capture_status']
            or h['block_count'] != count
            or h['flags'] != (p.PCIE_LZ_FLAGS_LAST if h['chunk_index'] == p.PCIE_LZ_FRAME_CHUNKS - 1 else 0)
            or h['descriptors_bytes'] != count * p.PCIE_LZ_DESCRIPTOR_LENGTH
            or not 1 <= h['data_bytes'] <= count * p.PCIE_LZ_BLOCK_RAW_BYTES
            or len(wire) != p.PCIE_LZ_HEADER_LENGTH + h['descriptors_bytes'] + h['data_bytes']):
        raise LzStreamError('data chunk geometry/count/terminal/length')
    return h


def parse_chunk(wire: bytes) -> Chunk:
    """Validate all declared extents before slicing or decompressing any block."""
    h = _parse_header(wire)
    if h['product_type'] == p.PCIE_LZ_PRODUCT_TYPES_FAILURE:
        return Chunk(MappingProxyType(h), b'')
    count = h['block_count']
    identity = FrameIdentity(h['source_session'], h['camera'], h['capture_sequence'], h['mode_epoch'])
    # These are logical offline offsets only; wire never supplies a DDR address.
    frame = CfsFrame(identity, h['width'], h['height'], h['generation'],
                     p.PCIE_LZ_FRAME_BLOCKS * p.PCIE_LZ_BLOCK_RAW_BYTES)
    data_begin = p.PCIE_LZ_HEADER_LENGTH + h['descriptors_bytes']
    descriptors = []
    consumed = 0
    for position in range(count):
        begin = p.PCIE_LZ_HEADER_LENGTH + position * p.PCIE_LZ_DESCRIPTOR_LENGTH
        d = _unpack(wire[begin:begin + p.PCIE_LZ_DESCRIPTOR_LENGTH], p.LZ_DESCRIPTOR_STRUCT,
                    p.LZ_DESCRIPTOR_FIELD_NAMES, p.LZ_DESCRIPTOR_EXPECTED_VALUES)
        if (d['block_id'] != h['first_block_id'] + position or d['data_offset'] != consumed
                or not 1 <= d['stored_len'] <= p.PCIE_LZ_BLOCK_RAW_BYTES
                or consumed + d['stored_len'] > h['data_bytes']):
            raise LzStreamError('block identity/offset/stored extent')
        index = BlockIndex(d['block_id'] * p.PCIE_LZ_BLOCK_RAW_BYTES,
                           d['raw_len'], d['stored_len'], align64(d['stored_len']), d['samples'],
                           d['raw_crc'], d['stored_crc'], h['generation'], d['mode'], d['predictor'],
                           h['format'], d['flags'], d['block_id'])
        try:
            index_bytes = index.pack(frame)
        except CfsError as exc:
            raise LzStreamError(str(exc)) from exc
        descriptors.append((index, index_bytes, consumed))
        consumed += d['stored_len']
    if consumed != h['data_bytes']:
        raise LzStreamError('unconsumed data bytes')
    output = bytearray()
    for index, index_bytes, offset in descriptors:
        payload = wire[data_begin + offset:data_begin + offset + index.stored_len]
        try:
            output.extend(decode_block(frame, StoredBlock(identity, index_bytes, payload),
                                       expected_block_id=index.block_id))
        except CfsError as exc:
            raise LzStreamError(str(exc)) from exc
    return Chunk(MappingProxyType(h), bytes(output))


_VARYING_FIELDS = frozenset(('record_length', 'product_type', 'flags', 'chunk_index', 'block_count',
                            'first_block_id', 'descriptors_bytes', 'data_bytes', 'error', 'capture_status'))


class Reassembler:
    """One active fixed-size frame; ordered chunks; explicit source/epoch binding.

    Sequence is strictly increasing within this owner. Recreate the owner only at
    a caller-confirmed new source session/epoch. fail_pending() handles a missing
    record or application deadline and never returns/releases a DMA buffer.
    """
    def __init__(self, *, source_session: int, mode_epoch: int):
        if (type(source_session) is not int or not 1 <= source_session <= 0xffffffff
                or type(mode_epoch) is not int or not 0 <= mode_epoch <= 0xffffffff):
            raise LzStreamError('invalid owner identity')
        self.source_session, self.mode_epoch = source_session, mode_epoch
        self._highest = -1
        self._signature = None
        self._next = 0
        self._raw = bytearray()

    @property
    def buffered_bytes(self) -> int:
        return len(self._raw)

    def fail_pending(self) -> None:
        self._signature = None
        self._next = 0
        self._raw.clear()

    def feed(self, wire: bytes) -> bytes | None:
        try:
            h = _parse_header(wire)
            if (h['source_session'], h['mode_epoch']) != (self.source_session, self.mode_epoch):
                raise LzStreamError('stale/wrong owner session or epoch')
            signature = tuple((name, value) for name, value in h.items() if name not in _VARYING_FIELDS)
            if self._signature is None:
                if h['capture_sequence'] <= self._highest or h['chunk_index'] != 0:
                    raise LzStreamError('late/repeated frame or missing first chunk')
                self._highest = h['capture_sequence']
                self._signature = signature
            if signature != self._signature or h['chunk_index'] != self._next:
                raise LzStreamError('changed frame metadata or missing/repeated chunk')
            if h['product_type'] == p.PCIE_LZ_PRODUCT_TYPES_FAILURE:
                raise LzStreamError('negative frame terminal: ' + str(h['error']))
            # The valid header has already consumed this frame sequence. A bad
            # first-block CRC must not permit a retry to resurrect that frame.
            c = parse_chunk(wire)
            if len(self._raw) + len(c.raw) > p.PCIE_LZ_FRAME_RAW_BYTES:
                raise LzStreamError('bounded frame overflow')
            self._raw.extend(c.raw)
            self._next += 1
            if h['flags'] & p.PCIE_LZ_FLAGS_LAST:
                if self._next != p.PCIE_LZ_FRAME_CHUNKS or len(self._raw) != p.PCIE_LZ_FRAME_RAW_BYTES:
                    raise LzStreamError('incomplete successful frame')
                result = bytes(self._raw)
                self.fail_pending()
                return result
            return None
        except LzStreamError:
            self.fail_pending()
            raise
