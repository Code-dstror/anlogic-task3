"""Private v2-to-VisionService association and qualified neutral-stat provider.

The public FrameRef is host-issued. Wire CFG session/epoch are a separate
namespace and are never read from today's MMIO to label yesterday's pixels.
The caller supplies policy scores and real Environment/resource qualification.
No profile scores, HDR/sync qualification, or hardware execution are invented.
"""
from __future__ import annotations

from dataclasses import dataclass

from . import pcie_protocol_v1 as p
from .adaptive_config_owner import Observation
from .record_v2 import RecordMetadata
from .vision_execution import HardwareFrameStamp


@dataclass(frozen=True)
class NeutralDecision:
    preferred_profile: str
    benefit: float
    risk: float


def hardware_frame_stamp(meta, identity, metadata: RecordMetadata | None):
    if metadata is None or metadata.source is None:
        return None
    source = metadata.source
    if (meta.ref.camera_id != identity.camera_id or source.camera != identity.camera_id
            or source.sequence != identity.sequence):
        raise ValueError("v2 metadata does not belong to this published RGB identity")
    return HardwareFrameStamp(source.session, source.epoch, source.camera, source.sequence)


def neutral_observation(meta, identity, metadata: RecordMetadata | None, *,
                        observed_ns: int, decision: NeutralDecision):
    stamp = hardware_frame_stamp(meta, identity, metadata)
    if (stamp is None or metadata.neutral_context is None
            or metadata.neutral_stats is None):
        return None
    if not isinstance(decision, NeutralDecision):
        raise TypeError("trusted neutral policy must return NeutralDecision")
    kind = ("DIGITAL_REPLAY" if metadata.source.kind == p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY
            else "PHYSICAL_CAMERA")
    exposure = metadata.actual_exposure
    return Observation(meta.ref, observed_ns, decision.preferred_profile, decision.benefit,
                       decision.risk, width=meta.width, height=meta.height, source_kind=kind,
                       actual_exposure=exposure if exposure else None, hdr_qualified=False)


class RecordV2Providers:
    """Providers for the existing frozen SemanticExecutionAdapter.

    One Linux owner calls VisionService.pump. backend.poll freezes one resident
    metadata+identity pair, untouched by receive/conversion threads. Providers
    run synchronously inside that same pump, before a subsequent poll. Policy
    is explicit; no hook or CFG writes are enabled by the receiver CLI.
    """
    def __init__(self, backend, *, policy_provider, clock):
        if not callable(policy_provider) or not callable(clock):
            raise TypeError("explicit trusted policy and clock required")
        # Keep the established injection signature; observations use immutable
        # FrameMeta age rather than calling this compatibility clock again.
        self.backend, self.policy_provider, self.clock = backend, policy_provider, clock

    def frame_stamp(self, meta, identity):
        return hardware_frame_stamp(meta, identity, self.backend.metadata_for(identity))

    def observation(self, meta):
        resident = self.backend.resident_record()
        if resident is None:
            return None
        identity, metadata = resident
        if (metadata is None or metadata.neutral_stats is None
                or metadata.neutral_context is None):
            return None
        decision = self.policy_provider(meta, metadata.neutral_stats)
        # Conversion, publication and repeated policy evaluation cannot renew
        # the same source's age. This host time is not sensor capture time.
        return neutral_observation(meta, identity, metadata,
                                   observed_ns=meta.received_monotonic_ns, decision=decision)
