"""Linux-private optional bridge from validated VisionService requests to CFG1.

AI imports only linux.vision_api. Trusted observation/environment providers and
apply/cancel belong to the Linux owner, never the public client protocol.
"""
from __future__ import annotations

from dataclasses import dataclass
from threading import RLock

from .adaptive_config_owner import AdaptiveConfigOwner, Environment, Observation


@dataclass(frozen=True)
class HardwareFrameStamp:
    """Trusted complete source stamp; AJPG v1 cannot supply this tuple.

    The producer must obtain it from a qualified wire/control association for
    this exact frame, never a later GET_EPOCH or a host-copy cohort counter.
    """
    session: int
    mode_epoch: int
    camera: int
    sequence: int


class SemanticExecutionAdapter:
    def __init__(self, owner: AdaptiveConfigOwner, *, environment_provider,
                 observation_provider, frame_stamp_provider=None, read_only: bool = True,
                 require_source_stamp: bool = False):
        if not isinstance(owner, AdaptiveConfigOwner):
            raise TypeError("requires the unique AdaptiveConfigOwner")
        if not callable(environment_provider) or not callable(observation_provider):
            raise TypeError("trusted snapshot providers are required")
        if type(read_only) is not bool or type(require_source_stamp) is not bool:
            raise ValueError("execution boundary flags must be bool")
        if require_source_stamp and frame_stamp_provider is None:
            raise ValueError("required complete source stamp needs a provider")
        self._owner = owner
        self._environment_provider = environment_provider
        self._observation_provider = observation_provider
        if frame_stamp_provider is not None and not callable(frame_stamp_provider):
            raise TypeError("full stamp provider must be callable")
        self._frame_stamp_provider = frame_stamp_provider
        self._read_only = read_only
        self._require_source_stamp = require_source_stamp
        self._lock = RLock()
        self._environment = None
        self._latest = None
        self._stamp = None
        self._matched = None
        self._observation_errors = 0

    def frame_published(self, meta, identity):
        """Map public identity; do not derive neutral scores from enhanced RGB.

        Provider errors disable admission for this frame; they never disturb
        receive/display or silently retain an observation from another frame.
        """
        with self._lock:
            self._latest = meta, identity
            self._stamp = None
            self._environment = None
            try:
                env = self._environment_provider(meta)
                if not isinstance(env, Environment) or (env.public_session, env.public_epoch) != (
                        meta.ref.session_id, meta.ref.mode_epoch):
                    raise ValueError("trusted environment public cohort mismatch")
                self._owner.update_environment(env)
                obs = self._observation_provider(meta)
                if obs is not None:
                    if not isinstance(obs, Observation) or obs.frame_ref != meta.ref:
                        raise ValueError("neutral observation must name the published frame")
                    self._owner.observe(obs)
                self._environment = env
                if self._frame_stamp_provider is not None:
                    stamp = self._frame_stamp_provider(meta, identity)
                    if stamp is not None:
                        if (not isinstance(stamp, HardwareFrameStamp)
                                or any(type(v) is not int or not 0 <= v <= 0xFFFFFFFF for v in
                                       (stamp.session, stamp.mode_epoch, stamp.camera, stamp.sequence))
                                or not stamp.session or stamp.camera != identity.camera_id
                                or stamp.sequence != identity.sequence):
                            raise ValueError("invalid complete hardware frame stamp")
                        self._stamp = stamp
            except Exception:
                self._observation_errors += 1
                self._environment = None
                self._stamp = None
            self._match_applied()

    def _match_applied(self):
        applied = self._owner.last_applied()
        if applied is None or self._environment is None or self._latest is None or self._stamp is None:
            return
        meta, identity = self._latest
        if (applied.session == self._environment.cfg_session
                and (applied.session, applied.mode_epoch, applied.camera, applied.first_actual_frame_sequence)
                == (self._stamp.session, self._stamp.mode_epoch, self._stamp.camera, self._stamp.sequence)):
            self._matched = (meta.ref.session_id, meta.ref.mode_epoch, applied)

    def hardware_actions_applied(self, public_session, public_epoch):
        with self._lock:
            self._match_applied()
            applied = self._owner.last_applied()
            return (not self._owner.diagnostics()["quarantined"]
                    and self._environment is not None and self._matched is not None
                    and self._stamp is not None
                    and self._matched[:2] == (public_session, public_epoch)
                    and self._matched[2] == applied
                    and applied.session == self._environment.cfg_session
                    and (self._stamp.session, self._stamp.mode_epoch, self._stamp.camera)
                    == (applied.session, applied.mode_epoch, applied.camera))

    def request_action(self, client_id, request_id, frame_ref, kind, args, deadline_ns):
        from linux.vision_api import ActionStatus
        with self._lock:
            if self._read_only:
                return ActionStatus(request_id, "REJECTED", "READ_ONLY")
            if self._environment is None or self._latest is None or self._latest[0].ref != frame_ref:
                return ActionStatus(request_id, "REJECTED", "UNKNOWN_OBSERVATION")
            if self._require_source_stamp and self._stamp is None:
                return ActionStatus(request_id, "REJECTED", "UNSUPPORTED_SOURCE_STAMP")
            return self._owner.request_action(client_id, request_id, frame_ref, kind, args, deadline_ns)

    def supports_profile(self, name):
        return self._owner.supports_profile(name)

    def get_request_status(self, client_id, request_id):
        return self._owner.get_request_status(client_id, request_id)

    def apply_pending(self):
        """Explicit trusted owner operation; never run on the MPP callback."""
        with self._lock:
            if self._read_only:
                raise PermissionError("read-only semantic adapter")
        result = self._owner.apply_pending()
        with self._lock:
            self._match_applied()
        return result

    def cancel_pending(self):
        if self._read_only:
            raise PermissionError("read-only semantic adapter")
        return self._owner.cancel_pending()

    def diagnostics(self):
        with self._lock:
            matched = (False if self._latest is None else self.hardware_actions_applied(
                self._latest[0].ref.session_id, self._latest[0].ref.mode_epoch))
            return {"read_only": self._read_only, "observation_errors": self._observation_errors,
                    "source_stamp_required": self._require_source_stamp,
                    "complete_stamp_available": self._stamp is not None,
                    "actual_frame_matched": matched,
                    **self._owner.diagnostics()}
