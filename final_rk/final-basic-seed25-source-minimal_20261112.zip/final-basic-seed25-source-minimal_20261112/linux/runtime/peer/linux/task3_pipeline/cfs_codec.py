"""CFS layout2 offline RAW10 reference; no device access or AJPG CRC change."""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, fields
import struct
from typing import Callable, Iterable
import zlib

from .raw_frame_store import RawFrameError, pack_raw10, unpack_raw10

LAYOUT_ID = 2
FORMAT_RAW10_LE5 = 1
FLAG_COMMITTED = 1
BLOCK_SAMPLES = 2048
BLOCK_BYTES = 2560
INDEX = struct.Struct("<IHHHHIIIBBBBI")
MAX_TOKEN_BYTES = BLOCK_BYTES + (BLOCK_BYTES + 127) // 128


class CfsError(ValueError):
    """Invalid identity, metadata, token stream or CRC; output is not usable."""


def _uint(value: int, name: str, maximum: int = 0xffffffff) -> int:
    if type(value) is not int or not 0 <= value <= maximum:
        raise CfsError(f"invalid {name}")
    return value


def align64(length: int) -> int:
    return (_uint(length, "length") + 63) & ~63


def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xffffffff


def lz_encode(data: bytes) -> bytes:
    """Independent greedy three-byte dictionary encoder, one bounded candidate.

    Tokens need not byte-match another encoder. The decoder defines the wire
    contract. At most 4096 dictionary keys are retained in the block-local table.
    """
    if type(data) is not bytes or not 1 <= len(data) <= BLOCK_BYTES:
        raise CfsError("LZ input length/type")
    table = OrderedDict()
    output, literal = bytearray(), bytearray()

    def flush() -> None:
        if literal:
            output.append(len(literal) - 1)
            output.extend(literal)
            literal.clear()

    def remember(position: int) -> None:
        if position + 3 <= len(data):
            key = data[position:position + 3]
            table[key] = position
            table.move_to_end(key)
            if len(table) > 4096:
                table.popitem(last=False)

    cursor = 0
    while cursor < len(data):
        prior = table.get(data[cursor:cursor + 3]) if cursor + 3 <= len(data) else None
        length = 0
        if prior is not None and 1 <= cursor - prior <= 4096:
            while length < min(130, len(data) - cursor) and data[prior + length] == data[cursor + length]:
                length += 1
        if length >= 3:
            flush()
            output.append(0x80 | (length - 3))
            output.extend(struct.pack("<H", cursor - prior))
            for position in range(cursor, cursor + length):
                remember(position)
            cursor += length
        else:
            literal.append(data[cursor])
            remember(cursor)
            cursor += 1
            if len(literal) == 128:
                flush()
    flush()
    return bytes(output)


def lz_decode(stored: bytes, expected_length: int) -> bytes:
    """Strict forward-overlap decoder; no reference encoder/predictor calls."""
    if (type(stored) is not bytes or not 1 <= len(stored) <= MAX_TOKEN_BYTES
            or not 1 <= _uint(expected_length, "expected_length") <= BLOCK_BYTES):
        raise CfsError("LZ stream length/type")
    output = bytearray()
    cursor = 0
    while cursor < len(stored):
        if len(output) == expected_length:
            raise CfsError("unconsumed token bytes")
        token = stored[cursor]
        cursor += 1
        if token < 128:
            length = token + 1
            if cursor + length > len(stored):
                raise CfsError("truncated literal")
            if len(output) + length > expected_length:
                raise CfsError("literal output overflow")
            output.extend(stored[cursor:cursor + length])
            cursor += length
        else:
            length = (token & 127) + 3
            if cursor + 2 > len(stored):
                raise CfsError("truncated match")
            distance = stored[cursor] | stored[cursor + 1] << 8
            cursor += 2
            if not 1 <= distance <= 4096 or distance > len(output):
                raise CfsError("illegal match distance")
            if len(output) + length > expected_length:
                raise CfsError("match output overflow")
            for _ in range(length):
                output.append(output[-distance])
    if len(output) != expected_length:
        raise CfsError("LZ output underflow")
    return bytes(output)


@dataclass(frozen=True)
class FrameIdentity:
    session: int
    camera: int
    sequence: int
    mode_epoch: int

    def validate(self) -> None:
        for field in fields(self):
            _uint(getattr(self, field.name), field.name)
        if self.session == 0 or self.camera > 1:
            raise CfsError("invalid frame identity")


@dataclass(frozen=True)
class CfsFrame:
    identity: FrameIdentity
    width: int
    height: int
    generation: int
    pool_size: int
    data_offset: int = 0
    slot_stride: int = BLOCK_BYTES
    layout_id: int = LAYOUT_ID
    format: int = FORMAT_RAW10_LE5

    def validate(self) -> None:
        if not isinstance(self.identity, FrameIdentity):
            raise CfsError("missing outer frame identity")
        self.identity.validate()
        _uint(self.layout_id, "layout_id")
        _uint(self.format, "format")
        if (not 1 <= _uint(self.width, "width", 65535)
                or not 1 <= _uint(self.height, "height", 65535)
                or not _uint(self.generation, "generation")
                or not _uint(self.pool_size, "pool_size")
                or self.layout_id != LAYOUT_ID or self.format != FORMAT_RAW10_LE5):
            raise CfsError("unsupported CFS frame geometry/generation/layout/format")
        _uint(self.data_offset, "data_offset")
        _uint(self.slot_stride, "slot_stride")
        slots = (self.width * self.height + BLOCK_SAMPLES - 1) // BLOCK_SAMPLES
        if (self.slot_stride != BLOCK_BYTES or self.data_offset % 64
                or self.data_offset + slots * self.slot_stride > self.pool_size):
            raise CfsError("fixed slot data allocation/pool range invalid")
        if self.raw_bytes > 0xffffffff:
            raise CfsError("frame byte range overflow")

    @property
    def raw_bytes(self) -> int:
        return (self.width * self.height * 10 + 7) // 8

    def block_count(self, block_id: int) -> int:
        self.validate()
        remaining = self.width * self.height - _uint(block_id, "block_id") * BLOCK_SAMPLES
        if remaining <= 0:
            raise CfsError("block outside frame")
        return min(BLOCK_SAMPLES, remaining)


@dataclass(frozen=True)
class BlockIndex:
    pool_offset: int
    raw_len: int
    stored_len: int
    aligned_len: int
    samples: int
    raw_crc: int
    stored_crc: int
    generation: int
    mode: int
    predictor: int
    format: int
    flags: int
    block_id: int

    def validate(self, frame: CfsFrame) -> None:
        frame.validate()
        for field in fields(self):
            maximum = (0xffff if field.name in {"raw_len", "stored_len", "aligned_len", "samples"}
                       else 0xff if field.name in {"mode", "predictor", "format", "flags"} else 0xffffffff)
            _uint(getattr(self, field.name), field.name, maximum)
        if self.samples != frame.block_count(self.block_id) or self.raw_len != (self.samples * 10 + 7) // 8:
            raise CfsError("block sample/raw length mismatch")
        if self.generation != frame.generation or self.format != FORMAT_RAW10_LE5 or self.flags != FLAG_COMMITTED:
            raise CfsError("block generation/format/reserved flags mismatch")
        if (self.mode, self.predictor) not in {(0, 0), (1, 1)}:
            raise CfsError("unsupported mode/predictor")
        if (not 1 <= self.stored_len <= MAX_TOKEN_BYTES or self.aligned_len != align64(self.stored_len)
                or self.aligned_len > frame.slot_stride
                or self.pool_offset != frame.data_offset + self.block_id * frame.slot_stride
                or self.pool_offset % 64 or self.pool_offset + self.aligned_len > frame.pool_size
                or self.pool_offset + self.aligned_len > 0xffffffff):
            raise CfsError("stored/pool length/alignment/range invalid")
        if self.mode == 0 and self.stored_len != self.raw_len:
            raise CfsError("RAW stored length mismatch")

    def pack(self, frame: CfsFrame) -> bytes:
        self.validate(frame)
        return INDEX.pack(*(getattr(self, field.name) for field in fields(self)))

    @classmethod
    def unpack(cls, data: bytes, frame: CfsFrame) -> BlockIndex:
        if type(data) is not bytes or len(data) != INDEX.size:
            raise CfsError("index must be exactly 32 bytes")
        result = cls(*INDEX.unpack(data))
        result.validate(frame)
        return result


@dataclass(frozen=True)
class StoredBlock:
    identity: FrameIdentity
    index: bytes
    storage: bytes


@dataclass(frozen=True)
class EncodedBlock:
    block: StoredBlock
    decision: str  # COMPRESSED / NO_BENEFIT / ENC_BUSY


def _unpack(data: bytes, count: int) -> list[int]:
    try:
        return unpack_raw10(data, count)
    except (RawFrameError, TypeError, IndexError) as exc:
        raise CfsError("invalid canonical RAW10 packed bytes/tail") from exc


def encode_block(frame: CfsFrame, block_id: int, samples: Iterable[int], *,
                 pool_offset: int, encoder_busy: bool = False) -> EncodedBlock:
    """Save original RAW on busy/no benefit; never save residuals as RAW."""
    count = frame.block_count(block_id)
    values = []
    for sample in samples:
        if len(values) == count:
            raise CfsError("excess samples")
        values.append(_uint(sample, "sample", 1023))
    if len(values) != count or type(encoder_busy) is not bool:
        raise CfsError("missing samples/invalid busy flag")
    raw = pack_raw10(values)
    start = block_id * BLOCK_SAMPLES
    residuals = [value if i < 2 or (start + i) % frame.width < 2
                 else (value - values[i - 2]) & 1023 for i, value in enumerate(values)]
    candidate = None if encoder_busy else lz_encode(pack_raw10(residuals))
    compressed = candidate is not None and align64(len(candidate)) + 64 <= align64(len(raw))
    stored = candidate if compressed else raw
    index = BlockIndex(pool_offset, len(raw), len(stored), align64(len(stored)), count,
                       crc32(raw), crc32(stored), frame.generation,
                       1 if compressed else 0, 1 if compressed else 0,
                       FORMAT_RAW10_LE5, FLAG_COMMITTED, block_id)
    encoded = StoredBlock(frame.identity, index.pack(frame), stored)
    return EncodedBlock(encoded, "ENC_BUSY" if encoder_busy else "COMPRESSED" if compressed else "NO_BENEFIT")


def decode_block(frame: CfsFrame, block: StoredBlock, *, expected_block_id: int | None = None,
                 canonical_padding: bool = False) -> bytes:
    """Validate before decode/copy; independently invert modulo prediction."""
    frame.validate()
    if not isinstance(block, StoredBlock) or not isinstance(block.identity, FrameIdentity):
        raise CfsError("missing outer block identity")
    block.identity.validate()
    if block.identity != frame.identity:
        raise CfsError("outer session/camera/sequence/epoch mismatch")
    index = BlockIndex.unpack(block.index, frame)
    if expected_block_id is not None and index.block_id != _uint(expected_block_id, "expected_block_id"):
        raise CfsError("unexpected block ID")
    expected_storage = index.aligned_len if canonical_padding else index.stored_len
    if type(block.storage) is not bytes or len(block.storage) != expected_storage:
        raise CfsError("storage length mismatch")
    if canonical_padding and any(block.storage[index.stored_len:]):
        raise CfsError("nonzero storage padding")
    payload = block.storage[:index.stored_len]
    if crc32(payload) != index.stored_crc:
        raise CfsError("stored CRC mismatch")
    if index.mode == 0:
        raw = payload
        _unpack(raw, index.samples)
    else:
        residuals = _unpack(lz_decode(payload, index.raw_len), index.samples)
        recovered = []
        start = index.block_id * BLOCK_SAMPLES
        for i, residual in enumerate(residuals):
            recovered.append(residual if i < 2 or (start + i) % frame.width < 2
                             else (residual + recovered[i - 2]) & 1023)
        raw = pack_raw10(recovered)
    if len(raw) != index.raw_len or crc32(raw) != index.raw_crc:
        raise CfsError("raw CRC/length mismatch")
    return raw


def export_padded(frame: CfsFrame, block: StoredBlock) -> StoredBlock:
    """Offline canonical export only; never request unwritten DDR tail bytes."""
    decode_block(frame, block)
    index = BlockIndex.unpack(block.index, frame)
    return StoredBlock(block.identity, block.index,
                       block.storage + bytes(index.aligned_len - index.stored_len))


class RangeDecoder:
    """Two-block cache, keyed by complete immutable frame identity+generation.

    Provider obtains exact stored blocks; it cannot return just a block ID from
    another camera/session. No DMA, pin/release or hardware retry is performed.
    """
    def __init__(self, provider: Callable[[FrameIdentity, int], StoredBlock]):
        self.provider = provider
        self._cache = OrderedDict()

    def fetch(self, frame: CfsFrame, offset: int, length: int) -> bytes:
        frame.validate()
        _uint(offset, "offset")
        _uint(length, "length", BLOCK_BYTES)
        if offset % 16 or length == 0 or offset + length > frame.raw_bytes:
            raise CfsError("RAW FETCH offset/length/range invalid")
        first, last = offset // BLOCK_BYTES, (offset + length - 1) // BLOCK_BYTES
        output = bytearray()
        for block_id in range(first, last + 1):
            key = frame, block_id
            if key not in self._cache:
                block = self.provider(frame.identity, block_id)
                raw = decode_block(frame, block, expected_block_id=block_id)
                self._cache[key] = raw
                while len(self._cache) > 2:
                    self._cache.popitem(last=False)
            self._cache.move_to_end(key)
            raw = self._cache[key]
            begin = max(0, offset - block_id * BLOCK_BYTES)
            end = min(len(raw), offset + length - block_id * BLOCK_BYTES)
            output.extend(raw[begin:end])
        if len(output) != length:
            raise CfsError("incomplete decoded range")
        return bytes(output)
