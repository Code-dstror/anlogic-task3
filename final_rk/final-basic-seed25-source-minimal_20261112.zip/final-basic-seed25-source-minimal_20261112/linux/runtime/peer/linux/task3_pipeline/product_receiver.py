"""Synchronous product dispatch over an already configured C2H Receiver.

The caller owns the sole Receiver, capability/record selection, START/STOP and
all downstream consumption. No device is opened here. The driver must have
validated SAFE_RESULT, full DMA identity and fence before publishing a lease;
this adapter cannot establish those properties from record bytes.

Each record makes one explicit bounded mmap-to-bytes copy before RELEASE.
The existing JPEG parser also slices its payload; native LZ recovery allocates
its bounded RAW output. This is neither DMA-BUF import nor a zero-copy path.
There is no queue or background worker: consume each returned batch before
calling receive again to exert backpressure. Retaining batches is the caller's
memory responsibility. Calls must be serialized by the same owner.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from linux.dma_c2h_candidate.c2h_abi import RESULT_COMPLETE
from linux.dma_c2h_candidate.receiver import BATCH_MAX, Receiver, TransportStopped
from linux.stream_diag.records import Record, parse_record

from . import pcie_protocol_v1 as p
from .record_selection import header_length

if TYPE_CHECKING:
    from linux.lz_native import NativeFrame


class ReassemblyOwner(Protocol):
    """NativeReassembler's synchronous API; push must not retain its input."""

    def push(self, record: bytes) -> NativeFrame | None: ...
    def fail_pending(self) -> None: ...


@dataclass(frozen=True)
class JpegProduct:
    record: Record
    # Full owned AJPG record for the existing MPP decode_record(bytes) entry.
    wire: bytes
    transport_identity: tuple[int, ...]


@dataclass(frozen=True)
class RawProduct:
    frame: NativeFrame
    # This is the terminal segment's transport identity, never the source key.
    transport_identity: tuple[int, ...]


@dataclass(frozen=True)
class SafeTransportFailure:
    result: int
    transport_identity: tuple[int, ...]


@dataclass(frozen=True)
class RejectedProduct:
    reason: str
    transport_identity: tuple[int, ...]


Product = JpegProduct | RawProduct | SafeTransportFailure | RejectedProduct


class ProductReceiver:
    """Reuse one Receiver and an explicitly source-bound NativeReassembler.

    expected_jpeg_version must match the caller's pre-DMA record selection;
    this argument does not negotiate or prove device support. No implicit
    version detection/fallback is performed. Passing no reassembler rejects LZ.

    At most max_batch records are consumed per call and only one copied input
    is processed at a time. Returned storage is bounded by max_batch times the
    larger of twice max_record_bytes (wire plus JPEG payload) and one RAW frame,
    plus parser/recovery scratch. JPEG wire can be passed to the existing MPP
    decode_record entry with the same explicitly selected record version.
    The backend may additionally hold its fixed pool of mapped DMA buffers.
    A slow synchronous consumer backpressures both JPEG and LZ; this baseline
    does not provide product fairness or establish a sustained frame rate.

    Malformed products and SAFE error completions return explicit events and
    invalidate the unfinished LZ frame. Transport/read/release exceptions are
    fatal for this adapter: they propagate, invalidate only software assembly,
    and never automatically release remaining leases. The owner must finish
    consumers and use Receiver's explicit fault/abandon procedure as needed.
    """

    def __init__(self, receiver: Receiver, *, reassembler: ReassemblyOwner | None = None,
                 expected_jpeg_version: int = p.PROTOCOL_VERSION,
                 max_batch: int = 1, max_record_bytes: int | None = None):
        header_length(expected_jpeg_version)
        if type(max_batch) is not int or not 1 <= max_batch <= BATCH_MAX:
            raise ValueError('max_batch must be within the C2H batch limit')
        limit = receiver.capacity if max_record_bytes is None else max_record_bytes
        if type(limit) is not int or not 4 <= limit <= receiver.capacity:
            raise ValueError('record bound must fit the runtime DMA capacity')
        self.receiver = receiver
        self.reassembler = reassembler
        self.expected_jpeg_version = expected_jpeg_version
        self.max_batch = max_batch
        self.max_record_bytes = limit
        self.copied_bytes = 0
        self.records_received = 0
        self._faulted = False
        self._busy = False

    def fail_pending(self) -> None:
        """Application deadline/loss: discard LZ state, never release DMA."""
        if self.reassembler is not None:
            self.reassembler.fail_pending()

    def receive(self, maximum: int = 1) -> tuple[Product, ...]:
        """Block once for a record batch; incomplete LZ chunks yield no product.

        Batch order is preserved. Reject events do not suppress other safe
        products in that batch. Safe errors have no payload and are released;
        quarantine/unknown transport results are rejected by Receiver itself.
        """
        if self._faulted or self._busy:
            raise RuntimeError('product receiver is faulted or already receiving')
        if type(maximum) is not int or not 1 <= maximum <= self.max_batch:
            raise ValueError('requested batch exceeds configured bound')
        self._busy = True
        try:
            products = []
            leases = self.receiver.receive(maximum)
            for lease in leases:
                identity = lease.record_identity
                self.records_received += 1
                if lease.result != RESULT_COMPLETE:
                    lease.release()
                    self.fail_pending()
                    products.append(SafeTransportFailure(lease.result, identity))
                    continue
                if lease.length > self.max_record_bytes:
                    lease.release()
                    self.fail_pending()
                    products.append(RejectedProduct('record exceeds configured copy bound', identity))
                    continue
                # No view survives RELEASE, including when bytes() fails.
                with lease.view() as view:
                    wire = bytes(view)
                self.copied_bytes += len(wire)
                lease.release()
                try:
                    magic = int.from_bytes(wire[:4], 'little')
                    if magic == p.FRAME_MAGIC:
                        product = JpegProduct(parse_record(
                            wire, expected_version=self.expected_jpeg_version), wire, identity)
                        products.append(product)
                    elif magic == p.PCIE_LZ_MAGIC:
                        if self.reassembler is None:
                            raise ValueError('LZ product has no configured reassembly owner')
                        frame = self.reassembler.push(wire)
                        if frame is not None:
                            products.append(RawProduct(frame, identity))
                    else:
                        raise ValueError('unknown product magic')
                except ValueError as exc:
                    self.fail_pending()
                    products.append(RejectedProduct(str(exc), identity))
            return tuple(products)
        except TransportStopped:
            # Normal transport EOF follows verified host drain. This is an
            # application-frame stop, not a fault or proof of FPGA-wide quiet.
            self.fail_pending()
            return ()
        except BaseException:
            self._faulted = True
            self.fail_pending()
            raise
        finally:
            self._busy = False
