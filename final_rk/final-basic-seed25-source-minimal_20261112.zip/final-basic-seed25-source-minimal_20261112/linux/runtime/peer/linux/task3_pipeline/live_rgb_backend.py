"""Optional single-camera selected AJPG/MPP copied-NV12 producer for VisionService.

No device opens, DMA reads, decoder, RGA, CFG writes or CPU JPEG fallback here.
The receiver submits only successful MPP completions with already-owned bytes.
Conversion and waiting AI work are bounded independently of receive/display.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from threading import Condition, Thread
import time

from linux.vision_api.backend import FrameIdentity, RGBFrame
from linux.vision_api import NeutralFrameStats, SourceFrameMetadata, SourceFrameStamp
from . import pcie_protocol_v1 as p
from .record_v2 import RecordMetadata


def nv12_to_rgb888(pixels: bytes, width: int, height: int,
                  hor_stride: int, ver_stride: int) -> bytes:
    """BT.601 limited-range integer conversion, tightly packed RGB888.

    UV is interleaved, sampled at floor(x/2),floor(y/2). Padding is ignored.
    Coefficients use 8 fractional bits; round +128 then >>8 and clamp0..255.
    This is Linux CPU conversion of NV12, never CPU JPEG decoding or RGA.
    """
    if (any(type(v) is not int or v <= 0 for v in (width, height, hor_stride, ver_stride))
            or hor_stride % 2 or ver_stride % 2
            or hor_stride < width + width % 2 or ver_stride < height + height % 2
            or type(pixels) is not bytes or len(pixels) != hor_stride * ver_stride * 3 // 2):
        raise ValueError("invalid NV12 dimensions/stride/owned byte count")
    rgb = bytearray(width * height * 3)
    uv_base = hor_stride * ver_stride
    for y in range(height):
        row, uv_row = y * hor_stride, uv_base + (y // 2) * hor_stride
        for x in range(width):
            c = max(0, pixels[row + x] - 16)
            uv = uv_row + (x // 2) * 2
            d, e = pixels[uv] - 128, pixels[uv + 1] - 128
            out = (y * width + x) * 3
            rgb[out] = min(255, max(0, (298*c + 409*e + 128) >> 8))
            rgb[out+1] = min(255, max(0, (298*c - 100*d - 208*e + 128) >> 8))
            rgb[out+2] = min(255, max(0, (298*c + 516*d + 128) >> 8))
    return bytes(rgb)


@dataclass(frozen=True)
class _Copy:
    identity: FrameIdentity
    width: int
    height: int
    hor_stride: int
    ver_stride: int
    timestamp_ns: int
    nv12: bytes
    received_monotonic_ns: int
    metadata: RecordMetadata | None = None


def _public_source_metadata(copied: _Copy) -> SourceFrameMetadata | None:
    """Translate the same immutable parsed record; never read today's MMIO.

    This is descriptive source data, not a sensor-sync or board qualification.
    The sampled grid is transported independently of enhanced decoded pixels.
    """
    metadata = copied.metadata
    if metadata is None:
        return None
    source = metadata.source
    kind = ("DIGITAL_REPLAY" if source.kind == p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY
            else "PHYSICAL_CAMERA")
    stamp = SourceFrameStamp(source.session, source.epoch, source.camera, source.sequence,
                             kind, {p.PCIE_RECORD_V2_FORMAT_RAW10:"RAW10",
                                    p.PCIE_RECORD_V2_FORMAT_RAW14:"RAW14"}[source.format],
                             {p.PCIE_RECORD_V2_ROLE_SINGLE:"SINGLE",
                              p.PCIE_RECORD_V2_ROLE_LONG:"LONG",
                              p.PCIE_RECORD_V2_ROLE_SHORT:"SHORT"}[source.role])
    context = metadata.neutral_context
    if context is not None and (
            context.session, context.epoch, context.sequence, context.camera,
            context.source_kind, context.source_format) != (
                source.session, source.epoch, source.sequence, source.camera, source.kind, source.format):
        raise ValueError("neutral context does not belong to this source record")
    stats = metadata.neutral_stats
    public_stats = None if stats is None else NeutralFrameStats(
        *(getattr(stats, name) for name in NeutralFrameStats.__dataclass_fields__))
    quality = {p.PCIE_RECORD_V2_TIME_UNKNOWN:"UNKNOWN",
               p.PCIE_RECORD_V2_TIME_LOCAL_PIXEL_COUNTER_NS:"LOCAL_PIXEL_COUNTER_NS",
               p.PCIE_RECORD_V2_TIME_COMMON_FPGA_COUNTER_NS:"COMMON_FPGA_COUNTER_NS"}[metadata.time_quality]
    return SourceFrameMetadata(stamp, metadata.jpeg_session, metadata.jpeg_generation, metadata.jpeg_slot,
        timestamp_ns=copied.timestamp_ns if metadata.validity_flags & p.PCIE_RECORD_V2_FLAG_TIME else None,
        time_quality=quality, actual_exposure=metadata.actual_exposure, actual_gain=metadata.actual_gain,
        calibration_id=metadata.calibration_id,
        exposure_group=metadata.exposure_group if metadata.actual_exposure is not None else None,
        pair_id=metadata.pair_id, job_id=metadata.job_id, write_tag=metadata.write_tag,
        neutral_stats=public_stats, neutral_view_id=context.view_id if context else None,
        neutral_schema=context.schema if context else None, source_qualified=metadata.qualified)


class LiveRGBBackend:
    """One host-owned producer, latest bounded queues, independent AI leases.

    source_epoch is a host receiver cohort and generation a copied-frame number,
    neither a RAW slot generation nor a hardware CFG epoch. AJPG v1 has no
    camera/session/epoch/pair/exposure/calibration association. This class never
    associates v1 with a HardwareFrameStamp, even when sequence equals a CFG ACK.
    Validated v2 metadata follows the owned pixels through both bounded queues.
    """
    camera_ids = (0,)

    def __init__(self, *, camera_ids=(0,), source_kind="PHYSICAL_CAMERA", queue_depth=2,
                 max_frame_bytes=32*1024*1024, max_fps=1.0, clock=time.monotonic_ns,
                 converter=nv12_to_rgb888):
        if tuple(camera_ids) != (0,):
            raise ValueError("AJPG v1 dual production backend is UNSUPPORTED")
        if source_kind not in {"PHYSICAL_CAMERA", "TABLET_RECAPTURE", "DIGITAL_REPLAY", "SYNTHETIC_REPLAY"}:
            raise ValueError("explicit source kind required")
        if type(queue_depth) is not int or not 1 <= queue_depth <= 8:
            raise ValueError("queue_depth must be1..8")
        if type(max_frame_bytes) is not int or max_frame_bytes <= 0:
            raise ValueError("invalid frame bound")
        if type(max_fps) not in (float, int) or not 0 < max_fps <= 60:
            raise ValueError("max_fps must be finite and0..60")
        self._clock, self._interval = clock, max(1, round(1e9/max_fps))
        self._converter = converter
        self._source_kind = source_kind
        self._depth, self._max_bytes = queue_depth, max_frame_bytes
        self._cv = Condition()
        self._input, self._output = deque(), deque()
        self._closed, self._next_copy = False, 0
        self._source_epoch, self._generation, self._last_sequence = 0, 0, None
        self._wire_cohort, self._resident = None, None
        self._submitted = self._converted = self._dropped = self._errors = 0
        self._error = None
        self._thread = Thread(target=self._run, name="vision-rgb-copy", daemon=True)
        self._thread.start()

    def want_frame(self):
        """Receiver calls before MPP; skipped frames cause no extra NV12 copy."""
        with self._cv:
            now = self._clock()
            if self._closed or now < self._next_copy:
                return False
            self._next_copy = now + self._interval
            return True

    def submit(self, frame, record):
        """After successful MPP return; frame.nv12 was copied while borrowed.

        This method never waits for conversion, AI, queue space or display.
        Decoder/record failures are not submitted by receive_video.
        """
        if (frame.sequence != record.sequence or frame.width != record.width or frame.height != record.height
                or frame.width*frame.height*3 > self._max_bytes
                or frame.hor_stride % 2 or frame.ver_stride % 2
                or frame.hor_stride < frame.width + frame.width % 2
                or frame.ver_stride < frame.height + frame.height % 2
                or frame.hor_stride*frame.ver_stride*3//2 > self._max_bytes
                or not isinstance(frame.nv12, (bytes, bytearray, memoryview))
                or len(frame.nv12) != frame.hor_stride*frame.ver_stride*3//2
                or type(record.sequence) is not int or record.sequence < 0
                or type(record.timestamp_ns) is not int or record.timestamp_ns < 0):
            raise ValueError("invalid successful MPP copy/record metadata")
        pixels = bytes(frame.nv12)  # Defensive copy if a test/private producer supplied a mutable buffer.
        received_ns = self._clock()
        if type(received_ns) is not int or received_ns < 0:
            raise ValueError("host NV12 availability clock must return nonnegative integer nanoseconds")
        metadata = getattr(record, "metadata", None)
        if metadata is not None:
            if (not isinstance(metadata, RecordMetadata) or metadata.source is None
                    or metadata.source.camera != 0 or metadata.source.sequence != record.sequence):
                raise ValueError("singlecamera0 v2 RGB copy requires this exact complete wire source")
        with self._cv:
            if self._closed:
                return False
            if metadata is not None:
                cohort = metadata.source.session, metadata.source.epoch
                if self._wire_cohort is not None and cohort != self._wire_cohort:
                    old_session, old_epoch = self._wire_cohort
                    session_delta = (cohort[0]-old_session) & 0xFFFFFFFF
                    if ((cohort[0] == old_session and cohort[1] < old_epoch)
                            or (cohort[0] != old_session and not 0 < session_delta < 0x80000000)):
                        raise ValueError("backward v2 source cohort")
                    self._source_epoch += 1  # Host invalidation counter, not the wire CFG epoch.
                    self._last_sequence = None
                    self._dropped += len(self._input)+len(self._output)
                    self._input.clear()
                    self._output.clear()
                    self._resident = None
                self._wire_cohort = cohort
            elif self._wire_cohort is not None:
                raise ValueError("record version changed inside v2 copy cohort")
            if self._last_sequence is not None and record.sequence <= self._last_sequence:
                raise ValueError("backward wire sequence; explicit new host cohort required")
            self._generation += 1
            self._last_sequence = record.sequence
            copied = _Copy(FrameIdentity(0, record.sequence, self._source_epoch, self._generation),
                           frame.width, frame.height, frame.hor_stride, frame.ver_stride,
                           record.timestamp_ns, pixels, received_ns, metadata)
            if len(self._input) == self._depth:
                self._input.popleft()
                self._dropped += 1
            self._input.append(copied)
            self._submitted += 1
            self._cv.notify()
            return True

    def _run(self):
        while True:
            with self._cv:
                self._cv.wait_for(lambda: self._closed or self._input)
                if self._closed:
                    return
                copied = self._input.popleft()
            try:
                rgb = self._converter(copied.nv12, copied.width, copied.height,
                                      copied.hor_stride, copied.ver_stride)
                if type(rgb) is not bytes or len(rgb) != copied.width*copied.height*3:
                    raise ValueError("converter did not return exact owned RGB888")
                metadata = copied.metadata
                source_metadata = _public_source_metadata(copied)
                kind = self._source_kind if metadata is None else (
                    "DIGITAL_REPLAY" if metadata.source.kind == p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY
                    else "PHYSICAL_CAMERA")
                frame = RGBFrame(copied.identity, copied.width, copied.height, rgb,
                                 kind, f"ajpg-v{1 if metadata is None else 2}:{copied.width}x{copied.height}",
                                 calibration_id=(str(metadata.calibration_id) if metadata is not None
                                                 and metadata.calibration_id is not None else None),
                                 capture_time_ns=(copied.timestamp_ns if metadata is None
                                                  or metadata.validity_flags & p.PCIE_RECORD_V2_FLAG_TIME else None),
                                 capture_time_quality="UNKNOWN", source_metadata=source_metadata,
                                 received_monotonic_ns=copied.received_monotonic_ns)
            except Exception as exc:
                with self._cv:
                    self._errors += 1
                    self._error = f"{type(exc).__name__}: {exc}"[:192]
                continue
            with self._cv:
                if self._closed or copied.identity.source_epoch != self._source_epoch:
                    self._dropped += 1
                    continue
                if len(self._output) == self._depth:
                    self._output.popleft()
                    self._dropped += 1
                self._output.append((frame, copied.metadata))
                self._converted += 1
                self._cv.notify_all()

    def poll(self, camera_id=0):
        if type(camera_id) is not int or camera_id != 0:
            raise ValueError("AJPG v1 camera1 is UNSUPPORTED")
        with self._cv:
            if not self._output:
                return None
            # Linux/AI publication favors latest complete converted frame.
            self._dropped += len(self._output)-1
            frame, metadata = self._output[-1]
            self._output.clear()
            self._resident = frame.identity, metadata
            return frame

    def metadata_for(self, identity):
        """Exact last-poll identity only; no slot scan, seq lookup or MMIO relabel."""
        with self._cv:
            return self._resident[1] if self._resident is not None and self._resident[0] == identity else None

    def resident_record(self):
        with self._cv:
            return self._resident

    def new_host_cohort(self):
        """Explicit owner notification, no hardware reset/reopen or inference."""
        with self._cv:
            self._source_epoch += 1
            self._last_sequence = None
            self._wire_cohort, self._resident = None, None
            self._dropped += len(self._input)+len(self._output)
            self._input.clear()
            self._output.clear()

    def describe(self):
        with self._cv:
            metadata = self._resident[1] if self._resident is not None else None
            kind = self._source_kind if metadata is None else (
                "DIGITAL_REPLAY" if metadata.source.kind == p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY
                else "PHYSICAL_CAMERA")
            return {"backend": "live_mpp_copied_nv12_cpu_rgb", "source_kind": kind,
                    "source_kind_origin": "RCD2" if metadata else "HOST_DECLARED_V1",
                    "board_status": "NOT_RUN", "queue_depth": self._depth,
                    "waiting_frames": len(self._input)+len(self._output), "dropped": self._dropped,
                    "hardware_actions_applied": False}

    def diagnostics(self):
        with self._cv:
            metadata = self._resident[1] if self._resident is not None else None
            return {**self.describe(), "submitted": self._submitted, "converted": self._converted,
                    "conversion_errors": self._errors, "last_error": self._error,
                    "source_epoch_kind": "HOST_RECEIVER_COHORT", "generation_kind": "HOST_COPY",
                    "received_time_kind": "HOST_OWNED_NV12_AVAILABLE",
                    "exposure": metadata.actual_exposure if metadata and metadata.actual_exposure is not None else "UNKNOWN",
                    "gain": metadata.actual_gain if metadata and metadata.actual_gain is not None else "UNKNOWN",
                    "calibration": metadata.calibration_id if metadata and metadata.calibration_id is not None else "UNKNOWN",
                    "sync": "UNKNOWN", "wire_time_quality": metadata.time_quality if metadata else "UNKNOWN",
                    "full_cfg_stamp": "AVAILABLE_RCD2" if metadata and metadata.source else "UNAVAILABLE_AJPG_V1",
                    "wire_source_stamp": ({"session": metadata.source.session, "epoch": metadata.source.epoch,
                                           "camera": metadata.source.camera, "sequence": metadata.source.sequence}
                                          if metadata and metadata.source else None),
                    "jpeg_identity": ({"session": metadata.jpeg_session, "slot": metadata.jpeg_slot,
                                       "generation": metadata.jpeg_generation} if metadata else None),
                    "neutral_stats_complete": bool(metadata and metadata.neutral_stats),
                    "dual": "UNSUPPORTED"}

    def close(self):
        with self._cv:
            self._closed = True
            self._input.clear()
            self._output.clear()
            self._resident = None
            self._cv.notify_all()
        self._thread.join(timeout=2)


class LiveVisionConsumer:
    """Receiver injection plus owner publication; client gets only VisionClient.

    The CLI uses no execution hook. A trusted in-process Linux host may inject
    SemanticExecutionAdapter separately; neither the AI nor MPP callback owns
    its CFG transport or calls apply_pending.
    """
    def __init__(self, *, execution_hook=None, semantic_owner=None,
                 environment_provider=None, neutral_policy_provider=None,
                 read_only=True, service_options=None, **backend_options):
        from linux.vision_api.service import VisionService
        if semantic_owner is not None and execution_hook is not None:
            raise ValueError("choose the existing execution hook or unique semantic owner")
        if semantic_owner is None and (environment_provider is not None or neutral_policy_provider is not None):
            raise ValueError("trusted providers require an explicit semantic owner")
        if service_options is not None and (type(service_options) is not dict or
                set(service_options) & {"backend", "execution_hook"}):
            raise ValueError("invalid private service options")
        self.backend = LiveRGBBackend(**backend_options)
        try:
            if semantic_owner is not None:
                from .source_stamp import RecordV2Providers
                from .vision_execution import SemanticExecutionAdapter
                providers = RecordV2Providers(self.backend, policy_provider=neutral_policy_provider,
                                              clock=self.backend._clock)
                execution_hook = SemanticExecutionAdapter(semantic_owner,
                    environment_provider=environment_provider, observation_provider=providers.observation,
                    frame_stamp_provider=providers.frame_stamp, read_only=read_only,
                    require_source_stamp=True)
            self.execution_adapter = execution_hook  # Private owner operation; absent from VisionClient.
            self.service = VisionService(self.backend, execution_hook=execution_hook, **(service_options or {}))
        except Exception:
            self.backend.close()
            raise
        # All identity/stat/policy providers are now bound before publication.
        self._publication_error = None
        self._thread = Thread(target=self._publish, name="vision-service-owner", daemon=True)
        self._thread.start()

    def _publish(self):
        while True:
            with self.backend._cv:
                self.backend._cv.wait_for(lambda: self.backend._closed or self.backend._output)
                if self.backend._closed:
                    return
            try:
                self.service.pump(0)
            except Exception as exc:
                self._publication_error = f"{type(exc).__name__}: {exc}"[:192]

    def want_frame(self):
        return self.backend.want_frame()

    def submit(self, frame, record):
        return self.backend.submit(frame, record)

    def diagnostics(self):
        return {**self.backend.diagnostics(), "frames_published": self.service.frames_published,
                "publication_error": self._publication_error,
                "hardware_actions_applied": self.service.discover()["hardware_actions_applied"]}

    def close(self):
        self.backend.close()
        self._thread.join(timeout=2)
