"""Private Linux F57 policy owner; AI must import only linux.vision_api.

This adapter uses the actual CFG1 transaction client. It does not attach itself
to VisionService, expose raw configuration to AI, or add hardware capabilities.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import asdict, dataclass
import json
import math
from threading import RLock
import time
import weakref

from linux.vision_api import ActionStatus, FrameRef
from .config_transaction import AppliedConfiguration, Configuration, ConfigError, ConfigTransactions
from .advanced_config import AdvancedConfiguration
from .mono_config_v2 import MonoCapabilities, MonoConfiguration
from . import pcie_protocol_v1 as p


@dataclass(frozen=True)
class Profile:
    """Trusted Linux policy, never supplied in request args by an AI client."""
    configuration: Configuration | None
    requires_hdr: bool = False
    requires_cfs: bool = False
    requires_dual: bool = False
    requires_virtual: bool = False
    high_bandwidth: bool = False
    extension: AdvancedConfiguration | MonoConfiguration | None = None


DEFAULT_PROFILES = {
    "normal": Profile(Configuration()),
    "low_light": Profile(Configuration(mode=p.PCIE_CFG_MODE_GAUSSIAN)),
    "backlight": Profile(Configuration(mode=p.PCIE_CFG_MODE_HISTOGRAM)),
    "dehaze": Profile(None),
}


@dataclass(frozen=True)
class Policy:
    observation_ttl_ns: int = 300_000_000
    minimum_residence_ns: int = 500_000_000
    stable_observations: int = 3
    benefit_enter: float = .65
    benefit_leave: float = .40
    risk_enter: float = .25
    risk_leave: float = .40
    queue_enter: float = .50
    queue_leave: float = .75
    request_limit: int = 2048


@dataclass(frozen=True)
class Environment:
    """Trusted backend snapshot; qualification flags need actual joint evidence.

    Public and CFG sessions are different namespaces; the Linux adapter maps
    them explicitly. Bandwidth is RAW worst case, never expected CFS savings.
    """
    public_session: str
    public_epoch: int
    cfg_session: int
    observed_ns: int
    camera_present: int = 1
    queue_used: int = 0
    queue_capacity: int = 4
    free_slots: int = 1
    codec_ready: bool = True
    raw_bandwidth_qualified: bool = False
    high_bandwidth_qualified: bool = False
    integrated_features: frozenset[str] = frozenset()
    dehaze_lut_generation: int | None = None


@dataclass(frozen=True)
class Observation:
    """Qualified neutral/source-RGB statistics, not enhanced-output feedback.

    Exposure may be unknown. It blocks HDR qualification, not normal mono RGB.
    A frame reference may count at most once toward a settling streak.
    """
    frame_ref: FrameRef
    observed_ns: int
    preferred_profile: str
    benefit: float
    risk: float
    width: int = 1920
    height: int = 1080
    valid: bool = True
    source_rgb: bool = True
    source_kind: str = "PHYSICAL_CAMERA"
    actual_exposure: int | None = None
    hdr_qualified: bool = False


@dataclass
class _Request:
    fingerprint: str
    status: ActionStatus
    ref: FrameRef
    profile: str
    deadline_ns: int
    prepared: object = None
    phase: str = "PREPARING"


_owner_lock = RLock()
_owners = weakref.WeakKeyDictionary()


def _integer(value, *, minimum=0):
    return type(value) is int and value >= minimum


def _score(value):
    return type(value) in (float, int) and math.isfinite(value) and 0 <= value <= 1


def _features(profile):
    """Required integration evidence, separate from the register support mask."""
    ext = profile.extension
    required = {name for name in ("hdr", "cfs", "dual", "virtual")
                if getattr(profile, "requires_" + name)}
    if isinstance(ext, MonoConfiguration):
        if ext.product_mode == p.PCIE_CFG_V2_MODES_MONO_HDR:
            required.add("hdr")
        elif ext.product_mode == p.PCIE_CFG_V2_MODES_MONO_SDR_LZ:
            required.add("lz")
        for bit, name in ((p.PCIE_CFG_V2_ENABLES_GRAY, "gray"),
                          (p.PCIE_CFG_V2_ENABLES_DEHAZE, "dehaze"),
                          (p.PCIE_CFG_V2_ENABLES_GAUSSIAN_IMAGE, "color_gaussian"),
                          (p.PCIE_CFG_V2_ENABLES_HISTOGRAM, "he"),
                          (p.PCIE_CFG_V2_ENABLES_MULTISCALE, "f22"),
                          (p.PCIE_CFG_V2_ENABLES_LANE, "f23")):
            if ext.processing_enables & bit:
                required.add(name)
    elif ext is not None:
        required.update(name.lower() for name in ("HDR", "CFS", "NR", "DEHAZE", "F22", "F23", "F24", "F25")
                        if ext.enable & getattr(p, "PCIE_CFG_EXT_FEATURE_" + name))
    return required


def _validate_mono_profiles(profiles):
    """A complete explicit family cannot clear independent analysis/products."""
    normal = profiles["normal"]
    base = normal.extension
    analysis = p.PCIE_CFG_V2_ENABLES_MULTISCALE | p.PCIE_CFG_V2_ENABLES_LANE
    if (normal != Profile(Configuration(), extension=base)
            or base.product_mode not in (p.PCIE_CFG_V2_MODES_MONO_SDR, p.PCIE_CFG_V2_MODES_MONO_SDR_LZ)
            or base.processing_enables & ~analysis):
        raise ValueError("mono normal requires COLOR/Q75 and only independent F22/lane background bits")
    additions = {"normal": 0, "low_light": p.PCIE_CFG_V2_ENABLES_GAUSSIAN_IMAGE,
                 "backlight": p.PCIE_CFG_V2_ENABLES_HISTOGRAM,
                 "dehaze": p.PCIE_CFG_V2_ENABLES_DEHAZE, "hdr": 0}
    for name, profile in profiles.items():
        if profile.configuration is None:
            if profile.extension is not None:
                raise ValueError("unsupported mono profile must have no extension")
            continue
        ext = profile.extension
        if (name not in additions or not isinstance(ext, MonoConfiguration)
                or profile.configuration.mode != p.PCIE_CFG_MODE_COLOR):
            raise ValueError("mono family requires explicit schema2 COLOR profiles; no legacy fallback")
        ext.validate(MonoCapabilities(7, 63), width=1920, height=1080, camera_present=1)
        if ext.processing_enables != base.processing_enables | additions[name]:
            raise ValueError("mono semantic transition must preserve independent F22/lane and use its named processing bit")
        expected_mode = p.PCIE_CFG_V2_MODES_MONO_HDR if name == "hdr" else base.product_mode
        if ext.product_mode != expected_mode:
            raise ValueError("mono semantic transition cannot change the product mode implicitly")
        if name == "hdr" and base.product_mode == p.PCIE_CFG_V2_MODES_MONO_SDR_LZ:
            raise ValueError("HDR cannot replace an active LZ product family")


class AdaptiveConfigOwner:
    """One bounded pending transaction and one observer record per camera.

    request_action prepares only; apply_pending explicitly commits and waits for
    actual-frame APPLIED. A rejected post-READY admission retains ownership until
    trusted Linux calls cancel_pending, which uses the real CFG CANCEL handshake.
    No method cancels a timed-out COMMIT or retries/reopens a terminal client.
    """
    def __init__(self, transactions: ConfigTransactions, *, policy=Policy(),
                 profiles=None, clock=time.monotonic_ns):
        if not isinstance(transactions, ConfigTransactions):
            raise TypeError("owner requires the actual ConfigTransactions adapter")
        for name in ("observation_ttl_ns", "stable_observations", "request_limit"):
            if not _integer(getattr(policy, name), minimum=1):
                raise ValueError(f"invalid {name}")
        if not _integer(policy.minimum_residence_ns):
            raise ValueError("invalid minimum residence")
        for name in ("benefit_enter", "benefit_leave", "risk_enter", "risk_leave", "queue_enter", "queue_leave"):
            if not _score(getattr(policy, name)):
                raise ValueError(f"invalid {name}")
        if not (policy.benefit_leave < policy.benefit_enter and policy.risk_enter < policy.risk_leave
                and policy.queue_enter < policy.queue_leave):
            raise ValueError("hysteresis thresholds must have distinct enter/leave bands")
        selected = dict(DEFAULT_PROFILES if profiles is None else profiles)
        if not set(DEFAULT_PROFILES) <= set(selected) <= set(DEFAULT_PROFILES) | {"nr", "hdr"}:
            raise ValueError("preserve public profile names and COLOR/Q75 normal anchor")
        if any(not isinstance(profile, Profile) for profile in selected.values()):
            raise TypeError("invalid trusted profile")
        mono = isinstance(selected["normal"].extension, MonoConfiguration)
        if mono:
            _validate_mono_profiles(selected)
        elif selected["normal"] != DEFAULT_PROFILES["normal"]:
            raise ValueError("preserve COLOR/Q75 normal anchor")
        if not mono and selected["dehaze"] != DEFAULT_PROFILES["dehaze"] and (
                selected["dehaze"].extension is None or not selected["dehaze"].extension.enable & p.PCIE_CFG_EXT_FEATURE_DEHAZE):
            raise ValueError("dehaze cannot be aliased to an unrelated available CFG mode")
        for profile in selected.values():
            if not isinstance(profile, Profile):
                raise TypeError("invalid trusted profile")
            for name in ("requires_hdr", "requires_cfs", "requires_dual", "requires_virtual", "high_bandwidth"):
                if type(getattr(profile, name)) is not bool:
                    raise ValueError("profile qualification flags must be bool")
            if profile.configuration is not None:
                profile.configuration.validate()
                if profile.configuration.mode not in (p.PCIE_CFG_MODE_COLOR, p.PCIE_CFG_MODE_GAUSSIAN,
                                                       p.PCIE_CFG_MODE_HISTOGRAM):
                    raise ValueError("semantic profiles map only the qualified COLOR/GAUSSIAN/HISTOGRAM ABI")
            if profile.extension is not None:
                if (not isinstance(profile.extension, (AdvancedConfiguration, MonoConfiguration))
                        or profile.configuration is None or isinstance(profile.extension, MonoConfiguration) != mono):
                    raise ValueError('advanced profile needs an immutable snapshot and legacy base configuration')
                profile.extension.words()
        for name, feature in (("nr", p.PCIE_CFG_EXT_FEATURE_NR), ("hdr", p.PCIE_CFG_EXT_FEATURE_HDR)):
            if not mono and name in selected and (selected[name].extension is None or not selected[name].extension.enable & feature):
                raise ValueError(f'{name} profile must enable its actual advanced feature')
        with _owner_lock:
            previous = _owners.get(transactions)
            if previous is not None and previous() is not None:
                raise ValueError("CFG transport already has a semantic owner")
            _owners[transactions] = weakref.ref(self)
        self._transport, self._policy, self._profiles, self._clock = transactions, policy, selected, clock
        self._mono = mono
        self._lock = RLock()
        self._environment = None
        self._observations = {}
        self._streaks = {}
        self._requests = OrderedDict()
        self._pending = None
        self._terminal = False
        self._active_profile = None
        self._last_applied = None
        self._last_applied_ns = None
        self._fallback = None

    def _now(self):
        value = self._clock()
        if not _integer(value):
            raise ValueError("owner clock must return monotonic integer nanoseconds")
        return value

    def update_environment(self, snapshot: Environment):
        """Private adapter operation; cannot replace or clear a live transaction."""
        with self._lock:
            if (not isinstance(snapshot, Environment) or not isinstance(snapshot.public_session, str)
                    or not 1 <= len(snapshot.public_session) <= 128
                    or not _integer(snapshot.public_epoch) or not _integer(snapshot.cfg_session, minimum=1)
                    or not _integer(snapshot.observed_ns) or snapshot.observed_ns > self._now()
                    or type(snapshot.camera_present) is not int or not 1 <= snapshot.camera_present <= 3
                    or not _integer(snapshot.queue_used) or not _integer(snapshot.queue_capacity, minimum=1)
                    or snapshot.queue_used > snapshot.queue_capacity or not _integer(snapshot.free_slots)
                    or not isinstance(snapshot.integrated_features, frozenset)
                    or not snapshot.integrated_features <= {"hdr", "cfs", "dual", "virtual", "nr", "dehaze", "f22", "f23", "f24", "f25",
                        "gray", "color_gaussian", "he", "lz", "low_light_quality", "backlight_quality"}
                    or snapshot.dehaze_lut_generation is not None and not _integer(snapshot.dehaze_lut_generation, minimum=1)
                    or any(type(getattr(snapshot, name)) is not bool for name in
                           ("codec_ready", "raw_bandwidth_qualified", "high_bandwidth_qualified"))):
                raise ValueError("invalid trusted environment")
            old = self._environment
            if old is not None and snapshot.observed_ns < old.observed_ns:
                raise ValueError("backward environment observation")
            if old is not None and (old.public_session, old.public_epoch, old.cfg_session) != (
                    snapshot.public_session, snapshot.public_epoch, snapshot.cfg_session):
                self._observations.clear()
                self._streaks.clear()
            self._environment = snapshot

    def observe(self, observation: Observation):
        with self._lock:
            ref = observation.frame_ref if isinstance(observation, Observation) else None
            if (not isinstance(ref, FrameRef) or type(ref.camera_id) is not int or ref.camera_id not in (0, 1)
                    or not _integer(ref.sequence, minimum=1) or not _integer(ref.mode_epoch)
                    or not isinstance(ref.session_id, str) or ref.view != "source_rgb"
                    or not _integer(observation.observed_ns) or observation.observed_ns > self._now()
                    or not isinstance(observation.preferred_profile, str) or observation.preferred_profile not in self._profiles
                    or not _score(observation.benefit) or not _score(observation.risk)
                    or not _integer(observation.width, minimum=1) or not _integer(observation.height, minimum=1)
                    or type(observation.valid) is not bool or type(observation.source_rgb) is not bool
                    or type(observation.hdr_qualified) is not bool
                    or not isinstance(observation.source_kind, str)
                    or observation.source_kind not in {"PHYSICAL_CAMERA", "TABLET_RECAPTURE", "DIGITAL_REPLAY", "SYNTHETIC_REPLAY"}
                    or observation.actual_exposure is not None and not _integer(observation.actual_exposure)):
                raise ValueError("invalid neutral observation")
            env = self._environment
            if env is None or (ref.session_id, ref.mode_epoch) != (env.public_session, env.public_epoch):
                raise ValueError("observation cohort mismatch")
            previous = self._observations.get(ref.camera_id)
            if previous is not None and (ref.sequence <= previous.frame_ref.sequence
                                         or observation.observed_ns < previous.observed_ns):
                raise ValueError("duplicate/backward observation cannot advance settling")
            profile, count = self._streaks.get(ref.camera_id, (None, 0))
            good = (observation.valid and observation.source_rgb
                    and observation.benefit >= self._policy.benefit_enter
                    and observation.risk <= self._policy.risk_enter)
            contiguous = previous is not None and observation.observed_ns-previous.observed_ns < self._policy.observation_ttl_ns
            self._streaks[ref.camera_id] = (observation.preferred_profile,
                min(count + 1, self._policy.stable_observations) if good and contiguous and profile == observation.preferred_profile else 1 if good else 0)
            self._observations[ref.camera_id] = observation

    def _admission(self, ref, profile_name, deadline, now):
        if now >= deadline:
            return "DEADLINE"
        env = self._environment
        if env is None:
            return "UNKNOWN_ENVIRONMENT"
        if env.cfg_session != self._transport.session:
            return "CFG_SESSION_MISMATCH"
        if (ref.session_id, ref.mode_epoch, ref.view) != (env.public_session, env.public_epoch, "source_rgb"):
            return "STALE_FRAME"
        present = env.camera_present & self._transport.capabilities.camera_present
        if not present & (1 << ref.camera_id):
            return "CAMERA_ABSENT"
        observation = self._observations.get(ref.camera_id)
        if observation is None:
            return "UNKNOWN_OBSERVATION"
        if observation.frame_ref != ref:
            return "STALE_FRAME"
        if (now - observation.observed_ns >= self._policy.observation_ttl_ns
                or now - env.observed_ns >= self._policy.observation_ttl_ns):
            return "OBSERVATION_EXPIRED"
        if not observation.valid or not observation.source_rgb:
            return "OBSERVATION_INVALID"
        if (observation.width > self._transport.capabilities.max_width
                or observation.height > self._transport.capabilities.max_height):
            return "UNSUPPORTED_GEOMETRY"
        profile = self._profiles[profile_name]
        if profile.configuration is None:
            return "UNSUPPORTED_PROFILE"
        if profile.extension is not None and (observation.width, observation.height) != (
                self._transport.capabilities.max_width, self._transport.capabilities.max_height):
            return 'UNSUPPORTED_GEOMETRY'
        for feature in sorted(_features(profile)):
            if feature == "dual" and present != 3:
                return "CAMERA1_ABSENT"
            if feature not in env.integrated_features:
                return f"UNSUPPORTED_FEATURE_{feature.upper()}"
            if feature == "hdr":
                if not observation.actual_exposure:
                    return "UNKNOWN_EXPOSURE"
                if observation.source_kind != "PHYSICAL_CAMERA" or not observation.hdr_qualified:
                    return "HDR_NOT_QUALIFIED"
            if profile.extension is None or feature in {"dual", "virtual"} or (
                    self._mono and feature == "cfs"):
                return "UNSUPPORTED_CFG_ABI"
            if feature == 'dehaze' and env.dehaze_lut_generation != profile.extension.dehaze_lut_generation:
                return 'UNQUALIFIED_DEHAZE_LUT_GENERATION'
        try:
            self._transport.capabilities.supports(profile.configuration)
            if profile.extension is not None:
                self._transport.validate_extension(profile.extension)
        except ConfigError as exc:
            if exc.code not in (p.PCIE_CFG_ERROR_INVALID, p.PCIE_CFG_ERROR_UNSUPPORTED):
                self._terminal = True
                return 'TRANSPORT_FAILURE_QUARANTINE'
            return "UNSUPPORTED_CFG_EXT" if profile.extension is not None else "UNSUPPORTED_CFG_FEATURE"
        except Exception:
            self._terminal = True
            return 'TRANSPORT_FAILURE_QUARANTINE'
        if self._mono and profile_name in {"low_light", "backlight"} and (
                profile_name + "_quality" not in env.integrated_features):
            return "SCENE_QUALITY_UNQUALIFIED"
        if not env.raw_bandwidth_qualified:
            return "RAW_BANDWIDTH_UNQUALIFIED"
        high = (profile.high_bandwidth or profile.configuration.quality > p.PCIE_CFG_DEFAULT_QUALITY
                or observation.width > 1920 or observation.height > 1080
                or self._transport.capabilities.compiled_profile != p.PCIE_CFG_PROFILE_MONO1920)
        if high and not env.high_bandwidth_qualified:
            return "HIGH_BANDWIDTH_UNQUALIFIED"
        retained = profile_name == self._active_profile
        queue_limit = self._policy.queue_leave if retained else self._policy.queue_enter
        if not env.codec_ready or not env.free_slots:
            return "QUEUE_NOT_READY"
        if env.queue_used / env.queue_capacity > queue_limit:
            return "QUEUE_PRESSURE"
        risk_limit = self._policy.risk_leave if retained else self._policy.risk_enter
        if observation.risk > risk_limit:
            return "RISK_GATE"
        if profile_name != "normal":
            if observation.preferred_profile != profile_name:
                return "SCENE_MISMATCH"
            benefit_limit = self._policy.benefit_leave if retained else self._policy.benefit_enter
            if observation.benefit < benefit_limit:
                return "QUALITY_GATE"
            if not retained and self._streaks.get(ref.camera_id, (None, 0))[1] < self._policy.stable_observations:
                return "HYSTERESIS_SETTLING"
        if not retained and self._last_applied_ns is not None and now-self._last_applied_ns < self._policy.minimum_residence_ns:
            return "MINIMUM_RESIDENCE"
        return None

    def _set_status(self, record, status, reason, epoch=None):
        record.status = ActionStatus(record.status.request_id, status, reason, epoch)
        if status in ("REJECTED", "EXPIRED"):
            self._fallback = "normal"  # Advice only; no register write.
        return record.status

    def _transport_failure(self, record, exception):
        self._terminal = True
        record.phase = "QUARANTINED"
        reason = "TRANSPORT_TIMEOUT_QUARANTINE" if isinstance(exception, TimeoutError) else "TRANSPORT_FAILURE_QUARANTINE"
        return self._set_status(record, "REJECTED", reason)

    def request_action(self, client_id, request_id, frame_ref, kind, args, deadline_ns):
        """Private execution hook matching public semantics, not auto-installed.

        The public service still owns authentication/issued-FrameRef validation.
        This owner additionally requires the exact current trusted observation.
        """
        if (not isinstance(client_id, str) or not 1 <= len(client_id) <= 128
                or not isinstance(request_id, str) or not 1 <= len(request_id) <= 128
                or not isinstance(frame_ref, FrameRef) or type(frame_ref.camera_id) is not int
                or frame_ref.camera_id not in (0, 1) or not _integer(frame_ref.sequence, minimum=1)
                or not _integer(frame_ref.mode_epoch) or not isinstance(frame_ref.session_id, str)
                or not isinstance(kind, str) or not isinstance(args, dict) or not _integer(deadline_ns)):
            raise ValueError("invalid semantic request")
        try:
            fingerprint = json.dumps([asdict(frame_ref), kind, args, deadline_ns], sort_keys=True, allow_nan=False)
        except (ValueError, TypeError) as exc:
            raise ValueError("semantic request must be finite JSON") from exc
        if len(fingerprint.encode()) > 65536:
            raise ValueError("semantic request exceeds message bound")
        key = client_id, request_id
        with self._lock:
            old = self._requests.get(key)
            if old:
                return self.get_request_status(client_id, request_id) if old.fingerprint == fingerprint else ActionStatus(request_id, "REJECTED", "ID_CONFLICT")
            if len(self._requests) >= self._policy.request_limit:
                return ActionStatus(request_id, "REJECTED", "REQUEST_BUDGET")
            profile = args.get("profile") if kind == "enhancement" and set(args) == {"profile"} else None
            record = _Request(fingerprint, ActionStatus(request_id, "PENDING", "PREPARING"), frame_ref, profile, deadline_ns)
            self._requests[key] = record
            if not isinstance(profile, str) or profile not in self._profiles:
                return self._set_status(record, "REJECTED", "INVALID_ARGS" if kind == "enhancement" else "UNSUPPORTED_ACTION")
            if self._terminal:
                return self._set_status(record, "REJECTED", "OWNER_QUARANTINED")
            if self._pending is not None:
                return self._set_status(record, "REJECTED", "OWNER_BUSY")
            reason = self._admission(frame_ref, profile, deadline_ns, self._now())
            if reason:
                return self._set_status(record, "EXPIRED" if reason == "DEADLINE" else "REJECTED", reason)
            if profile == self._active_profile:
                return self._set_status(record, "APPLIED", "ALREADY_ACTIVE", self._last_applied.mode_epoch)
            self._pending = key
            configuration = self._profiles[profile].configuration
            extension = self._profiles[profile].extension
        try:
            prepared = self._transport.prepare(configuration) if extension is None else self._transport.prepare(configuration, extension=extension)
        except Exception as exc:
            with self._lock:
                return self._transport_failure(record, exc)
        with self._lock:
            record.prepared, record.phase = prepared, "READY"
            reason = self._admission(frame_ref, profile, deadline_ns, self._now())
            if reason:
                return self._set_status(record, "EXPIRED" if reason == "DEADLINE" else "REJECTED", reason)
            return self._set_status(record, "PENDING", "PREPARED_READY")

    def apply_pending(self):
        """Trusted owner calls after fresh admission; synchronous actual APPLIED."""
        with self._lock:
            if self._pending is None:
                return None
            record = self._requests[self._pending]
            if self._terminal:
                return self._set_status(record, "REJECTED", "OWNER_QUARANTINED")
            if record.phase != "READY":
                return ActionStatus(record.status.request_id, "PENDING", "OWNER_BUSY")
            reason = self._admission(record.ref, record.profile, record.deadline_ns, self._now())
            if reason:
                return self._set_status(record, "EXPIRED" if reason == "DEADLINE" else "REJECTED", reason)
            record.phase = "COMMITTING"
            self._set_status(record, "PENDING", "COMMITTING_ACTUAL_FRAME")
        try:
            applied = self._transport.commit(record.prepared)
        except Exception as exc:
            with self._lock:
                return self._transport_failure(record, exc)
        with self._lock:
            # Once COMMIT was sent, late policy changes cannot undo hardware.
            # Report its actual identity even if the semantic deadline elapsed.
            if not isinstance(applied, AppliedConfiguration):
                return self._transport_failure(record, ConfigError("missing actual APPLIED identity"))
            self._active_profile, self._last_applied, self._last_applied_ns = record.profile, applied, self._now()
            record.phase = "APPLIED"
            self._pending = None
            self._fallback = None
            reason = "ACTUAL_FRAME_APPLIED_AFTER_DEADLINE" if self._last_applied_ns >= record.deadline_ns else "ACTUAL_FRAME_APPLIED"
            return self._set_status(record, "APPLIED", reason, applied.mode_epoch)

    def cancel_pending(self):
        """Explicit Linux pre-COMMIT CANCEL only; never timeout recovery."""
        with self._lock:
            if self._pending is None:
                return None
            record = self._requests[self._pending]
            if self._terminal:
                return ActionStatus(record.status.request_id, "REJECTED", "OWNER_QUARANTINED")
            if record.phase != "READY":
                return ActionStatus(record.status.request_id, "REJECTED", "OWNER_BUSY")
            record.phase = "CANCELLING"
        try:
            self._transport.cancel(record.prepared)
        except Exception as exc:
            with self._lock:
                return self._transport_failure(record, exc)
        with self._lock:
            record.phase = "CANCELLED"
            self._pending = None
            return self._set_status(record, "REJECTED", "CANCELLED_PREPARED")

    def get_request_status(self, client_id, request_id):
        with self._lock:
            record = self._requests.get((client_id, request_id))
            if (record is not None and self._pending is not None and self._requests[self._pending] is record
                    and record.phase in ("PREPARING", "READY") and self._now() >= record.deadline_ns):
                return self._set_status(record, "EXPIRED", "DEADLINE")
            return None if record is None else record.status

    def diagnostics(self):
        """Private scalar snapshot; never expose transport or imply write drain."""
        with self._lock:
            return {"quarantined": self._terminal, "busy": self._pending is not None,
                    "active_profile": self._active_profile,
                    "pending_phase": None if self._pending is None else self._requests[self._pending].phase,
                    "applied_epoch": None if self._last_applied is None else self._last_applied.mode_epoch,
                    "request_records": len(self._requests), "fallback_advice": self._fallback,
                    "exposure_known": {camera: bool(obs.actual_exposure) for camera, obs in self._observations.items()}}

    def last_applied(self):
        """Private adapter reads the immutable actual CFG identity for mapping.

        Device session/sequence/epoch is not a public FrameRef; the production
        backend must rotate/map its public identity through its own owner.
        """
        with self._lock:
            return self._last_applied

    def supports_profile(self, name):
        """Only explicitly registered trusted semantic policies enter admission."""
        with self._lock:
            profile = self._profiles.get(name)
            return profile is not None and profile.configuration is not None and (
                name not in {'nr', 'hdr'} or profile.extension is not None)
