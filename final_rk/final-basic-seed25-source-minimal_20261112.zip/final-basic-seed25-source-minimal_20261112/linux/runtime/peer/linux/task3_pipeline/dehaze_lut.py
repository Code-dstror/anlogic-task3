"""Explicit F21 LUT transactions on an already owned BAR; no DMA or recovery."""
from __future__ import annotations

from dataclasses import dataclass
import math
import time

from . import pcie_protocol_v1 as p
from .raw_frame_store import BarAccess


class LutError(RuntimeError):
    def __init__(self, message: str, code: int = 0):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class LutSnapshot:
    session: int
    sequence: int
    active_generation: int
    result_generation: int
    valid: bool
    loading: bool


def reciprocal_words() -> tuple[int, ...]:
    """Exact round-half-up 65536/n; indices below64 are deliberately unusable."""
    return tuple(0 if n < 64 else (131072 + n) // (2 * n) for n in range(257))


def _uint(value: int, name: str, maximum: int = 0xFFFFFFFF, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise ValueError(f"{name} must be an integer in {minimum}..{maximum}")
    return value


class DehazeLutTransactions:
    """Caller owns the same BAR and applied CFG session throughout this client.

    Construction only reads. load() performs QUERY, BEGIN, all257 validated WORD
    operations, real COMMIT and another QUERY. It never enables F21: the caller
    subsequently requests that generation through the normal CFG apply barrier.
    Only a proved USER-side BEGIN admission rejection may wait and try a new
    sequence within one timeout budget. Other failures close this client; no
    abort, reset or DMA operation is issued.
    """

    def __init__(self, bar: BarAccess, *, session: int, timeout_s: float,
                 poll_interval_s: float = 0.001, clock=time.monotonic, sleep=time.sleep):
        _uint(session, "session", minimum=1)
        if not math.isfinite(timeout_s) or timeout_s <= 0 or not math.isfinite(poll_interval_s) or poll_interval_s <= 0:
            raise ValueError("finite positive command timeout and polling interval required")
        self.bar, self.session = bar, session
        self.timeout_s, self.poll_interval_s, self.clock, self.sleep = timeout_s, poll_interval_s, clock, sleep
        self._terminal = False
        self._last_command_error = None
        if bar.read32(p.PCIE_REG_DEVICE_MAGIC) != p.DEVICE_MAGIC or bar.read32(p.PCIE_REG_PROTOCOL_VERSION) != p.PROTOCOL_VERSION:
            raise LutError("AJPG device identity mismatch")
        if bar.read32(p.PCIE_REG_ALGO_MAGIC) != p.PCIE_ALGO_MAGIC or bar.read32(p.PCIE_REG_ALGO_ABI_VERSION) != p.PCIE_ALGO_ABI_VERSION:
            raise LutError("algorithm control ABI unavailable")
        if not bar.read32(p.PCIE_REG_ALGO_FEATURES) & p.PCIE_ALGO_FEATURE_F21:
            raise LutError("F21 LUT control unavailable")
        if bar.read32(p.PCIE_REG_ALGO_STATUS) & p.PCIE_ALGO_STATUS_BUSY:
            raise LutError("another algorithm command owns this BAR")
        self._check_session()
        previous_session = bar.read32(p.PCIE_REG_ALGO_RESPONSE_SESSION)
        self.sequence = bar.read32(p.PCIE_REG_ALGO_RESPONSE_SEQUENCE) if previous_session == session else 0

    def _fail(self, message: str, code: int = 0):
        self._terminal = True
        raise LutError(message, code)

    def _check_session(self):
        if self._terminal:
            raise LutError("LUT client is terminal; caller owns recovery")
        status = self.bar.read32(p.PCIE_REG_CFG_STATUS)
        if not status & p.PCIE_CFG_STATUS_SESSION_READY or self.bar.read32(p.PCIE_REG_CFG_SESSION) != self.session:
            self._fail("applied source session changed or is not ready")

    def _command(self, command: int, generation: int = 0, index: int = 0,
                 value: int = 0, *, expected_errors: tuple[int, ...] = (),
                 _deadline: float | None = None) -> LutSnapshot:
        self._last_command_error = None
        try:
            return self._command_impl(command, generation, index, value,
                                      expected_errors=expected_errors, deadline=_deadline)
        except LutError:
            raise
        except Exception as exc:
            self._terminal = True
            raise LutError("BAR operation failed; command acceptance is uncertain and no retry was issued") from exc

    def _command_impl(self, command: int, generation: int, index: int,
                      value: int, *, expected_errors: tuple[int, ...],
                      deadline: float | None) -> LutSnapshot:
        self._check_session()
        if deadline is not None and self.clock() >= deadline:
            self._fail("LUT BEGIN admission timed out; no load established", p.PCIE_ALGO_ERROR_CORE_STATE)
        if self.sequence == 0xFFFFFFFF:
            self._fail("command sequence exhausted; a fresh source session is required")
        if self.bar.read32(p.PCIE_REG_ALGO_STATUS) & p.PCIE_ALGO_STATUS_BUSY:
            self._fail("algorithm BAR became busy outside this owner")
        self.sequence += 1
        for register, word in (
            (p.PCIE_REG_ALGO_TARGET, p.PCIE_ALGO_TARGET_F21),
            (p.PCIE_REG_ALGO_SESSION, self.session), (p.PCIE_REG_ALGO_SEQUENCE, self.sequence),
            (p.PCIE_REG_ALGO_GENERATION, generation), (p.PCIE_REG_ALGO_INDEX, index),
            (p.PCIE_REG_ALGO_VALUE, value),
        ):
            self.bar.write32(register, word)
        self.bar.write32(p.PCIE_REG_ALGO_COMMAND, command)
        if deadline is None:
            deadline = self.clock() + self.timeout_s
        while True:
            self._check_session()
            status = self.bar.read32(p.PCIE_REG_ALGO_STATUS)
            if status & p.PCIE_ALGO_STATUS_DONE and not status & p.PCIE_ALGO_STATUS_BUSY:
                sequence = self.bar.read32(p.PCIE_REG_ALGO_RESPONSE_SEQUENCE)
                session = self.bar.read32(p.PCIE_REG_ALGO_RESPONSE_SESSION)
                if (session, sequence) != (self.session, self.sequence):
                    self._fail("completed LUT reply has a different session/sequence")
                error = self.bar.read32(p.PCIE_REG_ALGO_ERROR)
                if bool(status & p.PCIE_ALGO_STATUS_ERROR) != bool(error):
                    self._fail("inconsistent LUT terminal status/error")
                self._last_command_error = error
                if error and error not in expected_errors:
                    self._fail("actual F21 LUT operation failed", error)
                return LutSnapshot(session, sequence,
                    self.bar.read32(p.PCIE_REG_ALGO_ACTIVE_GENERATION),
                    self.bar.read32(p.PCIE_REG_ALGO_RESULT_GENERATION),
                    bool(status & p.PCIE_ALGO_STATUS_LUT_VALID), bool(status & p.PCIE_ALGO_STATUS_LOADING))
            if self.clock() >= deadline:
                self._fail("LUT command timed out; no completion or safe abort inferred")
            self.sleep(min(self.poll_interval_s, max(0, deadline - self.clock())))

    def query(self) -> LutSnapshot:
        return self._command(p.PCIE_ALGO_COMMAND_QUERY)

    def abort(self, generation: int) -> LutSnapshot:
        _uint(generation, "generation", minimum=1)
        return self._command(p.PCIE_ALGO_COMMAND_ABORT, generation,
                             expected_errors=(p.PCIE_ALGO_ERROR_CORE_ABORT,))

    def load(self, generation: int) -> LutSnapshot:
        _uint(generation, "generation", minimum=1)
        previous = self.query()
        if previous.loading:
            raise LutError("an existing LUT load requires an explicit caller decision")
        if previous.valid and generation <= previous.active_generation:
            raise ValueError("new LUT generation must exceed the active generation")
        begin_deadline = self.clock() + self.timeout_s
        while True:
            begun = self._command(p.PCIE_ALGO_COMMAND_BEGIN, generation,
                expected_errors=(p.PCIE_ALGO_ERROR_CORE_STATE,), _deadline=begin_deadline)
            if self._last_command_error == 0:
                break
            # USER rejects BEGIN before enqueueing it and leaves QUERY's cache
            # unchanged. A PIX/core reply carries the requested generation and
            # must remain terminal, even when its error is also CORE_STATE.
            user_rejected = (self._last_command_error == p.PCIE_ALGO_ERROR_CORE_STATE
                and not begun.loading and begun.result_generation == previous.result_generation
                and begun.result_generation != generation
                and (begun.active_generation, begun.valid) == (previous.active_generation, previous.valid))
            if not user_rejected:
                self._fail("actual F21 LUT operation failed", self._last_command_error)
            remaining = begin_deadline - self.clock()
            if remaining <= 0:
                self._fail("LUT BEGIN admission timed out; no load established", p.PCIE_ALGO_ERROR_CORE_STATE)
            self.sleep(min(self.poll_interval_s, remaining))
        if not begun.loading or begun.result_generation != generation:
            self._fail("BEGIN did not establish the requested real load")
        for index, value in enumerate(reciprocal_words()):
            accepted = self._command(p.PCIE_ALGO_COMMAND_WORD, generation, index, value)
            if not accepted.loading or accepted.result_generation != generation:
                self._fail("WORD lost its actual LUT load owner")
        committed = self._command(p.PCIE_ALGO_COMMAND_COMMIT, generation)
        if not committed.valid or committed.loading or committed.active_generation != generation or committed.result_generation != generation:
            self._fail("COMMIT lacks the requested actual LUT generation")
        verified = self.query()
        if not verified.valid or verified.loading or verified.active_generation != generation:
            self._fail("post-COMMIT QUERY does not confirm the actual active LUT")
        return verified
