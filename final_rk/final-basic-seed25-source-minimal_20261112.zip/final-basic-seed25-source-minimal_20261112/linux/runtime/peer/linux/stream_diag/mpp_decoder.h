#ifndef STREAM_DIAG_MPP_DECODER_H
#define STREAM_DIAG_MPP_DECODER_H
#include <stddef.h>
#include <stdint.h>

/* One caller, one in-flight JPEG. callback's frame is borrowed until return.
 * Native consumers may include rk_mpi.h and cast borrowed_frame to MppFrame.
 * Copy pixels before retaining them; buffer references do not prevent the
 * next decode from overwriting the same output allocation. */
typedef struct stream_mpp_decoder stream_mpp_decoder;
typedef struct {
    uint32_t width, height, hor_stride, ver_stride;
    uint32_t format, errinfo, discard;
    uint64_t buffer_size;
} stream_mpp_result;
typedef int (*stream_mpp_consumer)(void *opaque, void *borrowed_frame,
                                  const stream_mpp_result *result);

int stream_mpp_open(stream_mpp_decoder **out, uint32_t max_width,
                    uint32_t max_height, size_t max_jpeg, int timeout_ms);
int stream_mpp_decode(stream_mpp_decoder *decoder, const uint8_t *jpeg,
                      size_t length, uint32_t width, uint32_t height,
                      stream_mpp_result *result, stream_mpp_consumer consumer,
                      void *opaque);
const char *stream_mpp_error(const stream_mpp_decoder *decoder);
/* Call only inside a stream_mpp_consumer; copies stride-padded NV12. */
int stream_mpp_copy_nv12(void *borrowed_frame, uint8_t *dest, size_t capacity);
void stream_mpp_close(stream_mpp_decoder *decoder);
#endif
