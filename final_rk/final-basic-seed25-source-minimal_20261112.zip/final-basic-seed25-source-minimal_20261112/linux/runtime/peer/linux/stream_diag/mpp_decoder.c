#define MODULE_TAG "stream_diag_mpp"
#include "mpp_decoder.h"
#include "rk_mpi.h"
#include "mpp_buffer.h"
#include "mpp_frame.h"
#include "mpp_packet.h"
#include "mpp_task.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct stream_mpp_decoder {
    MppCtx ctx;
    MppApi *mpi;
    MppBufferGroup input_group, output_group;
    MppBuffer input_buffer, output_buffer;
    MppPacket packet;
    MppFrame frame;
    uint32_t max_width, max_height;
    size_t max_jpeg;
    int timeout_ms, poisoned;
    char error[192];
};

static int failed(stream_mpp_decoder *d, const char *phase, int code)
{
    d->poisoned = 1;
    snprintf(d->error, sizeof(d->error), "%s failed (%d); decoder cannot be reused",
             phase, code);
    return -1;
}

void stream_mpp_close(stream_mpp_decoder *d)
{
    int ret;
    if (!d) return;
    /* Target runtime/driver teardown semantics remain a deployment precondition.
     * A published frame may be released by MPP's task-port cleanup. */
    if (d->ctx) {
        ret = mpp_destroy(d->ctx);
        if (ret) {
            d->poisoned = 1;
            fprintf(stderr, "stream_diag_mpp: mpp_destroy failed (%d); "
                    "retaining decoder and buffers; no retry/reopen\n", ret);
            return;
        }
    }
    if (d->packet) mpp_packet_deinit(&d->packet);
    if (d->frame) mpp_frame_deinit(&d->frame);
    if (d->input_buffer) mpp_buffer_put(d->input_buffer);
    if (d->output_buffer) mpp_buffer_put(d->output_buffer);
    if (d->input_group) mpp_buffer_group_put(d->input_group);
    if (d->output_group) mpp_buffer_group_put(d->output_group);
    free(d);
}

const char *stream_mpp_error(const stream_mpp_decoder *d)
{
    return d ? d->error : "decoder not open";
}

int stream_mpp_copy_nv12(void *borrowed_frame, uint8_t *dest, size_t capacity)
{
    MppFrame frame = (MppFrame)borrowed_frame;
    MppBuffer buffer;
    size_t bytes;
    void *ptr;
    int ret;
    if (!frame || !dest || mpp_frame_get_fmt(frame) != MPP_FMT_YUV420SP) return -1;
    buffer = mpp_frame_get_buffer(frame);
    bytes = (size_t)mpp_frame_get_hor_stride(frame) *
            mpp_frame_get_ver_stride(frame) * 3 / 2;
    if (!buffer || bytes > capacity || bytes > mpp_buffer_get_size(buffer)) return -1;
    ptr = mpp_buffer_get_ptr(buffer);
    if (!ptr) return -1;
    ret = mpp_buffer_sync_begin(buffer);
    if (ret) return ret;
    memcpy(dest, ptr, bytes);
    return mpp_buffer_sync_end(buffer);
}

int stream_mpp_open(stream_mpp_decoder **out, uint32_t max_width,
                    uint32_t max_height, size_t max_jpeg, int timeout_ms)
{
    stream_mpp_decoder *d;
    MppFrameFormat format = MPP_FMT_YUV420SP;
    size_t stride, rows, output_size;
    int ret;
    if (!out) return -1;
    *out = NULL;
    if (!max_width || !max_height || max_width > 65535 || max_height > 65535 ||
        max_jpeg < 4 || max_jpeg > SIZE_MAX - 1024 || timeout_ms <= 0 ||
        timeout_ms >= MPP_POLL_MAX) return -1;
    /* Conservative fixed allocation (official JPEG example uses 4*aligned
     * pixels). Wider alignment covers the requested maximum, not header lies. */
    stride = ((size_t)max_width + 255) & ~(size_t)255;
    rows = ((size_t)max_height + 15) & ~(size_t)15;
    if (stride > SIZE_MAX / rows / 4) return -1;
    output_size = stride * rows * 4;
    d = calloc(1, sizeof(*d));
    if (!d) return -1;
    d->max_width = max_width;
    d->max_height = max_height;
    d->max_jpeg = max_jpeg;
    d->timeout_ms = timeout_ms;
#define OPEN_CALL(call) do { ret = (call); if (ret) goto error; } while (0)
    OPEN_CALL(mpp_create(&d->ctx, &d->mpi));
    OPEN_CALL(mpp_init(d->ctx, MPP_CTX_DEC, MPP_VIDEO_CodingMJPEG));
    OPEN_CALL(d->mpi->control(d->ctx, MPP_DEC_SET_OUTPUT_FORMAT, &format));
    OPEN_CALL(mpp_buffer_group_get_internal(&d->input_group, MPP_BUFFER_TYPE_DRM));
    OPEN_CALL(mpp_buffer_group_get_internal(&d->output_group, MPP_BUFFER_TYPE_DRM));
    OPEN_CALL(mpp_buffer_get(d->input_group, &d->input_buffer, max_jpeg + 1024));
    OPEN_CALL(mpp_buffer_get(d->output_group, &d->output_buffer, output_size));
#undef OPEN_CALL
    *out = d;
    return 0;
error:
    stream_mpp_close(d);
    return ret ? ret : -1;
}

int stream_mpp_decode(stream_mpp_decoder *d, const uint8_t *jpeg,
                      size_t length, uint32_t width, uint32_t height,
                      stream_mpp_result *result, stream_mpp_consumer consumer,
                      void *opaque)
{
    MppTask task = NULL;
    MppFrame output = NULL;
    MppFrame expected_frame = NULL;
    MppPacket returned = NULL;
    MppBuffer buffer;
    void *ptr;
    int ret, consumer_ret = 0;
    if (!d || !result) return -1;
    if (d->poisoned) return -1;
    if (!jpeg || length < 4 || length > d->max_jpeg || !width || !height ||
        width > d->max_width || height > d->max_height ||
        jpeg[0] != 0xff || jpeg[1] != 0xd8 ||
        jpeg[length - 2] != 0xff || jpeg[length - 1] != 0xd9)
        return failed(d, "JPEG bounds/markers", -1);
    memset(result, 0, sizeof(*result));
    ptr = mpp_buffer_get_ptr(d->input_buffer);
    if (!ptr) return failed(d, "input buffer map", -1);
#define CALL(phase, call) do { ret = (call); if (ret) return failed(d, phase, ret); } while (0)
    CALL("input CPU sync begin", mpp_buffer_sync_begin(d->input_buffer));
    memcpy(ptr, jpeg, length);
    memset((uint8_t *)ptr + length, 0, 1024);
    CALL("input CPU sync end", mpp_buffer_sync_end(d->input_buffer));
    CALL("packet init", mpp_packet_init_with_buffer(&d->packet, d->input_buffer));
    mpp_packet_set_pos(d->packet, ptr);
    mpp_packet_set_length(d->packet, length);
    /* No EOS per JPEG: this context processes a continuous sequence. */
    CALL("frame init", mpp_frame_init(&d->frame));
    mpp_frame_set_buffer(d->frame, d->output_buffer);
    expected_frame = d->frame;
    CALL("input poll", d->mpi->poll(d->ctx, MPP_PORT_INPUT, (MppPollType)d->timeout_ms));
    CALL("input dequeue", d->mpi->dequeue(d->ctx, MPP_PORT_INPUT, &task));
    if (!task) return failed(d, "missing input task", -1);
    CALL("set input packet", mpp_task_meta_set_packet(task, KEY_INPUT_PACKET, d->packet));
    CALL("set output frame", mpp_task_meta_set_frame(task, KEY_OUTPUT_FRAME, d->frame));
    CALL("input enqueue", d->mpi->enqueue(d->ctx, MPP_PORT_INPUT, task));
    /* Successful enqueue transfers the frame to MPP. On enqueue failure the
     * dequeued task stays caller-held; queue teardown does not free its frame. */
    d->frame = NULL;
    task = NULL;
    CALL("output poll", d->mpi->poll(d->ctx, MPP_PORT_OUTPUT, (MppPollType)d->timeout_ms));
    CALL("output dequeue", d->mpi->dequeue(d->ctx, MPP_PORT_OUTPUT, &task));
    if (!task) return failed(d, "missing output task", -1);
    CALL("get output frame", mpp_task_meta_get_frame(task, KEY_OUTPUT_FRAME, &output));
    /* get_frame consumes the metadata entry: reclaim before any validation. */
    d->frame = output;
    if (output != expected_frame) return failed(d, "output frame identity", -1);
    result->width = mpp_frame_get_width(output);
    result->height = mpp_frame_get_height(output);
    result->hor_stride = mpp_frame_get_hor_stride(output);
    result->ver_stride = mpp_frame_get_ver_stride(output);
    result->format = mpp_frame_get_fmt(output);
    result->errinfo = mpp_frame_get_errinfo(output);
    result->discard = mpp_frame_get_discard(output);
    buffer = mpp_frame_get_buffer(output);
    result->buffer_size = buffer ? mpp_buffer_get_size(buffer) : 0;
    if (!buffer || result->errinfo || result->discard ||
        result->width != width || result->height != height ||
        result->format != MPP_FMT_YUV420SP ||
        result->hor_stride < width || result->ver_stride < height ||
        (uint64_t)result->hor_stride * result->ver_stride * 3 / 2 > result->buffer_size)
        return failed(d, "decoded frame validation", -1);
    if (consumer) consumer_ret = consumer(opaque, output, result);
    CALL("output recycle", d->mpi->enqueue(d->ctx, MPP_PORT_OUTPUT, task));
    task = NULL;
    /* Observe input ownership return before deinit or buffer reuse. */
    CALL("input return poll", d->mpi->poll(d->ctx, MPP_PORT_INPUT, (MppPollType)d->timeout_ms));
    CALL("input return dequeue", d->mpi->dequeue(d->ctx, MPP_PORT_INPUT, &task));
    if (!task) return failed(d, "missing returned input task", -1);
    CALL("returned packet", mpp_task_meta_get_packet(task, KEY_INPUT_PACKET, &returned));
    if (returned != d->packet) return failed(d, "input packet identity", -1);
    CALL("clear input packet", mpp_task_meta_set_packet(task, KEY_INPUT_PACKET, NULL));
    CALL("clear output frame", mpp_task_meta_set_frame(task, KEY_OUTPUT_FRAME, NULL));
    CALL("packet release", mpp_packet_deinit(&d->packet));
    CALL("input empty recycle", d->mpi->enqueue(d->ctx, MPP_PORT_INPUT, task));
    CALL("frame release", mpp_frame_deinit(&d->frame));
#undef CALL
    if (consumer_ret) return failed(d, "frame consumer", consumer_ret);
    return 0;
}
