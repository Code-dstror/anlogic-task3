"""Optional bounded NV12 -> GStreamer kmssink presentation; no JPEG decode."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import os
import queue
import re
import selectors
import subprocess
import threading
import time

from .decoder import DecodedFrame


class PresentationError(RuntimeError):
    pass


def _copy_identity(identity: dict | None) -> dict | None:
    """Copy at most eight validated flat scalar fields, without user hooks."""
    if identity is None:
        return None
    if type(identity) is not dict or len(identity) > 8:
        raise PresentationError("identity must be None or a plain dict with at most eight fields")
    copied = {}
    for index, (key, value) in enumerate(identity.items()):
        # The per-entry limit also bounds copying if another thread mutates input.
        if index >= 8 or type(key) is not str or len(key) > 32:
            raise PresentationError("identity keys must be plain strings of at most 32 characters")
        kind = type(value)
        if not (value is None or kind is bool or
                kind is int and 0 <= value <= 0xffffffffffffffff or
                kind is str and len(value) <= 128):
            raise PresentationError("identity values must be None/bool/uint64/short plain strings")
        copied[key] = value
    return copied


@dataclass(frozen=True)
class _OwnedFrame:
    pixels: bytes
    identity: dict | None


def pack_nv12(frame: DecodedFrame) -> bytes:
    """Remove MPP horizontal/vertical padding from Y and interleaved UV."""
    w, h, stride, rows = frame.width, frame.height, frame.hor_stride, frame.ver_stride
    if frame.nv12 is None:
        raise PresentationError("MPP NV12 copy is required for presentation")
    if min(w, h) <= 0 or w % 2 or h % 2 or stride < w or rows < h or rows % 2:
        raise PresentationError("unsupported NV12 dimensions/stride")
    required = stride * rows * 3 // 2
    if len(frame.nv12) < required:
        raise PresentationError("truncated stride-padded MPP NV12 buffer")
    source = memoryview(frame.nv12)
    packed = bytearray(w * h * 3 // 2)
    target = memoryview(packed)
    for row in range(h):
        target[row * w:(row + 1) * w] = source[row * stride:row * stride + w]
    uv_source, uv_target = stride * rows, w * h
    for row in range(h // 2):
        target[uv_target + row * w:uv_target + (row + 1) * w] = \
            source[uv_source + row * stride:uv_source + row * stride + w]
    return bytes(packed)


def gst_command(*, width: int, height: int, connector_id: int, plane_id: int | None,
                driver_name: str, force_modesetting: bool, fps: int = 60,
                colorimetry: str | None = None, executable: str = "gst-launch-1.0") -> list[str]:
    if width <= 0 or height <= 0 or width % 2 or height % 2 or fps <= 0:
        raise ValueError("presentation requires positive even NV12 dimensions and positive fps")
    if connector_id < 0 or (plane_id is not None and plane_id < 0):
        raise ValueError("connector and plane IDs must be explicit nonnegative IDs")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", driver_name):
        raise ValueError("invalid DRM driver name")
    if colorimetry is not None and not re.fullmatch(r"[A-Za-z0-9_:.-]+", colorimetry):
        raise ValueError("invalid GStreamer colorimetry")
    command = [executable, "-q", "fdsrc", "fd=0", "!", "rawvideoparse",
               f"width={width}", f"height={height}", "format=nv12", f"framerate={fps}/1",
               f"plane-strides=<{width},{width}>", f"plane-offsets=<0,{width * height}>",
               f"frame-size={width * height * 3 // 2}"]
    if colorimetry:
        command.append(f"colorimetry={colorimetry}")
    command += ["!", "queue", "max-size-buffers=2", "max-size-bytes=0", "max-size-time=0",
                "leaky=downstream", "!", "kmssink", f"driver-name={driver_name}",
                f"connector-id={connector_id}", "sync=false",
                f"force-modesetting={'true' if force_modesetting else 'false'}"]
    if plane_id is not None:
        command.append(f"plane-id={plane_id}")
    return command


class LatestFrames:
    """Drop only whole queued frames; a partially written frame cannot be skipped."""
    def __init__(self, depth: int):
        if not 1 <= depth <= 8:
            raise ValueError("presentation queue depth must be 1..8")
        self.queue: queue.Queue[bytes | _OwnedFrame] = queue.Queue(depth)
        self.lock = threading.Lock()
        self.submitted = self.dropped = 0

    def put(self, data: bytes | _OwnedFrame) -> None:
        with self.lock:
            self.submitted += 1
            try:
                self.queue.put_nowait(data)
            except queue.Full:
                try:
                    self.queue.get_nowait()
                    self.dropped += 1
                except queue.Empty:
                    pass
                self.queue.put_nowait(data)


class GstKmsPresenter:
    def __init__(self, *, width: int, height: int, connector_id: int,
                 plane_id: int | None = None, driver_name: str = "rockchip",
                 force_modesetting: bool = False, queue_depth: int = 2,
                 write_timeout_s: float = 2, colorimetry: str | None = None):
        if write_timeout_s <= 0:
            raise ValueError("presentation write timeout must be positive")
        self.width, self.height = width, height
        self.connector_id, self.plane_id = connector_id, plane_id
        self.driver_name, self.force_modesetting = driver_name, force_modesetting
        self.colorimetry = colorimetry
        self.command = gst_command(width=width, height=height, connector_id=connector_id,
                                   plane_id=plane_id, driver_name=driver_name,
                                   force_modesetting=force_modesetting, colorimetry=colorimetry)
        self.frames = LatestFrames(queue_depth)
        self.write_timeout_s = write_timeout_s
        self.lock = threading.Lock()
        self._submit_lock = threading.Lock()
        self.error: str | None = None
        self.stderr_tail: deque[str] = deque(maxlen=8)
        self.written = 0
        self.last_written_identity: dict | None = None
        self.last_written_monotonic_ns: int | None = None
        self.writing_identity: dict | None = None
        self.writing_bytes = 0
        self.closing = threading.Event()
        self.closed = False
        # Plugin probes happen before C2H opens; no implicit installation/fallback.
        for element in ("fdsrc", "rawvideoparse", "queue", "kmssink"):
            try:
                probe = subprocess.run(["gst-inspect-1.0", element], stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL, timeout=3, check=False)
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise PresentationError(f"GStreamer {element} unavailable: {exc}") from exc
            if probe.returncode:
                raise PresentationError(f"GStreamer plugin {element} unavailable")
        try:
            self.process = subprocess.Popen(self.command, stdin=subprocess.PIPE,
                                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                            bufsize=0, start_new_session=True)
        except OSError as exc:
            raise PresentationError(f"cannot launch GStreamer KMS presenter: {exc}") from exc
        assert self.process.stdin is not None and self.process.stderr is not None
        os.set_blocking(self.process.stdin.fileno(), False)
        self.stderr_thread = threading.Thread(target=self._stderr, name="kms-stderr", daemon=True)
        self.writer_thread = threading.Thread(target=self._writer, name="kms-nv12", daemon=True)
        self.stderr_thread.start()
        self.writer_thread.start()

    def _stderr(self) -> None:
        assert self.process.stderr is not None
        while True:
            chunk = self.process.stderr.readline(512)
            if not chunk:
                return
            text = chunk.decode("utf-8", "replace").strip()
            with self.lock:
                self.stderr_tail.append(text[:256])
                if text.startswith("ERROR") and self.error is None:
                    self.error = text[:256]

    def _writer(self) -> None:
        assert self.process.stdin is not None
        fd = self.process.stdin.fileno()
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(fd, selectors.EVENT_WRITE)
                while not self.closing.is_set() or not self.frames.queue.empty():
                    try:
                        packet = self.frames.queue.get(timeout=0.05)
                    except queue.Empty:
                        self.check()
                        continue
                    data = packet.pixels if isinstance(packet, _OwnedFrame) else packet
                    identity = packet.identity if isinstance(packet, _OwnedFrame) else None
                    with self.lock:
                        self.writing_identity, self.writing_bytes = identity, 0
                    pending, deadline = memoryview(data), time.monotonic() + self.write_timeout_s
                    while pending:
                        self.check()
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise PresentationError("KMS input pipe frame-write timeout")
                        if not selector.select(min(remaining, 0.05)):
                            continue
                        try:
                            written = os.write(fd, pending)
                        except BlockingIOError:
                            continue
                        if written <= 0:
                            raise PresentationError("KMS input pipe stopped accepting frames")
                        pending = pending[written:]
                        with self.lock:
                            self.writing_bytes += written
                    with self.lock:
                        self.written += 1
                        self.last_written_identity = identity
                        self.last_written_monotonic_ns = time.monotonic_ns()
                        self.writing_identity, self.writing_bytes = None, 0
                    # Keep only descriptive last-written metadata while idle.
                    del pending, data, packet, identity
        except Exception as exc:
            with self.lock:
                self.error = self.error or f"{type(exc).__name__}: {exc}"[:256]
        finally:
            self.process.stdin.close()  # EOF only at whole-frame boundary or explicit failure.

    def check(self) -> None:
        code = self.process.poll()
        with self.lock:
            if self.error:
                raise PresentationError(self.error)
            if code is not None and not self.closed:
                tail = "; ".join(self.stderr_tail)[-512:]
                raise PresentationError(f"GStreamer KMS exited ({code}): {tail}")

    def submit(self, frame: DecodedFrame) -> None:
        self.check()
        if self.closing.is_set():
            raise PresentationError("KMS presenter is closing")
        if (frame.width, frame.height) != (self.width, self.height):
            raise PresentationError("decoded geometry differs from configured HDMI input")
        self.submit_owned(pack_nv12(frame))

    def submit_owned(self, data: bytes, *, identity: dict | None = None) -> None:
        """Queue one owned tight NV12 frame with descriptive input identity.

        Identity is None or a plain flat dict: <=8 plain string keys (<=32 chars),
        with None/bool/uint64/plain string (<=128 chars) values. Unknown short
        keys are descriptive metadata and authenticate nothing. No user copying
        hooks are invoked. Identity is retained through partial pipe writes. A completed
        write proves only delivery to GStreamer stdin, never physical scanout.
        Existing submit(DecodedFrame) keeps its synchronous packing behavior.
        """
        if type(data) is not bytes or len(data) != self.width * self.height * 3 // 2:
            raise PresentationError("expected exact owned tightly packed NV12 bytes")
        owned_identity = _copy_identity(identity)
        with self._submit_lock:
            self.check()
            if self.closing.is_set():
                raise PresentationError("KMS presenter is closing")
            self.frames.put(_OwnedFrame(data, owned_identity))

    def snapshot(self) -> dict[str, object]:
        with self.frames.lock, self.lock:
            return {"hdmi_frames_submitted": self.frames.submitted,
                    "hdmi_connector_id": self.connector_id, "hdmi_plane_id": self.plane_id,
                    "hdmi_driver_name": self.driver_name,
                    "hdmi_colorimetry": self.colorimetry,
                    "hdmi_force_modesetting": self.force_modesetting,
                    "hdmi_frames_written": self.written, "hdmi_queue_dropped": self.frames.dropped,
                    "hdmi_queue_records": self.frames.queue.qsize(),
                    "hdmi_last_written_identity": (self.last_written_identity.copy()
                                                   if self.last_written_identity is not None else None),
                    "hdmi_last_written_monotonic_ns": self.last_written_monotonic_ns,
                    "hdmi_writing_identity": (self.writing_identity.copy()
                                              if self.writing_identity is not None else None),
                    "hdmi_writing_bytes": self.writing_bytes,
                    "hdmi_writer_alive": self.writer_thread.is_alive(),
                    "hdmi_presented_frames": "UNVERIFIED", "hdmi_error": self.error,
                    "hdmi_process_returncode": self.process.poll(),
                    "hdmi_stderr_tail": list(self.stderr_tail)}

    def close(self, timeout_s: float = 3) -> None:
        if self.closed:
            return
        with self._submit_lock:
            self.closing.set()
        self.writer_thread.join(timeout_s)
        try:
            self.process.wait(timeout=max(0.1, timeout_s))
        except subprocess.TimeoutExpired:
            with self.lock:
                self.error = self.error or "GStreamer did not complete presentation/EOS within shutdown bound"
            self.process.terminate()  # Display-only child; never touch the C2H reader/process.
            try:
                self.process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=1)
        self.writer_thread.join(0.1)
        self.stderr_thread.join(0.1)
        if self.writer_thread.is_alive():
            with self.lock:
                self.error = self.error or "KMS writer still owns an unfinished frame after close bound"
            raise PresentationError(self.error)
        if self.process.returncode:
            with self.lock:
                self.error = self.error or f"GStreamer KMS exited ({self.process.returncode})"
        self.closed = True
        if self.error:
            raise PresentationError(self.error)
