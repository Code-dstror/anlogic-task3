"""Synchronous persistent MPP hardware decoder; no software fallback."""
from __future__ import annotations

import ctypes as C
from dataclasses import dataclass
from pathlib import Path
import threading
import time
from typing import Iterable, Iterator

from linux.task3_pipeline import pcie_protocol_v1 as protocol
from .records import Record, RecordError, parse_record


class MppError(RuntimeError):
    pass


class _Result(C.Structure):
    _fields_ = [(name, C.c_uint32) for name in
                ("width", "height", "hor_stride", "ver_stride", "format",
                 "errinfo", "discard")] + [("buffer_size", C.c_uint64)]


_Consumer = C.CFUNCTYPE(C.c_int, C.c_void_p, C.c_void_p, C.POINTER(_Result))


@dataclass(frozen=True)
class DecodedFrame:
    sequence: int
    width: int
    height: int
    hor_stride: int
    ver_stride: int
    format: int
    buffer_size: int
    decode_ns: int
    nv12: bytes | None = None


class PersistentMppDecoder:
    """Call decode_record after a complete DMA read has returned ownership.

    One context and two fixed DMA buffers span all calls. Calls serialize;
    caller queues must also have a finite capacity. Native frame ownership is
    held until optional NV12 copying completes. Errors close the decoder.
    """
    def __init__(self, library: Path | str, *, max_width: int, max_height: int,
                 timeout_ms: int, max_payload: int = protocol.MAX_PAYLOAD):
        if not 1 <= max_width <= 65535 or not 1 <= max_height <= 65535:
            raise ValueError("max dimensions must be 1..65535")
        if not 1 <= timeout_ms < 8000:
            raise ValueError("MPP task timeout_ms must be 1..7999")
        if not 4 <= max_payload <= protocol.MAX_PAYLOAD:
            raise ValueError("max_payload exceeds AJPG bounds")
        self._lock = threading.Lock()
        self._handle = C.c_void_p()
        self._max_width, self._max_height = max_width, max_height
        self._max_payload = max_payload
        try:
            self._lib = C.CDLL(str(Path(library).resolve()))
        except OSError as exc:
            raise MppError(f"Rockchip MPP library unavailable: {exc}") from exc
        lib = self._lib
        lib.stream_mpp_open.argtypes = [C.POINTER(C.c_void_p), C.c_uint32,
                                        C.c_uint32, C.c_size_t, C.c_int]
        lib.stream_mpp_open.restype = C.c_int
        lib.stream_mpp_decode.argtypes = [C.c_void_p, C.c_void_p, C.c_size_t,
                                         C.c_uint32, C.c_uint32, C.POINTER(_Result),
                                         _Consumer, C.c_void_p]
        lib.stream_mpp_decode.restype = C.c_int
        lib.stream_mpp_error.argtypes = [C.c_void_p]
        lib.stream_mpp_error.restype = C.c_char_p
        lib.stream_mpp_close.argtypes = [C.c_void_p]
        lib.stream_mpp_close.restype = None
        lib.stream_mpp_copy_nv12.argtypes = [C.c_void_p, C.c_void_p, C.c_size_t]
        lib.stream_mpp_copy_nv12.restype = C.c_int
        ret = lib.stream_mpp_open(C.byref(self._handle), max_width, max_height,
                                  max_payload, timeout_ms)
        if ret or not self._handle.value:
            raise MppError(f"MPP MJPEG hardware context/DRM buffers init failed: {ret}")

    def _close_locked(self) -> None:
        if self._handle.value:
            self._lib.stream_mpp_close(self._handle)
            self._handle = C.c_void_p()

    def close(self) -> None:
        with self._lock:
            self._close_locked()

    def __enter__(self) -> PersistentMppDecoder:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def decode_record(self, data: bytes, *, copy_nv12: bool = False,
                      expected_version: int = protocol.PROTOCOL_VERSION) -> DecodedFrame:
        record = parse_record(data, expected_version=expected_version)  # Reject before touching MPP.
        if (record.width > self._max_width or record.height > self._max_height
                or len(record.jpeg) > self._max_payload):
            raise RecordError("record exceeds configured decoder buffer bounds")
        with self._lock:
            if not self._handle.value:
                raise MppError("decoder closed; explicit reinitialization required")
            return self._decode(record, copy_nv12)

    def _decode(self, record: Record, copy_nv12: bool) -> DecodedFrame:
        pixels: list[bytes] = []
        copy_error: list[str] = []

        @_Consumer
        def consume(_opaque: object, frame: object, metadata: C.POINTER(_Result)) -> int:
            if not copy_nv12:
                return 0
            try:
                result = metadata.contents
                size = result.hor_stride * result.ver_stride * 3 // 2
                buffer = C.create_string_buffer(size)
                ret = self._lib.stream_mpp_copy_nv12(frame, buffer, size)
                if ret:
                    copy_error.append(f"NV12 CPU sync/copy failed: {ret}")
                    return -1
                pixels.append(buffer.raw)
                return 0
            except Exception as exc:
                copy_error.append(str(exc)[:192])
                return -1

        result = _Result()
        packet = C.create_string_buffer(record.jpeg)
        started_ns = time.perf_counter_ns()
        ret = self._lib.stream_mpp_decode(self._handle, packet, len(record.jpeg),
                                          record.width, record.height, C.byref(result),
                                          consume, None)
        decode_ns = time.perf_counter_ns() - started_ns
        if ret:
            error = self._lib.stream_mpp_error(self._handle)
            message = error.decode("utf-8", "replace") if error else f"MPP failed: {ret}"
            self._close_locked()
            raise MppError(copy_error[0] if copy_error else message)
        return DecodedFrame(record.sequence, result.width, result.height,
                            result.hor_stride, result.ver_stride, result.format,
                            result.buffer_size, decode_ns, pixels[0] if pixels else None)

    def decode_records(self, records: Iterable[bytes], *, copy_nv12: bool = False,
                       expected_version: int = protocol.PROTOCOL_VERSION
                       ) -> Iterator[DecodedFrame]:
        for data in records:
            yield self.decode_record(data, copy_nv12=copy_nv12, expected_version=expected_version)
