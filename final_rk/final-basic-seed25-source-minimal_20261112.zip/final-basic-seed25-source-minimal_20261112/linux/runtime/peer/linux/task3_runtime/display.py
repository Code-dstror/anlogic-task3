"""Bounded owned-frame display and exact-source optional result overlay.

No decoder/model/device discovery here. submit never packs pixels, waits for an
inference result or writes a pipe. Written identities describe GStreamer input;
they do not prove physical presentation or sensor-to-display latency.
"""
from __future__ import annotations

from collections import deque
from dataclasses import asdict
import math
from threading import Condition, Lock, Thread
import time

from linux.pixel_native import MAX_HEIGHT, MAX_ROWS, MAX_STRIDE, MAX_WIDTH
from linux.vision_api.inference import CompletedInference
from .pipeline import DisplayFrame, SourceKey


class DisplayError(RuntimeError):
    pass


def _validate(envelope: DisplayFrame) -> int:
    if not isinstance(envelope, DisplayFrame) or not isinstance(envelope.key, SourceKey):
        raise ValueError("display requires an owned DisplayFrame with SourceKey")
    key, frame, record = envelope.key, envelope.decoded, envelope.record
    if (not isinstance(key.receiver_cohort, str) or not 1 <= len(key.receiver_cohort) <= 128
            or type(key.camera) is not int or key.camera != 0
            or type(key.sequence) is not int or not 0 <= key.sequence <= 0xffffffff):
        raise ValueError("invalid display receiver/source identity")
    source = (key.session, key.epoch, key.jpeg_generation)
    if source != (None, None, None) and any(type(value) is not int or not 0 <= value <= 0xffffffff
                                          for value in source):
        raise ValueError("partial or invalid SOURCE/generation identity")
    if SourceKey.from_record(key.receiver_cohort, record) != key:
        raise ValueError("display identity differs from its exact record")
    width, height, stride, rows = frame.width, frame.height, frame.hor_stride, frame.ver_stride
    if (any(type(value) is not int or value <= 0 or value % 2
            for value in (width, height, stride, rows))
            or width > MAX_WIDTH or height > MAX_HEIGHT or stride > MAX_STRIDE or rows > MAX_ROWS
            or stride < width or rows < height
            or (frame.sequence, width, height) != (key.sequence, record.width, record.height)
            or type(frame.nv12) is not bytes or len(frame.nv12) != stride * rows * 3 // 2
            or type(record.jpeg) is not bytes):
        raise ValueError("display requires matching complete owned MPP NV12/record")
    if (any(type(value) is not int or value < 0
            for value in (envelope.host_dispatch_ns, envelope.decoded_ns))
            or envelope.decoded_ns < envelope.host_dispatch_ns):
        raise ValueError("invalid host display timestamps")
    return len(frame.nv12) + len(record.jpeg)


class DisplayWorker:
    """One packing/overlay worker and a bounded queue of complete owned copies.

    presenter must have explicit colorimetry and submit_owned/check/close/snapshot;
    pixels is NativePixels or the same synchronous owned-byte pack contract.
    broker must belong to this receiver's runtime and must not be reused across
    receiver cohorts. An overlay callback is optional and performs no inference.
    It receives (original DisplayFrame, matching CompletedInference), and returns
    tight NV12 bytes, an owned decoded frame, or a DisplayFrame with the same key.
    It must never relabel another image. At lookup, missing/stale/wrong results
    use the original image immediately. Slow callbacks hold only owned CPU copies.
    Optional display_delay_s (0..0.1, default0) holds the current owned frame
    until its decoded host timestamp plus that budget before looking up a
    result. It never blocks submit/DMA and never makes a result valid. close
    interrupts the wait, then the existing active-frame completion rule applies.
    Queue depth remains1..8; delayed high-rate display should budget more slots.
    """
    def __init__(self, presenter, pixels, *, broker=None, overlay=None, depth=2,
                 max_frame_bytes=32 * 1024 * 1024, clock=time.monotonic_ns, display_delay_s=0):
        if type(depth) is not int or not 1 <= depth <= 8:
            raise ValueError("display queue depth must be 1..8")
        if type(max_frame_bytes) is not int or not 1 <= max_frame_bytes <= 64 * 1024 * 1024:
            raise ValueError("invalid display copy bound")
        if not isinstance(getattr(presenter, "colorimetry", None), str) or not presenter.colorimetry:
            raise ValueError("runtime display requires explicit GStreamer colorimetry")
        if overlay is not None and (not callable(overlay) or broker is None):
            raise ValueError("overlay callback requires an inference broker")
        if (type(display_delay_s) not in (int, float) or not math.isfinite(display_delay_s)
                or not 0 <= display_delay_s <= .1):
            raise ValueError("display delay must be a finite 0..0.1 seconds")
        self.presenter, self.pixels, self.broker, self.overlay = presenter, pixels, broker, overlay
        self.depth, self.max_frame_bytes, self.clock = depth, max_frame_bytes, clock
        self.display_delay_s = display_delay_s
        self._delay_ns = round(display_delay_s * 1e9)
        self._cv, self._close_lock = Condition(), Lock()
        self._queue, self._cohort = deque(), None
        self._closing = self._closed = self._close_incomplete = False
        self._error = self._close_error = None
        self._inflight = self._last_submitted = self._last_failed = None
        self._inflight_bytes = self._pending_bytes = 0
        self._submitted = self._dropped = self._close_dropped = self._processed = 0
        self._overlay_applied = self._overlay_missing = self._overlay_rejected = 0
        self._last_overlay_rejection = None
        self._delay_waiting = False
        self._delay_wait_frames = self._delay_wait_ns = self._delay_max_wait_ns = 0
        self._delay_close_interrupts = 0
        self._thread = Thread(target=self._run, name="runtime-display-owned", daemon=True)
        self._thread.start()

    def submit(self, envelope: DisplayFrame) -> bool:
        size = _validate(envelope)
        if size > self.max_frame_bytes:
            raise ValueError("display copy exceeds configured byte bound")
        if (envelope.decoded.width, envelope.decoded.height) != (self.presenter.width, self.presenter.height):
            raise ValueError("display geometry differs from explicitly configured presenter")
        with self._cv:
            if self._closing or self._error:
                raise DisplayError(self._error or "display worker is closing")
            if self._cohort is not None and envelope.key.receiver_cohort != self._cohort:
                raise ValueError("new receiver cohort requires a new display worker/broker")
            self._cohort = envelope.key.receiver_cohort
            if len(self._queue) == self.depth:
                _, removed = self._queue.popleft()
                self._pending_bytes -= removed
                self._dropped += 1
            self._queue.append((envelope, size))
            self._pending_bytes += size
            self._submitted += 1
            self._cv.notify()
        return True

    def _delay(self, envelope):
        if not self._delay_ns:
            return
        now = self.clock()
        if type(now) is not int or now < 0:
            raise ValueError("display delay requires host monotonic nanoseconds")
        # Timestamp age consumes the budget. Clamp future/injected timestamps to
        # the configured bound, and use a real monotonic timeout so a stalled
        # injected observation clock cannot turn this into an unbounded wait.
        remaining = min(self._delay_ns, max(0, envelope.decoded_ns + self._delay_ns - now))
        if not remaining:
            return
        end = time.monotonic_ns() + remaining
        with self._cv:
            remaining = max(0, end - time.monotonic_ns())
            if not remaining:
                return
            self._delay_waiting = True
            self._delay_wait_frames += 1
            started = time.monotonic_ns()
            interrupted = self._cv.wait_for(lambda: self._closing, timeout=remaining / 1e9)
            waited = time.monotonic_ns() - started
            self._delay_waiting = False
            self._delay_wait_ns += waited
            self._delay_max_wait_ns = max(self._delay_max_wait_ns, waited)
            if interrupted:
                self._delay_close_interrupts += 1

    def _matched(self, envelope, completed):
        try:
            if not isinstance(completed, CompletedInference):
                return False
            meta, result = completed.ticket.meta, completed.result
            source, key = meta.source_metadata, envelope.key
            return (source is not None and
                    (source.stamp.session_id, source.stamp.mode_epoch, source.stamp.camera_id,
                     source.stamp.sequence, source.jpeg_generation) ==
                    (key.session, key.epoch, key.camera, key.sequence, key.jpeg_generation)
                    and (meta.width, meta.height) == (envelope.decoded.width, envelope.decoded.height)
                    and result.frame_ref == meta.ref and result.profile_id == meta.profile_id
                    and result.coordinate_space == "source"
                    and completed.ticket.deadline_ns > self.clock())
        except (AttributeError, TypeError, ValueError):
            return False

    def _tight(self, envelope):
        frame = envelope.decoded
        if self.overlay is not None:
            key = envelope.key
            completed = (None if key.session is None else self.broker.lookup_source(
                session=key.session, epoch=key.epoch, camera=key.camera, sequence=key.sequence,
                jpeg_generation=key.jpeg_generation))
            if completed is None:
                with self._cv:
                    self._overlay_missing += 1
            elif not self._matched(envelope, completed):
                with self._cv:
                    self._overlay_rejected += 1
                    self._last_overlay_rejection = "inference result does not match this SOURCE/generation/geometry/ref"
            else:
                changed = self.overlay(envelope, completed)
                if isinstance(changed, DisplayFrame):
                    _validate(changed)
                    if changed.key != envelope.key:
                        raise DisplayError("overlay returned a different receiver/SOURCE/generation identity")
                    frame = changed.decoded
                elif type(changed) is bytes:
                    if len(changed) != frame.width * frame.height * 3 // 2:
                        raise DisplayError("overlay must return exact owned tightly packed NV12 bytes")
                    with self._cv:
                        self._overlay_applied += 1
                    return changed
                else:
                    # The trusted callback may return a new owned DecodedFrame.
                    changed_envelope = DisplayFrame(envelope.key, changed, envelope.record,
                                                    envelope.host_dispatch_ns, envelope.decoded_ns)
                    _validate(changed_envelope)
                    frame = changed
                if (frame.width, frame.height) != (envelope.decoded.width, envelope.decoded.height):
                    raise DisplayError("overlay changed display geometry")
                with self._cv:
                    self._overlay_applied += 1
        data = self.pixels.pack(frame.nv12, frame.width, frame.height, frame.hor_stride, frame.ver_stride)
        if type(data) is not bytes or len(data) != frame.width * frame.height * 3 // 2:
            raise DisplayError("native pack did not return exact owned tight NV12")
        return data

    def _run(self):
        while True:
            with self._cv:
                self._cv.wait_for(lambda: self._queue or self._closing)
                if not self._queue:
                    return
                envelope, size = self._queue.popleft()
                self._pending_bytes -= size
                self._inflight, self._inflight_bytes = envelope.key, size
            try:
                _validate(envelope)
                self.presenter.check()
                self._delay(envelope)
                data = self._tight(envelope)
                self.presenter.submit_owned(data, identity=asdict(envelope.key))
                with self._cv:
                    self._processed += 1
                    self._last_submitted = envelope.key
            except Exception as error:
                with self._cv:
                    self._error = f"{type(error).__name__}: {error}"[:256]
                    self._last_failed = envelope.key
                    self._dropped += len(self._queue)
                    self._queue.clear()
                    self._pending_bytes = 0
                return
            finally:
                with self._cv:
                    self._inflight, self._inflight_bytes = None, 0
            # No pending CPU frame/output is retained during an idle wait.
            del data, envelope

    def check(self):
        with self._cv:
            if self._error:
                raise DisplayError(self._error)
        self.presenter.check()

    def snapshot(self):
        with self._cv:
            result = dict(display_queue_depth=self.depth, display_queue_records=len(self._queue),
                          display_queue_bytes=self._pending_bytes, display_max_frame_bytes=self.max_frame_bytes,
                          display_submitted=self._submitted, display_queue_dropped=self._dropped,
                          display_close_dropped=self._close_dropped, display_packed_submitted=self._processed,
                          display_inflight_identity=asdict(self._inflight) if self._inflight else None,
                          display_inflight_bytes=self._inflight_bytes,
                          display_last_submitted_identity=asdict(self._last_submitted) if self._last_submitted else None,
                          display_last_failed_identity=asdict(self._last_failed) if self._last_failed else None,
                          display_overlay_applied=self._overlay_applied, display_overlay_missing=self._overlay_missing,
                          display_overlay_rejected=self._overlay_rejected,
                          display_overlay_rejection=self._last_overlay_rejection,
                          display_delay_s=self.display_delay_s,
                          display_delay_waiting=self._delay_waiting,
                          display_delay_wait_frames=self._delay_wait_frames,
                          display_delay_wait_ns=self._delay_wait_ns,
                          display_delay_max_wait_ns=self._delay_max_wait_ns,
                          display_delay_close_interrupts=self._delay_close_interrupts,
                          display_delay_scope="HOST_DISPLAY_BUDGET_NOT_REALTIME_OR_PHYSICAL_PRESENTATION",
                          display_error=self._error, display_close_error=self._close_error,
                          display_closing=self._closing, display_closed=self._closed,
                          display_close_incomplete=self._close_incomplete,
                          display_thread_alive=self._thread.is_alive(),
                          display_physical_presentation="UNVERIFIED")
        result.update(self.presenter.snapshot())
        return result

    def close(self, timeout_s=3):
        if type(timeout_s) not in (int, float) or not math.isfinite(timeout_s) or timeout_s <= 0:
            raise ValueError("display close timeout must be finite and positive")
        with self._close_lock:
            with self._cv:
                if self._closed:
                    return
                self._closing = True
                self._close_dropped += len(self._queue)
                self._dropped += len(self._queue)
                self._queue.clear()
                self._pending_bytes = 0
                self._cv.notify()
            deadline = time.monotonic() + timeout_s
            self._thread.join(timeout_s)
            if self._thread.is_alive():
                with self._cv:
                    self._close_incomplete = True
                    self._close_error = "display worker still owns an active CPU frame; close may be retried"
                raise DisplayError(self._close_error)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with self._cv:
                    self._close_incomplete = True
                    self._close_error = "display worker stopped; presenter close remains pending"
                raise DisplayError(self._close_error)
            try:
                self.presenter.close(timeout_s=remaining)
            except Exception as error:
                with self._cv:
                    self._close_incomplete = not bool(getattr(self.presenter, "closed", False))
                    self._closed = not self._close_incomplete
                    self._close_error = f"{type(error).__name__}: {error}"[:256]
                raise DisplayError(self._close_error) from error
            with self._cv:
                self._closed, self._close_incomplete, self._close_error = True, False, None
                failure = self._error
            if failure:
                raise DisplayError(failure)
