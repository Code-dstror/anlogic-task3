"""Single-camera Linux integration; imports never open devices or start workers."""
