"""Cold selection and bounded receive/drain over one existing C2H owner."""
from __future__ import annotations

import math
import time

from linux.task3_pipeline.config_transaction import ConfigTransactions
from linux.task3_pipeline.record_selection import select_record
from linux.task3_pipeline.product_receiver import ProductReceiver
from linux.task3_pipeline import pcie_protocol_v1 as p


class _ReadyBatch:
    """Uses the same Receiver; no second fd, lease table or MMIO owner."""
    def __init__(self, receiver):
        self.receiver = receiver
        self.capacity = receiver.capacity

    def receive(self, maximum):
        return self.receiver.receive_available(maximum)


class C2HSession:
    """Explicit state machine. Construct with an already opened nonblocking fd.

    Initial cold prepare selects exactly once. Normal STOP/RESUME preserves the
    CFG session and record version. Faults are terminal and never trigger reset,
    reselect, retry, close, RELEASE or a replacement owner automatically.
    Runtime control work must keep receive/drain progressing during CFG waits.
    """
    def __init__(self, receiver, *, jpeg_version: int, timeout_s: float,
                 reassembler=None, maximum_batch=4, clock=None, sleep=None,
                 lz_frame_timeout_s=None):
        if not math.isfinite(timeout_s) or timeout_s <= 0:
            raise ValueError('explicit finite transaction timeout required')
        self.receiver, self.version, self.timeout_s = receiver, jpeg_version, timeout_s
        self.reassembler, self.maximum_batch = reassembler, maximum_batch
        if reassembler is not None and (type(lz_frame_timeout_s) not in (int, float)
                or not math.isfinite(lz_frame_timeout_s) or lz_frame_timeout_s <= 0):
            raise ValueError('LZ requires an explicit finite application frame timeout')
        self._clock = clock or time.monotonic
        self._lz_timeout, self._lz_started = lz_frame_timeout_s, None
        self.lz_deadline_failures = 0
        self.products = ProductReceiver(_ReadyBatch(receiver), reassembler=reassembler,
                                        expected_jpeg_version=jpeg_version, max_batch=maximum_batch)
        self.state = 'NEW'
        self.transactions = self.selection = None
        self._resume_candidate = self._warm_receipt = None
        self._warm_boot_reader = None
        self.start_issued = False
        self._options = dict(timeout_s=timeout_s)
        if clock is not None:
            self._options['clock'] = clock
        if sleep is not None:
            self._options['sleep'] = sleep

    def _fault(self):
        self.state = 'FAULTED'
        self._lz_started = None
        self.products.fail_pending()
        self._resume_candidate = None

    def prepare_warm(self, receipt, *, boot_id, boot_id_reader=None):
        """Read-only same-probe attach; ARMED/backlog need not be cold-ready."""
        if self.state != 'NEW' or self.reassembler is not None:
            raise RuntimeError('warm attach requires a new JPEG-only session')
        from .warm_attach import validate_current
        try:
            selection = validate_current(self.receiver, receipt, boot_id=boot_id)
            if selection.version != self.version:
                raise RuntimeError('requested record version differs from warm receipt')
            self.transactions = ConfigTransactions(self.receiver, **self._options)
            if self.transactions.wait_session_ready() != selection.session:
                raise RuntimeError('warm source session changed')
            self.selection = selection
            self._warm_receipt = receipt
            self._warm_boot_reader = boot_id_reader or (lambda: boot_id)
            self.state = 'PREPARED'
            return selection
        except BaseException:
            self._fault()
            raise

    def capture_resume(self, *, boot_id, controls_idle):
        """Create only an in-memory candidate; close/report must still succeed."""
        from .warm_attach import capture_stopped
        self._resume_candidate = capture_stopped(self, boot_id=boot_id, controls_idle=controls_idle)
        return self._resume_candidate

    def prepare(self):
        if self.state != 'NEW':
            raise RuntimeError('cold preparation is allowed exactly once')
        try:
            info = self.receiver.snapshot()
            if not info.transport_drained or self.receiver.leased_count or self.receiver.poll(0):
                raise RuntimeError('cold preparation requires stopped transport without ready/leased records')
            # Legacy default-v1 selection deliberately performs no writes; it
            # still must not turn an armed old session into a new cold runtime.
            control = self.receiver.read32(p.PCIE_REG_CONTROL)
            status = self.receiver.read32(p.PCIE_REG_STATUS)
            busy = (p.PCIE_STATUS_C2H_RUNNING | p.PCIE_STATUS_TX_BUSY |
                    p.PCIE_STATUS_SOURCE_BUSY | p.PCIE_STATUS_SESSION_ARMED)
            if control & p.PCIE_CONTROL_APP_ENABLE or status & busy or not status & p.PCIE_STATUS_SESSION_REARM_READY:
                raise RuntimeError('cold preparation requires actual source-off rearm-ready state')
            self.transactions = ConfigTransactions(self.receiver, **self._options)
            session = self.transactions.wait_session_ready()
            self.selection = select_record(self.receiver, self.version, **self._options)
            if self.selection.session not in (0, session):
                raise RuntimeError('record selection source session mismatch')
            if self.reassembler is not None:
                epoch = self.receiver.read32(p.PCIE_REG_CFG_MODE_EPOCH)
                if (self.reassembler.session_id, self.reassembler.stream_epoch) != (session, epoch):
                    raise RuntimeError('LZ owner does not match real CFG session/epoch')
                caps = self.transactions.mono_capabilities()
                if not caps.modes & (1 << p.PCIE_CFG_V2_MODES_MONO_SDR_LZ):
                    raise RuntimeError('running profile does not advertise continuous LZ')
            self.state = 'PREPARED'
            return self.selection
        except BaseException:
            self._fault()
            raise

    def start(self):
        if self.state not in ('PREPARED', 'STOPPED'):
            raise RuntimeError('session cannot START in this state')
        try:
            if self._warm_receipt is not None:
                from .warm_attach import validate_current
                validate_current(self.receiver, self._warm_receipt, boot_id=self._warm_boot_reader())
            # BOOT/session must remain stable; normal resume never SELECTs.
            if self.transactions.wait_session_ready() != self.transactions.session:
                raise RuntimeError('source session changed')
            self.start_issued = True
            self.receiver.start()  # driver: RESUME, then restricted APP_ENABLE=1
            self.state = 'RUNNING'
            self._warm_receipt = None  # Later same-instance STOP/RESUME keeps its normal contract.
            self._resume_candidate = None
        except BaseException:
            self._fault()
            raise

    def request_stop(self):
        if self.state == 'DRAINING':
            return
        if self.state != 'RUNNING':
            raise RuntimeError('session is not running')
        try:
            self.receiver.stop()  # driver: APP_ENABLE=0, then DMA STOP/fence drain
            self.state = 'DRAINING'
        except BaseException:
            self._fault()
            raise

    def receive(self, timeout_s: float):
        if self.state not in ('RUNNING', 'DRAINING'):
            raise RuntimeError('session is not receiving')
        try:
            now = self._clock()
            if self._lz_started is not None and now - self._lz_started >= self._lz_timeout:
                self.products.fail_pending()  # Application-only; never a DMA release.
                self._lz_started = None
                self.lz_deadline_failures += 1
            if not self.receiver.poll(timeout_s):
                return ()
            products = self.products.receive(self.maximum_batch)
            if self.reassembler is not None:
                if not self.reassembler.buffered_bytes:
                    self._lz_started = None
                elif self._lz_started is None:
                    self._lz_started = self._clock()
            return products
        except BaseException:
            self._fault()
            raise

    def finish_stop(self) -> bool:
        if self.state != 'DRAINING':
            raise RuntimeError('STOP has not been requested')
        try:
            # A safe completion can still be READY even when counts match.
            # Caller must keep receive() processing until no descriptor remains.
            if self.receiver.poll(0) or self.receiver.leased_count:
                return False
            snapshot = self.receiver.snapshot()
            if snapshot.quarantined:
                raise RuntimeError('transport quarantined during drain')
            if not snapshot.transport_drained:
                return False
            self.products.fail_pending()
            self._lz_started = None
            self.state = 'STOPPED'
            return True
        except BaseException:
            self._fault()
            raise

    def close(self):
        if self.state not in ('NEW', 'PREPARED', 'STOPPED'):
            raise RuntimeError('drain first; faulted owners require explicit abandon')
        try:
            if self._resume_candidate is not None:
                from .warm_attach import validate_candidate
                validate_candidate(self._resume_candidate)
            self.receiver.close()
            self.state = 'CLOSED'
        except BaseException:
            self._fault()
            raise

    def abandon(self):
        """Only after all consumers finish; does not reclaim quarantined DMA."""
        self.products.fail_pending()
        self.receiver.abandon()
        self.state = 'CLOSED_FAULTED'
