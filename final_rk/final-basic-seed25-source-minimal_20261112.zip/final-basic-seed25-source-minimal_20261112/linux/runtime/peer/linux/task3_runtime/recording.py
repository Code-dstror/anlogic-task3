"""Bounded owned JPEG recording; no device, mount, decode or DMA lease access.

Adapted in scope from linux/stream_diag/mjpeg_recorder.py at 57df88833:
exclusive run ownership, original JPEG bytes, JSONL identity index, atomic
directory publication and preservation of partial failures. This smaller writer
uses concatenated MJPEG rather than AVI, and never recovers/deletes other runs.
Local fsync is not TF durability, capture FPS or power-loss qualification.
"""
from __future__ import annotations

from collections import deque
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import stat
from threading import Condition, Thread
import time
from uuid import uuid4

from linux.stream_diag.records import parse_record
from linux.task3_pipeline.product_receiver import JpegProduct
from .pipeline import SourceKey

MANIFEST_LIMIT = 4096
INDEX_LIMIT = 8192
FILES = ('video.mjpeg', 'frames.jsonl', 'manifest.json')


def _json(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def _integer(name, value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'invalid {name}')


def _regular(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError('unsafe recording file')
    return info


def _directory(path):
    if path.is_symlink() or getattr(path, 'is_junction', lambda: False)():
        raise ValueError('recording paths must not traverse links')
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode):
        raise ValueError('recording ancestor is not a directory')
    return info


def _open_new(path):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                 getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0), 0o600)
    return os.fdopen(fd, 'wb', buffering=0)


def _write(file, data):
    if file.write(data) != len(data):
        raise OSError('short recording write; active segment remains partial')


def _sync(file):
    file.flush()
    os.fsync(file.fileno())


def _sync_dir(path):
    if os.name == 'nt':
        return  # Windows tests do not qualify POSIX directory durability.
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class PublicationUncertain(OSError):
    """Rename succeeded, directory sync and restoring .partial both failed."""


def _publish_owned(partial, final, root):
    if final.exists():
        raise ValueError('segment destination already exists')
    partial.rename(final)
    try:
        _sync_dir(root)
    except OSError as error:
        try:
            if partial.exists():
                raise OSError('partial destination unexpectedly exists')
            final.rename(partial)
        except OSError:
            raise PublicationUncertain('publication durability unknown; owned final directory retained') from error
        raise


def _digest(path, maximum):
    size = _regular(path).st_size
    if size > maximum:
        raise ValueError('sealed file exceeded its bound')
    digest = hashlib.sha256()
    with path.open('rb') as file:
        remaining = size
        while remaining:
            data = file.read(min(remaining, 65536))
            if not data:
                raise ValueError('sealed file truncated')
            digest.update(data)
            remaining -= len(data)
        if file.read(1):
            raise ValueError('sealed file grew')
    return size, digest.hexdigest()


class RotatingRecorder:
    """Synchronous single-worker writer into a NEW explicit run directory.

    max_total_bytes includes video, indexes and manifest reservations;
    max_files includes run.json and three files for each active/sealed segment.
    max_records bounds resident indexed records, not lifetime capture count.
    Concurrent external mutation is unsupported and fails closed when detected.
    """
    file_names = FILES
    run_format = 'task3-mjpeg-run-v1'
    version_label = 'jpeg_version'

    def __init__(self, root, *, receiver_cohort, jpeg_version,
                 width=1920, height=1080, max_frame_bytes=16*1024*1024,
                 max_segment_bytes=64*1024*1024, max_segment_records=600,
                 max_total_bytes=512*1024*1024, max_records=6000, max_files=31):
        if not isinstance(receiver_cohort, str) or not 1 <= len(receiver_cohort) <= 128:
            raise ValueError('explicit bounded receiver cohort required')
        for name, value, low, high in (
                ('width', width, 1, 1920), ('height', height, 1, 1080),
                ('max_frame_bytes', max_frame_bytes, 4, 16*1024*1024),
                ('max_segment_bytes', max_segment_bytes, MANIFEST_LIMIT + 1, 2**31-1),
                ('max_segment_records', max_segment_records, 1, 100000),
                ('max_total_bytes', max_total_bytes, 2*MANIFEST_LIMIT+1, 2**63-1),
                ('max_records', max_records, 1, 1000000), ('max_files', max_files, 4, 3073)):
            _integer(name, value, low, high)
        if jpeg_version not in (1, 2, 3):
            raise ValueError('explicit selected JPEG record version required')
        candidate = Path(root)
        if '..' in candidate.parts or not candidate.name or candidate.name in ('.', '..'):
            raise ValueError('explicit new run path required')
        self.root = candidate.absolute()
        self.cohort, self.version = receiver_cohort, jpeg_version
        self.width, self.height = width, height
        self.max_frame_bytes, self.max_segment_bytes = max_frame_bytes, max_segment_bytes
        self.max_segment_records, self.max_total_bytes = max_segment_records, max_total_bytes
        self.max_records, self.max_files = max_records, max_files
        self.run_id = uuid4().hex
        self._sealed, self._active = deque(), None
        self._last = None
        self._bytes = self._records = self._serial = 0
        self.written = self.evicted_records = self.evicted_segments = 0
        self.closed = self.failed = False
        self.publication_uncertain = False
        # No mkdir(parents=True), no mount, no reuse of an existing directory.
        for parent in reversed(self.root.parents):
            _directory(parent)
        self.root.mkdir(mode=0o700)
        info = _directory(self.root)
        self._root_identity = (info.st_dev, info.st_ino)
        manifest = _json(dict(format=self.run_format, run_id=self.run_id,
            receiver_cohort=self.cohort, **{self.version_label: self.version},
            width=width, height=height, max_total_bytes=max_total_bytes,
            max_records=max_records, max_files=max_files,
            qualified_tf=False, qualified_2h=False))
        if len(manifest) > MANIFEST_LIMIT:
            raise ValueError('run manifest bound')
        self._manifest = manifest
        with _open_new(self.root / 'run.json') as file:
            _write(file, manifest)
            _sync(file)
        self._bytes = len(manifest)
        _sync_dir(self.root)

    def _owned_root(self):
        info = _directory(self.root)
        if (info.st_dev, info.st_ino) != self._root_identity:
            raise ValueError('recording run directory replaced')
        path = self.root / 'run.json'
        if _regular(path).st_size != len(self._manifest) or path.read_bytes() != self._manifest:
            raise ValueError('recording ownership manifest changed')

    def _evict(self):
        if not self._sealed:
            raise ValueError('quota cannot fit complete frame without touching partial/user data')
        segment = self._sealed[0]
        self._owned_root()
        path = segment['path']
        _directory(path)
        with os.scandir(path) as entries:
            names = []
            for entry in entries:
                names.append(entry.name)
                if len(names) > len(self.file_names):
                    raise ValueError('unknown file in sealed segment; will not delete')
        if set(names) != set(self.file_names):
            raise ValueError('sealed segment file set changed')
        # Revalidate all files before deleting any; only our successful seals
        # are in this deque. Never scan/adopt prior runs or unknown partials.
        for name in self.file_names:
            if _digest(path / name, self.max_segment_bytes) != segment['files'][name]:
                raise ValueError('sealed segment changed; will not delete')
        for name in self.file_names:
            (path / name).unlink()
        path.rmdir()
        _sync_dir(self.root)
        self._sealed.popleft()
        self._bytes -= segment['bytes']
        self._records -= segment['records']
        self.evicted_records += segment['records']
        self.evicted_segments += 1

    def _reserve(self, extra, records=0, new_segment=0):
        while (self._bytes + extra > self.max_total_bytes or
               self._records + records > self.max_records or
               1 + len(self.file_names)*(len(self._sealed) + bool(self._active) + new_segment) > self.max_files):
            self._evict()

    def _begin(self):
        self._owned_root()
        self._serial += 1
        name = f'seg-{self._serial:08d}'
        path = self.root / (name + '.partial')
        path.mkdir(mode=0o700)
        self._active = dict(path=path, name=name, video=None, index=None,
                            bytes=MANIFEST_LIMIT, records=0, video_bytes=0)
        self._bytes += MANIFEST_LIMIT
        self._active['video'] = _open_new(path / 'video.mjpeg')
        self._active['index'] = _open_new(path / 'frames.jsonl')

    def append(self, product, key=None, *, received_ns=None):
        if self.closed or self.failed:
            raise RuntimeError('recorder is closed or faulted')
        try:
            if not isinstance(product, JpegProduct) or type(product.wire) is not bytes:
                raise TypeError('recorder requires an owned parsed JpegProduct')
            if len(product.wire) > self.max_frame_bytes + 448:
                raise ValueError('record exceeds bounded JPEG envelope')
            # Producer typing alone is not parser provenance. Revalidate in the
            # writer thread, never perform JPEG decode/re-encode.
            record = parse_record(product.wire, expected_version=self.version)
            if record != product.record or type(record.jpeg) is not bytes:
                raise ValueError('product record/wire mismatch')
            if (record.width, record.height) != (self.width, self.height) or len(record.jpeg) > self.max_frame_bytes:
                raise ValueError('record geometry/size exceeds selected stream')
            expected = SourceKey.from_record(self.cohort, record)
            if key is not None and key != expected:
                raise ValueError('record/source key mismatch')
            key = expected
            now = time.monotonic_ns() if received_ns is None else received_ns
            _integer('received_ns', now, 0, 2**63-1)
            if self._last is not None:
                previous, previous_ns = self._last
                if (key.session != previous.session or
                        (key.epoch is None) != (previous.epoch is None) or
                        (key.epoch is not None and key.epoch < previous.epoch) or
                        (key.epoch == previous.epoch and key.sequence <= previous.sequence) or now < previous_ns):
                    raise ValueError('old/repeated source identity or host timestamp')
                if key.epoch != previous.epoch:
                    self._seal()  # Each segment keeps one source epoch.
            offset = self._active['video_bytes'] if self._active else 0
            def index_line(position):
                return _json(dict(source=asdict(key), offset=position, length=len(record.jpeg),
                    received_monotonic_ns=now, source_timestamp_ns=record.timestamp_ns,
                    host_timing_only=True, width=record.width, height=record.height,
                    wire_header_hex=product.wire[:-len(record.jpeg)].hex(),
                    wire_sha256=hashlib.sha256(product.wire).hexdigest(),
                    jpeg_sha256=hashlib.sha256(record.jpeg).hexdigest()))
            line = index_line(offset)
            if len(line) > INDEX_LIMIT or len(record.jpeg) + len(line) + MANIFEST_LIMIT > self.max_segment_bytes:
                raise ValueError('complete frame cannot fit segment bound')
            if self._active and (self._active['records'] >= self.max_segment_records or
                    self._active['records'] >= self.max_records or
                    self._active['bytes'] + len(record.jpeg) + len(line) > self.max_segment_bytes or
                    self._active['bytes'] + len(record.jpeg) + len(line) + len(self._manifest) > self.max_total_bytes):
                self._seal()
                line = index_line(0)
            extra = len(record.jpeg) + len(line)
            self._reserve(extra + (0 if self._active else MANIFEST_LIMIT), records=1,
                          new_segment=int(self._active is None))
            if self._active is None:
                self._begin()
            active = self._active
            # Reserve before writes, including bytes that may survive a short
            # write. Failure leaves the complete directory labelled .partial.
            self._bytes += extra
            active['bytes'] += extra
            _write(active['video'], record.jpeg)
            _write(active['index'], line)
            active['video_bytes'] += len(record.jpeg)
            active['records'] += 1
            self._records += 1
            self.written += 1
            self._last = key, now
        except BaseException as error:
            self.publication_uncertain |= isinstance(error, PublicationUncertain)
            self.abort()
            raise

    def _seal(self):
        active = self._active
        if active is None:
            return
        for name in ('video', 'index'):
            _sync(active[name])
            active[name].close()
        declarations = {name: _digest(active['path'] / name, self.max_segment_bytes)
                        for name in FILES[:2]}
        manifest = _json(dict(format='task3-mjpeg-segment-v1', run_id=self.run_id,
            records=active['records'], files=declarations,
            qualified_tf=False, qualified_2h=False))
        if len(manifest) > MANIFEST_LIMIT:
            raise ValueError('segment manifest bound')
        with _open_new(active['path'] / 'manifest.json') as file:
            _write(file, manifest)
            _sync(file)
        _sync_dir(active['path'])
        final = self.root / (active['name'] + '.segment')
        _publish_owned(active['path'], final, self.root)
        declarations['manifest.json'] = (len(manifest), hashlib.sha256(manifest).hexdigest())
        exact = active['bytes'] - MANIFEST_LIMIT + len(manifest)
        self._bytes -= MANIFEST_LIMIT - len(manifest)
        self._sealed.append(dict(path=final, files=declarations,
                                 bytes=exact, records=active['records']))
        self._active = None

    def snapshot(self):
        return dict(written=self.written, retained_records=self._records,
            reserved_bytes=self._bytes, max_total_bytes=self.max_total_bytes,
            files_upper_bound=1 + len(self.file_names)*(len(self._sealed) + bool(self._active)),
            sealed_segments=len(self._sealed), partial=self._active is not None,
            publication_uncertain=self.publication_uncertain,
            evicted_records=self.evicted_records, evicted_segments=self.evicted_segments,
            closed=self.closed, failed=self.failed, tf='NOT_RUN', voice='NOT_RUN',
            continuous_2h='NOT_RUN')

    def close(self):
        if self.closed:
            return
        if self.failed:
            self.abort()
            return
        try:
            self._seal()
            self.closed = True
        except BaseException as error:
            self.publication_uncertain |= isinstance(error, PublicationUncertain)
            self.abort()
            raise

    def abort(self):
        self.failed = True
        if self._active:
            for name in ('video', 'index'):
                file = self._active.get(name)
                if file is not None and not file.closed:
                    file.close()
        self.closed = True


class BoundedRecorderWorker:
    """No disk IO on submit/snapshot; queue overflow drops the NEW whole frame.

    Queue storage <= queue_depth * max_item_bytes, plus one active item. Items
    own bytes, never DMA leases. close(timeout_s) never closes worker file handles.
    """
    def __init__(self, root, *, queue_depth=4, max_item_bytes=32*1024*1024+448,
                 recorder_factory=RotatingRecorder, **options):
        _integer('queue_depth', queue_depth, 1, 64)
        _integer('max_item_bytes', max_item_bytes, 8, 32*1024*1024+448)
        self.root, self.options, self.factory = root, options, recorder_factory
        self.depth, self.max_item_bytes = queue_depth, max_item_bytes
        self._condition, self._queue = Condition(), deque()
        self._thread = None
        self._stop = False
        self._status = dict(state='NEW', accepted=0, dropped=0, queued_bytes=0,
                            written=0, failed_frames=0, inflight=False,
                            failure=None, worker_done=False)

    def start(self):
        with self._condition:
            if self._thread is not None or self._stop:
                raise RuntimeError('recorder worker is single use')
            self._status['state'] = 'STARTING'
            self._thread = Thread(target=self._run, name='task3-recorder', daemon=True)
            self._thread.start()
        return self

    def _item_size(self, product):
        if not isinstance(product, JpegProduct) or type(product.wire) is not bytes or type(product.record.jpeg) is not bytes:
            raise TypeError('recording requires an owned JpegProduct')
        return len(product.wire) + len(product.record.jpeg)

    def submit(self, product, key=None):
        size = self._item_size(product)
        with self._condition:
            if (self._thread is None or self._stop or self._status['failure'] or
                    size > self.max_item_bytes or len(self._queue) >= self.depth):
                self._status['dropped'] += 1
                return False
            self._queue.append((product, key, time.monotonic_ns(), size))
            self._status['accepted'] += 1
            self._status['queued_bytes'] += size
            self._condition.notify()
            return True

    def request_stop(self):
        with self._condition:
            self._stop = True
            self._condition.notify()

    def close(self, timeout_s=0.1):
        if type(timeout_s) not in (int, float) or not math.isfinite(timeout_s) or timeout_s < 0:
            raise ValueError('invalid worker close timeout')
        self.request_stop()
        if self._thread:
            self._thread.join(timeout_s)
        return self.snapshot()

    def snapshot(self):
        with self._condition:
            result = dict(self._status, pending=len(self._queue), queue_depth=self.depth,
                        tf='NOT_RUN', voice='NOT_RUN', continuous_2h='NOT_RUN')
            if 'storage' in result:
                result['storage'] = dict(result['storage'])
            return result

    def _run(self):
        recorder = None
        try:
            recorder = self.factory(self.root, **self.options)
            with self._condition:
                self._status['state'] = 'RUNNING'
            while True:
                with self._condition:
                    self._condition.wait_for(lambda: self._queue or self._stop)
                    if not self._queue:
                        break
                    product, key, received, size = self._queue.popleft()
                    self._status['queued_bytes'] -= size
                    self._status['inflight'] = True
                recorder.append(product, key, received_ns=received)
                with self._condition:
                    self._status['written'] += 1
                    self._status['inflight'] = False
                    self._status['storage'] = recorder.snapshot()
            recorder.close()
            with self._condition:
                self._status['storage'] = recorder.snapshot()
                self._status['state'] = 'STOPPED'
        except BaseException as error:
            if recorder is not None:
                try:
                    recorder.abort()
                except BaseException:
                    pass
            with self._condition:
                self._status['failure'] = f'{type(error).__name__}: {error}'[:512]
                self._status['failed_frames'] += int(self._status['inflight'])
                self._status['inflight'] = False
                self._status['state'] = 'FAILED'
                self._stop = True
                if recorder is not None:
                    self._status['storage'] = recorder.snapshot()
        finally:
            with self._condition:
                self._status['dropped'] += len(self._queue)
                self._queue.clear()
                self._status['queued_bytes'] = 0
                self._status['worker_done'] = True
