"""Same-probe JPEG resume receipts, never adoption of an unknown idle device.

Receipts are bounded canonical JSON in an owner-controlled directory. Their
hashes detect mismatched files, not malicious changes: this is not authentication.
Only normal transport drain/close is attested, not FPGA-wide quiet or fresh capture.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path
import stat
import uuid

from linux.task3_pipeline import pcie_protocol_v1 as p
from linux.task3_pipeline.config_transaction import Configuration
from linux.task3_pipeline.record_selection import RecordSelection, header_length


MAX_RECEIPT_BYTES = 16384
MAX_REPORT_BYTES = 262144
FORMAT = 'PH1A_C2H_WARM_RESUME'
OWNER_FIELDS = ('owner_info_version', 'user_abi', 'pci_domain', 'pci_bus', 'pci_devfn',
                'generation', 'transport_session')
POOL_FIELDS = ('user_abi', 'slots', 'capacity', 'dma_bits', 'mapping_bytes')
REGISTER_NAMES = (
    'DEVICE_MAGIC', 'PROTOCOL_VERSION', 'CAPABILITIES',
    'CFG_MAGIC', 'CFG_ABI_VERSION', 'CFG_FEATURES', 'CFG_COMPILED_PROFILE',
    'CFG_CAMERA_PRESENT', 'CFG_MAX_WIDTH', 'CFG_MAX_HEIGHT', 'CFG_SESSION',
    'CFG_STATUS', 'CFG_RESPONSE_SEQUENCE', 'CFG_ERROR', 'CFG_ACTIVE_SESSION',
    'CFG_MODE_EPOCH', 'CFG_APPLIED_FIRST_SEQUENCE', 'CFG_APPLIED_CAMERA',
    'CFG_ACTIVE_MODE', 'CFG_ACTIVE_QUALITY', 'CFG_ACTIVE_FLAGS', 'CFG_ACTIVE_MIN_QUALITY',
    'CFG_ACTIVE_FRAME_BUDGET', 'CFG_ACTIVE_RESTART_MCUS',
    'CFG_EXT_MAGIC', 'CFG_EXT_ABI_VERSION', 'CFG_EXT_WIDTH', 'CFG_EXT_SUPPORTED',
    'CFG_EXT_STRIPS', 'CFG_EXT_APPLIED_LUT_GENERATION', 'CFG_EXT_COMBINATIONS',
    'CFG_EXT_SCHEMAS', 'CFG_EXT_V2_MODES', 'CFG_EXT_V2_ENABLES',
    'RECORD_MAGIC', 'RECORD_ABI_VERSION', 'RECORD_FEATURES', 'RECORD_SUPPORTED_VERSIONS',
    'RECORD_STATUS', 'RECORD_RESPONSE_SEQUENCE', 'RECORD_RESPONSE_SESSION', 'RECORD_ERROR',
    'RECORD_SELECTED_VERSION', 'RECORD_SELECTED_HEADER_LENGTH', 'RECORD_SELECTION_EPOCH',
    'ALGO_MAGIC', 'ALGO_ABI_VERSION', 'ALGO_FEATURES', 'ALGO_STATUS',
    'ALGO_RESPONSE_SEQUENCE', 'ALGO_RESPONSE_SESSION', 'ALGO_RESULT_GENERATION',
    'ALGO_ERROR', 'ALGO_ACTIVE_GENERATION',
)
BASE_FIELDS = ('CFG_ACTIVE_MODE', 'CFG_ACTIVE_QUALITY', 'CFG_ACTIVE_FLAGS',
               'CFG_ACTIVE_MIN_QUALITY', 'CFG_ACTIVE_FRAME_BUDGET', 'CFG_ACTIVE_RESTART_MCUS')


class WarmAttachError(RuntimeError):
    pass


def _canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                       allow_nan=False) + '\n').encode('ascii')


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise WarmAttachError('duplicate JSON key')
        result[key] = value
    return result


def _json(data):
    try:
        return json.loads(data, object_pairs_hook=_unique,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    except (ValueError, UnicodeError, TypeError) as error:
        raise WarmAttachError('invalid bounded JSON') from error


def _uint(value, bits=32, minimum=0):
    return type(value) is int and minimum <= value < 1 << bits


def _boot(value):
    if type(value) is not str:
        raise WarmAttachError('canonical boot UUID required')
    try:
        if str(uuid.UUID(value)) != value:
            raise ValueError('noncanonical UUID')
    except ValueError as error:
        raise WarmAttachError('canonical boot UUID required') from error
    return value


def read_boot_id(path=Path('/proc/sys/kernel/random/boot_id')):
    with Path(path).open('r', encoding='ascii') as stream:
        value = stream.read(64).strip()
    return _boot(value)


@dataclass(frozen=True)
class WarmState:
    boot_id: str
    owner: tuple[int, ...]
    pool: tuple[int, ...]
    watermarks: tuple[int, int]
    registers: tuple[int, ...]
    active_extension: tuple[int, ...]
    selection: tuple[int, ...]

    def digest(self):
        return hashlib.sha256(_canonical(asdict(self))).hexdigest()


@dataclass(frozen=True)
class WarmResumeReceipt:
    state: WarmState
    report_path: str
    report_sha256: str

    def to_bytes(self):
        _validate_state(self.state)
        if (type(self.report_path) is not str or not 1 <= len(self.report_path) <= 4096
                or '\x00' in self.report_path or not Path(self.report_path).is_absolute()
                or type(self.report_sha256) is not str or len(self.report_sha256) != 64
                or any(c not in '0123456789abcdef' for c in self.report_sha256)):
            raise WarmAttachError('invalid report provenance')
        data = _canonical(dict(format=FORMAT, schema=1, state=asdict(self.state),
            identity_sha256=self.state.digest(), report_path=self.report_path,
            report_sha256=self.report_sha256, proof='NORMAL_CLOSE_CONFIRMED'))
        if len(data) > MAX_RECEIPT_BYTES:
            raise WarmAttachError('resume receipt exceeds byte bound')
        return data


@dataclass(frozen=True)
class WarmResumeCandidate:
    state: WarmState
    _session: object

    def confirm_closed(self, *, report_path, report_sha256):
        if self._session.state != 'CLOSED' or self._session._resume_candidate is not self:
            raise WarmAttachError('normal close of the captured session was not confirmed')
        return WarmResumeReceipt(self.state, str(Path(report_path).resolve()), report_sha256)


def _validate_state(state):
    if not isinstance(state, WarmState):
        raise WarmAttachError('typed warm state required')
    _boot(state.boot_id)
    for values, count, bits in ((state.owner, 7, 64), (state.pool, 5, 32),
            (state.watermarks, 2, 64), (state.registers, len(REGISTER_NAMES), 32),
            (state.active_extension, 32, 32), (state.selection, 5, 32)):
        if type(values) is not tuple or len(values) != count or any(not _uint(v, bits) for v in values):
            raise WarmAttachError('invalid fixed warm state vector')
    owner = dict(zip(OWNER_FIELDS, state.owner))
    if (owner['owner_info_version'] != 1 or owner['user_abi'] != 2
            or not _uint(owner['pci_domain'], 16) or not _uint(owner['pci_bus'], 8)
            or not _uint(owner['pci_devfn'], 8) or not _uint(owner['generation'])
            or not owner['transport_session'] or state.watermarks[0] != state.watermarks[1]
            or state.pool[0] != 2 or not 1 <= state.pool[1] <= 16 or not state.pool[2]
            or state.pool[3] not in (32, 64) or state.pool[4] < state.pool[2]):
        raise WarmAttachError('invalid owner/pool/drained watermarks')
    regs = dict(zip(REGISTER_NAMES, state.registers))
    version, length, session, sequence, epoch = state.selection
    if version not in (2, 3) or length != header_length(version) or not session or not sequence:
        raise WarmAttachError('warm resume requires complete explicit record-v2/v3 selection')
    if (regs['DEVICE_MAGIC'] != p.DEVICE_MAGIC or regs['PROTOCOL_VERSION'] != p.PROTOCOL_VERSION
            or regs['CFG_MAGIC'] != p.PCIE_CFG_MAGIC or regs['CFG_ABI_VERSION'] != p.PCIE_CFG_ABI_VERSION
            or regs['RECORD_MAGIC'] != p.PCIE_RECORD_V2_MAGIC
            or regs['RECORD_ABI_VERSION'] != p.PCIE_RECORD_V2_ABI_VERSION):
        raise WarmAttachError('device/config/record ABI mismatch')
    needed = p.PCIE_CAPABILITY_CONFIG_TRANSACTION | p.PCIE_CAPABILITY_RECORD_V2
    features = p.PCIE_RECORD_V2_FEATURE_VERSION2 | p.PCIE_RECORD_V2_FEATURE_SOURCE_STAMP
    if version == 3:
        features |= p.PCIE_RECORD_V3_FEATURE_VERSION3 | p.PCIE_RECORD_V3_FEATURE_SPARSE
    if (regs['CAPABILITIES'] & needed != needed or regs['RECORD_FEATURES'] & features != features
            or not regs['RECORD_SUPPORTED_VERSIONS'] & (1 << version)):
        raise WarmAttachError('required record/source capability unavailable')
    if (regs['CFG_SESSION'] != session or regs['CFG_ACTIVE_SESSION'] != session
            or not regs['CFG_STATUS'] & p.PCIE_CFG_STATUS_SESSION_READY
            or regs['CFG_STATUS'] & (p.PCIE_CFG_STATUS_BUSY | p.PCIE_CFG_STATUS_READY | p.PCIE_CFG_STATUS_ERROR)
            or regs['CFG_ERROR']):
        raise WarmAttachError('CFG is not a stable completed source session')
    if (regs['RECORD_STATUS'] & (p.PCIE_RECORD_V2_STATUS_BUSY | p.PCIE_RECORD_V2_STATUS_ERROR)
            or not regs['RECORD_STATUS'] & p.PCIE_RECORD_V2_STATUS_DONE or regs['RECORD_ERROR']
            or (regs['RECORD_SELECTED_VERSION'], regs['RECORD_SELECTED_HEADER_LENGTH'],
                regs['RECORD_RESPONSE_SESSION'], regs['RECORD_RESPONSE_SEQUENCE'],
                regs['RECORD_SELECTION_EPOCH']) != state.selection):
        raise WarmAttachError('record selection ACK is pending, failed or changed')
    if (regs['ALGO_STATUS'] & (p.PCIE_ALGO_STATUS_BUSY | p.PCIE_ALGO_STATUS_LOADING | p.PCIE_ALGO_STATUS_ERROR)
            or regs['ALGO_ERROR']):
        raise WarmAttachError('LUT operation is pending or failed')
    if regs['ALGO_MAGIC'] not in (0, p.PCIE_ALGO_MAGIC) or (
            regs['ALGO_MAGIC'] and regs['ALGO_ABI_VERSION'] != p.PCIE_ALGO_ABI_VERSION):
        raise WarmAttachError('unknown LUT ABI')
    try:
        Configuration(*(regs[name] for name in BASE_FIELDS)).validate()
    except Exception as error:
        raise WarmAttachError('invalid active base configuration') from error
    schema = state.active_extension[0] & 255
    if regs['CFG_EXT_MAGIC']:
        if (regs['CFG_EXT_MAGIC'] != p.PCIE_CFG_EXT_MAGIC or regs['CFG_EXT_ABI_VERSION'] != 1
                or regs['CFG_EXT_WIDTH'] != 1024):
            raise WarmAttachError('unknown active extension ABI')
        if schema == 2:
            from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
            active = MonoConfiguration.from_words(state.active_extension)
            if active.product_mode != p.PCIE_CFG_V2_MODES_MONO_SDR:
                raise WarmAttachError('warm resume currently supports SDR JPEG only')
        elif schema == 1:
            from linux.task3_pipeline.advanced_config import AdvancedConfiguration
            active = AdvancedConfiguration.from_words(state.active_extension)
            if active.enable & (p.PCIE_CFG_EXT_FEATURE_CFS | p.PCIE_CFG_EXT_FEATURE_HDR):
                raise WarmAttachError('warm resume currently supports SDR JPEG only, no HDR/CFS')
        elif any(state.active_extension):
            raise WarmAttachError('unknown active extension schema')
    elif any(state.active_extension):
        raise WarmAttachError('extension words without a known extension ABI')


def _sample(receiver, *, boot_id, selection):
    if receiver.leased_count or receiver.poll(0):
        raise WarmAttachError('ready results or leases remain')
    info = receiver.snapshot()
    if not info.transport_drained:
        raise WarmAttachError('transport is active, quarantined or not drained')
    owner = receiver.owner_identity()
    if receiver.read32(p.PCIE_REG_CONTROL) != 0:
        raise WarmAttachError('APP must be disabled without unknown control bits')
    status = receiver.read32(p.PCIE_REG_STATUS)
    link = p.PCIE_STATUS_LINK_UP | p.PCIE_STATUS_USER_RESET_RELEASED
    if status & link != link:
        raise WarmAttachError('current link/reset state is unavailable')
    # SOURCE_BUSY/TX_BUSY/ARMED/REARM_READY may describe retained FPGA backlog.
    # They are deliberately neither static gates nor part of the equality key.
    regs = tuple(receiver.read32(getattr(p, 'PCIE_REG_' + name)) for name in REGISTER_NAMES)
    extension = tuple(receiver.read32(p.PCIE_REG_CFG_EXT_ACTIVE_BASE + 4*i) for i in range(32))
    result = WarmState(_boot(boot_id), tuple(getattr(owner, n) for n in OWNER_FIELDS),
        tuple(getattr(info, n) for n in POOL_FIELDS), (info.submitted, info.completed),
        regs, extension, tuple(asdict(selection).values()))
    _validate_state(result)
    return result


def capture_stopped(session, *, boot_id, controls_idle):
    if (controls_idle is not True or session.state != 'STOPPED' or session.reassembler is not None
            or session.transactions is None or session.transactions._prepared is not None
            or session.transactions._terminal):
        raise WarmAttachError('normal stopped JPEG session and completed controls are required')
    first = _sample(session.receiver, boot_id=boot_id, selection=session.selection)
    second = _sample(session.receiver, boot_id=boot_id, selection=session.selection)
    if first != second:
        raise WarmAttachError('warm snapshot changed during capture')
    return WarmResumeCandidate(first, session)


def validate_current(receiver, receipt, *, boot_id):
    if not isinstance(receipt, WarmResumeReceipt):
        raise WarmAttachError('validated warm receipt required')
    _validate_state(receipt.state)
    _verify_report(receipt)
    if _boot(boot_id) != receipt.state.boot_id:
        raise WarmAttachError('boot changed; warm receipt is stale')
    selection = RecordSelection(*receipt.state.selection)
    first = _sample(receiver, boot_id=boot_id, selection=selection)
    second = _sample(receiver, boot_id=boot_id, selection=selection)
    if first != receipt.state or second != receipt.state:
        raise WarmAttachError('probe, generation, watermarks, source or active snapshot changed')
    return selection


def validate_candidate(candidate):
    session = candidate._session
    if (session.state != 'STOPPED' or session.transactions._prepared is not None
            or session.transactions._terminal):
        raise WarmAttachError('captured owner no longer has completed controls')
    for _ in range(2):
        if _sample(session.receiver, boot_id=candidate.state.boot_id, selection=session.selection) != candidate.state:
            raise WarmAttachError('captured stopped identity changed before close')


def configuration_snapshot(receipt):
    """Return the exact attested base/extension for an optional source barrier."""
    _validate_state(receipt.state)
    regs = dict(zip(REGISTER_NAMES, receipt.state.registers))
    base = Configuration(*(regs[name] for name in BASE_FIELDS))
    words = receipt.state.active_extension
    extension = None
    if any(words):
        from linux.task3_pipeline.advanced_config import AdvancedConfiguration
        from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
        extension = (MonoConfiguration if words[0] & 255 == 2 else AdvancedConfiguration).from_words(words)
        if extension.words() != words:
            raise WarmAttachError('active extension cannot be reproduced exactly')
    return base, extension


def _path(path):
    path = Path(path).absolute()
    if any(part.is_symlink() or getattr(part, 'is_junction', lambda: False)()
           for part in (path, *path.parents)):
        raise WarmAttachError('receipt/report path must not traverse links')
    return path


def _read_file(path, maximum):
    path = _path(path)
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
    fd = os.open(path, flags)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise WarmAttachError('receipt/report must be a regular file')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(maximum + 1)
        if len(data) > maximum:
            raise WarmAttachError('receipt/report exceeds byte bound')
        return data
    finally:
        os.close(fd)


def load_receipt(path):
    data = _read_file(path, MAX_RECEIPT_BYTES)
    value = _json(data)
    expected = {'format', 'schema', 'state', 'identity_sha256', 'report_path', 'report_sha256', 'proof'}
    if type(value) is not dict or set(value) != expected or value['format'] != FORMAT or (
            type(value['schema']) is not int or value['schema'] != 1 or value['proof'] != 'NORMAL_CLOSE_CONFIRMED'):
        raise WarmAttachError('unsupported resume receipt schema/proof')
    state = value['state']
    if type(state) is not dict or set(state) != set(WarmState.__dataclass_fields__):
        raise WarmAttachError('invalid resume state schema')
    if any(type(state[key]) is not list for key in state if key != 'boot_id'):
        raise WarmAttachError('fixed resume state arrays required')
    receipt = WarmResumeReceipt(WarmState(**{key: item if key == 'boot_id' else tuple(item)
        for key, item in state.items()}), value['report_path'], value['report_sha256'])
    if receipt.to_bytes() != data or receipt.state.digest() != value['identity_sha256']:
        raise WarmAttachError('receipt is not canonical or identity digest differs')
    _verify_report(receipt, receipt_path=path)
    return receipt


def _verify_report(receipt, *, receipt_path=None):
    report_bytes = _read_file(receipt.report_path, MAX_REPORT_BYTES)
    if hashlib.sha256(report_bytes).hexdigest() != receipt.report_sha256:
        raise WarmAttachError('normal-close report changed or was not completely saved')
    report = _json(report_bytes)
    if type(report) is not dict or type(report.get('warm_resume')) is not dict:
        raise WarmAttachError('normal-close report has invalid proof schema')
    proof = report.get('warm_resume', {})
    output = proof.get('output')
    if type(output) is not str or not output:
        raise WarmAttachError('normal-close report lacks a receipt output')
    if (report.get('state') != 'CLOSED' or report.get('failure') is not None
            or report.get('ownership_retained') is not False
            or proof.get('availability') != 'READY_IF_MATCHING_RECEIPT_EXISTS'
            or proof.get('identity_sha256') != receipt.state.digest()
            or receipt_path is not None and _path(output) != _path(receipt_path)):
        raise WarmAttachError('report does not attest this normally closed receipt')
    if _read_file(output, MAX_RECEIPT_BYTES) != receipt.to_bytes():
        raise WarmAttachError('matching successfully published receipt is absent')


def publish_receipt(path, receipt):
    """File data is fsynced before an exclusive atomic final name is published.

    This receipt expires across boot, so no power-loss survival claim is made.
    No fallible qualification operation follows the final hard-link publication.
    """
    path = _path(path)
    if path.exists() or not path.parent.is_dir():
        raise WarmAttachError('receipt output must be a new file in an existing owner directory')
    data = receipt.to_bytes()
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.partial')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)  # Atomic and refuses an existing destination.
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass  # A retained private temporary does not invalidate a published proof.
    return hashlib.sha256(data).hexdigest()
