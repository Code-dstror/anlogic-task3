"""Owned products to persistent MPP and bounded consumer mailboxes."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from threading import Lock
import time

from linux.task3_pipeline.product_receiver import (JpegProduct, RawProduct,
                                                  RejectedProduct, SafeTransportFailure)


@dataclass(frozen=True)
class SourceKey:
    receiver_cohort: str
    session: int | None
    epoch: int | None
    camera: int
    sequence: int
    jpeg_generation: int | None

    @classmethod
    def from_record(cls, cohort, record):
        metadata = record.metadata
        if metadata is None:
            return cls(cohort, None, None, 0, record.sequence, None)
        source = metadata.source
        if source is None or source.camera != 0 or source.sequence != record.sequence:
            raise ValueError('runtime requires exact single-camera SOURCE association')
        return cls(cohort, source.session, source.epoch, source.camera,
                   source.sequence, metadata.jpeg_generation)


@dataclass(frozen=True)
class DisplayFrame:
    key: SourceKey
    decoded: object
    record: object
    host_dispatch_ns: int
    decoded_ns: int

    @property
    def storage_bytes(self):
        return len(self.decoded.nv12 or b'') + len(self.record.jpeg)


class LatestMailbox:
    """Bounded whole-object queue; drops waiting copies, never a hardware lease."""
    def __init__(self, *, depth: int, max_item_bytes: int, size_of):
        if type(depth) is not int or not 1 <= depth <= 16:
            raise ValueError('mailbox depth must be 1..16')
        if type(max_item_bytes) is not int or not 1 <= max_item_bytes <= 64 * 1024 * 1024:
            raise ValueError('invalid mailbox item bound')
        self.depth, self.max_item_bytes, self.size_of = depth, max_item_bytes, size_of
        self._items, self._lock = deque(), Lock()
        self.submitted = self.dropped = self.taken = self.resident_bytes = 0

    def submit(self, item):
        size = self.size_of(item)
        if type(size) is not int or not 0 <= size <= self.max_item_bytes:
            raise ValueError('mailbox object exceeds byte bound')
        with self._lock:
            if len(self._items) == self.depth:
                _, removed = self._items.popleft()
                self.resident_bytes -= removed
                self.dropped += 1
            self._items.append((item, size))
            self.resident_bytes += size
            self.submitted += 1

    def take(self, *, latest=False):
        with self._lock:
            if not self._items:
                return None
            if latest:
                while len(self._items) > 1:
                    _, removed = self._items.popleft()
                    self.resident_bytes -= removed
                    self.dropped += 1
            item, size = self._items.popleft()
            self.resident_bytes -= size
            self.taken += 1
            return item

    def snapshot(self):
        with self._lock:
            return dict(depth=self.depth, pending=len(self._items), resident_bytes=self.resident_bytes,
                        submitted=self.submitted, dropped=self.dropped, taken=self.taken)


class ProductPipeline:
    """One serialized producer; callbacks receive independent owned data only.

    display/raw/jpeg sinks should be bounded mailboxes, never blocking device
    writers. A slow MPP decode can backpressure transport, but owns no DMA view.
    This class starts no threads, synthesizes no SOURCE and makes no AI decision.
    """
    def __init__(self, decoder, *, jpeg_version: int, receiver_cohort: str,
                 display=None, vision=None, raw=None, recorder=None, clock=time.monotonic_ns,
                 expected_geometry=None, frame_observer=None):
        if not isinstance(receiver_cohort, str) or not 1 <= len(receiver_cohort) <= 128:
            raise ValueError('explicit receiver cohort required')
        self.decoder, self.jpeg_version, self.cohort = decoder, jpeg_version, receiver_cohort
        if expected_geometry is not None and expected_geometry != (1920, 1080):
            raise ValueError('production geometry is fixed at 1920x1080')
        self.expected_geometry = expected_geometry
        if frame_observer is not None and not callable(frame_observer):
            raise TypeError('frame observer must be a nonblocking callable')
        self.frame_observer = frame_observer
        self.display, self.vision, self.raw, self.recorder, self.clock = display, vision, raw, recorder, clock
        self.jpeg_count = self.raw_count = self.rejected_count = self.transport_failures = 0
        self.decoded_bytes = self.decode_ns = 0
        self.jpeg_payload_bytes = self.rgb_reference_bytes = self.max_decode_ns = 0
        self.first_decoded_ns = self.last_decoded_ns = None
        self.first_product_rejection = self.first_safe_transport_failure = None
        self._source_session = self._source_epoch = self._last_sequence = None
        self._has_source = None
        self.faulted = False

    def consume(self, products):
        if self.faulted:
            raise RuntimeError('product pipeline is terminal')
        # ProductReceiver bounds every batch; callers cannot sneak in an iterator.
        if type(products) is not tuple or len(products) > 16:
            raise ValueError('expected bounded product tuple')
        try:
            for product in products:
                received = self.clock()
                if isinstance(product, RejectedProduct):
                    self.rejected_count += 1
                    if self.first_product_rejection is None:
                        self.first_product_rejection = dict(reason=product.reason[:256],
                            transport_identity=tuple(product.transport_identity[:4]))
                    continue
                if isinstance(product, SafeTransportFailure):
                    self.transport_failures += 1
                    if self.first_safe_transport_failure is None:
                        self.first_safe_transport_failure = dict(result=product.result,
                            transport_identity=tuple(product.transport_identity[:4]))
                    continue
                if isinstance(product, RawProduct):
                    self.raw_count += 1
                    if self.raw is not None:
                        self.raw.submit(product)
                    continue
                if not isinstance(product, JpegProduct):
                    raise TypeError('unknown product event')
                if self.expected_geometry is not None and (product.record.width, product.record.height) != self.expected_geometry:
                    raise ValueError('JPEG geometry differs from the running mono profile')
                key = SourceKey.from_record(self.cohort, product.record)
                stamped = key.session is not None
                if self._has_source is not None and stamped != self._has_source:
                    raise ValueError('SOURCE presence changed within selected record session')
                if self._source_session is not None and key.session != self._source_session:
                    raise ValueError('unexpected source session change; explicit recovery required')
                if (self._source_epoch is not None and key.epoch < self._source_epoch or
                        self._source_epoch == key.epoch and self._last_sequence is not None
                        and key.sequence <= self._last_sequence):
                    raise ValueError('backward source epoch or repeated/backward capture sequence')
                self._has_source, self._source_session = stamped, key.session
                self._source_epoch, self._last_sequence = key.epoch, key.sequence
                want_vision = self.vision is not None and self.vision.want_frame()
                frame = self.decoder.decode_record(product.wire, expected_version=self.jpeg_version,
                                                    copy_nv12=self.display is not None or want_vision)
                if (frame.sequence, frame.width, frame.height) != (
                        product.record.sequence, product.record.width, product.record.height):
                    raise ValueError('MPP completion does not belong to the input record')
                if self.display is not None or want_vision:
                    if type(frame.nv12) is not bytes or len(frame.nv12) != frame.hor_stride * frame.ver_stride * 3 // 2:
                        raise ValueError('MPP consumer requires an independent complete NV12 copy')
                envelope = DisplayFrame(key, frame, product.record, received, self.clock())
                if self.frame_observer is not None:
                    self.frame_observer(envelope)
                self.jpeg_count += 1
                self.decode_ns += frame.decode_ns
                self.max_decode_ns = max(self.max_decode_ns, frame.decode_ns)
                self.jpeg_payload_bytes += len(product.record.jpeg)
                self.rgb_reference_bytes += frame.width * frame.height * 3
                if self.first_decoded_ns is None:
                    self.first_decoded_ns = envelope.decoded_ns
                self.last_decoded_ns = envelope.decoded_ns
                self.decoded_bytes += len(frame.nv12 or b'')
                if self.recorder is not None:
                    self.recorder.submit(product)
                if want_vision:
                    self.vision.submit(frame, product.record)
                if self.display is not None:
                    self.display.submit(envelope)
        except BaseException:
            self.faulted = True
            raise

    def snapshot(self):
        interval = None if self.first_decoded_ns is None else self.last_decoded_ns - self.first_decoded_ns
        return dict(jpeg_decoded=self.jpeg_count, raw_complete=self.raw_count,
                    product_rejected=self.rejected_count, safe_transport_failures=self.transport_failures,
                    first_product_rejection=self.first_product_rejection,
                    first_safe_transport_failure=self.first_safe_transport_failure,
                    decoded_copy_bytes=self.decoded_bytes, decode_ns=self.decode_ns,
                    mean_decode_ms=None if not self.jpeg_count else self.decode_ns / self.jpeg_count / 1e6,
                    max_decode_ms=self.max_decode_ns / 1e6,
                    observed_decode_fps=None if not interval or self.jpeg_count < 2 else (self.jpeg_count - 1) * 1e9 / interval,
                    fps_scope='FIRST_TO_LAST_HOST_DECODE_COMPLETION_NOT_STEADY_WINDOW_OR_DISPLAY_FPS',
                    jpeg_payload_bytes=self.jpeg_payload_bytes,
                    rgb888_reference_bytes=self.rgb_reference_bytes,
                    rgb888_compression_ratio=None if not self.jpeg_payload_bytes else self.rgb_reference_bytes / self.jpeg_payload_bytes,
                    compression_reference='RGB888_VIEW_BYTES_NOT_SENSOR_RAW10',
                    faulted=self.faulted, physical_display_fps='NOT_MEASURED',
                    sensor_to_host_latency='UNQUALIFIED_CLOCK_DOMAINS')
