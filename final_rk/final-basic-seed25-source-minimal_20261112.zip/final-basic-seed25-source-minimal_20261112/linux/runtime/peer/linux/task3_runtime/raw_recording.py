"""Full native LZ recovery to bounded raw10 + exact terminal metadata storage.

The native decoder supplies validated owned bytes; this sink checks the frame
envelope and header/identity agreement again, without repeating decompression.
Partial frames never receive a .segment name. Disk/TF throughput is unqualified.
"""
from __future__ import annotations

from dataclasses import asdict
import hashlib
import time

from linux.lz_native import NativeFrame
from linux.task3_pipeline import pcie_protocol_v1 as p
from linux.task3_pipeline.product_receiver import RawProduct
from .recording import (RotatingRecorder, BoundedRecorderWorker, _json, _integer,
                        _open_new, _write, _sync, _sync_dir, _publish_owned,
                        PublicationUncertain, INDEX_LIMIT)


def validate_frame(product):
    if not isinstance(product, RawProduct) or not isinstance(product.frame, NativeFrame):
        raise TypeError('raw recorder requires a completed native RawProduct')
    frame = product.frame
    if type(frame.raw) is not bytes or len(frame.raw) != p.PCIE_LZ_FRAME_RAW_BYTES:
        raise ValueError('RAW10 frame must contain exactly 2592000 owned bytes')
    header = dict(frame.header)
    if set(header) != set(p.LZ_HEADER_FIELD_NAMES):
        raise ValueError('native frame requires the exact terminal header')
    # Generated field packing validates all numeric widths and reserved byte
    # dimensions; constants below bind this to the successful final chunk.
    p.LZ_HEADER_STRUCT.pack(*(header[name] for name in p.LZ_HEADER_FIELD_NAMES))
    if any(header[name] != value for name, value in p.LZ_HEADER_EXPECTED_VALUES.items()):
        raise ValueError('invalid fixed RAW terminal header')
    identity = tuple(header[name] for name in ('source_session', 'camera', 'capture_sequence',
                                               'mode_epoch', 'generation'))
    if identity != tuple(asdict(frame.identity).values()) or not identity[0] or identity[1] or not identity[4]:
        raise ValueError('native identity differs from successful terminal header')
    mask = (p.PCIE_LZ_VALIDITY_IDENTITY | p.PCIE_LZ_VALIDITY_TIME | p.PCIE_LZ_VALIDITY_BAYER |
            p.PCIE_LZ_VALIDITY_QUALIFIED | p.PCIE_LZ_VALIDITY_DIAGNOSTICS)
    count = p.PCIE_LZ_FRAME_BLOCKS - (p.PCIE_LZ_FRAME_CHUNKS-1)*p.PCIE_LZ_BLOCKS_PER_CHUNK
    if (header['product_type'] != p.PCIE_LZ_PRODUCT_TYPES_DATA or header['error'] or header['capture_status'] or
            header['flags'] != p.PCIE_LZ_FLAGS_LAST or header['chunk_index'] != p.PCIE_LZ_FRAME_CHUNKS-1 or
            header['first_block_id'] != (p.PCIE_LZ_FRAME_CHUNKS-1)*p.PCIE_LZ_BLOCKS_PER_CHUNK or
            header['block_count'] != count or header['descriptors_bytes'] != count*p.PCIE_LZ_DESCRIPTOR_LENGTH or
            not 1 <= header['data_bytes'] <= count*p.PCIE_LZ_BLOCK_RAW_BYTES or
            header['record_length'] != p.PCIE_LZ_HEADER_LENGTH + header['descriptors_bytes'] + header['data_bytes'] or
            header['validity'] & ~mask or not header['validity'] & p.PCIE_LZ_VALIDITY_IDENTITY or
            header['source_kind'] not in (p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY, p.PCIE_RECORD_V2_SOURCE_PHYSICAL)):
        raise ValueError('not a successful complete RAW frame terminal')
    if header['validity'] & p.PCIE_LZ_VALIDITY_TIME:
        if header['time_quality'] not in (p.PCIE_RECORD_V2_TIME_LOCAL_PIXEL_COUNTER_NS,
                                        p.PCIE_RECORD_V2_TIME_COMMON_FPGA_COUNTER_NS):
            raise ValueError('invalid RAW time provenance')
    elif header['capture_timestamp_ns'] or header['time_quality']:
        raise ValueError('unknown RAW time must remain unknown')
    if header['validity'] & p.PCIE_LZ_VALIDITY_BAYER:
        if header['bayer_phase'] not in (p.PCIE_LZ_BAYER_PHASES_RGGB, p.PCIE_LZ_BAYER_PHASES_GRBG,
                                       p.PCIE_LZ_BAYER_PHASES_GBRG, p.PCIE_LZ_BAYER_PHASES_BGGR):
            raise ValueError('invalid RAW Bayer phase')
    elif header['bayer_phase']:
        raise ValueError('unknown RAW Bayer phase must remain unknown')
    if not header['validity'] & p.PCIE_LZ_VALIDITY_DIAGNOSTICS and any(
            header[name] for name in ('selection_ordinal', 'admitted_ordinal', 'failed_total')):
        raise ValueError('unknown RAW diagnostics must be zero')
    return frame, header


class RotatingRawRecorder(RotatingRecorder):
    """Reuse exclusive-run ownership, quota accounting and verified eviction."""
    file_names = ('frame.raw10', 'frame.json')
    run_format = 'task3-raw10-run-v1'
    version_label = 'lz_version'

    def __init__(self, root, *, receiver_cohort, max_total_bytes=512*1024*1024, max_frames=128):
        _integer('max_frames', max_frames, 1, 1024)
        if max_total_bytes < p.PCIE_LZ_FRAME_RAW_BYTES + INDEX_LIMIT + 4096:
            raise ValueError('RAW quota cannot fit one complete frame and metadata')
        super().__init__(root, receiver_cohort=receiver_cohort, jpeg_version=p.LZ_HEADER_EXPECTED_VALUES['version'],
            max_frame_bytes=p.PCIE_LZ_FRAME_RAW_BYTES,
            max_segment_bytes=p.PCIE_LZ_FRAME_RAW_BYTES + INDEX_LIMIT, max_segment_records=1,
            max_total_bytes=max_total_bytes, max_records=max_frames, max_files=max(4, 1 + 2*max_frames))

    def append(self, product, key=None, *, received_ns=None):
        if self.closed or self.failed:
            raise RuntimeError('raw recorder is closed or faulted')
        try:
            frame, header = validate_frame(product)
            if key is not None and key != frame.identity:
                raise ValueError('RAW sink key must be the exact native identity')
            now = time.monotonic_ns() if received_ns is None else received_ns
            _integer('received_ns', now, 0, 2**63-1)
            if self._last is not None:
                previous, previous_ns = self._last
                if (frame.identity.source_session != previous.source_session or
                        frame.identity.mode_epoch < previous.mode_epoch or
                        (frame.identity.mode_epoch == previous.mode_epoch and
                         frame.identity.capture_sequence <= previous.capture_sequence) or now < previous_ns):
                    raise ValueError('old/repeated RAW source identity or host timestamp')
            row = _json(dict(format='task3-raw10-frame-v1', run_id=self.run_id,
                receiver_cohort=self.cohort, source=asdict(frame.identity),
                terminal_header={name: value.hex() if type(value) is bytes else value
                                 for name, value in header.items()},
                raw_bytes=len(frame.raw), raw_sha256=hashlib.sha256(frame.raw).hexdigest(),
                received_monotonic_ns=now, host_timing_only=True,
                tf_qualified=False, raw_bandwidth_qualified=False))
            if len(row) > INDEX_LIMIT:
                raise ValueError('RAW sidecar exceeds metadata bound')
            total = len(frame.raw) + len(row)
            self._reserve(total, records=1, new_segment=1)
            self._owned_root()
            self._serial += 1
            name = f'raw-{self._serial:08d}'
            path = self.root / (name + '.partial')
            path.mkdir(mode=0o700)
            self._active = dict(path=path, video=None, index=None)
            self._bytes += total  # Reserve even if a subsequent write is partial.
            for field, filename, data in (('video', 'frame.raw10', frame.raw), ('index', 'frame.json', row)):
                file = _open_new(path / filename)
                self._active[field] = file
                _write(file, data)
                _sync(file)
                file.close()
            _sync_dir(path)
            final = self.root / (name + '.segment')
            _publish_owned(path, final, self.root)
            self._sealed.append(dict(path=final, bytes=total, records=1,
                files={'frame.raw10': (len(frame.raw), hashlib.sha256(frame.raw).hexdigest()),
                       'frame.json': (len(row), hashlib.sha256(row).hexdigest())}))
            self._active = None
            self._records += 1
            self.written += 1
            self._last = frame.identity, now
        except BaseException as error:
            self.publication_uncertain |= isinstance(error, PublicationUncertain)
            self.abort()
            raise

    def _seal(self):
        # append publishes each complete RAW frame; never publish a failed partial.
        if self._active is not None:
            raise RuntimeError('incomplete RAW frame cannot be sealed')


class BoundedRawRecorderWorker(BoundedRecorderWorker):
    """Independent RAW queue: slow disk drops whole owned frames, no DMA views."""
    def __init__(self, root, *, queue_depth=2, recorder_factory=RotatingRawRecorder, **options):
        super().__init__(root, queue_depth=queue_depth, max_item_bytes=p.PCIE_LZ_FRAME_RAW_BYTES + INDEX_LIMIT,
                         recorder_factory=recorder_factory, **options)

    def _item_size(self, product):
        if not isinstance(product, RawProduct) or not isinstance(product.frame, NativeFrame):
            raise TypeError('RAW recording requires a completed NativeFrame')
        if type(product.frame.raw) is not bytes or len(product.frame.raw) != p.PCIE_LZ_FRAME_RAW_BYTES:
            raise ValueError('RAW recording cannot accept a partial frame')
        return len(product.frame.raw) + INDEX_LIMIT
