"""Bounded read-only RK host inventory. No device opens, MMIO or driver changes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
import struct
import sys


def read_bounded(path: Path, maximum: int = 65536) -> bytes | None:
    try:
        with path.open('rb') as stream:
            value = stream.read(maximum + 1)
    except (FileNotFoundError, PermissionError, IsADirectoryError, OSError):
        return None
    if len(value) > maximum:
        raise ValueError(f'inventory input exceeds {maximum} bytes: {path}')
    return value


def _text(path: Path, maximum: int = 65536) -> str | None:
    value = read_bounded(path, maximum)
    return None if value is None else value.decode('utf-8', errors='replace').replace('\x00', '|').strip('|\n ')


def _limited_children(path: Path, maximum: int):
    try:
        result = []
        for item in path.iterdir():
            result.append(item)
            if len(result) > maximum:
                raise ValueError(f'inventory directory exceeds {maximum} entries: {path}')
        return sorted(result)
    except (FileNotFoundError, PermissionError):
        return []


def _driver(path: Path) -> str | None:
    target = path / 'driver'
    return target.resolve().name if target.is_symlink() else None


def library_identity(path: Path) -> dict:
    # Reading a regular library does not dlopen it or initialize MPP hardware.
    if not path.is_file():
        return {'path': str(path), 'status': 'MISSING'}
    if path.stat().st_size > 64 * 1024 * 1024:
        raise ValueError('library inventory limited to 64 MiB per file')
    data = read_bounded(path, 64 * 1024 * 1024)
    if data is None:
        return {'path': str(path), 'status': 'UNREADABLE'}
    result = {'path': str(path.resolve()), 'bytes': len(data),
              'sha256': hashlib.sha256(data).hexdigest(), 'status': 'READ_ONLY'}
    if data[:6] == b'\x7fELF\x02\x01' and len(data) >= 64:
        result.update(elf_class=64, endian='little', elf_type=struct.unpack_from('<H', data, 16)[0],
                      machine=struct.unpack_from('<H', data, 18)[0])
    else:
        result['elf'] = 'NOT_ELF64_LITTLE'
    return result


def inspect_host(*, sys_root=Path('/sys'), proc_root=Path('/proc'), libraries=(), kernel_build=None) -> dict:
    sys_root, proc_root = Path(sys_root), Path(proc_root)
    if len(libraries) > 8:
        raise ValueError('at most eight explicit libraries')
    pci = []
    module_names = {'ph1a_c2h', 'mpp_service', 'rockchipdrm', 'rga3', 'rknpu'}
    for path in _limited_children(sys_root / 'bus/pci/devices', 512):
        module_link = path / 'driver/module'
        module_name = module_link.resolve().name if module_link.is_symlink() else None
        if module_name:
            module_names.add(module_name)
        pci.append({'bdf': path.name, 'vendor': _text(path / 'vendor', 32),
                    'device': _text(path / 'device', 32), 'class': _text(path / 'class', 32),
                    'driver': _driver(path), 'module': module_name,
                    'current_link_speed': _text(path / 'current_link_speed', 128),
                    'current_link_width': _text(path / 'current_link_width', 32)})
    drm = []
    for path in _limited_children(sys_root / 'class/drm', 128):
        if '-' not in path.name or not path.name.startswith('card'):
            continue
        edid = read_bounded(path / 'edid', 32768)
        drm.append({'connector': path.name, 'status': _text(path / 'status', 64),
                    'modes': (_text(path / 'modes', 8192) or '').splitlines(),
                    'edid_sha256': hashlib.sha256(edid).hexdigest() if edid else None})
    dt = sys_root / 'firmware/devicetree/base'
    nodes = {}
    for name in ('pcie@2a210000', 'usb@23400000', 'phy@2b060000'):
        node = dt / name
        nodes[name] = {'present': node.is_dir(), 'status': _text(node / 'status', 256),
                       'compatible': _text(node / 'compatible', 1024)}
    mem = _text(proc_root / 'meminfo') or ''
    memory = {line.split(':', 1)[0]: line.split(':', 1)[1].strip() for line in mem.splitlines()
              if ':' in line and line.split(':', 1)[0] in ('MemTotal', 'MemAvailable', 'CmaTotal', 'CmaFree')}
    config = read_bounded(proc_root / 'config.gz', 2 * 1024 * 1024)
    kernel = None
    if kernel_build is not None:
        base = Path(kernel_build)
        kernel = {'path': str(base.resolve()), 'present': base.is_dir(), 'inputs': {}}
        for name in ('.config', 'Module.symvers', 'include/generated/utsrelease.h', 'include/generated/autoconf.h'):
            data = read_bounded(base / name, 16 * 1024 * 1024)
            kernel['inputs'][name] = None if data is None else {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    modules = []
    for name in sorted(module_names):
        path = sys_root / 'module' / name
        note = read_bounded(path / 'notes/.note.gnu.build-id', 4096)
        modules.append({'name': name, 'sysfs_present': path.is_dir(),
                        'version': _text(path / 'version', 256), 'srcversion': _text(path / 'srcversion', 256),
                        'build_id_note_sha256': hashlib.sha256(note).hexdigest() if note else None,
                        'build_id_note_hex': note.hex() if note else None,
                        'parameters': {key: _text(path / 'parameters' / key, 128) for key in
                                       ('slots', 'capacity', 'dma_bits', 'irq_hint', 'poll_ms', 'drain_ms')}
                        if name == 'ph1a_c2h' else {}})
    return {
        'scope': 'READ_ONLY_HOST_INVENTORY_NOT_DMA_OR_BOARD_QUALIFICATION',
        'roots': {'sys': str(sys_root), 'proc': str(proc_root)},
        'machine': platform.machine(), 'python': sys.version,
        'kernel_release': _text(proc_root / 'sys/kernel/osrelease', 256),
        'boot_id': _text(proc_root / 'sys/kernel/random/boot_id', 128),
        'model': _text(dt / 'model', 1024), 'compatible': _text(dt / 'compatible', 2048),
        'historical_shared_phy_nodes': nodes, 'pci': pci, 'drm': drm, 'memory': memory, 'modules': modules,
        'running_config_gz_sha256': hashlib.sha256(config).hexdigest() if config else None,
        'libraries': [library_identity(Path(path)) for path in libraries], 'kernel_build': kernel,
        'limitations': ['No /dev node, BAR, GPIO, driver binding, power or display mode was changed.',
                        'Node names are historical hints, not proof of the active routing; missing status is not disabled.',
                        'Kernel input hashes and a release string alone do not prove module compatibility.',
                        'Missing module sysfs does not exclude built-in support; driver ABI numbers do not identify its exact build.',
                        'Connected HDMI and advertised modes do not prove actual presentation rate.'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--library', action='append', default=[], type=Path)
    parser.add_argument('--kernel-build', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if sys.platform != 'linux':
        parser.error('actual host inventory must run on Linux; use injected roots only in tests')
    report = json.dumps(inspect_host(libraries=args.library, kernel_build=args.kernel_build), indent=2)
    if args.output:
        with args.output.open('x', encoding='utf-8') as stream:
            stream.write(report + '\n')
    else:
        print(report)


if __name__ == '__main__':
    main()
