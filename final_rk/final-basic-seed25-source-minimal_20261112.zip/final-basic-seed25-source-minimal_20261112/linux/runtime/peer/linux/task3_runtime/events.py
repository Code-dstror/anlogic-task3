"""Bounded delivery of supplied alerts; no collision/lane/obstacle inference.

Events attach to an observed SOURCE frame, never the latest unrelated preview.
No distance is synthesized. Voice is an optional explicitly serviced callback;
publishing never starts audio devices, TTS, processes or callback work.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import hashlib
import math
import os
from pathlib import Path
import stat
import struct
import subprocess
from threading import Lock
import time

from .pipeline import SourceKey

KINDS = frozenset(('collision', 'lane', 'obstacle'))
SEVERITIES = frozenset(('info', 'warning', 'critical'))


@dataclass(frozen=True)
class AlertEvent:
    event_id: int
    kind: str
    key: SourceKey
    severity: str
    message: str
    created_monotonic_ns: int
    expires_monotonic_ns: int


class WavVoiceSink:
    """Explicit prerecorded PCM alerts through a separately dispatched aplay.

    Initialization performs file validation only. No TTS or inferred distance is
    generated. Missing configuration is visible in snapshot(); calling an
    unavailable sink raises, so EventRouter accounts the failed delivery.
    subprocess.run kills/waits for its own audio child on TimeoutExpired. It has
    no reference to the Receiver, DMA worker, or consumer lease.
    """
    def __init__(self, wav_paths, *, aplay_path, alsa_device, max_bytes=4*1024*1024,
                 max_duration_s=5, timeout_s=6, runner=subprocess.run, clock=time.monotonic_ns):
        if type(max_bytes) is not int or not 44 <= max_bytes <= 16*1024*1024:
            raise ValueError('invalid WAV byte bound')
        if (type(max_duration_s) not in (int, float) or not math.isfinite(max_duration_s) or
                not 0 < max_duration_s <= 30 or type(timeout_s) not in (int, float) or
                not math.isfinite(timeout_s) or not 0 < timeout_s <= 60):
            raise ValueError('invalid voice duration/timeout bound')
        if (type(alsa_device) is not str or not 1 <= len(alsa_device) <= 128 or
                '\0' in alsa_device):
            raise ValueError('explicit ALSA device required')
        if type(wav_paths) is not dict or not set(wav_paths) <= KINDS:
            raise ValueError('WAV mapping must use collision/lane/obstacle kinds')
        self.max_bytes, self.max_duration_s, self.timeout_s = max_bytes, max_duration_s, timeout_s
        self.device, self.runner, self.clock = alsa_device, runner, clock
        self.paths, self._identities = {}, {}
        self.configured = False
        self.reason = None
        self.attempts = self.completed = self.timeouts = self.failures = 0
        self.aplay = str(aplay_path) if aplay_path is not None else ''
        binary = Path(self.aplay)
        if (not self.aplay or not binary.is_absolute() or not binary.is_file() or
                not os.access(binary, os.X_OK)):
            self.reason = 'NOT_CONFIGURED: explicit aplay executable is unavailable'
            return
        if not wav_paths:
            self.reason = 'NOT_CONFIGURED: no prerecorded WAV alerts supplied'
            return
        try:
            for kind, name in wav_paths.items():
                path = Path(name)
                if not path.is_absolute():
                    raise ValueError('WAV paths must be explicit absolute paths')
                self._identities[kind] = self._validate(path)
                self.paths[kind] = path
        except (OSError, ValueError) as error:
            self.reason = f'NOT_CONFIGURED: {error}'[:512]
            self.paths.clear()
            self._identities.clear()
            return
        self.configured = True

    def _validate(self, path):
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or
                not 44 <= info.st_size <= self.max_bytes):
            raise ValueError('WAV must be one bounded regular file')
        with path.open('rb') as file:
            raw = file.read(self.max_bytes + 1)
        if (len(raw) != info.st_size or raw[:4] != b'RIFF' or raw[8:12] != b'WAVE' or
                struct.unpack_from('<I', raw, 4)[0] + 8 != len(raw)):
            raise ValueError('invalid/truncated WAV RIFF envelope')
        cursor, fmt, payload = 12, None, None
        while cursor < len(raw):
            if cursor + 8 > len(raw):
                raise ValueError('truncated WAV chunk')
            name, length = struct.unpack_from('<4sI', raw, cursor)
            cursor += 8
            if cursor + length + (length & 1) > len(raw):
                raise ValueError('WAV chunk exceeds file')
            if name == b'fmt ':
                if fmt is not None or length != 16:
                    raise ValueError('only one standard PCM WAV fmt is supported')
                fmt = struct.unpack_from('<HHIIHH', raw, cursor)
            elif name == b'data':
                if payload is not None:
                    raise ValueError('duplicate WAV data')
                payload = length
            cursor += length + (length & 1)
        if fmt is None or payload is None:
            raise ValueError('WAV requires PCM format and data')
        codec, channels, rate, byte_rate, align, bits = fmt
        if (codec != 1 or channels not in (1, 2) or bits not in (8, 16, 24, 32) or
                not 8000 <= rate <= 192000 or align != channels * (bits // 8) or
                byte_rate != rate * align or not payload or payload % align or
                payload / byte_rate > self.max_duration_s):
            raise ValueError('WAV must contain bounded-duration integer PCM audio')
        return (info.st_dev, info.st_ino, info.st_size, hashlib.sha256(raw).hexdigest())

    def __call__(self, event):
        if not isinstance(event, AlertEvent):
            raise TypeError('voice sink requires a structured AlertEvent')
        if not self.configured or event.kind not in self.paths:
            raise RuntimeError(self.reason or f'NOT_CONFIGURED: no WAV for {event.kind}')
        self.attempts += 1
        try:
            path = self.paths[event.kind]
            if self._validate(path) != self._identities[event.kind]:
                raise ValueError('WAV changed since voice configuration')
            now = self.clock()
            if type(now) is not int or not event.created_monotonic_ns <= now < event.expires_monotonic_ns:
                raise ValueError('voice alert expired or clock domain mismatched')
            timeout = min(self.timeout_s, (event.expires_monotonic_ns - now) / 1e9)
            result = self.runner([self.aplay, '-q', '-D', self.device, '--', str(path)],
                shell=False, check=False, timeout=timeout, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if result.returncode != 0:
                raise RuntimeError(f'aplay failed with exit status {result.returncode}')
            self.completed += 1
        except subprocess.TimeoutExpired:
            self.timeouts += 1
            self.failures += 1
            raise
        except Exception:
            self.failures += 1
            raise

    def snapshot(self):
        return dict(configured=self.configured, reason=self.reason, mapped_kinds=tuple(sorted(self.paths)),
                    attempts=self.attempts, completed=self.completed, timeouts=self.timeouts,
                    failures=self.failures, device_qualified=False)


class EventRouter:
    """One serialized SOURCE producer, bounded pending display/voice events.

    event_id is a caller-assigned globally increasing positive integer. The
    constant-space high watermark rejects replay even after queue eviction.
    A new session/cohort needs a new router. Epoch increases clear older events
    and frame registrations; capture sequence may restart in a new epoch.
    """
    def __init__(self, *, receiver_cohort, capacity=32, frame_window=8,
                 max_ttl_s=3.0, min_interval_s=1.0,
                 clock=time.monotonic_ns, voice_sink=None):
        if not isinstance(receiver_cohort, str) or not 1 <= len(receiver_cohort) <= 128:
            raise ValueError('explicit bounded receiver cohort required')
        for name, value, high in (('capacity', capacity, 1024), ('frame_window', frame_window, 1024)):
            if type(value) is not int or not 1 <= value <= high:
                raise ValueError(f'invalid {name}')
        for name, value, low in (('max_ttl_s', max_ttl_s, 0.001), ('min_interval_s', min_interval_s, 0)):
            if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= 60:
                raise ValueError(f'invalid {name}')
        if voice_sink is not None and not callable(voice_sink):
            raise TypeError('voice sink must be a callback')
        self.cohort, self.capacity, self.frame_window = receiver_cohort, capacity, frame_window
        self.max_ttl_ns, self.interval_ns = int(max_ttl_s*1e9), int(min_interval_s*1e9)
        self.clock, self.voice_sink = clock, voice_sink
        self._lock, self._voice_dispatch_lock = Lock(), Lock()
        self._frames, self._events, self._voice = deque(), deque(), deque()
        self._last_key = None
        self._last_id = self._last_now = 0
        self._last_kind = {}
        self.accepted = self.rejected = self.rate_limited = self.dropped = self.expired = 0
        self.voice_delivered = self.voice_failed = self.voice_dropped = 0

    def _now(self):
        now = self.clock()
        if type(now) is not int or now < self._last_now:
            raise ValueError('invalid/backward monotonic clock')
        self._last_now = now
        return now

    def _key(self, key):
        if (not isinstance(key, SourceKey) or key.receiver_cohort != self.cohort or
                type(key.camera) is not int or key.camera != 0 or
                any(type(value) is not int or not 0 <= value <= 0xffffffff
                    for value in (key.session, key.epoch, key.sequence, key.jpeg_generation)) or
                not key.session or not key.jpeg_generation):
            raise ValueError('exact single-camera SOURCE identity is required')

    def _prune(self, now):
        while self._frames and now - self._frames[0][1] >= self.max_ttl_ns:
            self._frames.popleft()
        retained = deque(event for event in self._events if event.expires_monotonic_ns > now)
        self.expired += len(self._events) - len(retained)
        self._events = retained
        retained_voice = deque(event for event in self._voice if event.expires_monotonic_ns > now)
        self.voice_dropped += len(self._voice) - len(retained_voice)
        self._voice = retained_voice

    def observe_frame(self, key, *, received_ns=None):
        self._key(key)
        with self._lock:
            now = self._now()
            received = now if received_ns is None else received_ns
            if type(received) is not int or not 0 <= received <= now:
                raise ValueError('invalid observed-frame monotonic timestamp')
            previous = self._last_key
            if previous is not None and (key.session != previous.session or key.epoch < previous.epoch or
                                         (key.epoch == previous.epoch and key.sequence <= previous.sequence)):
                raise ValueError('old/session-changed/repeated SOURCE frame')
            if self._frames and received < self._frames[-1][1]:
                raise ValueError('backward observed-frame timestamp')
            if previous is not None and key.epoch != previous.epoch:
                self.dropped += len(self._events)
                self.voice_dropped += len(self._voice)
                self._frames.clear()
                self._events.clear()
                self._voice.clear()
            self._last_key = key
            self._frames.append((key, received))
            while len(self._frames) > self.frame_window:
                self._frames.popleft()
            self._prune(now)

    def publish(self, *, event_id, kind, key, severity, ttl_s, message=''):
        self._key(key)
        if (type(event_id) is not int or not 1 <= event_id <= 2**63-1 or
                kind not in KINDS or severity not in SEVERITIES or
                type(message) is not str or len(message) > 160 or
                type(ttl_s) not in (int, float) or not math.isfinite(ttl_s) or
                not 0 < ttl_s*1e9 <= self.max_ttl_ns):
            raise ValueError('invalid structured alert')
        with self._lock:
            now = self._now()
            self._prune(now)
            observed = next((stamp for frame, stamp in self._frames if frame == key), None)
            if (event_id <= self._last_id or observed is None or self._last_key is None or
                    key.session != self._last_key.session or key.epoch != self._last_key.epoch or
                    observed + int(ttl_s*1e9) <= now):
                self.rejected += 1
                return None
            self._last_id = event_id  # Valid candidate IDs cannot be replayed after rate limiting.
            previous = self._last_kind.get(kind)
            if previous is not None and now - previous < self.interval_ns:
                self.rate_limited += 1
                return None
            event = AlertEvent(event_id, kind, key, severity, message, now,
                               observed + int(ttl_s*1e9))
            self._last_kind[kind] = now
            if len(self._events) == self.capacity:
                self._events.popleft()
                self.dropped += 1
            self._events.append(event)
            if self.voice_sink is not None:
                if len(self._voice) == self.capacity:
                    self._voice.popleft()
                    self.voice_dropped += 1
                self._voice.append(event)
            self.accepted += 1
            return event

    def take(self):
        with self._lock:
            self._prune(self._now())
            return self._events.popleft() if self._events else None

    def dispatch_voice(self, maximum=1):
        """Caller chooses a separate consumer context; callback may block.

        No retries: a callback error can follow a partially delivered utterance.
        This method never holds the router lock while invoking the callback.
        """
        if type(maximum) is not int or not 1 <= maximum <= self.capacity:
            raise ValueError('invalid voice dispatch bound')
        if not self._voice_dispatch_lock.acquire(blocking=False):
            return 0
        try:
            return self._dispatch_voice(maximum)
        finally:
            self._voice_dispatch_lock.release()

    def _dispatch_voice(self, maximum):
        delivered = 0
        for _ in range(maximum):
            with self._lock:
                self._prune(self._now())
                event = self._voice.popleft() if self._voice else None
            if event is None:
                break
            try:
                self.voice_sink(event)
            except Exception:
                with self._lock:
                    self.voice_failed += 1
            else:
                with self._lock:
                    self.voice_delivered += 1
                delivered += 1
        return delivered

    def snapshot(self):
        with self._lock:
            self._prune(self._now())
            return dict(accepted=self.accepted, rejected=self.rejected, rate_limited=self.rate_limited,
                dropped=self.dropped, expired=self.expired, pending=len(self._events),
                registered_frames=len(self._frames), voice_pending=len(self._voice),
                voice_delivered=self.voice_delivered, voice_failed=self.voice_failed,
                voice_dropped=self.voice_dropped, voice_device='NOT_RUN')
