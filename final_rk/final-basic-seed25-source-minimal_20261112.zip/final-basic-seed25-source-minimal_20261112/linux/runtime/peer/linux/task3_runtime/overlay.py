"""Render supplied exact-frame detection boxes onto owned stride-padded NV12.

This module performs no recognition, distance estimate, tracking or coordinate
transform. Source bboxes are half-open (x0,y0,x1,y1): finite ordered coordinates
are clipped to the visible image, lower edges floor and upper edges ceil. A box
with no visible intersection is rejected. Lines extend inward from that integer
rectangle. All provided detections (at most the broker's 256) are validated;
only the first max_boxes (1..64, default32) are drawn, without changing results.

Y outside the stroke, all padding and untouched UV cells remain byte-identical.
NV12 shares one U,V pair per 2x2 luma cell: neutralizing a touched stroke cell
also affects that cell's neighboring luma pixels, as the format requires.
Drawing uses row slices and perimeter row loops, never Python full-image loops.
Two bounded owned NV12 allocations cover the mutable drawing and returned bytes.
These display budgets are local settings, not a wire protocol or hardware range
qualification. Caller must verify the actual producer's NV12 range/colorimetry.
Result validity is checked before drawing and after the owned return copy;
subsequent pipe/physical presentation time is not measured or guaranteed.
"""
from __future__ import annotations

from dataclasses import replace
import math
import time

from linux.pixel_native import BT601_FULL, BT601_LIMITED
from linux.stream_diag.decoder import DecodedFrame
from linux.stream_diag.records import Record
from linux.task3_pipeline import pcie_protocol_v1 as p
from linux.task3_pipeline.record_v2 import RecordMetadata, SourceStamp
from linux.vision_api.inference import CompletedInference, InferenceTicket
from linux.vision_api.types import (Detection, FrameMeta, FrameRef, SourceFrameMetadata,
                                    SourceFrameStamp, VisionResult)
from .display import _validate
from .pipeline import DisplayFrame, SourceKey


class OverlayError(ValueError):
    pass


def _match(envelope, completed, now):
    if (type(envelope) is not DisplayFrame or type(envelope.key) is not SourceKey
            or type(envelope.decoded) is not DecodedFrame or type(envelope.record) is not Record):
        raise OverlayError("box overlay requires the exact owned display/decoded/record types")
    _validate(envelope)
    key, frame, metadata = envelope.key, envelope.decoded, envelope.record.metadata
    if (key.session is None or type(metadata) is not RecordMetadata
            or type(metadata.source) is not SourceStamp):
        raise OverlayError("box overlay requires complete SOURCE and JPEG generation")
    if type(completed) is not CompletedInference or type(completed.ticket) is not InferenceTicket:
        raise OverlayError("expected a completed inference ticket")
    ticket, result = completed.ticket, completed.result
    if type(ticket.meta) is not FrameMeta or type(result) is not VisionResult:
        raise OverlayError("invalid completed inference metadata/result")
    meta, source = ticket.meta, ticket.meta.source_metadata
    if (type(meta.ref) is not FrameRef or type(result.frame_ref) is not FrameRef
            or type(source) is not SourceFrameMetadata or type(source.stamp) is not SourceFrameStamp):
        raise OverlayError("inference lacks an exact SOURCE/ref")
    stamp = source.stamp
    identity = (stamp.session_id, stamp.mode_epoch, stamp.camera_id, stamp.sequence, source.jpeg_generation)
    if (any(type(value) is not int or not 0 <= value <= 0xffffffff for value in identity)
            or identity != (key.session, key.epoch, key.camera, key.sequence, key.jpeg_generation)
            or source.jpeg_session_id != metadata.jpeg_session or source.jpeg_slot != metadata.jpeg_slot):
        raise OverlayError("inference belongs to a different SOURCE/JPEG generation")
    kinds = {p.PCIE_RECORD_V2_SOURCE_PHYSICAL: "PHYSICAL_CAMERA",
             p.PCIE_RECORD_V2_SOURCE_DIGITAL_REPLAY: "DIGITAL_REPLAY"}
    formats = {p.PCIE_RECORD_V2_FORMAT_RAW10: "RAW10", p.PCIE_RECORD_V2_FORMAT_RAW14: "RAW14"}
    roles = {p.PCIE_RECORD_V2_ROLE_SINGLE: "SINGLE", p.PCIE_RECORD_V2_ROLE_LONG: "LONG",
             p.PCIE_RECORD_V2_ROLE_SHORT: "SHORT"}
    original = metadata.source
    if (original.kind not in kinds or original.format not in formats or original.role not in roles
            or stamp.source_kind != kinds.get(original.kind) or stamp.source_format != formats.get(original.format)
            or stamp.exposure_role != roles.get(original.role) or meta.source_kind != stamp.source_kind):
        raise OverlayError("inference SOURCE format/kind/exposure association differs")
    if ((meta.width, meta.height, meta.stride, meta.pixel_format) !=
            (frame.width, frame.height, frame.width * 3, "RGB888")
            or result.frame_ref != meta.ref or result.profile_id != meta.profile_id
            or type(meta.profile_id) is not str or not 1 <= len(meta.profile_id) <= 128
            or type(result.model_id) is not str or not 1 <= len(result.model_id) <= 128
            or result.coordinate_space != "source"):
        raise OverlayError("inference geometry/ref/profile/source coordinates differ")
    times = (now, meta.received_monotonic_ns, ticket.issued_ns, ticket.deadline_ns,
             result.produced_ns, completed.completed_ns)
    if (any(type(value) is not int or value < 0 for value in times)
            or not meta.received_monotonic_ns <= ticket.issued_ns <= result.produced_ns <= completed.completed_ns <= now
            or not now < ticket.deadline_ns):
        raise OverlayError("inference is expired or has invalid host monotonic times")
    return frame, result


def _rectangle(detection, width, height):
    if type(detection) is not Detection or type(detection.bbox) is not tuple or len(detection.bbox) != 4:
        raise OverlayError("expected a bounded detection with four source coordinates")
    bbox = detection.bbox
    if (any(type(value) not in (int, float) or type(value) is float and not math.isfinite(value) for value in bbox)
            or not bbox[0] < bbox[2] or not bbox[1] < bbox[3]
            or type(detection.class_id) is not int or detection.class_id < 0
            or type(detection.score) not in (int, float) or not 0 <= detection.score <= 1
            or type(detection.score) is float and not math.isfinite(detection.score)):
        raise OverlayError("invalid/nonfinite detection box, class or score")
    x0, y0, x1, y1 = bbox
    clipped = (max(0, min(width, x0)), max(0, min(height, y0)),
               max(0, min(width, x1)), max(0, min(height, y1)))
    if clipped[0] >= clipped[2] or clipped[1] >= clipped[3]:
        raise OverlayError("detection box has no visible source intersection")
    return (math.floor(clipped[0]), math.floor(clipped[1]),
            math.ceil(clipped[2]), math.ceil(clipped[3]))


def _stroke(output, stride, rows, rectangle, thickness, white):
    x0, y0, x1, y1 = rectangle
    uv_base = stride * rows

    def line(y, left, right):
        output[y * stride + left:y * stride + right] = white * (right - left)
        # Each affected 2x2 cell gets neutral U and V; active bounds are even.
        uv_left, uv_right = left // 2 * 2, (right + 1) // 2 * 2
        start = uv_base + (y // 2) * stride
        output[start + uv_left:start + uv_right] = b"\x80" * (uv_right - uv_left)

    top_end, bottom_start = min(y1, y0 + thickness), max(y0, y1 - thickness)
    for y in range(y0, top_end):
        line(y, x0, x1)
    for y in range(max(top_end, bottom_start), y1):
        line(y, x0, x1)
    for y in range(top_end, bottom_start):
        line(y, x0, min(x1, x0 + thickness))
        right_start = max(x0 + thickness, x1 - thickness)
        if right_start < x1:
            line(y, right_start, x1)


def make_box_overlay(nv12_range, max_boxes=32, thickness=2, *, clock=time.monotonic_ns):
    """Return callback(DisplayFrame, CompletedInference) -> owned DecodedFrame.

    FULL draws Y255, LIMITED Y235; U/V are128. thickness is 1..16 pixels and
    max_boxes is1..64. Box clipping/rounding and NV12 shared-chroma behavior are
    defined in this module's docstring. No result is invented or modified.
    """
    if type(nv12_range) is not str or nv12_range not in (BT601_FULL, BT601_LIMITED):
        raise ValueError("explicit verified BT601_FULL/BT601_LIMITED range required")
    if type(max_boxes) is not int or not 1 <= max_boxes <= 64:
        raise ValueError("overlay max_boxes must be 1..64")
    if type(thickness) is not int or not 1 <= thickness <= 16:
        raise ValueError("overlay thickness must be 1..16")
    if not callable(clock):
        raise TypeError("overlay clock must be callable")
    white = bytes([255 if nv12_range == BT601_FULL else 235])

    def overlay(envelope, completed):
        started = clock()
        frame, result = _match(envelope, completed, started)
        if type(result.boxes) is not tuple or len(result.boxes) > 256:
            raise OverlayError("inference detection tuple exceeds broker's 256-box contract")
        # Validate every bounded supplied box before allocating/drawing anything.
        rectangles = [_rectangle(detection, frame.width, frame.height) for detection in result.boxes]
        output = bytearray(frame.nv12)
        for rectangle in rectangles[:max_boxes]:
            _stroke(output, frame.hor_stride, frame.ver_stride,
                    rectangle, thickness, white)
        owned = bytes(output)
        finished = clock()
        if type(finished) is not int or not started <= finished < completed.ticket.deadline_ns:
            raise OverlayError("inference expired before overlay copy completed")
        return replace(frame, nv12=owned)

    return overlay
