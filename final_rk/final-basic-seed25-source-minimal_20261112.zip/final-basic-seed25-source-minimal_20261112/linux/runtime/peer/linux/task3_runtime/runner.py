"""Explicit C2H runtime assembly; importing this module opens no devices.

One receiver owns DMA and BAR access. A bounded control worker serializes the
same ConfigTransactions while the receive loop continues to service buffers.
Faulted, unconfirmed owners are retained; cleanup is never a substitute for drain.
"""
from __future__ import annotations

import argparse
from collections import deque
from dataclasses import asdict, dataclass, field
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import sys
from threading import Condition, Event, Thread
import time
import uuid

from linux.task3_pipeline import pcie_protocol_v1 as p
from linux.task3_pipeline.config_transaction import Configuration
from linux.task3_pipeline.advanced_config import AdvancedConfiguration
from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
from linux.task3_pipeline.adaptive_config_owner import AdaptiveConfigOwner, Profile
from linux.task3_pipeline.source_stamp import RecordV2Providers
from linux.task3_pipeline.vision_execution import SemanticExecutionAdapter
from linux.vision_api import ActionStatus, FrameRef
from .pipeline import LatestMailbox, ProductPipeline
from .session import C2HSession


def _positive(value, name, *, maximum=None):
    if (type(value) not in (int, float) or not math.isfinite(value) or value <= 0
            or maximum is not None and value > maximum):
        raise ValueError(f'{name} must be finite and positive')


def _image_configuration_only(extension):
    """Transport drain does not prove FPGA product-workspace switch safety."""
    if isinstance(extension, MonoConfiguration) and extension.product_mode != p.PCIE_CFG_V2_MODES_MONO_SDR:
        raise ValueError('runtime product-mode changes are unsupported; FPGA backlog may remain')
    if isinstance(extension, AdvancedConfiguration) and extension.enable & (
            p.PCIE_CFG_EXT_FEATURE_HDR | p.PCIE_CFG_EXT_FEATURE_CFS):
        raise ValueError('runtime HDR/CFS product changes require an unavailable FPGA quiet barrier')


@dataclass(frozen=True)
class RunOptions:
    device: str
    jpeg_version: int
    mpp_library: Path
    pixel_library: Path
    nv12_range: str
    config_timeout_s: float
    drain_timeout_s: float
    report_output: Path
    max_seconds: float | None = None
    poll_seconds: float = .02
    mpp_timeout_ms: int = 1000
    connector_id: int | None = None
    plane_id: int | None = None
    gst_colorimetry: str | None = None
    record_dir: Path | None = None
    enable_vision: bool = False
    vision_max_fps: float = 1.0
    enable_lz: bool = False
    lz_library: Path | None = None
    lz_frame_timeout_s: float | None = None
    raw_record_dir: Path | None = None
    display_delay_ms: float = 0
    resume_receipt: Path | None = None
    resume_receipt_output: Path | None = None
    warm_source_barrier: bool = False

    def validate(self):
        if not isinstance(self.device, str) or not self.device or '\x00' in self.device:
            raise ValueError('explicit device path required')
        if type(self.jpeg_version) is not int or self.jpeg_version not in (1, 2, 3):
            raise ValueError('explicit JPEG record version 1, 2 or 3 required')
        if self.nv12_range not in ('BT601_FULL', 'BT601_LIMITED'):
            raise ValueError('explicit verified NV12 color range required')
        for name in ('config_timeout_s', 'drain_timeout_s', 'poll_seconds', 'vision_max_fps'):
            _positive(getattr(self, name), name)
        if self.poll_seconds > 1 or self.vision_max_fps > 60:
            raise ValueError('poll interval <=1s and vision sampling <=60Hz required')
        if self.max_seconds is not None:
            _positive(self.max_seconds, 'max_seconds')
        if type(self.mpp_timeout_ms) is not int or not 1 <= self.mpp_timeout_ms < 8000:
            raise ValueError('MPP timeout must be 1..7999ms')
        for name in ('enable_vision', 'enable_lz'):
            if type(getattr(self, name)) is not bool:
                raise ValueError('feature switches must be bool')
        for name in ('connector_id', 'plane_id'):
            value = getattr(self, name)
            if value is not None and (type(value) is not int or value < 0):
                raise ValueError('display IDs must be explicit nonnegative integers')
        if self.connector_id is None and (self.plane_id is not None or self.gst_colorimetry is not None):
            raise ValueError('display options require a connector')
        if self.connector_id is not None and not self.gst_colorimetry:
            raise ValueError('display requires explicit verified GStreamer colorimetry')
        if (type(self.display_delay_ms) not in (int, float) or not math.isfinite(self.display_delay_ms)
                or not 0 <= self.display_delay_ms <= 100):
            raise ValueError('display delay must be finite 0..100 milliseconds')
        if self.display_delay_ms and self.connector_id is None:
            raise ValueError('nonzero display delay requires a connector')
        if self.enable_lz and (self.lz_library is None or self.jpeg_version == 1):
            raise ValueError('LZ needs an explicit native library and source-stamped JPEG records')
        if self.enable_lz:
            _positive(self.lz_frame_timeout_s, 'lz_frame_timeout_s')
        elif self.lz_frame_timeout_s is not None:
            raise ValueError('LZ frame timeout requires an enabled LZ owner')
        if self.raw_record_dir is not None and not self.enable_lz:
            raise ValueError('RAW recording requires LZ recovery')
        if (self.resume_receipt is not None or self.resume_receipt_output is not None) and (
                self.jpeg_version not in (2, 3) or self.enable_lz):
            raise ValueError('warm resume receipts support explicit record-v2/v3 JPEG only')
        if type(self.warm_source_barrier) is not bool or self.warm_source_barrier and self.resume_receipt is None:
            raise ValueError('source epoch barrier requires an explicit warm resume receipt')
        if self.resume_receipt is not None and self.enable_vision and not self.warm_source_barrier:
            raise ValueError('warm backlog capture freshness is unqualified; vision/AI is disabled')
        if self.resume_receipt_output is not None and (
                Path(self.resume_receipt_output).absolute() == Path(self.report_output).absolute()
                or self.resume_receipt is not None and Path(self.resume_receipt_output).absolute() == Path(self.resume_receipt).absolute()):
            raise ValueError('resume output must be a new distinct receipt file')


@dataclass
class ControlTicket:
    """Caller owns the result; the worker retains no unbounded result history."""
    done: Event = field(default_factory=Event)
    result: object = None
    error: str | None = None


class ControlWorker:
    """One command stream; a semantic owner and manual writer cannot coexist."""
    def __init__(self, transactions, *, adapter=None, fixed_source_epoch=None, depth=4):
        if type(depth) is not int or not 1 <= depth <= 16:
            raise ValueError('control mailbox depth must be 1..16')
        self.transactions, self.adapter, self.fixed_source_epoch = transactions, adapter, fixed_source_epoch
        self.depth = depth
        self._cv, self._queue = Condition(), deque()
        self._thread = None
        self._stop = self._busy = False
        self.failure = None
        self.submitted = self.completed = self.cancelled = 0
        self.last_applied = None
        self._barrier_locked = False

    def start(self):
        with self._cv:
            if self._thread is not None or self._stop:
                raise RuntimeError('control worker is single use')
            self._thread = Thread(target=self._run, name='task3-control', daemon=True)
            self._thread.start()
        return self

    def _submit(self, kind, args):
        with self._cv:
            if self.fixed_source_epoch is not None:
                raise RuntimeError('LZ source epoch is fixed; explicit stopped rebind is required')
            if self._thread is None or self._stop or self.failure:
                raise RuntimeError('control mailbox is closed')
            if len(self._queue) >= self.depth:
                raise RuntimeError('control mailbox is full')
            ticket = ControlTicket()
            self._queue.append((kind, args, ticket))
            self.submitted += 1
            self._cv.notify()
            return ticket

    def configure(self, configuration: Configuration, *, extension=None):
        if self._barrier_locked:
            raise RuntimeError('warm source barrier owns the control mailbox')
        if self.adapter is not None:
            raise RuntimeError('semantic owner owns CFG; manual writes are disabled')
        if not isinstance(configuration, Configuration) or extension is not None and not isinstance(
                extension, (AdvancedConfiguration, MonoConfiguration)):
            raise TypeError('immutable bounded configuration snapshots required')
        configuration.validate()
        if extension is not None:
            extension.words()
        _image_configuration_only(extension)
        return self._submit('manual', (configuration, extension))

    def source_barrier(self, configuration, extension):
        with self._cv:
            if self.adapter is not None or self.submitted or self._busy or self._queue:
                raise RuntimeError('source barrier must be the first sole control operation')
            self._barrier_locked = True
        _image_configuration_only(extension)
        return self._submit('manual', (configuration, extension))

    def release_source_barrier(self):
        with self._cv:
            self._barrier_locked = False

    def semantic(self, *args):
        if self.adapter is None:
            raise RuntimeError('no trusted semantic owner was configured')
        if len(args) != 6:
            raise ValueError('complete semantic request required')
        client, request, ref, kind, values, deadline = args
        if (any(type(value) is not str or not 1 <= len(value) <= 128 for value in (client, request))
                or not isinstance(ref, FrameRef) or kind != 'enhancement' or type(values) is not dict
                or set(values) != {'profile'} or type(values['profile']) is not str
                or not 1 <= len(values['profile']) <= 32 or type(deadline) is not int or deadline < 0):
            raise ValueError('bounded semantic profile request required')
        args = (client, request, ref, kind, dict(values), deadline)
        return self._submit('semantic', args)

    def request_stop(self):
        with self._cv:
            self._stop = True
            while self._queue:
                _, _, ticket = self._queue.popleft()
                ticket.error = 'CANCELLED_BEFORE_EXECUTION'
                ticket.done.set()
                self.cancelled += 1
            self._cv.notify_all()

    def _run(self):
        try:
            while True:
                with self._cv:
                    self._cv.wait_for(lambda: self._queue or self._stop)
                    if not self._queue:
                        break
                    kind, args, ticket = self._queue.popleft()
                    self._busy = True
                try:
                    if kind == 'manual':
                        configuration, extension = args
                        prepared = self.transactions.prepare(configuration, extension=extension)
                        # A known READY may be cancelled on an explicit runtime stop.
                        with self._cv:
                            stopping = self._stop
                        if stopping:
                            self.transactions.cancel(prepared)
                            ticket.error = 'CANCELLED_PREPARED_ON_STOP'
                        else:
                            ticket.result = self.transactions.commit(prepared)
                            self.last_applied = ticket.result
                    else:
                        ticket.result = self.adapter.request_action(*args)
                        with self._cv:
                            stopping = self._stop
                        if ticket.result.reason == 'PREPARED_READY':
                            ticket.result = (self.adapter.cancel_pending() if stopping
                                             else self.adapter.apply_pending())
                        self.last_applied = self.adapter._owner.last_applied()
                        if self.adapter.diagnostics()['quarantined']:
                            raise RuntimeError('semantic CFG state is quarantined')
                except BaseException as error:
                    ticket.error = f'{type(error).__name__}: {error}'[:512]
                    with self._cv:
                        self.failure = self.failure or ticket.error
                    self.request_stop()
                finally:
                    ticket.done.set()
                    with self._cv:
                        self._busy = False
                        self.completed += 1
                        self._cv.notify_all()
            if self.adapter is not None:
                state = self.adapter.diagnostics()
                if state['busy'] and state['pending_phase'] == 'READY' and not state['quarantined']:
                    self.adapter.cancel_pending()
        except BaseException as error:
            with self._cv:
                self.failure = self.failure or f'{type(error).__name__}: {error}'[:512]

    def close(self, timeout_s=0):
        self.request_stop()
        if self._thread is not None:
            self._thread.join(timeout_s)
        return self.snapshot()

    def snapshot(self):
        with self._cv:
            return dict(pending=len(self._queue), busy=self._busy,
                worker_done=self._thread is None or not self._thread.is_alive(),
                submitted=self.submitted, completed=self.completed, cancelled=self.cancelled,
                failure=self.failure, fixed_source_epoch=self.fixed_source_epoch,
                source_barrier_locked=self._barrier_locked,
                semantic_owner=self.adapter is not None,
                last_applied=None if self.last_applied is None else asdict(self.last_applied))


class QueuedSemanticHook:
    """Public validation stays in VisionService; only the CFG worker executes."""
    def __init__(self, adapter, worker, *, limit=256):
        self.adapter, self.worker, self.limit = adapter, worker, limit
        self._tickets = {}
        self._cv = Condition()

    def frame_published(self, *args):
        return self.adapter.frame_published(*args)

    def hardware_actions_applied(self, *args):
        return self.adapter.hardware_actions_applied(*args)

    def supports_profile(self, name):
        return self.adapter.supports_profile(name)

    def request_action(self, client_id, request_id, frame_ref, kind, args, deadline_ns):
        key = client_id, request_id
        with self._cv:
            if key in self._tickets:
                return self.get_request_status(*key)
            if len(self._tickets) >= self.limit:
                return ActionStatus(request_id, 'REJECTED', 'CONTROL_HISTORY_LIMIT')
            try:
                ticket = self.worker.semantic(client_id, request_id, frame_ref, kind, dict(args), deadline_ns)
            except RuntimeError as error:
                return ActionStatus(request_id, 'REJECTED', str(error))
            self._tickets[key] = ticket
            return ActionStatus(request_id, 'PENDING', 'CONTROL_QUEUED')

    def get_request_status(self, client_id, request_id):
        with self._cv:
            ticket = self._tickets.get((client_id, request_id))
            if ticket is None:
                return None
            if not ticket.done.is_set():
                return ActionStatus(request_id, 'PENDING', 'CONTROL_QUEUED')
            if ticket.error:
                return ActionStatus(request_id, 'REJECTED', ticket.error)
            return ticket.result


class NativeFactory:
    """Explicit native constructors; no install, driver binding or fallback."""
    device_evidence = 'ACTUAL_RUN_NOT_QUALIFIED'

    def boot_id(self):
        from .warm_attach import read_boot_id
        return read_boot_id()

    def receiver(self, options):
        from linux.dma_c2h_candidate.receiver import Receiver
        return Receiver(options.device, nonblocking=True)

    def decoder(self, options):
        from linux.stream_diag.decoder import PersistentMppDecoder
        return PersistentMppDecoder(options.mpp_library, max_width=1920, max_height=1080,
                                    timeout_ms=options.mpp_timeout_ms)

    def pixels(self, options):
        from linux.pixel_native import NativePixels
        return NativePixels(options.pixel_library)

    def reassembler(self, options, session, epoch):
        from linux.lz_native import NativeReassembler
        return NativeReassembler(session, epoch, options.lz_library)

    def display(self, options, pixels, broker, *, clock=time.monotonic_ns):
        from linux.stream_diag.presentation import GstKmsPresenter
        from .display import DisplayWorker
        from .overlay import make_box_overlay
        presenter = GstKmsPresenter(width=1920, height=1080, connector_id=options.connector_id,
            plane_id=options.plane_id, force_modesetting=False, colorimetry=options.gst_colorimetry)
        delay_s = options.display_delay_ms / 1000
        return DisplayWorker(presenter, pixels, broker=broker,
            overlay=make_box_overlay(options.nv12_range, clock=clock) if broker is not None else None,
            display_delay_s=delay_s, depth=min(8, max(2, math.ceil(60 * delay_s) + 2)), clock=clock)

    def recorder(self, options, cohort):
        from .recording import BoundedRecorderWorker
        return BoundedRecorderWorker(options.record_dir, receiver_cohort=cohort,
                                      jpeg_version=options.jpeg_version).start()

    def raw_recorder(self, options, cohort):
        from .raw_recording import BoundedRawRecorderWorker
        return BoundedRawRecorderWorker(options.raw_record_dir, receiver_cohort=cohort).start()


class RuntimeRunner:
    """Single-use runtime, injectable for offline tests and trusted application UI.

    run returns a bounded report. If ownership_retained is true, keep this
    runner/process alive for explicit recovery; no close/abandon was attempted.
    Trusted scene profiles require an explicit environment_provider and policy;
    default headless/vision operation never requests automatic enhancement.
    """
    def __init__(self, options: RunOptions, *, factory=None, stop_event=None,
                 clock=time.monotonic, clock_ns=time.monotonic_ns,
                 trusted_profiles=None, environment_provider=None, neutral_policy=None):
        options.validate()
        if options.resume_receipt is not None and trusted_profiles is not None:
            raise ValueError('warm resume does not yet support semantic owners')
        if trusted_profiles is not None and (not options.enable_vision or environment_provider is None
                                             or neutral_policy is None or options.enable_lz):
            raise ValueError('trusted semantic profiles need vision/providers and no fixed LZ owner')
        if trusted_profiles is not None:
            if type(trusted_profiles) is not dict:
                raise ValueError('explicit trusted profile manifest required')
            for profile in trusted_profiles.values():
                if not isinstance(profile, Profile) or any((profile.requires_hdr, profile.requires_cfs,
                                                           profile.requires_dual, profile.requires_virtual)):
                    raise ValueError('runtime semantic profiles may configure only mono image processing')
                _image_configuration_only(profile.extension)
        self.options, self.factory = options, factory or NativeFactory()
        self.stop_event = stop_event if stop_event is not None else Event()
        self.clock, self.clock_ns = clock, clock_ns
        self.trusted_profiles, self.environment_provider, self.neutral_policy = trusted_profiles, environment_provider, neutral_policy
        self.cohort = str(uuid.uuid4())
        from .events import EventRouter
        self.events = EventRouter(receiver_cohort=self.cohort, frame_window=32, clock=self.clock_ns)
        self.state = 'NEW'
        self.failure = None
        self.cleanup_errors = []
        self.ownership_retained = False
        self.receiver = self.session = self.decoder = self.pixels = None
        self.vision = self.inference = self.display = self.recorder = self.reassembler = self.control = self.pipeline = None
        self.raw_recorder = None
        self.raw = LatestMailbox(depth=1, max_item_bytes=p.PCIE_LZ_FRAME_RAW_BYTES,
                                 size_of=lambda item: len(item.frame.raw))
        self._report_file = None
        self._initial_transport = self._final_transport = None
        self._drain_discards = 0
        self._fixed_configuration_epoch = None
        self._warm_input = self._warm_candidate = None
        self._warm_receipt_hash = None
        self._warm_availability = 'NOT_REQUESTED' if options.resume_receipt_output is None else 'NOT_ELIGIBLE'
        self._warm_attached = False
        self._barrier_ticket = self._barrier_frame = None
        self._barrier_deadline = None
        self._barrier_applied = None
        self._barrier_open = False
        self._barrier_discarded = 0

    def _fail(self, phase, error):
        if self.failure is None:
            self.failure = dict(phase=phase, error=f'{type(error).__name__}: {error}'[:512])

    def prepare(self):
        if self.state != 'NEW':
            raise RuntimeError('runtime preparation is single use')
        # Reserve a new report before opening devices or starting threads.
        self._report_file = Path(self.options.report_output).open('x', encoding='utf-8', newline='\n')
        try:
            if self.options.resume_receipt_output is not None and Path(self.options.resume_receipt_output).exists():
                raise ValueError('resume receipt output already exists')
            if self.options.resume_receipt is not None:
                from .warm_attach import load_receipt
                self._warm_input = load_receipt(self.options.resume_receipt)
                if self.factory.boot_id() != self._warm_input.state.boot_id:
                    raise RuntimeError('warm resume boot changed')
            self.pixels = self.factory.pixels(self.options)
            self.decoder = self.factory.decoder(self.options)
            self.receiver = self.factory.receiver(self.options)
            self._initial_transport = asdict(self.receiver.snapshot())
            if self.options.enable_lz:
                session = self.receiver.read32(p.PCIE_REG_CFG_SESSION)
                epoch = self.receiver.read32(p.PCIE_REG_CFG_MODE_EPOCH)
                self.reassembler = self.factory.reassembler(self.options, session, epoch)
            self.session = C2HSession(self.receiver, jpeg_version=self.options.jpeg_version,
                timeout_s=self.options.config_timeout_s, reassembler=self.reassembler,
                lz_frame_timeout_s=self.options.lz_frame_timeout_s)
            if self._warm_input is None:
                self.session.prepare()
            else:
                self.session.prepare_warm(self._warm_input, boot_id=self.factory.boot_id(),
                                          boot_id_reader=self.factory.boot_id)
                self._warm_attached = True
            if self.reassembler is not None:
                self._fixed_configuration_epoch = self.reassembler.stream_epoch
            # A legacy PREPARE clears extension state. Do not let it silently
            # switch an already active product after a transport-only STOP.
            if self.receiver.read32(p.PCIE_REG_CFG_EXT_MAGIC) == p.PCIE_CFG_EXT_MAGIC:
                words = tuple(self.receiver.read32(p.PCIE_REG_CFG_EXT_ACTIVE_BASE + 4 * i) for i in range(32))
                schema = (words[0] >> p.PCIE_CFG_V2_OFFSET_SCHEMA) & ((1 << p.PCIE_CFG_V2_FIELD_WIDTH_SCHEMA) - 1)
                if schema == p.PCIE_CFG_V2_SCHEMA:
                    active = MonoConfiguration.from_words(words)
                    product_active = active.product_mode != p.PCIE_CFG_V2_MODES_MONO_SDR
                elif schema == 1:
                    enables = words[0] >> p.PCIE_CFG_EXT_OFFSET_ENABLE
                    product_active = bool(enables & (p.PCIE_CFG_EXT_FEATURE_HDR | p.PCIE_CFG_EXT_FEATURE_CFS))
                else:
                    product_active = any(words)  # Unknown active extensions cannot be cleared implicitly.
                if product_active:
                    self._fixed_configuration_epoch = self.receiver.read32(p.PCIE_REG_CFG_MODE_EPOCH)
            self.control = ControlWorker(self.session.transactions,
                fixed_source_epoch=self._fixed_configuration_epoch)
            if self.options.enable_vision:
                from linux.task3_pipeline.live_rgb_backend import LiveVisionConsumer
                from linux.vision_api.inference import InferenceBroker
                self.vision = LiveVisionConsumer(clock=self.clock_ns, max_fps=self.options.vision_max_fps,
                    converter=lambda *args: self.pixels.convert(*args, range=self.options.nv12_range),
                    service_options={'clock': self.clock_ns, 'history_limit': 16,
                        'max_frame_bytes': 1920 * 1080 * 3, 'max_clients': 4, 'max_leases': 2})
                if self.trusted_profiles is not None:
                    owner = AdaptiveConfigOwner(self.session.transactions, profiles=self.trusted_profiles, clock=self.clock_ns)
                    providers = RecordV2Providers(self.vision.backend, policy_provider=self.neutral_policy,
                                                   clock=self.clock_ns)
                    adapter = SemanticExecutionAdapter(owner, read_only=False, require_source_stamp=True,
                        environment_provider=self.environment_provider, observation_provider=providers.observation,
                        frame_stamp_provider=providers.frame_stamp)
                    self.control.adapter = adapter
                    # Before START no producer can publish; bind hook atomically here.
                    self.vision.service._execution_hook = QueuedSemanticHook(adapter, self.control)
                self.inference = InferenceBroker(self.vision.service, clock=self.clock_ns)
            if self.options.connector_id is not None:
                self.display = self.factory.display(self.options, self.pixels, self.inference, clock=self.clock_ns)
            if self.options.record_dir is not None:
                self.recorder = self.factory.recorder(self.options, self.cohort)
            if self.options.raw_record_dir is not None:
                self.raw_recorder = self.factory.raw_recorder(self.options, self.cohort)
            self.pipeline = ProductPipeline(self.decoder, jpeg_version=self.options.jpeg_version,
                receiver_cohort=self.cohort, display=self.display, vision=self.vision, raw=self.raw_recorder or self.raw,
                recorder=self.recorder, clock=self.clock_ns, expected_geometry=(1920, 1080),
                frame_observer=self._observe_frame)
            self.state = 'PREPARED'
            return self
        except BaseException as error:
            self._fail('PREPARE', error)
            self.state = 'FAULTED'
            self.ownership_retained = self.receiver is not None
            raise

    def _check_consumers(self):
        if self.display is not None:
            self.display.check()
        for item in (self.recorder, self.raw_recorder):
            if item is not None and item.snapshot().get('failure'):
                raise RuntimeError('recording worker failed: ' + item.snapshot()['failure'])
        if self.control is not None and self.control.snapshot()['failure']:
            raise RuntimeError('configuration worker failed: ' + self.control.snapshot()['failure'])

    def _observe_frame(self, envelope):
        if (self.options.resume_receipt is None or self._barrier_open) and envelope.key.session is not None:
            self.events.observe_frame(envelope.key, received_ns=envelope.host_dispatch_ns)

    def _source_barrier_products(self, products):
        """No consumer sees pre-barrier records. Hold at most one pre-ACK JPEG."""
        if not self.options.warm_source_barrier or self._barrier_open:
            return products
        from linux.task3_pipeline.product_receiver import JpegProduct
        from .warm_attach import REGISTER_NAMES, configuration_snapshot
        if self.clock() >= self._barrier_deadline:
            raise TimeoutError('warm source epoch barrier expired; capture age remains unknown')
        state = self._warm_input.state
        regs = dict(zip(REGISTER_NAMES, state.registers))
        if self._barrier_ticket.done.is_set() and self._barrier_applied is None:
            applied = self._barrier_ticket.result
            expected_base, expected_extension = configuration_snapshot(self._warm_input)
            if (self._barrier_ticket.error or applied is None or applied.configuration != expected_base
                    or applied.extension != expected_extension or applied.session != regs['CFG_SESSION']
                    or applied.camera != 0 or applied.mode_epoch == regs['CFG_MODE_EPOCH']):
                raise RuntimeError('warm same-configuration APPLIED is absent or mismatched')
            self._barrier_applied = applied
        pending = (() if self._barrier_frame is None else (self._barrier_frame,)) + products
        self._barrier_frame = None
        accepted = []
        for product in pending:
            if not isinstance(product, JpegProduct):
                self._barrier_discarded += 1
                continue
            source = product.record.metadata.source
            if source is None or source.session != regs['CFG_SESSION'] or source.camera != 0:
                raise RuntimeError('warm barrier received a foreign SOURCE')
            if self._barrier_open:
                accepted.append(product)
                continue
            if source.epoch <= regs['CFG_MODE_EPOCH']:
                self._barrier_discarded += 1
                continue
            if self._barrier_applied is None:
                if self._barrier_frame is None:
                    self._barrier_frame = product
                else:
                    self._barrier_discarded += 1
                continue
            applied = self._barrier_applied
            if (source.epoch, source.sequence) != (applied.mode_epoch, applied.first_actual_frame_sequence):
                raise RuntimeError('warm barrier did not observe the exact first APPLIED SOURCE frame')
            self._barrier_open = True
            self.control.release_source_barrier()
            accepted.append(product)
        return tuple(accepted)

    def _check_fixed_products(self, products):
        if self.reassembler is None:
            return
        from linux.task3_pipeline.product_receiver import JpegProduct, RawProduct
        expected = self.reassembler.session_id, self.reassembler.stream_epoch
        for product in products:
            if isinstance(product, JpegProduct):
                source = product.record.metadata.source
                identity = source.session, source.epoch
            elif isinstance(product, RawProduct):
                identity = product.frame.identity.source_session, product.frame.identity.mode_epoch
            else:
                continue
            if identity != expected:
                raise RuntimeError('SOURCE cohort changed with fixed LZ owner; explicit stopped rebind required')

    def _close_software(self):
        """Called after receive/drain stopped; never close a live worker's native owner."""
        clean = True
        for name in ('display', 'recorder', 'raw_recorder', 'vision'):
            item = getattr(self, name)
            if item is None:
                continue
            try:
                if name == 'vision':
                    item.close()
                    if item._thread.is_alive() or item.backend._thread.is_alive():
                        raise RuntimeError('vision workers still own copied pixels')
                else:
                    result = item.close(timeout_s=self.options.drain_timeout_s)
                    if name in ('recorder', 'raw_recorder') and not result.get('worker_done'):
                        raise RuntimeError('recording worker still owns files')
            except BaseException as error:
                self.cleanup_errors.append(f'{name}: {type(error).__name__}: {error}'[:512])
                clean = False
        if clean and self.decoder is not None:
            try:
                self.decoder.close()
            except BaseException as error:
                self.cleanup_errors.append(f'decoder: {type(error).__name__}: {error}'[:512])
                clean = False
        return clean

    def run(self):
        if self.state not in ('NEW', 'PREPARED'):
            raise RuntimeError('runtime is single use; no automatic restart or fault recovery')
        started = self.clock()
        stop_started = None
        try:
            if self.state == 'NEW':
                self.prepare()
            if self.state != 'PREPARED':
                raise RuntimeError('runtime is not prepared')
            if self.stop_event.is_set():
                self.state = 'STOPPED'
            else:
                self.session.start()
                self.control.start()
                self.state = 'RUNNING'
                if self.options.warm_source_barrier:
                    from .warm_attach import configuration_snapshot
                    self._barrier_deadline = self.clock() + self.options.config_timeout_s
                    self._barrier_ticket = self.control.source_barrier(*configuration_snapshot(self._warm_input))
            active_started = self.clock()
            while self.state in ('RUNNING', 'DRAINING'):
                now = self.clock()
                limit = self.options.max_seconds
                if limit is not None and now - active_started >= limit:
                    self.stop_event.set()
                try:
                    self._check_consumers()
                except BaseException as error:
                    self._fail('CONSUMER', error)
                    self.stop_event.set()
                if self.stop_event.is_set() and stop_started is None:
                    stop_started = now
                    self.control.request_stop()
                if stop_started is not None:
                    if now - stop_started >= self.options.drain_timeout_s:
                        raise TimeoutError('control/transport drain deadline; ownership retained')
                    if self.state == 'RUNNING' and self.control.snapshot()['worker_done']:
                        if self.control.snapshot()['failure']:
                            raise RuntimeError('CFG outcome is uncertain; owner retained')
                        self.session.request_stop()
                        self.state = 'DRAINING'
                products = self.session.receive(self.options.poll_seconds)
                if self.state == 'RUNNING' and self.failure is None:
                    products = self._source_barrier_products(products)
                    try:
                        self._check_fixed_products(products)
                        self.pipeline.consume(products)
                    except BaseException as error:
                        self._fail('PIPELINE', error)
                        self.stop_event.set()
                else:
                    self._drain_discards += len(products)
                if self.state == 'DRAINING' and self.session.finish_stop():
                    self.state = 'STOPPED'
            self._final_transport = asdict(self.receiver.snapshot())
            if not self._close_software():
                raise RuntimeError('software consumers have not completed cleanup')
            if (self.options.resume_receipt_output is not None and self.failure is None
                    and self.session.state == 'STOPPED'):
                controls = self.control.snapshot()
                idle = (controls['worker_done'] and not controls['busy'] and not controls['pending']
                        and controls['failure'] is None)
                self._warm_candidate = self.session.capture_resume(boot_id=self.factory.boot_id(), controls_idle=idle)
            self.session.close()
            if self.reassembler is not None:
                self.reassembler.close()
            self.state = 'CLOSED' if self.failure is None else 'CLOSED_WITH_ERROR'
            if self._warm_candidate is not None and self.state == 'CLOSED':
                self._warm_availability = 'READY_IF_MATCHING_RECEIPT_EXISTS'
        except BaseException as error:
            self._fail('RUN', error)
            self.state = 'FAULTED'
            self.ownership_retained = self.receiver is not None
            if self.control is not None:
                self.control.request_stop()
            # Best-effort STOP does not assert drain or close the retained fd.
            if self.receiver is not None and (self.options.resume_receipt is None
                    or self.session is not None and self.session.start_issued):
                try:
                    self.receiver.stop()
                except BaseException as stop_error:
                    self.cleanup_errors.append(f'STOP: {type(stop_error).__name__}: {stop_error}'[:512])
            elif self.receiver is None and self.decoder is not None:
                try:
                    self.decoder.close()
                except BaseException as cleanup_error:
                    self.cleanup_errors.append(f'decoder: {type(cleanup_error).__name__}: {cleanup_error}'[:512])
        report = self.snapshot()
        report['elapsed_seconds'] = max(0, self.clock() - started)
        report_saved = False
        report_bytes = None
        if self._report_file is not None:
            try:
                report_bytes = (json.dumps(report, indent=2, allow_nan=False) + '\n').encode('utf-8')
                self._report_file.write(report_bytes.decode('utf-8'))
                self._report_file.flush()
                if self.options.resume_receipt_output is not None:
                    os.fsync(self._report_file.fileno())
                report_saved = True
            except BaseException as error:
                report_saved = False
                report_error = f'{type(error).__name__}: {error}'[:512]
                self._fail('REPORT', error)
                if self.state == 'CLOSED':
                    self.state = 'CLOSED_WITH_ERROR'
                if report_bytes is None:
                    # Do not return the same unencodable object to CLI printing:
                    # serialization failure must not implicitly drop an owner.
                    report = dict(ownership_retained=self.ownership_retained,
                                  report_detail='UNAVAILABLE_SERIALIZATION_FAILURE')
                report['report_error'] = report_error
                report.update(state=self.state, failure=self.failure)
            finally:
                try:
                    self._report_file.close()
                except BaseException as error:
                    report_saved = False
                    report['report_close_error'] = f'{type(error).__name__}: {error}'[:512]
                    self._fail('REPORT_CLOSE', error)
                    if self.state == 'CLOSED':
                        self.state = 'CLOSED_WITH_ERROR'
                    report.update(state=self.state, failure=self.failure)
                self._report_file = None
        if self._warm_candidate is not None:
            if report_saved and self.state == 'CLOSED' and self.failure is None:
                try:
                    from .warm_attach import publish_receipt
                    receipt = self._warm_candidate.confirm_closed(report_path=self.options.report_output,
                        report_sha256=hashlib.sha256(report_bytes).hexdigest())
                    self._warm_receipt_hash = publish_receipt(self.options.resume_receipt_output, receipt)
                except BaseException as error:
                    self._fail('WARM_RECEIPT', error)
                    self.state = 'CLOSED_WITH_ERROR'
                    self._warm_availability = 'NOT_PUBLISHED'
            else:
                self._warm_availability = 'UNAVAILABLE_REPORT_OR_CLOSE_FAILURE'
            report.update(state=self.state, failure=self.failure)
            report['warm_resume'] = self._warm_report()
        return report

    def _warm_report(self):
        return dict(input=None if self.options.resume_receipt is None else str(Path(self.options.resume_receipt).absolute()),
            input_identity_sha256=None if self._warm_input is None else self._warm_input.state.digest(),
            input_provenance='PREVIOUS_NORMAL_CLOSE_AND_MATCHING_REPORT' if self._warm_input is not None else 'COLD_PATH',
            attached_readonly=self._warm_attached, backlog_possible=self.options.resume_receipt is not None,
            capture_freshness='FRESHNESS_UNQUALIFIED' if self.options.resume_receipt is not None else 'NOT_ASSERTED',
            ai_alerts=('SOURCE_EPOCH_GATE_OPEN_CAPTURE_AGE_UNKNOWN' if self._barrier_open else
                       'DISABLED_FOR_WARM_BACKLOG' if self.options.resume_receipt is not None else 'CALLER_POLICY'),
            source_barrier=dict(requested=self.options.warm_source_barrier, opened=self._barrier_open,
                scope='SOURCE_EPOCH_BARRIER_ONLY/CAPTURE_AGE_UNKNOWN', discarded=self._barrier_discarded,
                retained_jpeg_records=int(self._barrier_frame is not None),
                timeout_s=self.options.config_timeout_s if self.options.warm_source_barrier else None,
                applied=None if self._barrier_applied is None else asdict(self._barrier_applied)),
            recording_time='HOST_ARRIVAL_IS_NOT_CAPTURE_TIME_SOURCE_METADATA_UNCHANGED',
            output=None if self.options.resume_receipt_output is None else str(Path(self.options.resume_receipt_output).absolute()),
            availability=self._warm_availability,
            identity_sha256=None if self._warm_candidate is None else self._warm_candidate.state.digest(),
            receipt_sha256=self._warm_receipt_hash, authenticity='UNSIGNED_TRUSTED_OWNER_DIRECTORY_ONLY')

    def snapshot(self):
        report = dict(state=self.state, failure=self.failure, cleanup_errors=list(self.cleanup_errors),
            ownership_retained=self.ownership_retained, receiver_cohort=self.cohort,
            device_evidence=getattr(self.factory, 'device_evidence', 'INJECTED_BACKEND_NOT_DEVICE_QUALIFICATION'),
            kernel_build='NOT_RUN', board_qualification='NOT_RUN',
            source_mode='FIXED_CFG_EPOCH' if self._fixed_configuration_epoch is not None else 'SDR_IMAGE_CFG_ONLY',
            stop_semantics='TRANSPORT_DRAINED_WITH_FPGA_BACKLOG_POSSIBLE', product_mode_switch_safe=False,
            automatic_enhancement=False, nv12_range=self.options.nv12_range,
            vision_sampling_hz=self.options.vision_max_fps if self.options.enable_vision else 0,
            vision_sampling_qualification='CALLER_POLICY_NOT_THROUGHPUT_OR_300MS_INFERENCE_EVIDENCE',
            physical_hdmi='UNVERIFIED', latency_clock='UNQUALIFIED_SENSOR_HOST_CLOCK_DOMAINS',
            display_delay_ms=self.options.display_delay_ms,
            display_delay_scope='HOST_DISPLAY_BUDGET_NOT_REALTIME_OR_PHYSICAL_PRESENTATION',
            raw_sink='BOUNDED_RECORDING' if self.raw_recorder is not None else 'LATEST_OWNED_MAILBOX_NOT_RECORDING',
            transport_initial=self._initial_transport, transport_final=self._final_transport,
            drained_owned_products_discarded=self._drain_discards, raw_mailbox=self.raw.snapshot())
        report['requested'] = {name: str(getattr(self.options, name)) if isinstance(getattr(self.options, name), Path)
                               else getattr(self.options, name) for name in self.options.__dataclass_fields__}
        report['warm_resume'] = self._warm_report()
        if self.session is not None:
            report['session'] = dict(state=self.session.state,
                lz_deadline_failures=self.session.lz_deadline_failures)
            if self.session.transactions is not None:
                report['config_capabilities'] = asdict(self.session.transactions.capabilities)
            if self.session.selection is not None:
                report['record_selection'] = asdict(self.session.selection)
        for name in ('pipeline', 'control', 'display', 'recorder', 'raw_recorder', 'inference', 'events'):
            item = getattr(self, name)
            if item is not None:
                try:
                    report[name] = item.snapshot()
                except BaseException as error:
                    report[name] = {'snapshot_error': f'{type(error).__name__}: {error}'[:512]}
        if self.vision is not None:
            report['vision'] = self.vision.diagnostics()
            discovery = self.vision.service.discover()
            limits = discovery['limits']
            report['vision_service_limits'] = limits
            report['vision_service_rgb_reference_bound'] = (
                len(discovery['camera_ids']) + limits['history'] + limits['clients'] * limits['leases_per_client']
            ) * limits['frame_bytes']
        return report


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    commands = result.add_subparsers(dest='command', required=True)
    inspect = commands.add_parser('preflight', help='read-only host inventory; no device opens')
    inspect.add_argument('--library', action='append', default=[], type=Path)
    inspect.add_argument('--kernel-build', type=Path)
    inspect.add_argument('--output', type=Path)
    run = commands.add_parser('run', help='explicit device owner; starts DMA and optional display')
    for name in ('device', 'mpp-library', 'pixel-library', 'report-output'):
        run.add_argument('--' + name, required=True, type=str if name == 'device' else Path)
    run.add_argument('--jpeg-version', required=True, type=int, choices=(1, 2, 3))
    run.add_argument('--nv12-range', required=True, choices=('BT601_FULL', 'BT601_LIMITED'))
    run.add_argument('--config-timeout', required=True, type=float)
    run.add_argument('--drain-timeout', required=True, type=float)
    run.add_argument('--max-seconds', type=float)
    run.add_argument('--mpp-timeout-ms', type=int, default=1000)
    run.add_argument('--connector-id', type=int)
    run.add_argument('--plane-id', type=int)
    run.add_argument('--gst-colorimetry')
    run.add_argument('--display-delay-ms', type=float, default=0,
        help='0..100 ms host display waiting budget; not physical realtime/presentation proof')
    run.add_argument('--record-dir', type=Path)
    run.add_argument('--enable-vision', '--vision', dest='vision', action='store_true')
    run.add_argument('--vision-max-fps', type=float, help='explicit sampling policy, not measured inference rate')
    run.add_argument('--lz-library', type=Path)
    run.add_argument('--lz-frame-timeout', type=float)
    run.add_argument('--raw-record-dir', type=Path)
    run.add_argument('--resume-receipt', type=Path, help='explicit previous normal-close same-probe JPEG receipt; never cold adoption')
    run.add_argument('--write-resume-receipt', type=Path, help='new receipt file, published only after clean close and saved report')
    run.add_argument('--warm-source-barrier', action='store_true',
        help='same-config APPLIED/SOURCE barrier before consumers; capture age remains unknown')
    return result


def main(argv=None):
    arguments = parser()
    args = arguments.parse_args(argv)
    if sys.platform != 'linux':
        arguments.error('device runtime and actual inventory require Linux; use injected factories in offline tests')
    if args.command == 'preflight':
        from .preflight import inspect_host
        report = inspect_host(libraries=args.library, kernel_build=args.kernel_build)
        if args.output is not None:
            with args.output.open('x', encoding='utf-8') as stream:
                json.dump(report, stream, indent=2); stream.write('\n')
        else:
            print(json.dumps(report, indent=2))
        return 0
    try:
        if args.vision and args.vision_max_fps is None:
            raise ValueError('--enable-vision requires explicit --vision-max-fps')
        if args.lz_library is not None and args.raw_record_dir is None:
            raise ValueError('LZ CLI requires --raw-record-dir; library users may explicitly consume runner.raw')
        options = RunOptions(args.device, args.jpeg_version, args.mpp_library, args.pixel_library,
            args.nv12_range, args.config_timeout, args.drain_timeout, args.report_output,
            max_seconds=args.max_seconds, mpp_timeout_ms=args.mpp_timeout_ms,
            connector_id=args.connector_id, plane_id=args.plane_id, gst_colorimetry=args.gst_colorimetry,
            record_dir=args.record_dir, enable_vision=args.vision,
            vision_max_fps=1.0 if args.vision_max_fps is None else args.vision_max_fps,
            enable_lz=args.lz_library is not None, lz_library=args.lz_library,
            lz_frame_timeout_s=args.lz_frame_timeout, raw_record_dir=args.raw_record_dir,
            display_delay_ms=args.display_delay_ms, resume_receipt=args.resume_receipt,
            resume_receipt_output=args.write_resume_receipt, warm_source_barrier=args.warm_source_barrier)
        runtime = RuntimeRunner(options)
    except ValueError as error:
        arguments.error(str(error))
    def request_stop(_number, _frame):
        runtime.stop_event.set()
    for name in ('SIGINT', 'SIGTERM'):
        signal.signal(getattr(signal, name), request_stop)
    report = runtime.run()
    try:
        print(json.dumps(report, indent=2))
    except OSError:
        pass  # A broken output pipe must not implicitly close a retained DMA fd.
    if report['ownership_retained']:
        try:
            print('FAULT: owner retained; explicit platform recovery is required. No automatic close/restart.', file=sys.stderr)
        except OSError:
            pass
        retained = Event()
        while True:
            retained.wait(60)  # Keep fd/native owners alive; signals request stop only.
    return 0 if report['state'] == 'CLOSED' else 1
