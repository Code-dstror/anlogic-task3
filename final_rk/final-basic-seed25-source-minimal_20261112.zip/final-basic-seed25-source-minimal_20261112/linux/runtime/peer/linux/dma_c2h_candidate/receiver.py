"""Private Linux-owner adapter: frame metadata copies, mmap payload borrows.

The caller must finish every consumer (including asynchronous MPP input use)
before releasing a Lease. This module neither decodes nor claims DMA-BUF import.
"""
from dataclasses import dataclass
import errno
import mmap
import math
import os
import struct

try:
    from .c2h_abi import RESULT_COMPLETE, SAFE_RESULT_CODES, USER_ABI, MAX_RECORD_BYTES
    from .c2h_legacy_policy import READABLE, WRITABLE
    from .c2h_abi import OWNER_INFO_VERSION, OWNER_INFO_FIELD_NAMES, OWNER_INFO_FORMAT, GET_OWNER_IOCTL
except ImportError:
    from c2h_abi import RESULT_COMPLETE, SAFE_RESULT_CODES, USER_ABI, MAX_RECORD_BYTES
    from c2h_legacy_policy import READABLE, WRITABLE
    from c2h_abi import OWNER_INFO_VERSION, OWNER_INFO_FIELD_NAMES, OWNER_INFO_FORMAT, GET_OWNER_IOCTL

INFO = struct.Struct('=8I4Q')
COMPLETION = struct.Struct('=8I')
OWNER_INFO = struct.Struct(OWNER_INFO_FORMAT)
GET_OWNER = GET_OWNER_IOCTL
BATCH_MAX = 16


def _ioc(direction, number, size=0):
    # asm-generic ioctl encoding used by the target ARM64 Linux and x86_64.
    return (direction << 30) | (size << 16) | (ord('H') << 8) | number


GET_INFO = _ioc(2, 0x40, INFO.size)
START = _ioc(0, 0x41)
STOP = _ioc(0, 0x42)
RELEASE = _ioc(1, 0x43, 8 + BATCH_MAX * 8)
LEGACY = _ioc(3, 0x44, 8 + BATCH_MAX * 16)


class LinuxIO:
    def __init__(self, path, *, nonblocking=False):
        import fcntl
        self.fcntl = fcntl
        self.fd = os.open(path, os.O_RDWR | os.O_CLOEXEC | (os.O_NONBLOCK if nonblocking else 0))

    def ioctl(self, command, arg=0):
        return self.fcntl.ioctl(self.fd, command, arg)

    def map(self, capacity, offset):
        return mmap.mmap(self.fd, capacity, flags=mmap.MAP_SHARED,
                         prot=mmap.PROT_READ, offset=offset)

    def read(self, count):
        return os.read(self.fd, count)

    def poll(self, timeout_ms):
        import select
        waiter = select.poll()
        waiter.register(self.fd, select.POLLIN | select.POLLERR | select.POLLHUP)
        events = waiter.poll(timeout_ms)
        if any(mask & (select.POLLERR | select.POLLHUP | select.POLLNVAL) for _, mask in events):
            raise OSError('C2H device unavailable or quarantined')
        return any(mask & select.POLLIN for _, mask in events)

    def close(self):
        os.close(self.fd)


class TransportStopped(EOFError):
    """Normal STOP EOF: transport drained and no unread READY completions.

    Existing consumer leases may remain. This is not an upstream JPEG/LZ drain
    proof, and the same owner may resume normally without changing its nonce.
    """


@dataclass(frozen=True)
class OwnerIdentity:
    """Cached host-private probe identity, not an FPGA/source-session claim."""
    owner_info_version: int
    user_abi: int
    pci_domain: int
    pci_bus: int
    pci_devfn: int
    generation: int
    transport_session: int

    @property
    def bdf(self):
        return f'{self.pci_domain:04x}:{self.pci_bus:02x}:{self.pci_devfn >> 3:02x}.{self.pci_devfn & 7:x}'


@dataclass(frozen=True)
class ReceiverSnapshot:
    """One GET_INFO sample; counters are per probe and include prior opens.

    Completed counts safe fence/ACK results, including cancelled/error results;
    it does not count frames displayed, released leases, or upstream FIFO drain.
    """
    user_abi: int
    slots: int
    capacity: int
    running: int
    quarantined: int
    stopped: int
    dma_bits: int
    mapping_bytes: int
    status_polls: int
    interrupts: int
    submitted: int
    completed: int

    @property
    def transport_drained(self):
        """No in-flight transport descriptor; unread results/leases may remain."""
        return (not self.running and self.stopped == 1 and not self.quarantined and
                self.submitted == self.completed)


@dataclass(eq=False)
class Lease:
    _owner: 'Receiver'
    slot: int
    generation: int
    result: int
    length: int
    record_identity: tuple
    _released: bool = False

    def view(self):
        """Borrow record bytes; release every view before releasing this lease."""
        if self._released:
            raise RuntimeError('lease already released')
        return memoryview(self._owner._maps[self.slot])[:self.length].toreadonly()

    def release(self):
        self._owner.release([self])


class Receiver:
    def __init__(self, path=None, *, _io=None, nonblocking=False):
        self._io = _io if _io is not None else LinuxIO(path, nonblocking=nonblocking)
        self._nonblocking = nonblocking
        self._maps = []
        self._leases = {}
        self._closed = False
        self._poisoned = False
        self._last_snapshot = None
        self._last_owner = None
        try:
            info = self.snapshot()
            if info.quarantined:
                raise RuntimeError('incompatible or quarantined C2H backend')
            self.slots, self.capacity, self.mapping_bytes = info.slots, info.capacity, info.mapping_bytes
            for slot in range(self.slots):
                self._maps.append(self._io.map(self.mapping_bytes, slot * self.mapping_bytes))
        except BaseException:
            for mapping in self._maps:
                mapping.close()
            self._io.close()
            raise

    @property
    def nonblocking(self):
        return self._nonblocking

    @property
    def leased_count(self):
        return len(self._leases)

    def owner_identity(self):
        """Read identity even after a fault, without MMIO or modifying ownership.

        generation is the last attempted descriptor allocation (possibly an
        unconfirmed submit); session combines high=session[1], low=session[0].
        Older modules without this additive ioctl fail explicitly, never fall back.
        """
        if self._closed:
            raise RuntimeError('receiver is closed')
        raw = bytearray(OWNER_INFO.size)
        self._io.ioctl(GET_OWNER, raw)
        if len(raw) != OWNER_INFO.size:
            self._poisoned = True
            raise RuntimeError('invalid GET_OWNER size')
        owner = OwnerIdentity(**dict(zip(OWNER_INFO_FIELD_NAMES, OWNER_INFO.unpack(raw), strict=True)))
        previous = self._last_owner
        identity_fields = ('owner_info_version', 'user_abi', 'pci_domain', 'pci_bus', 'pci_devfn',
                           'transport_session')
        if (owner.owner_info_version != OWNER_INFO_VERSION or owner.user_abi != USER_ABI or
                not 0 <= owner.pci_domain <= 0xffff or not 0 <= owner.pci_bus <= 0xff or
                not 0 <= owner.pci_devfn <= 0xff or not 1 <= owner.transport_session <= 0xffffffffffffffff or
                not 0 <= owner.generation <= 0xffffffff or
                (self._last_snapshot is not None and owner.generation < self._last_snapshot.submitted) or
                (previous is not None and (owner.generation < previous.generation or
                 any(getattr(owner, name) != getattr(previous, name) for name in identity_fields)))):
            self._poisoned = True
            raise RuntimeError('inconsistent C2H owner identity; ownership retained')
        self._last_owner = owner
        return owner

    def snapshot(self):
        """Immutable validated GET_INFO, with fixed geometry and monotonic counters."""
        self._usable()
        raw = bytearray(INFO.size)
        self._io.ioctl(GET_INFO, raw)
        if len(raw) != INFO.size:
            self._poisoned = True
            raise RuntimeError('invalid GET_INFO size')
        info = ReceiverSnapshot(*INFO.unpack(raw))
        span = ((info.capacity + mmap.PAGESIZE - 1) // mmap.PAGESIZE) * mmap.PAGESIZE
        shape = ('user_abi', 'slots', 'capacity', 'dma_bits', 'mapping_bytes')
        counters = ('status_polls', 'interrupts', 'submitted', 'completed')
        previous = self._last_snapshot
        if (info.user_abi != USER_ABI or not 1 <= info.slots <= BATCH_MAX or
                not 0 < info.capacity <= MAX_RECORD_BYTES or info.dma_bits not in (32, 64) or
                info.mapping_bytes != span or
                any(getattr(info, key) not in (0, 1) for key in ('running', 'quarantined', 'stopped')) or
                (info.running and (info.stopped or info.quarantined)) or
                not 0 <= info.submitted - info.completed <= 1 or
                (previous is not None and (any(getattr(info, key) != getattr(previous, key) for key in shape) or
                 any(getattr(info, key) < getattr(previous, key) for key in counters)))):
            self._poisoned = True
            raise RuntimeError('inconsistent C2H GET_INFO snapshot; ownership retained')
        self._last_snapshot = info
        return info

    def poll(self, timeout_s):
        """Wait at most timeout_s on a nonblocking owner; timeout changes no leases."""
        self._usable()
        if not self.nonblocking:
            raise RuntimeError('poll requires a nonblocking Receiver')
        if (isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float)) or
                not math.isfinite(timeout_s) or not 0 <= timeout_s <= 2147483):
            raise ValueError('timeout must be finite and nonnegative')
        return self._io.poll(math.ceil(timeout_s * 1000))

    def receive_available(self, maximum=BATCH_MAX):
        """One bounded batch; [] means EAGAIN or normal STOP EOF, never release."""
        self._usable()
        if not self.nonblocking:
            raise RuntimeError('receive_available requires a nonblocking Receiver')
        try:
            return self.receive(maximum)
        except TransportStopped:
            return []
        except BlockingIOError as exc:
            if exc.errno not in (errno.EAGAIN, errno.EWOULDBLOCK):
                raise
            return []

    def start(self):
        self._usable()
        self._io.ioctl(START)

    def stop(self):
        """Request asynchronous drain; STOP itself never implies safe reuse."""
        self._usable()
        self._io.ioctl(STOP)

    def legacy_batch(self, operations):
        """[(offset, value, write)] for the existing single CFG/LUT owner only.

        Commands are never retried after ioctl errors (acceptance is uncertain).
        Hardware CFG PREPARE/COMMIT/APPLIED semantics remain with that owner.
        """
        self._usable()
        operations = list(operations)
        if not 1 <= len(operations) <= BATCH_MAX:
            raise ValueError('invalid MMIO batch size')
        payload = bytearray(8 + BATCH_MAX * 16)
        struct.pack_into('=II', payload, 0, len(operations), 0)
        for i, (offset, value, write) in enumerate(operations):
            if not isinstance(offset, int) or offset % 4 or not 0 <= offset < 4096:
                raise ValueError('MMIO offset must be aligned within legacy page')
            if not isinstance(value, int) or not 0 <= value <= 0xffffffff or write not in (0, 1):
                raise ValueError('invalid MMIO value/operation')
            if offset not in (WRITABLE if write else READABLE):
                raise PermissionError('MMIO operation is outside the generated single-owner policy')
            struct.pack_into('=4I', payload, 8 + i * 16, offset, value, write, 0)
        self._io.ioctl(LEGACY, payload)
        return [struct.unpack_from('=I', payload, 12 + i * 16)[0] for i in range(len(operations))]

    def read32(self, offset):
        return self.legacy_batch([(offset, 0, 0)])[0]

    def write32(self, offset, value):
        self.legacy_batch([(offset, value, 1)])

    def _usable(self):
        if self._closed or self._poisoned:
            raise RuntimeError('receiver is closed or has invalid completion metadata')

    def receive(self, maximum=BATCH_MAX):
        """Blocking sleep in read(); no Python polling or payload copy."""
        self._usable()
        if type(maximum) is not int or not 1 <= maximum <= BATCH_MAX:
            raise ValueError('invalid batch size')
        raw = self._io.read(maximum * COMPLETION.size)
        if not raw:
            try:
                drained = self.snapshot().transport_drained
            except BaseException:
                self._poisoned = True
                raise
            if drained:
                raise TransportStopped('C2H stopped with no unread safe results')
            self._poisoned = True
            raise RuntimeError('unexpected EOF without a drained transport; ownership retained')
        if len(raw) % COMPLETION.size or len(raw) > maximum * COMPLETION.size:
            self._poisoned = True
            raise RuntimeError('invalid completion batch; stop and close owner')
        leases = []
        seen = set()
        for values in COMPLETION.iter_unpack(raw):
            slot, generation, result, length, *record = values
            if (slot >= self.slots or not generation or result not in SAFE_RESULT_CODES or
                    length > self.capacity or (result != RESULT_COMPLETE and length) or
                    (result == RESULT_COMPLETE and not length) or slot in self._leases or slot in seen):
                self._poisoned = True
                raise RuntimeError('invalid or duplicate completion; no automatic recycling')
            seen.add(slot)
            leases.append(Lease(self, slot, generation, result, length, tuple(record)))
        for lease in leases:
            self._leases[lease.slot] = lease
        return leases

    def release(self, leases):
        self._usable()
        leases = list(leases)
        if not 1 <= len(leases) <= BATCH_MAX or len({x.slot for x in leases}) != len(leases):
            raise ValueError('invalid release batch')
        for lease in leases:
            if lease._owner is not self or lease._released or self._leases.get(lease.slot) is not lease:
                raise ValueError('stale or foreign lease')
        payload = bytearray(8 + BATCH_MAX * 8)
        struct.pack_into('=II', payload, 0, len(leases), 0)
        for i, lease in enumerate(leases):
            struct.pack_into('=II', payload, 8 + i * 8, lease.slot, lease.generation)
        # Only successful ioctl commits release; failed batches retain leases.
        self._io.ioctl(RELEASE, payload)
        for lease in leases:
            del self._leases[lease.slot]
            lease._released = True

    def close(self):
        if self._closed:
            return
        if self._leases:
            raise RuntimeError('finish consumers and release leases before closing')
        # Request STOP even after malformed metadata. No attempt at RESET/ACK.
        try:
            self._io.ioctl(STOP)
        finally:
            # mmap.close fails with BufferError if a borrowed view remains.
            # Keep fd open on that failure so close can be retried safely.
            for mapping in self._maps:
                mapping.close()
            self._io.close()
            self._closed = True

    def abandon(self):
        """After ALL consumers finish, close a faulted owner without recycling.

        No RELEASE ioctl is sent. The kernel drains or retains quarantined DMA
        allocations; unmapping a userspace view does not free those allocations.
        """
        if self._closed:
            return
        try:
            self._io.ioctl(STOP)
        except OSError:
            pass  # Quarantined/detached hardware cannot accept STOP.
        for mapping in self._maps:
            mapping.close()  # Refuse to close while a memoryview is exported.
        for lease in self._leases.values():
            lease._released = True
        self._leases.clear()
        self._io.close()
        self._closed = True
