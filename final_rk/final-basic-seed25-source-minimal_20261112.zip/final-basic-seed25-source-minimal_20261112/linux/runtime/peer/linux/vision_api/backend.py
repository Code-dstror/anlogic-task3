"""Linux-owned backend boundary. AI workers use types.VisionClient instead."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from typing import Iterable, Protocol

from .types import SourceFrameMetadata


def positive(value: int, name: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


@dataclass(frozen=True)
class FrameIdentity:
    camera_id: int
    sequence: int
    source_epoch: int
    generation: int


@dataclass(frozen=True)
class PairTag:
    pair_id: str
    left: FrameIdentity
    right: FrameIdentity


@dataclass(frozen=True)
class RGBFrame:
    identity: FrameIdentity
    width: int
    height: int
    pixels: bytes
    source_kind: str = "DIGITAL_REPLAY"
    geometry_id: str = "identity"
    calibration_id: str | None = None
    capture_time_ns: int | None = None
    capture_time_quality: str = "UNKNOWN"
    pair: PairTag | None = None
    source_metadata: SourceFrameMetadata | None = None
    # Trusted owner clock: when its independent source bytes became available.
    # Live MPP copies use NV12 delivery, before RGB conversion/queueing. This is
    # not sensor capture, DMA fence time or a synchronized hardware timestamp.
    # None retains the legacy service-publication timestamp fallback.
    received_monotonic_ns: int | None = None


class RGBBackend(Protocol):
    """poll is nonblocking and transfers immutable, independently owned bytes.

    A private hardware adapter must copy an MPP/driver borrow before returning.
    Neither a backend error nor consumer release permits DMA restart or free.
    """
    camera_ids: tuple[int, ...]
    def poll(self, camera_id: int) -> RGBFrame | None: ...
    def describe(self) -> dict: ...


class RGBReplayBackend:
    """Bounded injected RGB replay; full queues discard the oldest waiting frame."""
    def __init__(self, camera_ids: tuple[int, ...] = (0,), *, queue_depth: int = 2,
                 max_frame_bytes: int = 32 * 1024 * 1024):
        if (not camera_ids or len(camera_ids) > 2 or len(set(camera_ids)) != len(camera_ids)
                or any(type(c) is not int or c < 0 for c in camera_ids)):
            raise ValueError("one or two distinct nonnegative camera IDs required")
        self.camera_ids = tuple(camera_ids)
        self.queue_depth = positive(queue_depth, "queue_depth")
        self.max_frame_bytes = positive(max_frame_bytes, "max_frame_bytes")
        self._queues = {c: deque() for c in camera_ids}
        self._lock = Lock()
        self.dropped = 0

    def push(self, frame: RGBFrame) -> None:
        if frame.identity.camera_id not in self._queues:
            raise ValueError("camera absent")
        positive(frame.width, "width")
        positive(frame.height, "height")
        if (type(frame.pixels) is not bytes or len(frame.pixels) != frame.width * frame.height * 3
                or len(frame.pixels) > self.max_frame_bytes
                or frame.source_kind not in {"DIGITAL_REPLAY", "SYNTHETIC_REPLAY"}):
            raise ValueError("invalid replay RGB payload/source")
        with self._lock:
            waiting = self._queues[frame.identity.camera_id]
            if len(waiting) == self.queue_depth:
                waiting.popleft()
                self.dropped += 1
            waiting.append(frame)

    def poll(self, camera_id: int) -> RGBFrame | None:
        if camera_id not in self._queues:
            raise ValueError("camera absent")
        with self._lock:
            return self._queues[camera_id].popleft() if self._queues[camera_id] else None

    def describe(self) -> dict:
        with self._lock:
            return {"backend": "RGB_REPLAY", "source_kind": "DIGITAL_OR_SYNTHETIC_REPLAY",
                    "hardware_actions_applied": False, "queue_depth": self.queue_depth,
                    "waiting_frames": sum(map(len, self._queues.values())), "dropped": self.dropped}


@dataclass(frozen=True)
class RGBFile:
    path: Path
    identity: FrameIdentity
    width: int
    height: int
    pair: PairTag | None = None


class RGBFileBackend:
    """Finite raw RGB888 file replay, no JPEG decoder or model preprocessing.

    Files are read on explicit poll; this offline backend is not a live reader.
    A caller may supply an iterator so a long recording need not be catalogued.
    """
    def __init__(self, files: dict[int, Iterable[RGBFile]], *, max_frame_bytes: int = 32 * 1024 * 1024):
        self.camera_ids = tuple(files)
        RGBReplayBackend(self.camera_ids, max_frame_bytes=max_frame_bytes)
        self.max_frame_bytes = positive(max_frame_bytes, "max_frame_bytes")
        self._files = {camera: iter(entries) for camera, entries in files.items()}
        self._lock = Lock()

    def poll(self, camera_id: int) -> RGBFrame | None:
        if camera_id not in self._files:
            raise ValueError("camera absent")
        with self._lock:
            entry = next(self._files[camera_id], None)
            if entry is None:
                return None
            if not isinstance(entry, RGBFile) or entry.identity.camera_id != camera_id:
                raise ValueError("file camera mismatch")
            expected = positive(entry.width, "width") * positive(entry.height, "height") * 3
            if expected > self.max_frame_bytes:
                raise ValueError("file exceeds frame limit")
            # A bounded read rejects both truncation and trailing bytes.
            with Path(entry.path).open("rb") as stream:
                pixels = stream.read(expected + 1)
            if len(pixels) != expected:
                raise ValueError("RGB file length mismatch")
            return RGBFrame(entry.identity, entry.width, entry.height, pixels, pair=entry.pair)

    def describe(self) -> dict:
        return {"backend": "RGB_FILE_REPLAY", "source_kind": "DIGITAL_REPLAY",
                "hardware_actions_applied": False, "board_status": "NOT_RUN"}
