"""Bounded asynchronous inference tickets over the existing copied-RGB API.

This optional API accepts results for an issued, unexpired historical frame in
the same current public cohort. The existing latest-only submit_result contract
is unchanged. There is no model, preprocessing, DMA access or hardware action.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from threading import RLock
import time
import uuid

from .types import FrameMeta, VisionClient, VisionResult


@dataclass(frozen=True)
class InferenceTicket:
    ticket_id: str
    meta: FrameMeta
    pixels: bytes
    issued_ns: int
    deadline_ns: int


@dataclass(frozen=True)
class CompletedInference:
    ticket: InferenceTicket
    result: VisionResult
    completed_ns: int


class InferenceBroker:
    """One trusted host broker, bounded clients/tickets/results, no worker.

    Public service leases are released after taking their immutable byte
    reference. This broker's separate quotas account for those copied buffers.
    Holding a ticket never holds a DMA or MPP lease. Expiry invalidates results;
    caller-held immutable tickets cannot be physically revoked or overwritten.
    """
    def __init__(self, client: VisionClient, *, max_clients=4, per_client=2,
                 result_depth=8, max_frame_bytes=1920 * 1080 * 3,
                 ticket_ttl_ns=300_000_000, clock=time.monotonic_ns):
        for value, ceiling in ((max_clients, 32), (per_client, 16), (result_depth, 64),
                               (max_frame_bytes, 64 * 1024 * 1024), (ticket_ttl_ns, 10_000_000_000)):
            if type(value) is not int or not 1 <= value <= ceiling:
                raise ValueError('invalid inference quota/TTL')
        self._client, self._clock, self._lock = client, clock, RLock()
        self.max_clients, self.per_client, self.result_depth = max_clients, per_client, result_depth
        self.max_frame_bytes, self.ttl = max_frame_bytes, ticket_ttl_ns
        self._clients, self._pending, self._results = set(), {}, OrderedDict()
        self._cohort = None
        self.accepted = self.expired = self.discarded_results = 0
        self._result_age_ns = self._max_result_age_ns = 0

    def _sync(self):
        now = self._clock()
        if type(now) is not int or now < 0:
            raise ValueError('clock must return nonnegative monotonic nanoseconds')
        discovery = self._client.discover()
        cohort = discovery['session_id'], discovery['mode_epoch']
        if self._cohort is not None and cohort != self._cohort:
            self.expired += len(self._pending)
            self._pending.clear()
            self._results.clear()
        self._cohort = cohort
        for token, (_, ticket) in list(self._pending.items()):
            if now >= ticket.deadline_ns:
                del self._pending[token]
                self.expired += 1
        for token, (_, completed) in list(self._results.items()):
            if now >= completed.ticket.deadline_ns:
                del self._results[token]
        return now

    def acquire(self, client_id: str, camera_id=0) -> InferenceTicket | None:
        with self._lock:
            now = self._sync()
            if not isinstance(client_id, str) or not 1 <= len(client_id) <= 128:
                raise ValueError('invalid client id')
            if client_id not in self._clients:
                if len(self._clients) >= self.max_clients:
                    raise RuntimeError('inference client quota')
                self._clients.add(client_id)
            if sum(owner == client_id for owner, _ in self._pending.values()) >= self.per_client:
                return None
            lease = self._client.acquire_frame(client_id, camera_id)
            if lease is None:
                return None
            try:
                meta = lease.meta
                if (type(lease.pixels) is not bytes or meta.pixel_format != 'RGB888'
                        or meta.stride != meta.width * 3 or not 0 < len(lease.pixels) <= self.max_frame_bytes
                        or len(lease.pixels) != meta.stride * meta.height
                        or (meta.ref.session_id, meta.ref.mode_epoch) != self._cohort
                        or not 0 <= meta.received_monotonic_ns <= now):
                    raise ValueError('invalid copied RGB lease')
                deadline = min(lease.deadline_ns, meta.received_monotonic_ns + self.ttl)
                if now >= deadline:
                    return None
                ticket = InferenceTicket(str(uuid.uuid4()), meta, lease.pixels, now, deadline)
                self._pending[ticket.ticket_id] = client_id, ticket
                return ticket
            finally:
                self._client.release_frame(client_id, lease.lease_id)

    @staticmethod
    def _valid(ticket, result, now):
        if not isinstance(result, VisionResult):
            return False
        if (result.frame_ref != ticket.meta.ref or result.profile_id != ticket.meta.profile_id
                or result.coordinate_space != 'source' or not isinstance(result.model_id, str)
                or not 1 <= len(result.model_id) <= 128 or type(result.produced_ns) is not int
                or not ticket.issued_ns <= result.produced_ns <= now
                or not isinstance(result.boxes, tuple) or len(result.boxes) > 256):
            return False
        for detection in result.boxes:
            try:
                x0, y0, x1, y1 = detection.bbox
                if (len(detection.bbox) != 4 or not all(type(v) in (int, float) for v in detection.bbox)
                        or not 0 <= x0 < x1 <= ticket.meta.width or not 0 <= y0 < y1 <= ticket.meta.height
                        or type(detection.class_id) is not int or not 0 <= detection.class_id <= 0xffffffff
                        or type(detection.score) not in (int, float)
                        or not 0 <= detection.score <= 1):
                    return False
            except (TypeError, AttributeError, ValueError):
                return False
        return True

    def submit(self, client_id: str, ticket_id: str, result: VisionResult) -> str:
        if (type(client_id) is not str or not 1 <= len(client_id) <= 128
                or type(ticket_id) is not str or not 1 <= len(ticket_id) <= 128):
            return 'INVALID'
        with self._lock:
            now = self._sync()
            previous = self._results.get(ticket_id)
            if previous is not None:
                owner, completed = previous
                if owner != client_id:
                    return 'WRONG_OWNER'
                return 'ACCEPTED' if completed.result == result else 'CONFLICT'
            item = self._pending.get(ticket_id)
            if item is None:
                return 'STALE'
            owner, ticket = item
            if owner != client_id:
                return 'WRONG_OWNER'
            if not self._valid(ticket, result, now):
                return 'INVALID'
            del self._pending[ticket_id]
            if len(self._results) == self.result_depth:
                self._results.popitem(last=False)
                self.discarded_results += 1
            self._results[ticket_id] = client_id, CompletedInference(ticket, result, now)
            self.accepted += 1
            age = now - ticket.meta.received_monotonic_ns
            self._result_age_ns += age
            self._max_result_age_ns = max(self._max_result_age_ns, age)
            return 'ACCEPTED'

    def lookup_source(self, *, session: int, epoch: int, camera: int, sequence: int, jpeg_generation: int):
        """Exact source result only; no sequence-only/latest-frame substitution."""
        with self._lock:
            self._sync()
            for _, complete in reversed(self._results.values()):
                source = complete.ticket.meta.source_metadata
                if source is not None and (source.stamp.session_id, source.stamp.mode_epoch,
                        source.stamp.camera_id, source.stamp.sequence, source.jpeg_generation) == (
                            session, epoch, camera, sequence, jpeg_generation):
                    return complete
            return None

    def cancel(self, client_id: str, ticket_id: str):
        with self._lock:
            self._sync()
            item = self._pending.get(ticket_id)
            if item is not None:
                if item[0] != client_id:
                    raise PermissionError('ticket belongs to another client')
                del self._pending[ticket_id]

    def disconnect(self, client_id: str):
        with self._lock:
            self._clients.discard(client_id)
            self._pending = {k: v for k, v in self._pending.items() if v[0] != client_id}
            self._results = OrderedDict((k, v) for k, v in self._results.items() if v[0] != client_id)

    def snapshot(self):
        with self._lock:
            self._sync()
            return dict(pending=len(self._pending), results=len(self._results), clients=len(self._clients),
                        accepted=self.accepted, expired=self.expired, dropped_results=self.discarded_results,
                        mean_result_age_ms=None if not self.accepted else self._result_age_ns / self.accepted / 1e6,
                        max_result_age_ms=self._max_result_age_ns / 1e6,
                        result_age_scope='HOST_SOURCE_BYTES_AVAILABLE_TO_ACCEPTED_RESULT_NOT_SENSOR_TIME_OR_NPU_ONLY',
                        pixel_reference_bound=(self.max_clients * self.per_client + self.result_depth) * self.max_frame_bytes,
                        models_executed=0, hardware_lease_count=0)
