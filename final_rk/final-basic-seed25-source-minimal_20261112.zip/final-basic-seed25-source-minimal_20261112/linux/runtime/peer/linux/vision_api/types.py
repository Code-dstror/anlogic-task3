"""Hardware-independent Vision API v1; compatible with the R4 RGB contract."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class FrameRef:
    session_id: str
    camera_id: int
    sequence: int
    mode_epoch: int
    view: str = "source_rgb"


@dataclass(frozen=True)
class SourceFrameStamp:
    """Same-record producer identity; separate from host-issued FrameRef.

    Counter time/source identity alone does not qualify sensor synchronization.
    These descriptive values give clients no hardware control or buffer lease.
    """
    session_id: int
    mode_epoch: int
    camera_id: int
    sequence: int
    source_kind: str
    source_format: str
    exposure_role: str


@dataclass(frozen=True)
class NeutralFrameStats:
    """Successful pre-enhancement sampled grid, not decoded-RGB feedback.

    width/height describe the sampled grid and may differ from the RGB image.
    """
    sampled: int
    delivered: int
    sum_y: int
    dark: int
    bright: int
    min_y: int
    max_y: int
    dark_threshold: int
    bright_threshold: int
    width: int
    height: int


@dataclass(frozen=True)
class SourceFrameMetadata:
    stamp: SourceFrameStamp
    # JPEG-ring identity, never host-copy generation or RAW slot ownership.
    jpeg_session_id: int
    jpeg_generation: int
    jpeg_slot: int
    timestamp_ns: int | None = None
    time_quality: str = "UNKNOWN"
    actual_exposure: int | None = None
    actual_gain: int | None = None
    calibration_id: int | None = None
    exposure_group: int | None = None
    pair_id: int | None = None
    job_id: int | None = None
    write_tag: int | None = None
    neutral_stats: NeutralFrameStats | None = None
    neutral_view_id: int | None = None
    neutral_schema: int | None = None
    source_qualified: bool = False


@dataclass(frozen=True)
class FrameMeta:
    ref: FrameRef
    width: int
    height: int
    stride: int
    pixel_format: str
    profile_id: str
    source_kind: str
    geometry_id: str
    calibration_id: str | None
    capture_time_ns: int | None
    capture_time_quality: str
    received_monotonic_ns: int
    source_metadata: SourceFrameMetadata | None = None


@dataclass(frozen=True)
class FrameLease:
    lease_id: str
    meta: FrameMeta
    pixels: bytes
    deadline_ns: int


@dataclass(frozen=True)
class Detection:
    bbox: tuple[float, float, float, float]
    class_id: int
    score: float


@dataclass(frozen=True)
class VisionResult:
    frame_ref: FrameRef
    model_id: str
    profile_id: str
    coordinate_space: str
    boxes: tuple[Detection, ...]
    produced_ns: int


@dataclass(frozen=True)
class ActionStatus:
    request_id: str
    status: str
    reason: str
    applied_epoch: int | None = None


@dataclass(frozen=True)
class PairMeta:
    pair_id: str
    left: FrameRef
    right: FrameRef
    source_kind: str
    calibration_id: str | None
    capture_time_quality: str
    physical_sync_qualified: bool = False
    physical_depth_qualified: bool = False


class VisionClient(Protocol):
    def discover(self) -> dict: ...
    def acquire_frame(self, client_id: str, camera_id: int = 0) -> FrameLease | None: ...
    def release_frame(self, client_id: str, lease_id: str) -> None: ...
    def submit_result(self, client_id: str, result: VisionResult) -> str: ...
    def request_action(self, client_id: str, request_id: str, frame_ref: FrameRef,
                       kind: str, args: dict, deadline_ns: int) -> ActionStatus: ...
    def get_request_status(self, client_id: str, request_id: str) -> ActionStatus | None: ...
    def get_pair(self, client_id: str, left: FrameRef, right: FrameRef) -> PairMeta | None: ...
