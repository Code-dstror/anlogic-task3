"""Bounded in-process Vision service; private adapters inject an RGBBackend."""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import asdict, dataclass
import json
import math
from threading import RLock
import time
import uuid

from .backend import FrameIdentity, PairTag, RGBBackend, RGBFrame, positive
from .types import (ActionStatus, FrameLease, FrameMeta, FrameRef, NeutralFrameStats,
                    PairMeta, SourceFrameMetadata, SourceFrameStamp, VisionResult)


@dataclass(frozen=True)
class _Published:
    meta: FrameMeta
    frame: RGBFrame


class VisionService:
    """Consumer limits never block the backend or overwrite a held byte lease.

    pump/switch_backend belong to the Linux owner, outside VisionClient. This
    class is an in-process service boundary, not a deployed/authenticated IPC
    daemon. Its backend may own hardware; the public client never sees that owner.
    """
    def __init__(self, backend: RGBBackend, *, clock=time.monotonic_ns,
                 max_clients: int = 4, max_leases: int = 2,
                 ttl_ns: int = 300_000_000, history_limit: int = 64,
                 request_limit: int = 256, max_frame_bytes: int = 32 * 1024 * 1024,
                 execution_hook=None):
        for name, value in (("max_clients", max_clients), ("max_leases", max_leases),
                            ("ttl_ns", ttl_ns), ("history_limit", history_limit),
                            ("request_limit", request_limit), ("max_frame_bytes", max_frame_bytes)):
            positive(value, name)
        self.clock = clock
        self.max_clients, self.max_leases = max_clients, max_leases
        self.ttl_ns, self.history_limit = ttl_ns, history_limit
        self.request_limit, self.max_frame_bytes = request_limit, max_frame_bytes
        self._lock = RLock()
        self._clients = set()
        self._active = {}
        self._issued = OrderedDict()
        self._delivered = {}
        self._requests = OrderedDict()
        # Linux-owned hook, outside VisionClient. Requests reach it only after
        # the service has checked the client's issued current FrameRef.
        self._execution_hook = execution_hook
        self._delegated = set()
        self._accepted = set()
        self._latest = {}
        self._source_ids = {}
        self._source_epoch = None
        self._sequences = {}
        self.session_id = str(uuid.uuid4())
        self.mode_epoch = 0
        self.frames_published = self.results_accepted = 0
        self._set_backend(backend)

    def _set_backend(self, backend: RGBBackend) -> None:
        cameras = tuple(backend.camera_ids)
        if (not cameras or len(cameras) > 2 or len(set(cameras)) != len(cameras)
                or any(type(c) is not int or c < 0 for c in cameras)):
            raise ValueError("invalid backend camera IDs")
        self._backend, self._cameras = backend, cameras

    def _invalidate(self) -> None:
        self.session_id = str(uuid.uuid4())
        self.mode_epoch += 1
        self._latest.clear()
        self._issued.clear()
        self._delivered.clear()
        self._accepted.clear()
        self._sequences.clear()
        # Old immutable leases remain alive and still count toward quotas.
        # Old requests remain for idempotency; status retrieval marks them stale.

    def switch_backend(self, backend: RGBBackend) -> None:
        with self._lock:
            self._set_backend(backend)
            self._invalidate()
            self._source_ids.clear()
            self._source_epoch = None

    def discover(self) -> dict:
        with self._lock:
            # An injected private adapter may have richer diagnostics. Only
            # public scalar capability fields cross this boundary.
            description = self._backend.describe()
            capabilities = {key: value for key, value in description.items()
                            if key in {"backend", "source_kind", "board_status", "queue_depth",
                                       "waiting_frames", "dropped"}
                            and type(value) in (str, int, bool)
                            and (not isinstance(value, str) or len(value) <= 128)}
            applied = (False if self._execution_hook is None else
                       self._execution_hook.hardware_actions_applied(self.session_id, self.mode_epoch))
            capabilities["hardware_actions_applied"] = applied is True
            return {"api_version": 1, "session_id": self.session_id,
                    "mode_epoch": self.mode_epoch, "camera_ids": list(self._cameras),
                    "views": ["source_rgb"], "profiles": ["source_rgb_v1"],
                    "pixel_format": "RGB888", "metric_depth_qualified": False,
                    "received_time_semantics": "BACKEND_HOST_AVAILABLE_OR_PUBLICATION_FALLBACK",
                    "hardware_actions_applied": applied is True,
                    "backend_capabilities": capabilities,
                    "limits": {"clients": self.max_clients, "leases_per_client": self.max_leases,
                               "frame_bytes": self.max_frame_bytes, "history": self.history_limit,
                               "request_records": self.request_limit},
                    "frames_published": self.frames_published,
                    "outstanding_leases": len(self._active),
                    "results_accepted": self.results_accepted}

    def _validate_frame(self, frame: RGBFrame, camera_id: int) -> None:
        if (not isinstance(frame, RGBFrame) or not isinstance(frame.identity, FrameIdentity)
                or frame.identity.camera_id != camera_id):
            raise ValueError("backend frame camera mismatch")
        identity = frame.identity
        for name in ("sequence", "source_epoch", "generation"):
            value = getattr(identity, name)
            if type(value) is not int or value < 0 or (name == "generation" and value == 0):
                raise ValueError(f"invalid backend {name}")
        size = positive(frame.width, "width") * positive(frame.height, "height") * 3
        if type(frame.pixels) is not bytes or len(frame.pixels) != size or size > self.max_frame_bytes:
            raise ValueError("invalid backend RGB payload")
        if frame.source_kind not in {"PHYSICAL_CAMERA", "TABLET_RECAPTURE", "DIGITAL_REPLAY", "SYNTHETIC_REPLAY"}:
            raise ValueError("invalid source_kind")
        if not isinstance(frame.geometry_id, str) or not 1 <= len(frame.geometry_id) <= 128:
            raise ValueError("invalid geometry_id")
        if frame.calibration_id is not None and (not isinstance(frame.calibration_id, str)
                                                or not 1 <= len(frame.calibration_id) <= 128):
            raise ValueError("invalid calibration_id")
        if frame.capture_time_ns is not None and (type(frame.capture_time_ns) is not int
                                                 or frame.capture_time_ns < 0):
            raise ValueError("invalid capture time")
        if frame.received_monotonic_ns is not None and (
                type(frame.received_monotonic_ns) is not int or frame.received_monotonic_ns < 0):
            raise ValueError("invalid backend host availability time")
        if frame.capture_time_quality != "UNKNOWN":
            # No synchronized sensor-time qualification has been implemented here.
            raise ValueError("capture time quality unsupported")
        self._validate_source_metadata(frame)
        if frame.pair is not None:
            tag = frame.pair
            if (not isinstance(tag, PairTag) or not isinstance(tag.left, FrameIdentity)
                    or not isinstance(tag.right, FrameIdentity)
                    or not isinstance(tag.pair_id, str) or not 1 <= len(tag.pair_id) <= 128
                    or tag.left.camera_id == tag.right.camera_id
                    or tag.left.camera_id not in self._cameras or tag.right.camera_id not in self._cameras
                    or identity not in (tag.left, tag.right)):
                raise ValueError("invalid pair member metadata")

    @staticmethod
    def _validate_source_metadata(frame: RGBFrame) -> None:
        source = frame.source_metadata
        if source is None:
            return
        def uint(value, bits=32, minimum=0):
            return type(value) is int and minimum <= value < (1 << bits)
        if not isinstance(source, SourceFrameMetadata) or not isinstance(source.stamp, SourceFrameStamp):
            raise ValueError("invalid typed source metadata")
        stamp = source.stamp
        if (not uint(stamp.session_id, minimum=1) or not uint(stamp.mode_epoch)
                or not uint(stamp.sequence) or stamp.sequence != frame.identity.sequence
                or type(stamp.camera_id) is not int or stamp.camera_id != frame.identity.camera_id
                or stamp.source_kind != frame.source_kind
                or stamp.source_format not in {"RAW10", "RAW14"}
                or stamp.exposure_role not in {"SINGLE", "LONG", "SHORT"}
                or not uint(source.jpeg_session_id, minimum=1)
                or not uint(source.jpeg_generation, minimum=1) or not uint(source.jpeg_slot, bits=16)
                or type(source.source_qualified) is not bool):
            raise ValueError("source metadata does not name this RGB frame")
        for name in ("actual_exposure", "actual_gain", "calibration_id", "exposure_group",
                     "neutral_view_id", "neutral_schema"):
            value = getattr(source, name)
            if value is not None and not uint(value):
                raise ValueError(f"invalid source {name}")
        for name in ("timestamp_ns", "pair_id", "job_id", "write_tag"):
            value = getattr(source, name)
            if value is not None and not uint(value, bits=64):
                raise ValueError(f"invalid source {name}")
        if (source.time_quality not in {"UNKNOWN", "LOCAL_PIXEL_COUNTER_NS", "COMMON_FPGA_COUNTER_NS"}
                or (source.timestamp_ns is None) != (source.time_quality == "UNKNOWN")
                or source.timestamp_ns != frame.capture_time_ns):
            raise ValueError("source counter time mismatch")
        stats = source.neutral_stats
        if stats is not None:
            if (not isinstance(stats, NeutralFrameStats)
                    or any(not uint(getattr(stats, name)) for name in
                           ("sampled", "delivered", "dark", "bright", "width", "height"))
                    or not uint(stats.sum_y, bits=64)
                    or any(not uint(getattr(stats, name), bits=8) for name in
                           ("min_y", "max_y", "dark_threshold", "bright_threshold"))):
                raise ValueError("invalid typed neutral statistics")
            count = stats.width * stats.height
            if (count == 0 or stats.sampled != count or stats.delivered != count
                    or stats.min_y > stats.max_y or not count*stats.min_y <= stats.sum_y <= count*stats.max_y
                    or stats.dark > count or stats.bright > count
                    or source.neutral_view_id is None or source.neutral_schema is None):
                raise ValueError("neutral statistics must be a complete sampled grid")

    def pump(self, camera_id: int = 0) -> FrameRef | None:
        """Owner calls this once per available frame; no acquisition loop or reset."""
        with self._lock:
            if type(camera_id) is not int or camera_id not in self._cameras:
                raise ValueError("camera absent")
            frame = self._backend.poll(camera_id)
            if frame is None:
                return None
            self._validate_frame(frame, camera_id)
            published_ns = self.clock()
            if type(published_ns) is not int or published_ns < 0:
                raise ValueError("service clock must return nonnegative integer nanoseconds")
            received_ns = frame.received_monotonic_ns
            if received_ns is None:
                received_ns = published_ns  # Explicit compatibility fallback, not capture time.
            elif received_ns > published_ns:
                raise ValueError("backend host availability time is in the future")
            previous = self._source_ids.get(camera_id)
            current = frame.identity
            if self._source_epoch is not None and current.source_epoch < self._source_epoch:
                raise ValueError("stale source epoch")
            if previous is not None:
                if current.source_epoch < previous.source_epoch:
                    raise ValueError("backward source epoch")
                if current.source_epoch == previous.source_epoch:
                    if current.sequence <= previous.sequence or current.generation < previous.generation:
                        raise ValueError("duplicate/backward source identity")
            if self._source_epoch is not None and current.source_epoch > self._source_epoch:
                self._invalidate()
            self._source_epoch = current.source_epoch
            self._source_ids[camera_id] = current
            sequence = self._sequences.get(camera_id, 0) + 1
            self._sequences[camera_id] = sequence
            ref = FrameRef(self.session_id, camera_id, sequence, self.mode_epoch)
            meta = FrameMeta(ref, frame.width, frame.height, frame.width * 3, "RGB888",
                             "source_rgb_v1", frame.source_kind, frame.geometry_id,
                             frame.calibration_id, frame.capture_time_ns, frame.capture_time_quality,
                             received_ns, frame.source_metadata)
            self._latest[camera_id] = _Published(meta, frame)
            self.frames_published += 1
            if self._execution_hook is not None:
                self._execution_hook.frame_published(meta, frame.identity)
            return ref

    def _client(self, client_id: str) -> None:
        if not isinstance(client_id, str) or not 1 <= len(client_id) <= 128:
            raise ValueError("invalid client id")
        if client_id not in self._clients:
            if len(self._clients) == self.max_clients:
                raise RuntimeError("client limit")
            self._clients.add(client_id)

    def acquire_frame(self, client_id: str, camera_id: int = 0) -> FrameLease | None:
        with self._lock:
            self._client(client_id)
            if type(camera_id) is not int or camera_id not in self._cameras:
                raise ValueError("camera absent")
            if sum(owner == client_id for owner, _ in self._active.values()) >= self.max_leases:
                return None
            published = self._latest.get(camera_id)
            if published is None:
                return None
            meta = published.meta
            if (self._delivered.get((client_id, camera_id)) == meta.ref
                    or self.clock() >= meta.received_monotonic_ns + self.ttl_ns):
                return None
            lease = FrameLease(str(uuid.uuid4()), meta, published.frame.pixels,
                               meta.received_monotonic_ns + self.ttl_ns)
            self._active[lease.lease_id] = client_id, lease
            self._delivered[client_id, camera_id] = meta.ref
            self._issued[client_id, meta.ref] = published
            while len(self._issued) > self.history_limit:
                expired, _ = self._issued.popitem(last=False)
                self._accepted.discard(expired)
            return lease

    def release_frame(self, client_id: str, lease_id: str) -> None:
        with self._lock:
            item = self._active.get(lease_id)
            if item is None:
                return
            if item[0] != client_id:
                raise PermissionError("lease belongs to another client")
            del self._active[lease_id]

    def disconnect_client(self, client_id: str) -> None:
        """IPC owner calls after disconnect, reclaiming only independent byte refs."""
        with self._lock:
            self._clients.discard(client_id)
            for key in [key for key, (owner, _) in self._active.items() if owner == client_id]:
                del self._active[key]
            for key in [key for key in self._delivered if key[0] == client_id]:
                del self._delivered[key]
            for key in [key for key in self._issued if key[0] == client_id]:
                del self._issued[key]
                self._accepted.discard(key)
            for key in [key for key in self._requests if key[0] == client_id]:
                del self._requests[key]
                self._delegated.discard(key)

    def _current(self, client_id: str, ref: FrameRef) -> _Published | None:
        if (not isinstance(ref, FrameRef) or not isinstance(ref.session_id, str)
                or type(ref.camera_id) is not int or type(ref.sequence) is not int
                or type(ref.mode_epoch) is not int or ref.view != "source_rgb"
                or ref.session_id != self.session_id or ref.mode_epoch != self.mode_epoch):
            return None
        published = self._issued.get((client_id, ref))
        latest = self._latest.get(ref.camera_id)
        if (published is None or latest is None or latest.meta.ref != ref
                or self.clock() >= published.meta.received_monotonic_ns + self.ttl_ns):
            return None
        return published

    def submit_result(self, client_id: str, result: VisionResult) -> str:
        with self._lock:
            self._client(client_id)
            if not isinstance(result, VisionResult):
                return "INVALID"
            published = self._current(client_id, result.frame_ref)
            if published is None:
                return "STALE"
            meta = published.meta
            if (not isinstance(result.model_id, str) or not 1 <= len(result.model_id) <= 128
                    or result.profile_id != meta.profile_id or result.coordinate_space != "source"
                    or type(result.produced_ns) is not int
                    or not meta.received_monotonic_ns <= result.produced_ns <= self.clock()
                    or not isinstance(result.boxes, tuple) or len(result.boxes) > 256):
                return "INVALID"
            for detection in result.boxes:
                try:
                    x0, y0, x1, y1 = detection.bbox
                    if (not all(type(v) in (int, float) and math.isfinite(v) for v in detection.bbox)
                            or not 0 <= x0 < x1 <= meta.width or not 0 <= y0 < y1 <= meta.height
                            or type(detection.class_id) is not int or detection.class_id < 0
                            or type(detection.score) not in (int, float)
                            or not math.isfinite(detection.score) or not 0 <= detection.score <= 1):
                        return "INVALID"
                except (AttributeError, TypeError, ValueError):
                    return "INVALID"
            key = client_id, result.frame_ref
            if key not in self._accepted:
                self._accepted.add(key)
                self.results_accepted += 1
            return "ACCEPTED"

    def get_pair(self, client_id: str, left: FrameRef, right: FrameRef) -> PairMeta | None:
        with self._lock:
            self._client(client_id)
            first, second = self._current(client_id, left), self._current(client_id, right)
            if first is None or second is None or left.camera_id == right.camera_id:
                return None
            a, b = first.frame, second.frame
            tag = a.pair
            if (tag is None or tag != b.pair or tag.left != a.identity or tag.right != b.identity
                    or a.identity.source_epoch != b.identity.source_epoch
                    or a.source_kind != b.source_kind or a.geometry_id != b.geometry_id
                    or a.calibration_id != b.calibration_id):
                return None
            return PairMeta(tag.pair_id, left, right, a.source_kind, a.calibration_id, "UNKNOWN")

    def request_action(self, client_id: str, request_id: str, frame_ref: FrameRef,
                       kind: str, args: dict, deadline_ns: int) -> ActionStatus:
        with self._lock:
            self._client(client_id)
            if (not isinstance(request_id, str) or not 1 <= len(request_id) <= 128
                    or not isinstance(frame_ref, FrameRef) or not isinstance(args, dict)
                    or type(deadline_ns) is not int or deadline_ns < 0):
                raise ValueError("invalid semantic request")
            try:
                fingerprint = json.dumps([asdict(frame_ref), kind, args, deadline_ns],
                                         sort_keys=True, allow_nan=False)
            except (TypeError, ValueError) as exc:
                raise ValueError("request must be finite JSON") from exc
            if len(fingerprint.encode("utf-8")) > 65536:
                raise ValueError("request exceeds message limit")
            key = client_id, request_id
            if key in self._requests:
                if self._requests[key][0] != fingerprint:
                    return ActionStatus(request_id, "REJECTED", "ID_CONFLICT")
                return self.get_request_status(client_id, request_id)
            if len(self._requests) == self.request_limit:
                return ActionStatus(request_id, "REJECTED", "REQUEST_BUDGET")
            published = self._current(client_id, frame_ref)
            reason = None
            if self.clock() >= deadline_ns:
                reason = "DEADLINE"
            elif published is None:
                reason = "STALE_FRAME"
            elif kind == "record_event":
                if set(args) != {"label"} or not isinstance(args.get("label"), str) or not 1 <= len(args["label"]) <= 64:
                    reason = "INVALID_ARGS"
            elif kind == "enhancement":
                reason = "UNSUPPORTED_BACKEND" if self._execution_hook is None else None
                profile = args.get("profile")
                if set(args) != {"profile"} or not isinstance(profile, str):
                    reason = "INVALID_ARGS"
                elif profile in {"hdr", "nr"}:
                    if self._execution_hook is None or not getattr(self._execution_hook, 'supports_profile', lambda name: False)(profile):
                        reason = "UNSUPPORTED_PROFILE"
                elif profile not in {"normal", "low_light", "backlight", "dehaze"}:
                    reason = "INVALID_ARGS"
            elif kind == "depth":
                reason = "NOT_QUALIFIED_CALIBRATION_SYNC" if len(self._cameras) == 2 else "UNSUPPORTED_SINGLE_CAMERA"
                if published.meta.source_kind in {"DIGITAL_REPLAY", "SYNTHETIC_REPLAY", "TABLET_RECAPTURE"}:
                    reason = "NONPHYSICAL_METRIC_DEPTH"
                roi = args.get("roi")
                if (set(args) != {"roi", "coordinate_space"} or args.get("coordinate_space") != "source"
                        or not isinstance(roi, (tuple, list)) or len(roi) != 4
                        or not all(type(v) in (int, float) and math.isfinite(v) for v in roi)
                        or not 0 <= roi[0] < roi[2] <= published.meta.width
                        or not 0 <= roi[1] < roi[3] <= published.meta.height):
                    reason = "INVALID_ARGS"
            else:
                reason = "UNKNOWN_ACTION"
            status = ActionStatus(request_id, "REJECTED" if reason else "PENDING",
                                  reason or "NO_EXECUTION_ADAPTER")
            if reason is None and kind == "enhancement" and self._execution_hook is not None:
                status = self._execution_hook.request_action(
                    client_id, request_id, frame_ref, kind, dict(args), deadline_ns)
                self._delegated.add(key)
            self._requests[key] = fingerprint, status, deadline_ns, frame_ref
            return status

    def get_request_status(self, client_id: str, request_id: str) -> ActionStatus | None:
        with self._lock:
            item = self._requests.get((client_id, request_id))
            if item is None:
                return None
            _, status, deadline, ref = item
            if (client_id, request_id) in self._delegated:
                # A real APPLIED may follow a semantic deadline. Keep its
                # actual identity instead of changing it to a local expiry.
                delegated = self._execution_hook.get_request_status(client_id, request_id)
                return delegated if delegated is not None else status
            if status.status == "PENDING":
                if self.clock() >= deadline:
                    return ActionStatus(request_id, "EXPIRED", "DEADLINE")
                if self._current(client_id, ref) is None:
                    return ActionStatus(request_id, "EXPIRED", "STALE_FRAME")
            return status
