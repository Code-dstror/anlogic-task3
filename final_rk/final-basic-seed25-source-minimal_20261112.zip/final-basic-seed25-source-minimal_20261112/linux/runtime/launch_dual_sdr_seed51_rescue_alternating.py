"""Explicit drop_stale dual rescue, CAM0/CAM1 HDMI selection every ten seconds."""
if __package__:
    from . import dual_sdr_seed51 as release
    from .launch_dual_r3_alternating import main as launch
else:
    import dual_sdr_seed51 as release
    from launch_dual_r3_alternating import main as launch


def main(argv=None):
    return launch(argv, required_profile=release.RESCUE_ALTERNATING_PROFILE)


if __name__ == '__main__':
    main()
