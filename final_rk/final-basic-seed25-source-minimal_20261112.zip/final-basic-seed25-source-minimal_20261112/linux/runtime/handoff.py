"""Standalone handoff wrapper; preserves the byte-identical B22 video package.

verify is host/file-only. inspect/prepare read RK metadata but never open native
or MPP. run launches the original entry once, only with a current scene record.
No flashing, bind, module loading, retry, killing or recovery is implemented.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
from uuid import UUID, uuid4

BIT_SHA = 'b58a401475d169dc3ced250eefb88dbca850bfb6c1e5e99ed80b2763540e0c25'
MANIFEST_SHA = '0bfb15f22ede960ab2e0c62aea598a65f5d63a1aef9089f2a4c2a740da1723cc'
INDEX_SHA = '51131336be54a2bd9e49efc61cda068fe055cb6ed9b9901da759b88f7a78746a'
BDF = '0000:21:00.0'
BOOT = Path('/proc/sys/kernel/random/boot_id')
GUARDS = Path('/run/r6r2-p0-handoff')


def read_json(path):
    return json.loads(Path(path).read_text())


def save_new(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def package(root):
    return root / 'software/r5-p0-candidate'


def safe_file(root, relative):
    rel = Path(relative)
    if rel.is_absolute() or '..' in rel.parts or not rel.parts:
        raise ValueError('invalid bundle relative path')
    path = root / rel
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('bundle path escapes root')
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError('ordinary bundle file required: ' + str(rel))
    return path


def verify(root):
    index = read_json(root / 'artifact-index.json')
    for row in index['files']:
        body = safe_file(root, row['path']).read_bytes()
        if len(body) != row['bytes'] or sha256(body).hexdigest() != row['sha256']:
            raise ValueError('bundle hash mismatch: ' + row['path'])
    for path, digest in ((package(root) / 'manifest.json', MANIFEST_SHA),
                         (root / 'assets/build-index.json', INDEX_SHA),
                         (root / 'assets/01_CURRENT_R6r2_seed29.bit', BIT_SHA)):
        if sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('fixed B22 pairing mismatch: ' + str(path))
    manifest = read_json(package(root) / 'manifest.json')
    for row in manifest['files']:
        body = safe_file(package(root), row['path']).read_bytes()
        if len(body) != row['bytes'] or sha256(body).hexdigest() != row['sha256']:
            raise ValueError('original B22 payload changed: ' + row['path'])
    # Only now import the checked candidate. This wrapper is not added to its manifest.
    sys.path.insert(0, str(package(root)))
    from linux.r5_video import preflight
    if Path(preflight.__file__).resolve() != (package(root) / 'linux/r5_video/preflight.py').resolve():
        raise ValueError('cached source differs; execute tools/handoff.py directly in a fresh Python process')
    from linux.r5_video.preflight import check_software
    checked = check_software(package(root),
        library=package(root) / 'native/libstream_diag_mpp.so',
        bit=root / 'assets/01_CURRENT_R6r2_seed29.bit',
        ko=root / 'assets/ph1a_c2h.ko', build_index=root / 'assets/build-index.json',
        hardware_candidate='r6r2-seed29', runtime_profile='factory-6.1.99')
    if not checked['materials']['ready_for_environment_check']:
        raise ValueError('incomplete file pairing')
    return {'bundle_files_verified': len(index['files']),
            'candidate_files_verified': checked['manifest_files_verified'],
            'status': 'FILES_VERIFIED_NOT_BOARD_ACCEPTANCE'}


def owner_scan(proc=Path('/proc')):
    """Read metadata only; missing process is a race, unreadable process is unknown."""
    owners, errors = [], []
    for task in proc.glob('[0-9]*'):
        try:
            cmd = (task / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if 'linux.r5_video.x11_trial' in cmd:
                owners.append({'pid': task.name, 'kind': 'previous_trial'})
            for fd in (task / 'fd').iterdir():
                try:
                    name = os.readlink(fd)
                except FileNotFoundError:
                    continue
                if name.startswith(('/dev/ph1a', '/dev/sgdma', '/dev/mpp')):
                    owners.append({'pid': task.name, 'fd': fd.name, 'target': name})
            for line in (task / 'maps').read_text().splitlines():
                if any(p in line for p in ('/dev/ph1a', '/dev/sgdma', '/dev/mpp')):
                    owners.append({'pid': task.name, 'mapping': line})
        except (FileNotFoundError, ProcessLookupError):
            continue
        except OSError as exc:
            errors.append({'pid': task.name, 'error': str(exc)})
    return {'owners': owners, 'errors': errors}


def inspect_target(root):
    result = verify(root)
    boot = BOOT.read_text().strip()
    pci = []
    for dev in Path('/sys/bus/pci/devices').glob('*'):
        if (dev / 'vendor').read_text().strip() == '0x1edb':
            pci.append({'bdf': dev.name, 'device': (dev / 'device').read_text().strip(),
                        'driver': str((dev / 'driver').resolve()) if (dev / 'driver').exists() else None})
    result.update(boot_id=boot, kernel=os.uname().release, machine=os.uname().machine,
                  pci=pci, owners=owner_scan(), native_nodes=[str(p) for p in Path('/dev').glob('ph1a_c2h_*')],
                  prior_wrapper_attempt=(GUARDS / (boot + '.started.json')).exists(),
                  bit_in_SRAM='UNKNOWN_REQUIRES_CURRENT_PROGRAMMING_RECORD')
    return result


def driver_check(root):
    """Metadata only, before insmod and before optional new_id; no PCI BAR reads."""
    verify(root)
    from linux.r5_video.preflight import note_build_id
    from linux.r5_video.environment import _parameter_matches
    binding = read_json(root / 'assets/build-index.json')
    if os.uname().machine != 'aarch64' or os.uname().release != binding['kernel_release']:
        raise ValueError('factory RK kernel/architecture required')
    kernel = note_build_id(Path('/sys/kernel/notes').read_bytes())
    if kernel != binding['kernel_identity']['build_id']:
        raise ValueError('running kernel build-id differs')
    boot = BOOT.read_text().strip()
    scanned = owner_scan()
    if scanned['owners'] or scanned['errors']:
        raise ValueError('owner present or incomplete owner scan')
    device = Path('/sys/bus/pci/devices') / BDF
    if (device / 'vendor').read_text().strip() != '0x1edb' or (device / 'device').read_text().strip() != '0xabcd':
        raise ValueError('enumerated endpoint differs from fixed BDF/IDs')
    driver = str((device / 'driver').resolve()) if (device / 'driver').exists() else None
    module = Path('/sys/module/ph1a_c2h')
    if module.exists():
        registered = Path('/sys/bus/pci/drivers/ph1a_c2h_candidate/module')
        if registered.resolve(strict=True) != module:
            raise ValueError('registered driver belongs to a different module')
        module_id = note_build_id((module / 'notes/.note.gnu.build-id').read_bytes())
        if module_id != binding['module_build_id'] or (module / 'srcversion').exists():
            raise ValueError('loaded module identity differs')
        for name, expected in binding['parameters'].items():
            if not _parameter_matches(name, (module / 'parameters' / name).read_text().strip(), expected):
                raise ValueError('module parameter differs: ' + name)
        if driver is None:
            state = 'MATCHED_MODULE_ENDPOINT_UNBOUND_REQUIRES_APPROVED_NEW_ID'
        elif driver == '/sys/bus/pci/drivers/ph1a_c2h_candidate':
            state = 'MATCHED_ALREADY_BOUND_SKIP_INSMOD_AND_NEW_ID'
        else:
            raise ValueError('unexpected endpoint driver')
    else:
        if driver is not None:
            raise ValueError('unexpected binding without expected module')
        state = 'MATCHED_KERNEL_ENDPOINT_UNBOUND_REQUIRES_APPROVED_INSMOD'
    if BOOT.read_text().strip() != boot:
        raise ValueError('boot changed')
    return {'status': state, 'boot_id': boot, 'kernel_build_id': kernel,
            'native_opened': False, 'hardware_writes': 0}


def validate_scene(scene, boot):
    for field in ('programming_evidence', 'cold_start_evidence', 'user_confirmation_record'):
        if not isinstance(scene.get(field), str) or not scene[field].strip():
            raise ValueError('actual evidence text required: ' + field)
    if scene.get('boot_id') != boot or str(UUID(boot)) != boot:
        raise ValueError('scene boot is stale')
    if scene.get('bit_sha256') != BIT_SHA:
        raise ValueError('only original seed29; observation bit needs separate adaptation')
    for field in ('exclusive_control', 'no_prior_native_start_or_dma',
                  'power_and_configuration_unchanged_since_programming', 'approved_one_trial'):
        if scene.get(field) is not True:
            raise ValueError('reviewed scene assertion required: ' + field)


def target_ready(root, spec):
    from linux.r5_video.preflight import check_runtime
    from linux.r5_video.x11_trial import validate_acceptance, verify_display_files
    from linux.r5_video.environment import verify_environment
    mb = (package(root) / 'manifest.json').read_bytes()
    ib = (root / 'assets/build-index.json').read_bytes()
    validate_acceptance(spec, manifest=json.loads(mb), manifest_bytes=mb, index_bytes=ib)
    check_runtime(Path('/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0'))
    verify_display_files(spec)
    environment = verify_environment(spec['boot_id'], spec['bdf'], json.loads(ib),
                                     runtime_profile='factory-6.1.99')
    dev = Path(spec['device'])
    if not stat.S_ISCHR(dev.stat().st_mode):
        raise ValueError('observed native character node required')
    scanned = owner_scan()
    if scanned['owners'] or scanned['errors']:
        raise ValueError('device owner or incomplete ownership scan: ' + json.dumps(scanned))
    if (GUARDS / (spec['boot_id'] + '.started.json')).exists():
        raise ValueError('this boot already has a wrapper attempt; do not retry or delete guard')
    if BOOT.read_text().strip() != spec['boot_id']:
        raise ValueError('boot changed during preflight')
    return environment


def prepare(root, run_dir, scene_path):
    verify(root)
    scene = read_json(scene_path)
    boot = BOOT.read_text().strip()
    validate_scene(scene, boot)
    from linux.r5_video.x11_trial import SCOPE, RISK
    runtime = read_json(root / 'assets/display-baseline.json')
    manifest = read_json(package(root) / 'manifest.json')
    spec = dict(runtime, schema=1, scope=SCOPE, trial_id=str(uuid4()), risk_acceptance=RISK,
        boot_id=boot, bdf=BDF, device='/dev/ph1a_c2h_' + BDF, duration_s=10,
        manifest_sha256=MANIFEST_SHA, source_commit=manifest['linux_source_commit'],
        build_index_sha256=INDEX_SHA, bit_sha256=BIT_SHA,
        evidence_dir=str(run_dir / 'capture'), user_confirmation_record=scene['user_confirmation_record'])
    environment = target_ready(root, spec)
    run_dir.mkdir(mode=0o700)  # Never overwrite/recycle an old trial directory.
    save_new(run_dir / 'scene.json', scene)
    save_new(run_dir / 'acceptance.json', spec)
    save_new(run_dir / 'preparation.json', {'environment': environment, 'time_ns': time.time_ns(),
                                          'input_sha256': prepared_hashes(run_dir),
                                          'status': 'PREPARED_NO_NATIVE_OPEN'})
    return {'status': 'PREPARED_NO_NATIVE_OPEN', 'trial_id': spec['trial_id'], 'run_dir': str(run_dir)}


def trial_command(root, acceptance):
    return [sys.executable, '-B', '-m', 'linux.r5_video.x11_trial',
            '--root', str(package(root)), '--library', str(package(root) / 'native/libstream_diag_mpp.so'),
            '--mpp-runtime', '/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0',
            '--bit', str(root / 'assets/01_CURRENT_R6r2_seed29.bit'),
            '--tested-ko', str(root / 'assets/ph1a_c2h.ko'),
            '--build-index', str(root / 'assets/build-index.json'),
            '--run-approved-trial', str(acceptance)]


def prepared_hashes(run_dir):
    return {name: sha256((run_dir / name).read_bytes()).hexdigest()
            for name in ('scene.json', 'acceptance.json')}


def launch(root, run_dir):
    verify(root)
    if read_json(run_dir / 'preparation.json')['input_sha256'] != prepared_hashes(run_dir):
        raise ValueError('prepared scene/acceptance changed; no launch')
    spec = read_json(run_dir / 'acceptance.json')
    scene = read_json(run_dir / 'scene.json')
    validate_scene(scene, BOOT.read_text().strip())
    if scene['boot_id'] != spec['boot_id'] or scene['user_confirmation_record'] != spec['user_confirmation_record']:
        raise ValueError('acceptance differs from current scene/confirmation')
    if spec['duration_s'] != 10 or spec['bdf'] != BDF or spec['device'] != '/dev/ph1a_c2h_' + BDF:
        raise ValueError('fixed 10s baseline/BDF required')
    if spec['evidence_dir'] != str(run_dir / 'capture') or os.path.lexists(run_dir / 'capture'):
        raise ValueError('fresh capture path required')
    target_ready(root, spec)
    GUARDS.mkdir(mode=0o700, exist_ok=True)
    if GUARDS.is_symlink() or GUARDS.stat().st_mode & 0o022:
        raise ValueError('private real guard directory required')
    command = trial_command(root, run_dir / 'acceptance.json')
    attempt = {'boot_id': spec['boot_id'], 'trial_id': spec['trial_id'], 'argv': command,
               'time_ns': time.time_ns(), 'scope': 'ONE_ATTEMPT_NO_AUTOMATIC_RETRY'}
    save_new(GUARDS / (spec['boot_id'] + '.started.json'), attempt)
    save_new(run_dir / 'attempt.json', attempt)
    # Keep stdout off the UART. Original owner/MPP retention behavior is unchanged.
    fd = os.open(run_dir / 'owner.log', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    env = {k: v for k, v in os.environ.items()
           if not k.startswith(('LD_', 'PYTHON', 'GST_'))}
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUNBUFFERED='1')
    with os.fdopen(fd, 'wb') as output:
        process = subprocess.Popen(command, cwd=package(root), env=env, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    launched = {'pid': process.pid, 'trial_id': spec['trial_id'], 'status': 'LAUNCHED_NOT_ACCEPTED',
                'read_result_with': 'handoff.py summary --run-dir ' + str(run_dir)}
    save_new(run_dir / 'launch.json', launched)
    return launched


def summarize(run_dir):
    path = run_dir / 'capture/final-status.json'
    if not path.exists():
        return {'status': 'NO_SEALED_RESULT', 'next': 'read owner.log; do not automatically retry/kill'}
    data = read_json(path)
    final = data['final_snapshot']
    trial = final['trial']
    preview = final.get('preview') or {}
    session = final.get('session') or {}
    progress = trial.get('progress') or {}
    return {'status': 'RESULT_PRESENT_NOT_AUTOMATIC_HDMI_ACCEPTANCE', 'path': str(path),
            'trial_id': trial.get('trial_id'), 'outcome': trial.get('outcome'),
            'first_error': trial.get('first_error'), 'session_state': session.get('state'),
            'submitted_jpegs': preview.get('submitted_jpegs'),
            'video_window_start_monotonic_s': trial.get('video_window_start_monotonic_s'),
            'progress': {k: v for k, v in progress.items() if k not in ('events', 'timeline')},
            'physical_HDMI': trial.get('physical_HDMI'),
            'resources_retained': trial.get('resources_retained'),
            'note': 'Inspect first_error, CFG, three-layer window/tail and physical HDMI; retained != reopen-safe'}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=('verify', 'inspect', 'driver-check', 'prepare', 'run', 'summary'))
    p.add_argument('--bundle', type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument('--run-dir', type=Path)
    p.add_argument('--scene', type=Path)
    args = p.parse_args(argv)
    root = args.bundle.resolve(strict=True)
    if args.action in ('prepare', 'run', 'summary') and args.run_dir is None:
        p.error('--run-dir required')
    run_dir = args.run_dir.resolve() if args.run_dir else None
    if args.action == 'verify':
        result = verify(root)
    elif args.action == 'inspect':
        result = inspect_target(root)
    elif args.action == 'driver-check':
        result = driver_check(root)
    elif args.action == 'prepare':
        if args.scene is None:
            p.error('--scene required; actual current record, not historical approval')
        result = prepare(root, run_dir, args.scene)
    elif args.action == 'run':
        result = launch(root, run_dir)
    else:
        result = summarize(run_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
