"""Fixed-peer software health adapter for the explicit KMS health candidate.

Only the wait watchdog uses this view. Complete configuration/status/final
snapshots remain owned by the original peer. No event/history traversal, device
calls, or fallback to incomplete health when the reviewed layout is unavailable.
"""

COUNTERS = ('jpeg_frames', 'analysis_negative_terminals', 'analysis_frame_errors')
STATES = frozenset(('NEW', 'PREPARED', 'RUNNING', 'DRAINING', 'STOPPED',
                    'FAULTED', 'DRAINED_RETAINED', 'CLOSED'))


def _count(value):
    if type(value) is not int or value < 0:
        raise ValueError('nonnegative integer health counter required')
    return value


def snapshot_health(session):
    """Read fixed scalar counters under the same lock used by peer inspection.

    A missing lock, inspector, reader, counter or SOURCE journal fails closed.
    This adapter deliberately depends on the indexed peer's reviewed layout;
    it does not modify any peer file or call inspector.snapshot().
    """
    try:
        with session._inspect_lock:
            state, failure = session.state, session.failure
            if state not in STATES:
                raise ValueError('unknown peer state')
            counts = session.inspector._counts
            if not all(name in counts for name in COUNTERS):
                raise ValueError('required inspector health counter unavailable')
            counters = {name: _count(counts[name]) for name in COUNTERS}
            native = _count(session.reader.records)
            transport_failure = session.reader.fault
        # Do not nest the SOURCE journal lock under the parser lock.
        gap = session.source_gap_journal.snapshot()
        if not isinstance(gap, dict) or 'failure' not in gap:
            raise ValueError('SOURCE journal health unavailable')
        if transport_failure is not None:
            raise RuntimeError('transport fault: '+str(transport_failure)[:256])
        return dict(state=state, failure=failure, transport=dict(records=native),
                    products=dict(counters=counters),
                    source_gap_journal=dict(failure=gap['failure']))
    except Exception as error:
        raise RuntimeError('HEALTH_SNAPSHOT_UNAVAILABLE: '+str(error)[:256]) from error
