"""FPS artifact policy: DUAL_SDR for stereo, DUAL_HDR for every mono mode."""
import hashlib
import json
from pathlib import Path

SUFFIX='_FPS_HUD_V1'
HDR_BIT='0e4de42629bd48f000782feeec65493dda8cf9126749b80dcc44e62211e4230e'
SDR_BIT='12320a74248fba27c74d86f1709f9799b9c18ee0182a4f047ec6a67af72e2213'
HDR_SOURCE='06a122ee7060d56c5a4f783112cb727209c54ed5'
SDR_SOURCE='6f9c72762bd88abdc13e3a0ee31fd7dc97e4ccb7'
MONO_PROFILES=('dual-hdr-seed1-mono-six-stage','dual-hdr-seed1-cam0-sdr-hdr-sdr-3x10',
               'dual-hdr-seed1-mono-lane-data')
LANE_PROFILE='dual-hdr-seed1-mono-lane-overlay-10-60-10'
DUAL_PROFILES=('dual-sdr-seed51-drop-stale-side-by-side-n2-kms60',
               'dual-sdr-seed51-drop-stale-alternating-n2-kms60')
OBSERVERS={
 'mono':'3a557062584304fa95c4277def33c1f462ef4b47392f0d494e61db7378a7604a',
 'lane':'c1fb6fef48745c87c138578f4817067ecb07165ba7a07ada5a60cf30b1ae8da0',
 'dual':'4e9c47e6aee4ec7d113dcf2cad0d879d68a163b5ecc1b51d126a5823c070eef9',
}
COMMON_LIBRARIES={
 '/usr/lib/aarch64-linux-gnu/libgstreamer-1.0.so.0':'1159cec4173951f42c39f9143610a44579204eb218f101a6ad858649ead8348f',
 '/usr/lib/aarch64-linux-gnu/libgstvideo-1.0.so.0':'2610e2a21524e1c8b3230dbe4a67e796678ad6bd9e0d3b06a547283d1d3330a1',
}
DUAL_LIBRARIES={
 '/usr/lib/aarch64-linux-gnu/libgstbase-1.0.so.0':'e720042f445a2c4991f155c712a5a27876f8a6412ecc5e5e88b3a76610a98d5f',
 '/usr/lib/aarch64-linux-gnu/gstreamer-1.0/libgstcompositor.so':'23e124fed170252afceeca7bb018cff5c234d5bc49c3390ccc5e115aa2994ccf',
}
REQUIRED={'fps_hud.py','fps_hud_core.h','gst_fps_hud.h','fps_observer_source.py',
          'fps-hud.json','gst_fps_observer.c','launch_fps_hud.py'}


def variant_for(profile):
    if profile in MONO_PROFILES:return 'mono'
    if profile==LANE_PROFILE:return 'lane'
    if profile in DUAL_PROFILES:return 'dual'
    raise ValueError('FPS requires HDR seed1 mono or SDR seed51 dual profile')


def banner(variant):
    if variant not in OBSERVERS:raise ValueError('unknown FPS variant')
    return ('R5_FPS_HUD_'+variant.upper()+'_FRAME_DRIVEN_NV12_RETAIN_V1\n').encode()


def activate_mono(profiles,profile):
    variant=variant_for(profile)
    if variant=='dual' or profiles[profile]['bit_sha256']!=HDR_BIT:
        raise ValueError('FPS mono must use DUAL_HDR seed1')
    row=profiles[profile]
    if row.get('fps_hud_variant') or row['scope'].endswith(SUFFIX):
        raise ValueError('FPS policy cannot be installed twice')
    profiles[profile]=dict(row,observer_sha256=OBSERVERS[variant],scope=row['scope']+SUFFIX,
        fps_hud_variant=variant,fps_refresh='ON_VIDEO_FRAME_ONLY',
        fps_semantics='UNIQUE_VIDEO_BUFFER_AT_KMS_INPUT_NOT_SCANOUT_HZ')


def activate_dual(base_function,profile):
    if variant_for(profile)!='dual':raise ValueError('FPS dual must use DUAL_SDR seed51')
    def fixed(selected):
        if selected!=profile:raise ValueError('FPS artifact has one fixed base profile')
        value=base_function(selected)
        return dict(value,scope=value['scope']+SUFFIX,fps_hud_variant='dual')
    return fixed


def verify_feature(root,index,profile):
    variant=variant_for(profile);root=Path(root)
    expected_bit=SDR_BIT if variant=='dual' else HDR_BIT
    expected_source=SDR_SOURCE if variant=='dual' else HDR_SOURCE
    if (index.get('fps_hud'),index.get('bit_sha256'),index.get('fpga_source'))!=(variant,expected_bit,expected_source):
        raise ValueError('FPS bit/profile mapping differs')
    if not index['scope'].endswith(SUFFIX) or not REQUIRED<=index['files'].keys():
        raise ValueError('FPS scope or runtime closure incomplete')
    if variant=='dual' and 'gst_fps_dual_pipeline.h' not in index['files']:
        raise ValueError('FPS compositor source missing')
    info=json.loads((root/'fps-hud.json').read_text())
    if (info['scope'],info['fpga_source'])!=(index['scope'],expected_source):
        raise ValueError('FPS manifest source/scope differs')
    if (info['profile'],info['variant'],info['bit_sha256'],info['background_refresh'],info['counter_interval_ns'])!=(profile,variant,expected_bit,False,1000000000):
        raise ValueError('FPS manifest policy differs')
    if index['files']['gst_perf_observer']['sha256']!=OBSERVERS[variant]:
        raise ValueError('FPS observer identity differs')
    return info


def verify_libraries(variant):
    if variant not in OBSERVERS:raise ValueError('unknown FPS variant')
    expected=dict(COMMON_LIBRARIES)
    if variant=='dual':expected.update(DUAL_LIBRARIES)
    for name,digest in expected.items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:
            raise ValueError('FPS public library/plugin differs: '+name)
