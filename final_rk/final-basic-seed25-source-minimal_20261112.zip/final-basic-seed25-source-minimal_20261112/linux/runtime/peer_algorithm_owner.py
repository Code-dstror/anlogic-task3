"""Seed15 single-owner algorithm trial using the unchanged peer runtime.

Run this file as a standalone Python program. Import and --prepare-only never
open a device. The 1800 second START budget includes CFG/first-frame waits;
nominal dwell times sum to 1800, so the final HDR dwell is truncated by overhead.
The generated plan requires this wrapper: dehaze generation zero is deliberately
unusable until the actual QUERY reply supplies a new generation.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import importlib
import json
import os
from pathlib import Path
import re
import sys
import time

DURATION = 1800
SEED15_SHA256 = '7a9ba53028175ae88560bddc37806f4fab85b2622b61fbe2e71ad85b54f0f68b'
MODES = (('color', 0, 300), ('gray', 1, 180), ('gaussian', 4, 180),
         ('histogram', 8, 180), ('f22', 16, 180), ('f22_f23', 48, 180),
         ('combined61', 61, 180), ('dehaze', 2, 180),
         ('color_restore', 0, 120), ('hdr_diagnostic', 0, 120))


def configuration(enables=0, *, hdr=False, generation=0):
    ext = dict(schema=2, product_mode=2 if hdr else 0,
        processing_enables=enables, hdr_ratio=4 if hdr else 0,
        hdr_black_long=50 if hdr else 0, hdr_black_short=50 if hdr else 0,
        hdr_motion_base=64 if hdr else 0, hdr_motion_shift=3 if hdr else 0,
        hdr_qualification=15 if hdr else 0, hdr_max_delta_ns=50000000 if hdr else 0,
        hdr_max_wait_ns=100000000 if hdr else 0,
        hdr_max_age_ns=1000000000 if hdr else 0, dehaze_lut_generation=generation)
    return dict(schema=2, base=dict(mode='COLOR', quality=75, flags=0,
        min_quality=1, frame_budget=0, restart_mcus=0), extension=ext)


def build_plan():
    steps = [{'op': 'discover'}]
    for name, enables, seconds in MODES:
        if name == 'dehaze':
            steps += [{'op': 'configure', 'configuration': configuration()},
                      {'op': 'wait-product', 'kind': 'JPEG', 'epoch': 'active',
                       'timeout_s': 3, 'at_least': 5}, {'op': 'query-lut'}]
        steps += [{'op': 'configure', 'configuration': configuration(enables,
                    hdr=name == 'hdr_diagnostic')},
                  {'op': 'wait-product', 'kind': 'JPEG', 'epoch': 'active',
                   'timeout_s': 3, 'at_least': 5}]
        while seconds:
            chunk = min(60, seconds)
            steps.append({'op': 'wait', 'seconds': chunk})
            seconds -= chunk
        steps.append({'op': 'status'})
    return dict(version=1, steps=steps)


def next_generation(reply):
    get = reply.get if isinstance(reply, dict) else lambda key: getattr(reply, key)
    if get('loading'):
        raise RuntimeError('existing LUT load is not owned by this trial')
    active = get('active_generation')
    if type(active) is not int or not 0 <= active <= 0xffffffff:
        raise ValueError('invalid actual LUT active generation')
    if type(get('valid')) is not bool:
        raise ValueError('invalid actual LUT validity')
    generation = active + 1 if get('valid') else 1
    if generation > 0xffffffff:
        raise ValueError('LUT generation exhausted; no wrap')
    return generation


class TrialBudget:
    def __init__(self, clock=time.monotonic, duration=DURATION):
        self.clock, self.duration, self.started = clock, duration, None

    def start(self):
        if self.started is not None:
            raise RuntimeError('trial START budget is single use')
        self.started = self.clock()

    def remaining(self):
        if self.started is None:
            raise RuntimeError('native START budget has not begun')
        return max(0., self.started + self.duration - self.clock())


class SingleStop:
    """One intent before the syscall; unknown acceptance is never retried."""
    def __init__(self, stop):
        from threading import Lock
        self.stop, self.issued, self.lock = stop, False, Lock()

    def __call__(self):
        with self.lock:
            if self.issued:
                raise RuntimeError('STOP already issued; no repeated IO after unknown acceptance')
            self.issued = True
        return self.stop()


def close_retaining(session):
    """Peer DebugSession.close sequencing, stopping before native close/unmap.

    The unchanged parent implementation would close the native fd after host
    drain. That proves no FPGA-wide quiet. Never call receiver.close/abandon.
    """
    if session.state == 'DRAINED_RETAINED':
        return session.snapshot()
    session._control_stop.set()
    if session._control_thread is not None:
        session._control_thread.join(session.config_timeout_s + .1)
        if session._control_thread.is_alive():
            session._fault('CLOSE', TimeoutError('configuration worker still owns a transaction'))
    session._closing.set()
    session._pause.set()
    if session._receive_thread is not None:
        session._receive_thread.join(session.drain_timeout_s + .2)
        if session._receive_thread.is_alive():
            session._fault('CLOSE', TimeoutError('receiving worker still owns the device'))
    if session.failure is not None:
        return session.snapshot()
    if session.state not in ('STOPPED', 'PREPARED'):
        session._fault('CLOSE', RuntimeError('normal stopped state was not established'))
        return session.snapshot()
    try:
        if session.consumers is not None:
            result = session.consumers.close(timeout_s=session.drain_timeout_s)
            if not result.get('worker_done'):
                raise RuntimeError('consumer still owns data/files')
        with session._inspect_lock:
            session._finished_products = session.inspector.finish()
            session.inspector.close()
        session.state = 'DRAINED_RETAINED'
        session.ownership_retained = True
        return session.snapshot()
    except BaseException as error:
        session._fault('CLOSE', error)
        return session.snapshot()


def bounded_snapshot(value):
    """Preserve each epoch independently of the peer's final event ring."""
    selected = {key: value.get(key) for key in ('state', 'failure', 'stop_reason',
        'ownership_retained', 'owner', 'active', 'transport', 'observed_products')}
    products = value.get('products') or {}
    selected['products'] = {key: products[key] for key in products
                            if key not in ('events', 'event_summaries')}
    for key in ('events', 'event_summaries'):
        if key in products:
            selected['products'][key] = products[key][-3:]
    controls = value.get('controls') or {}
    selected['control_receipts'] = {key: controls.get(key) for key in
        ('last_applied', 'last_lut', 'failure', 'terminal', 'applied_count')}
    return selected


def atomic_json(path, value):
    data = (json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False) + '\n').encode()
    if len(data) > 2 * 1024 * 1024:
        raise ValueError('bounded trial snapshot exceeds 2MiB')
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('xb') as output:
        output.write(data)
        output.flush()
    os.replace(temporary, path)


class StepRunner:
    def __init__(self, execute, budget, event, snapshot, *, clock=time.monotonic,
                 preview_state=None):
        self.execute, self.budget, self.event, self.save_snapshot = execute, budget, event, snapshot
        self.clock = clock
        self.generation = None
        self.sequence = 0
        self.failed = False
        self.preview_state = preview_state
        self.preview_grace_start = None
        self.preview_epoch_boundary_ns = None
        self.preview_progress_armed = set()
        self.preview_seen = False
        self.preview_heartbeat_established = False

    def _preview_new_epoch(self):
        self.preview_grace_start = self.clock()
        self.preview_epoch_boundary_ns = round(self.clock() * 1e9)
        self.preview_progress_armed.clear()

    def _check_preview(self):
        if self.preview_state is None:
            return
        if self.preview_grace_start is None:
            self._preview_new_epoch()
        try:
            if self.preview_state.stat().st_size > 65536:
                raise ValueError('preview state exceeds 64KiB')
            state = json.loads(self.preview_state.read_text())
        except FileNotFoundError:
            if not self.preview_seen and self.clock() - self.preview_grace_start < 5:
                return
            raise RuntimeError('preview startup produced no state within five seconds')
        self.preview_seen = True
        if state.get('failure'):
            raise RuntimeError('preview failure: ' + str(state['failure'])[:512])
        now_ns = round(self.clock() * 1e9)
        heartbeat = state.get('heartbeat_received_ns')
        if type(heartbeat) is int and heartbeat > 0:
            self.preview_heartbeat_established = True
        if (self.preview_heartbeat_established or self.clock() - self.preview_grace_start >= 5):
            if type(heartbeat) is not int or heartbeat <= 0 or now_ns-heartbeat >= 3_000_000_000:
                raise RuntimeError('PREVIEW_STALE_3S: heartbeat_received_ns')
        for key in ('mpp_last_ns', 'sink_last_ns'):
            stamp = state.get(key)
            if type(stamp) is int and stamp >= self.preview_epoch_boundary_ns:
                self.preview_progress_armed.add(key)
            if key not in self.preview_progress_armed and self.clock()-self.preview_grace_start < 5:
                continue  # Await this epoch's first callback; failures/heartbeat stay live.
            if type(stamp) is not int or stamp <= 0 or now_ns - stamp >= 3_000_000_000:
                raise RuntimeError('PREVIEW_STALE_3S: ' + key)

    def _wait(self, session, seconds, stop):
        end = self.clock() + min(seconds, self.budget.remaining())
        previous = None
        started = False
        while not stop.is_set() and self.clock() < end:
            state = session.snapshot()  # Cached peer state only; no BAR/syscalls.
            if state.get('failure') or state.get('state') == 'FAULTED':
                raise RuntimeError('peer session faulted during dwell')
            counts = ((state.get('transport') or {}).get('records', 0),
                      ((state.get('products') or {}).get('counters') or {}).get('jpeg_frames', 0))
            started |= all(counts)
            if previous is None:
                previous = counts
                native_at = jpeg_at = self.clock()
            else:
                if counts[0] != previous[0]: native_at = self.clock()
                if counts[1] != previous[1]: jpeg_at = self.clock()
                previous = counts
            if started and self.clock() - min(native_at, jpeg_at) >= 3:
                stop.set()
                raise RuntimeError('STREAM_STALE_3S: no native or complete JPEG progress during dwell')
            self._check_preview()
            stop.wait(min(.25, max(0., end - self.clock())))

    def __call__(self, session, step, budget, stop):
        if self.failed or stop.is_set():
            raise RuntimeError('trial terminal; no later algorithm command')
        self.sequence += 1
        number = self.sequence
        step = deepcopy(step)
        begin = self.clock()
        self.event(dict(kind='STEP_BEGIN', step=number, monotonic_s=begin,
                        remaining_s=self.budget.remaining(), request=step))
        try:
            remaining = self.budget.remaining()
            if remaining <= 0:
                stop.set()
                return None
            if step['op'] == 'wait':
                result = self._wait(session, step['seconds'], stop)
            else:
                if (step['op'] == 'configure' and
                        step['configuration']['extension']['processing_enables'] & 2):
                    if self.generation is None:
                        raise RuntimeError('dehaze requires actual QUERY/load receipt')
                    step['configuration']['extension']['dehaze_lut_generation'] = self.generation
                result = self.execute(session, step, min(budget, remaining), stop)
                if step['op'] == 'wait-product':
                    self._preview_new_epoch()
                if step['op'] == 'query-lut':
                    self.generation = next_generation(result)
                    self.event(dict(kind='LUT_GENERATION_SELECTED', step=number,
                        monotonic_s=self.clock(), generation=self.generation,
                        actual_query=vars(result) if not isinstance(result, dict) else result))
                    left = min(budget - (self.clock() - begin), self.budget.remaining())
                    if left <= 0:
                        raise TimeoutError('QUERY/load exceeded command budget')
                    loaded = self.execute(session, dict(op='load-lut', generation=self.generation), left, stop)
                    self.event(dict(kind='LUT_LOAD_RETURN', step=number,
                        monotonic_s=self.clock(), generation=self.generation,
                        receipt=vars(loaded) if not isinstance(loaded, dict) else loaded))
            current = bounded_snapshot(session.snapshot())
            self.save_snapshot(number, current)
            self.event(dict(kind='STEP_RETURN', step=number, monotonic_s=self.clock(),
                elapsed_s=self.clock()-begin, actual_request=step, active=current.get('active')))
            return result
        except BaseException as error:
            self.failed = True
            stop.set()
            self.event(dict(kind='FIRST_FAILURE', step=number, monotonic_s=self.clock(),
                type=type(error).__name__, detail=str(error)[:512]))
            session._fault('ALGORITHM_TRIAL', error)
            self.save_snapshot(number, bounded_snapshot(session.snapshot()))
            raise


def import_peer(root):
    root = root.resolve(strict=True)
    if not (root / 'linux/rk_debug/cli.py').is_file():
        raise ValueError('peer-root must be the complete debug_host runtime')
    # Standalone process only: do not mix the workspace's linux modules with peer.
    existing = [name for name in sys.modules if name.startswith('linux.') and
                not name.startswith('linux.r5_video')]
    if existing:
        raise RuntimeError('run owner as a standalone file to isolate peer imports')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root))
    if 'linux' in sys.modules:
        sys.modules['linux'].__path__ = [str(root / 'linux')]
    cli = importlib.import_module('linux.rk_debug.cli')
    session = importlib.import_module('linux.rk_debug.session')
    return cli, session


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--peer-root', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--expected-boot', required=True)
    parser.add_argument('--bit-sha256', required=True)
    parser.add_argument('--device', required=True)
    parser.add_argument('--expected-bdf', required=True)
    parser.add_argument('--preview-state', type=Path,
                        help='optional atomic state written by the external preview process')
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--prepare-only', action='store_true')
    action.add_argument('--run', action='store_true')
    args = parser.parse_args(argv)
    if args.bit_sha256 != SEED15_SHA256:
        parser.error('this trial requires the fixed ac7 seed15 bit SHA256')
    if not re.fullmatch('[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', args.expected_boot):
        parser.error('expected-boot requires canonical boot UUID')
    cli, peer_session = import_peer(args.peer_root)
    cli._bdf(args.expected_bdf)
    if not args.device.startswith('/dev/') or '..' in Path(args.device).parts:
        parser.error('device requires an explicit /dev path')
    plan = build_plan()
    # Exercise the original script parser without writing a plan or touching /dev.
    saved_loader = cli.load_document
    try:
        cli.load_document = lambda _: plan
        steps = cli.load_steps(None)
    finally:
        cli.load_document = saved_loader
    run = cli._new_path(args.run_dir, directory=True)
    if args.prepare_only:
        print(json.dumps(dict(status='PREPARED_NO_DEVICE', plan=plan,
            nominal_dwell_s=sum(x[2] for x in MODES), start_budget_s=DURATION,
            note='CFG/first-frame overhead truncates final HDR; generation injected from actual QUERY'),
            ensure_ascii=False))
        return 0
    actual_boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if actual_boot != args.expected_boot:
        raise RuntimeError('current boot differs from explicit expected boot')
    run.mkdir(mode=0o700)
    atomic_json(run/'plan.json', plan)
    atomic_json(run/'trial-context.json', dict(expected_boot=args.expected_boot,
        declared_bit_sha256=args.bit_sha256, bit_identity_scope='OPERATOR_DECLARATION_NOT_READBACK',
        peer_root=str(args.peer_root.resolve()), device=args.device, expected_bdf=args.expected_bdf,
        global_seconds=DURATION, cfg_seconds=3, command_seconds=5, drain_seconds=3,
        max_records=200000, nominal_modes=MODES, path='PEER_NATIVE_OWNED_TO_BOUNDED_DISK_TO_EXTERNAL_MPP_X11',
        generation_placeholder='ZERO_TEMPLATE_REQUIRES_RUNTIME_QUERY_AND_LOAD',
        safety='NO_CLOSE_UNMAP_REOPEN_RESET_OR_RECOVERY'))
    events = (run/'steps.jsonl').open('x', buffering=1)
    def event(row):
        events.write(json.dumps(row, ensure_ascii=False, allow_nan=False)+'\n')
        events.flush()
    trial_budget = TrialBudget()
    class RetainingSession(peer_session.DebugSession):
        def snapshot(self):
            result = super().snapshot()
            now = time.monotonic()
            result['trial_timing'] = dict(start_call_monotonic_s=trial_budget.started,
                sampled_monotonic_s=now, budget_s=DURATION,
                elapsed_s=None if trial_budget.started is None else now-trial_budget.started,
                remaining_s=None if trial_budget.started is None else trial_budget.remaining(),
                scope='HOST_START_CALL_BUDGET_INCLUDES_CFG_NOT_PHYSICAL_HDMI_TIME')
            result.update(global_quiet_proven=False, native_closed=False, safe_reopen=False)
            return result

        def start(self):
            # START call begins the budget; unknown/slow calls do not grant extra time.
            trial_budget.start()
            event(dict(kind='START_CALL', monotonic_s=trial_budget.started))
            result = super().start()
            event(dict(kind='START_RETURN', monotonic_s=time.monotonic()))
            return result
        def close(self):
            result = close_retaining(self)
            result.update(global_quiet_proven=False, native_closed=False,
                          safe_reopen=False, start_budget_s=DURATION)
            return result
    class Factory(cli.NativeFactory):
        def receiver(self, peer_args):
            receiver = super().receiver(peer_args)
            receiver.stop = SingleStop(receiver.stop)
            return receiver

        def session(self, receiver, peer_args, consumers):
            return RetainingSession(receiver, jpeg_version=3, config_timeout_s=3,
                drain_timeout_s=3, consumers=consumers, allow_lab_hdr=True,
                expected_bdf=peer_args.expected_bdf, max_records=200000)
    execute = cli._execute
    cli._execute = StepRunner(execute, trial_budget, event,
        lambda number, value: atomic_json(run/f'step-{number:03d}.json', value),
        preview_state=args.preview_state)
    try:
        return cli.main(['run', '--device', args.device, '--expected-bdf', args.expected_bdf,
            '--jpeg-version', '3', '--config-timeout', '3', '--drain-timeout', '3',
            '--command-timeout', '5', '--max-seconds', str(DURATION),
            '--max-records', '200000', '--allow-lab-hdr', '--consumer-close-timeout', '3',
            '--jpeg-record-dir', str(run/'records'), '--report-output', str(run/'result.json'),
            '--script', str(run/'plan.json')], factory=Factory())
    finally:
        cli._execute = execute
        events.close()


if __name__ == '__main__':
    raise SystemExit(main())
