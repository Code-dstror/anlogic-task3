"""Isolated 60s CAM0/CAM1 color trial. Default only validates/prepares.

Loading and cold enumeration are separate reviewed operations. This entry never
unloads, resets, retries, restores the desktop or closes a started native owner.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys

if __package__:
    from . import dual_sdr_seed51 as seed51
    from . import dual_r3_driver as driver
    from .dual_r3 import BIT, SOURCE
    from .handoff import save_new
    from .kms_display import load_selection, environment
    from .launch_calfix_algorithm_trial import trial_guards
else:
    import dual_sdr_seed51 as seed51
    import dual_r3_driver as driver
    from dual_r3 import BIT, SOURCE
    from handoff import save_new
    from kms_display import load_selection, environment
    from launch_calfix_algorithm_trial import trial_guards

PROFILE = 'dual-r3-color-alternating-n2-kms60'
SCOPE = 'DUAL_R3_CAM0_CAM1_COLOR_6X10S_N2_RETAIN_V1'
FIXED_CAM0_PROFILE = 'dual-r3-color-fixed-cam0-n2-kms60'
FIXED_CAM0_SCOPE = 'DUAL_R3_BOTH_COLOR_HDMI_CAM0_ONLY_60S_N2_RETAIN_V1'
MPP = '5fb91f82869ef7823c1111dbc9ef39452e00ff4464c97010091db18d625e5d1a'
HDR_SEED1_B_PROFILE = 'dual-hdr-seed1-dual-drop-stale-cam0-cam1'


def hdr_seed1_release():
    # Historical runtimes omit this new release file; import only when selected.
    if __package__:
        from . import dual_hdr_seed1
    else:
        import dual_hdr_seed1
    return dual_hdr_seed1


def profile_spec(profile):
    if profile == seed51.SIDE_BY_SIDE_PROFILE:
        return dict(profile=profile,scope=seed51.SIDE_BY_SIDE_SCOPE,
            fixed_cam0=False,alternating=False,side_by_side=True,duration_s=60,
            segment_s=None,cameras=[0,1],monitored_receive_and_mpp_cameras=[0,1],
            canvas=[1920,1080],views=[dict(camera=0,x=0,y=270,width=960,height=540),
                                    dict(camera=1,x=960,y=270,width=960,height=540)])
    if profile == HDR_SEED1_B_PROFILE:
        return dict(profile=profile,scope=hdr_seed1_release().B_SCOPE,
            fixed_cam0=False,alternating=True,duration_s=40,segment_s=10,
            nominal_observation_s=20,first_frame_segments=True,segment_count=2,
            cameras=[0,1],monitored_receive_and_mpp_cameras=[0,1])
    if profile == seed51.RESCUE_ALTERNATING_PROFILE:
        return dict(profile=profile, scope=seed51.RESCUE_ALTERNATING_SCOPE,
            fixed_cam0=False, alternating=True, duration_s=60, segment_s=10,
            cameras=[0,1,0,1,0,1], monitored_receive_and_mpp_cameras=[0,1])
    if profile == seed51.RESCUE_PROFILE:
        return dict(profile=profile, scope=seed51.RESCUE_SCOPE, fixed_cam0=True,
            alternating=False, duration_s=60, segment_s=60, cameras=[0],
            monitored_receive_and_mpp_cameras=[0,1])
    if profile == seed51.PROFILE:
        return dict(profile=profile, scope=seed51.SCOPE, fixed_cam0=True,
            alternating=False, duration_s=60, segment_s=60, cameras=[0],
            monitored_receive_and_mpp_cameras=[0,1])
    if profile not in (PROFILE, FIXED_CAM0_PROFILE):
        raise ValueError('unknown fixed dual display profile')
    fixed = profile == FIXED_CAM0_PROFILE
    return dict(profile=profile, scope=FIXED_CAM0_SCOPE if fixed else SCOPE,
        fixed_cam0=fixed, alternating=not fixed, duration_s=60,
        segment_s=60 if fixed else 10, cameras=[0] if fixed else [0,1,0,1,0,1],
        monitored_receive_and_mpp_cameras=[0,1])


def release_identity(profile):
    profile_spec(profile)
    if profile == HDR_SEED1_B_PROFILE:
        return hdr_seed1_release().BIT,hdr_seed1_release().SOURCE
    return ((seed51.BIT, seed51.SOURCE)
            if profile in (seed51.PROFILE, *seed51.LOSSY_PROFILES) else (BIT, SOURCE))


def required_source_order_policy(profile):
    profile_spec(profile)
    return 'drop_stale' if profile in (*seed51.LOSSY_PROFILES,HDR_SEED1_B_PROFILE) else 'strict'


def validate_source_order_policy(profile, requested):
    if requested != required_source_order_policy(profile):
        raise ValueError('source order policy differs from the fixed runtime profile')
    return requested


def verify_runtime(root, expected, *, profile=PROFILE):
    spec = profile_spec(profile)
    root = Path(root)
    raw = (root/'runtime-index.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('runtime index SHA differs')
    index = json.loads(raw)
    if (index.get('profile'),index.get('scope'),index.get('bit_sha256'),index.get('fpga_source')) != (
            spec['profile'],spec['scope'],*release_identity(profile)):
        raise ValueError('fixed dual display runtime/profile/scope/bit required')
    validate_source_order_policy(profile, index.get('source_order_policy', 'strict'))
    required = {'dual_r3_stereo.py','dual_r3_trial.py','dual_r3_preview.py',
        'dual_r3_driver.py','dual_r3_load.py','launch_dual_r3_alternating.py','cold_mmio_journal.py',
        'gst_perf_observer','ph1a_c2h.ko','peer/dual_host/dual_records.py',
        'peer/dual_host/stereo_control.py','peer/linux/dma_c2h_candidate/receiver.py'}
    # The common launcher and cold helper import this inert release module for
    # both releases, including when an older R3 runtime is rebuilt.
    required.add('dual_sdr_seed51.py')
    if profile == HDR_SEED1_B_PROFILE:
        required.update(('dual_hdr_seed1.py','launch_seed1_dual_recipe.py',
            'hdr-seed1-debug-policy.json','hdr-seed1-dual-provenance.json',
            'stereo_source_order.py','stereo_owned_record_reader.py','stereo_drop_evidence.py'))
    if profile == seed51.PROFILE:
        required.update(('launch_dual_sdr_seed51.py', seed51.POLICY_FILE))
    if profile in seed51.LOSSY_PROFILES:
        required.update(('launch_dual_sdr_seed51_rescue.py', seed51.POLICY_FILE,
            'stereo_source_order.py', 'stereo_owned_record_reader.py',
            'stereo_drop_evidence.py', 'seed51-rescue-provenance.json'))
        if profile == seed51.RESCUE_ALTERNATING_PROFILE:
            required.add('launch_dual_sdr_seed51_rescue_alternating.py')
        if profile == seed51.SIDE_BY_SIDE_PROFILE:
            required.update(('launch_seed51_side_by_side.py','seed51-side-by-side-provenance.json'))
    rows = index['files']
    if not required <= rows.keys():
        raise ValueError('incomplete alternating runtime')
    actual = set()
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('runtime symlink rejected')
        if path.is_dir():
            continue
        if not stat.S_ISREG(path.stat().st_mode):
            raise ValueError('ordinary runtime files required')
        actual.add(path.relative_to(root).as_posix())
    if actual != set(rows)|{'runtime-index.json'}:
        raise ValueError('runtime closure differs')
    for name, row in rows.items():
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts or rel.as_posix() != name:
            raise ValueError('unsafe runtime path')
        body = (root/name).read_bytes()
        if len(body) != row['bytes'] or hashlib.sha256(body).hexdigest() != row['sha256']:
            raise ValueError('runtime member differs: '+name)
    if profile in (seed51.PROFILE, *seed51.LOSSY_PROFILES):
        seed51.verify_policy(root)
    if profile == HDR_SEED1_B_PROFILE:
        hdr_seed1_release().verify_policy(root)
    driver.verify_ko(root/'ph1a_c2h.ko', identity='stereo-n2')
    if index.get('fps_hud') is not None:
        if __package__:
            from .fps_hud import verify_feature
        else:
            from fps_hud import verify_feature
        verify_feature(root,index,profile)
    return index


def prepare(args):
    root = args.root.resolve(strict=True)
    spec = profile_spec(getattr(args,'profile',PROFILE))
    order_policy = validate_source_order_policy(spec['profile'],
        getattr(args, 'source_order_policy', 'strict'))
    index = verify_runtime(root,args.index_sha256,profile=spec['profile'])
    if not args.programming_note.strip():
        raise ValueError('current joint cold programming receipt required')
    target = driver.check_target(args.expected_boot, identity='stereo-n2')
    run = args.run_dir
    if (not run.is_absolute() or '..' in run.parts or os.path.lexists(run)
            or not run.parent.is_dir() or any(p.is_symlink() for p in run.parents)):
        raise ValueError('fresh absolute evidence directory required')
    if os.statvfs(run.parent).f_bavail*os.statvfs(run.parent).f_frsize < 128*1024*1024:
        raise ValueError('128MiB free evidence space required')
    guards = trial_guards(args.expected_boot)
    if args.owner:
        claim = json.loads(guards[3].read_text())
        if (claim['run_dir'],claim['index_sha256']) != (str(run),args.index_sha256):
            raise ValueError('owner guard differs')
    elif any(os.path.lexists(g) for g in guards):
        raise ValueError('prior trial; no same-boot reopen')
    selection = load_selection(args.kms_selection,args.kms_selection_sha256,
        args.expected_boot,live=args.execute or args.owner)
    if hashlib.sha256(Path('/usr/lib/aarch64-linux-gnu/librockchip_mpp.so.0').read_bytes()).hexdigest() != MPP:
        raise ValueError('factory MPP differs')
    observer = root/'gst_perf_observer'
    env = environment(observer,index['files']['gst_perf_observer']['sha256'],
        args.display_baseline,selection,verify_plugins=True)
    if index.get('fps_hud') is not None:
        if __package__:
            from .fps_hud import verify_libraries,banner
        else:
            from fps_hud import verify_libraries,banner
        verify_libraries('dual')
        if subprocess.check_output([str(observer),'--describe-profile'],timeout=5)!=banner('dual'):
            raise ValueError('FPS dual observer descriptor differs')
    for flag in ('--test-ring','--check-runtime'):
        subprocess.run([str(observer),flag],env=env,check=True,capture_output=True,timeout=5)
    # Query only; no pipeline/device opened. The live run resolves the same
    # plugin environment and fails if the required selector properties differ.
    plugin = 'compositor' if spec.get('side_by_side') else 'input-selector'
    query = subprocess.run(['/usr/bin/gst-inspect-1.0',plugin],env=env,
        capture_output=True,check=True,timeout=5,text=True)
    required_properties = (('background','xpos','ypos','width','height','NV12')
                           if spec.get('side_by_side') else ('active-pad','sync-streams','cache-buffers'))
    if not all(x in query.stdout for x in required_properties):
        raise ValueError('required '+plugin+' unavailable')
    layout_evidence = {'compositor':query.stdout} if spec.get('side_by_side') else {'input_selector':query.stdout}
    plan = dict(status='PREPARED_NO_NATIVE_OPEN',**spec,
        run_dir=str(run),index_sha256=args.index_sha256,target=target,
        bit_sha256=release_identity(spec['profile'])[0],
        fpga_source=release_identity(spec['profile'])[1],
        source_order_policy=order_policy,
        source_order_semantics=('VALIDATED_STALE_SOURCE_MAY_BE_DROPPED_NOT_LOSSLESS'
                                if order_policy == 'drop_stale' else 'STRICT_ORDER_VALIDATION'),
        hdr_allowed=False, runtime_cfg=False, programming_note=args.programming_note,
        bit_identity='OPERATOR_RECEIPT_NOT_SRAM_READBACK',
        algorithms='NONE_BOTH_COLOR',
        topology='ONE_COLD_DUAL_N2_APPLY_SELECT4_START_NO_RUNTIME_CFG',
        timing=('TWO_FIRST_SELECTED_SINK_WINDOWS_10S_EACH_START40S_NOT_PHYSICAL_SCANOUT'
                if spec.get('first_frame_segments') else 'HOST_START_60S_INCLUDES_STARTUP_NOT_60S_PHYSICAL_DISPLAY'),
        selection_sha256=args.kms_selection_sha256,
        **layout_evidence,release='RETAIN_NATIVE_MPP_DRM_NO_HOT_REOPEN')
    return plan,env


def run_owner(args, plan, env):
    if __package__:
        from .peer_algorithm_owner import import_peer
        from .dual_r3_preview import DualPreview
        from .dual_r3_trial import StereoTrial
    else:
        from peer_algorithm_owner import import_peer
        from dual_r3_preview import DualPreview
        from dual_r3_trial import StereoTrial
    cli,_ = import_peer(args.root/'peer')
    from linux.dma_c2h_candidate.receiver import Receiver
    args.run_dir.mkdir(mode=0o700)
    save_new(args.run_dir/'plan.json',plan)
    save_new(args.run_dir/'kms-selection.json',json.loads(args.kms_selection.read_text()))
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    signal.signal(signal.SIGINT,signal.SIG_IGN)
    receiver = preview = trial = None
    report = {}
    try:
        # Constructor retains the existing SDK's failed-open behavior. Once
        # returned, every later path is retained, even failed cold admission.
        receiver = Receiver(plan['target']['device'],nonblocking=True)
        mode = profile_spec(plan['profile'])
        preview_options = (dict(side_by_side=True) if mode.get('side_by_side') else
                           dict(segment_count=2) if plan['profile'] == HDR_SEED1_B_PROFILE else {})
        preview = DualPreview(args.run_dir/'preview',args.root/'gst_perf_observer',env,
            alternating=mode['alternating'],fixed_cam0=mode['fixed_cam0'],**preview_options)
        from algorithm_preview import atomic_json
        preparation = ({'preparation_factory':seed51.cold_preparation}
                       if plan['profile'] == seed51.PROFILE else {})
        if plan['profile'] in (*seed51.LOSSY_PROFILES,HDR_SEED1_B_PROFILE):
            if __package__:
                from .stereo_owned_record_reader import MetadataOwnedRecordReader
                from .stereo_drop_evidence import SourceDropEvidence
            else:
                from stereo_owned_record_reader import MetadataOwnedRecordReader
                from stereo_drop_evidence import SourceDropEvidence
            if plan['profile'] == HDR_SEED1_B_PROFILE:
                if __package__:
                    from .dual_r3_stereo import ColdStereoPreparation
                else:
                    from dual_r3_stereo import ColdStereoPreparation
                factory=lambda receiver,**kwargs:ColdStereoPreparation(receiver,profile=plan['profile'],**kwargs)
            else:
                factory=lambda receiver,**kwargs:seed51.rescue_cold_preparation(receiver,profile=plan['profile'],**kwargs)
            preparation = dict(preparation_factory=factory,
                source_order_policy=plan['source_order_policy'],
                reader_factory=MetadataOwnedRecordReader,
                record_evidence=SourceDropEvidence(args.run_dir/'source-drop-evidence',
                    run_id=args.run_dir.parent.name, capacity=4194304))
        timing_options = (dict(side_by_side=True) if mode.get('side_by_side') else
                          dict(first_frame_segments=True,segment_count=2) if mode.get('first_frame_segments') else {})
        trial = StereoTrial(receiver,preview,alternating=mode['alternating'],fixed_cam0=mode['fixed_cam0'],**timing_options,
            cold_evidence=lambda value:atomic_json(args.run_dir/'cold-diagnostics.json',value),
            progress=lambda value:atomic_json(args.run_dir/'status.json',value), **preparation)
        report = trial.run()
    except BaseException as error:
        report = dict(state='FAULTED_RETAINED',failure=type(error).__name__+': '+str(error)[:512])
    finally:
        try:
            save_new(args.run_dir/'result.json',report)
            print(json.dumps(report),flush=True)
        finally:
            # Never let a logging failure, signal or stdout EOF close the fd.
            cli.hold_retained_owner((receiver,preview,trial),report)


def main(argv=None, *, required_profile=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root','run-dir','kms-selection','display-baseline'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('index-sha256','expected-boot','programming-note','kms-selection-sha256'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--joint-cold-confirmed',action='store_true',required=True)
    parser.add_argument('--execute',action='store_true')
    choices = ((required_profile,) if required_profile is not None else
               (PROFILE,FIXED_CAM0_PROFILE,seed51.PROFILE,*seed51.LOSSY_PROFILES,HDR_SEED1_B_PROFILE))
    if required_profile is not None:
        profile_spec(required_profile)
    parser.add_argument('--profile',choices=choices,default=required_profile or PROFILE)
    parser.add_argument('--source-order-policy', choices=('strict', 'drop_stale'), default='strict',
        help='drop_stale is permitted only by the separate lossy seed51 rescue profile')
    parser.add_argument('--owner',action='store_true',help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    validate_source_order_policy(args.profile, args.source_order_policy)
    if not args.root.is_absolute() or args.root.is_symlink():
        raise ValueError('absolute ordinary runtime root required')
    plan,env = prepare(args)
    if args.owner:
        run_owner(args,plan,env)
    if not args.execute:
        print(json.dumps(plan));return
    launch = args.run_dir.parent/(args.run_dir.name+'-launch')
    launch.mkdir(exist_ok=False)
    save_new(trial_guards(args.expected_boot)[3],plan)
    save_new(launch/'preparation.json',plan)
    owner_args = list(sys.argv[1:] if argv is None else argv)
    owner_args.remove('--execute');owner_args.append('--owner')
    entry = ('launch_seed51_side_by_side.py' if args.profile == seed51.SIDE_BY_SIDE_PROFILE
             else 'launch_seed1_dual_recipe.py' if args.profile == HDR_SEED1_B_PROFILE
             else 'launch_dual_sdr_seed51_rescue_alternating.py' if args.profile == seed51.RESCUE_ALTERNATING_PROFILE
             else 'launch_dual_sdr_seed51_rescue.py' if args.profile == seed51.RESCUE_PROFILE
             else 'launch_dual_sdr_seed51.py' if args.profile == seed51.PROFILE
             else 'launch_dual_r3_alternating.py')
    command = ['/usr/bin/python3','-B',str(args.root/entry),*owner_args]
    with (launch/'owner.log').open('xb') as log:
        child = subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
            start_new_session=True,env=dict(PATH='/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C'))
    receipt = dict(status='OWNER_LAUNCHED_NOT_VIDEO_PASS',pid=child.pid,argv=command,plan=plan)
    save_new(launch/'launch.json',receipt)
    print(json.dumps(receipt))


from fps_hud import activate_dual as _fps_activate
profile_spec=_fps_activate(profile_spec,'dual-sdr-seed51-drop-stale-side-by-side-n2-kms60')

if __name__ == '__main__': main()
