/* Fixed first-trial layout: two 960x540 color views on a 1920x1080 canvas.
 * NV12 compositor scales in software. This is NOT the previous zero-converter
 * single-camera path, a synchronization proof, or the final 1080x2560 mode.
 * Separate fdsrc/MPP branches, bounded raw queues, one DRM owner/sink.
 */
static int r3_dual_pipeline(char *out, size_t size, int offline,
                            unsigned connector, unsigned plane) {
    int fd = -1;
    if (!offline) {
        const char *value=getenv("R3_CAM1_FD"); char *end=NULL;
        if(!value || !*value || strspn(value,"0123456789")!=strlen(value))return 0;
        errno=0; long parsed=strtol(value,&end,10);
        if(errno || *end || parsed<3 || parsed>1048575)return 0;
        fd=(int)parsed;
        int flags=fcntl(fd,F_GETFL);
        if(flags<0 || (flags&O_ACCMODE)==O_WRONLY)return 0;
    }
    const char *alternating=getenv("R3_ALTERNATING");
    if(alternating && strcmp(alternating,"1"))return 0;
    const char *layout=alternating ?
        "input-selector name=r3mix sync-streams=true sync-mode=clock cache-buffers=false ! "
        "capsfilter name=r5convert caps=video/x-raw,format=NV12,width=1920,height=1080 ! " :
        "r5fpscompositor name=r3mix background=black "
        "sink_0::xpos=0 sink_0::ypos=270 sink_0::width=960 sink_0::height=540 "
        "sink_1::xpos=960 sink_1::ypos=270 sink_1::width=960 sink_1::height=540 ! "
        "video/x-raw,format=NV12,width=1920,height=1080,framerate=30/1 ! "
        "capsfilter name=r5convert caps=video/x-raw,format=NV12 ! ";
    int n;
    if(offline) {
        n=snprintf(out,size,"%s identity name=r5sink ! fakesink async=false "
            "videotestsrc %s pattern=red ! video/x-raw,format=NV12,width=1920,height=1080,framerate=30/1 ! "
            "identity name=r5decoder ! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 ! r3mix.sink_0 "
            "videotestsrc %s pattern=blue ! video/x-raw,format=NV12,width=1920,height=1080,framerate=30/1 ! "
            "identity name=r3decoder1 ! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 ! r3mix.sink_1",layout,
            alternating?"is-live=true":"num-buffers=32",alternating?"is-live=true":"num-buffers=32");
    } else {
        n=snprintf(out,size,"%s kmssink name=r5sink driver-name=rockchip sync=false "
            "force-modesetting=true skip-vsync=true connector-id=%u plane-id=%u "
            "fdsrc fd=0 do-timestamp=true ! image/jpeg,framerate=30/1 ! jpegparse ! "
            "mppjpegdec name=r5decoder format=NV12 ! video/x-raw,format=NV12,width=1920,height=1080 ! "
            "queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! r3mix.sink_0 "
            "fdsrc fd=%d do-timestamp=true ! image/jpeg,framerate=30/1 ! jpegparse ! "
            "mppjpegdec name=r3decoder1 format=NV12 ! video/x-raw,format=NV12,width=1920,height=1080 ! "
            "queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! r3mix.sink_1",layout,connector,plane,fd);
    }
    return n>=0 && (size_t)n<size;
}
