"""Seed51 fixed-CAM0 dual preview; explicitly require --source-order-policy drop_stale."""
if __package__:
    from . import dual_sdr_seed51 as release
    from .launch_dual_r3_alternating import main as launch
else:
    import dual_sdr_seed51 as release
    from launch_dual_r3_alternating import main as launch


def main(argv=None):
    return launch(argv, required_profile=release.RESCUE_PROFILE)


if __name__ == '__main__':
    main()
