/* Frame-driven NV12 FPS HUD. No independent timer, new pipeline or DRM owner.
 * Mono counts buffers entering KMS. Alternation counts the selected tagged
 * input. Composition captures the actual used input identities inside the
 * documented aggregate_frames virtual method, never in an external probe.
 * Counters describe video sink input, not physical scanout or HDMI refresh Hz.
 */
#ifndef GST_FPS_HUD_H
#define GST_FPS_HUD_H
#include <gst/gst.h>
#include <gst/video/video.h>
#if R5_DUAL
#include <gst/video/gstvideoaggregator.h>
#endif
#include "fps_hud_core.h"

static struct fps_hud_counter fps_counts[2];
static _Atomic int fps_failed;
static uint64_t fps_outputs;
#if R5_DUAL
static int fps_last_selected=-1;
#else
static uint64_t fps_mono_serial;
#endif
static GstMiniObject *(*fps_writable)(GstMiniObject*);
static gboolean (*fps_info)(GstVideoInfo*,const GstCaps*);
static gboolean (*fps_map)(GstVideoFrame*,const GstVideoInfo*,GstBuffer*,GstMapFlags);
static void (*fps_unmap)(GstVideoFrame*);
static GstCaps *(*fps_caps)(GstPad*);
static void (*fps_unref)(GstMiniObject*);
static int fps_fail(void) { atomic_store(&fps_failed,1);return 0; }
static int fps_error(void) { return atomic_load(&fps_failed); }

#if R5_DUAL
struct fps_pair { uint64_t id[2]; };
static _Atomic uint64_t fps_input_serial[2];
static GQuark fps_input_key[2],fps_pair_key;
static GstElement *fps_mix;
static GstPad *fps_mix_pads[2];
static GstBuffer *(*fps_current)(GstVideoAggregatorPad*);
static void (*fps_qset)(GstMiniObject*,GQuark,gpointer,GDestroyNotify);
static gpointer (*fps_qget)(GstMiniObject*,GQuark);
static GQuark (*fps_quark)(const gchar*);
static gpointer (*fps_parent_class)(gpointer);
static void (*fps_type_query)(GType,GTypeQuery*);
static GType (*fps_type_register)(GType,const gchar*,const GTypeInfo*,GTypeFlags);
static gboolean (*fps_element_register)(GstPlugin*,const gchar*,guint,GType);
static GstElement *(*fps_factory_make)(const gchar*,const gchar*);
static void (*fps_object_unref)(gpointer);
static GstFlowReturn (*fps_parent_aggregate)(GstVideoAggregator*,GstBuffer*);
static GstFlowReturn fps_aggregate(GstVideoAggregator *vagg,GstBuffer *output) {
    if(fps_error() || (void*)vagg!=(void*)fps_mix || !output)return GST_FLOW_ERROR;
    struct fps_pair pair={{0,0}};
    for(unsigned i=0;i<2;i++) {
        GstBuffer *input=fps_current((GstVideoAggregatorPad*)fps_mix_pads[i]);
        if(input) {
            pair.id[i]=(uint64_t)(uintptr_t)fps_qget((GstMiniObject*)input,fps_input_key[i]);
            if(!pair.id[i]) { fps_fail();return GST_FLOW_ERROR; }
        }
    }
    if(!fps_parent_aggregate) { fps_fail();return GST_FLOW_ERROR; }
    GstFlowReturn flow=fps_parent_aggregate(vagg,output);
    if(flow!=GST_FLOW_OK)return flow;
    struct fps_pair *copy=malloc(sizeof *copy);
    if(!copy) { fps_fail();return GST_FLOW_ERROR; }
    *copy=pair;fps_qset((GstMiniObject*)output,fps_pair_key,copy,free);
    return flow;
}
static void fps_class_init(gpointer klass,gpointer data) {
    (void)data;
    GstVideoAggregatorClass *parent=fps_parent_class(klass);
    fps_parent_aggregate=parent->aggregate_frames;
    ((GstVideoAggregatorClass*)klass)->aggregate_frames=fps_aggregate;
}
static int fps_register_compositor(void) {
    GstElement *original=fps_factory_make("compositor",NULL);
    if(!original)return fps_fail();
    GType parent=G_TYPE_FROM_INSTANCE(original);GTypeQuery q={0};fps_type_query(parent,&q);
    fps_object_unref(original);
    if(q.class_size<sizeof(GstVideoAggregatorClass) || q.class_size>UINT16_MAX ||
       q.instance_size<sizeof(GstVideoAggregator) || q.instance_size>UINT16_MAX)return fps_fail();
    GTypeInfo info={.class_size=(guint16)q.class_size,.class_init=fps_class_init,
                   .instance_size=(guint16)q.instance_size};
    GType type=fps_type_register(parent,"R5FrameFpsCompositor",&info,0);
    return type && fps_element_register(NULL,"r5fpscompositor",0,type)?1:fps_fail();
}
static int fps_tag_input(void *pad,void *opaque,void *data) {
    (void)pad;
    if(fps_error())return GST_PAD_PROBE_DROP;
    unsigned camera=(unsigned)(uintptr_t)data;
    if(camera>1) { fps_fail();return GST_PAD_PROBE_DROP; }
    GstBuffer *buffer=GST_PAD_PROBE_INFO_BUFFER((GstPadProbeInfo*)opaque);
    uint64_t id=atomic_fetch_add(&fps_input_serial[camera],1)+1;
    if(camera>1 || !buffer || !id || id>UINTPTR_MAX) { fps_fail();return GST_PAD_PROBE_DROP; }
    fps_qset((GstMiniObject*)buffer,fps_input_key[camera],(void*)(uintptr_t)id,NULL);
    return GST_PAD_PROBE_OK;
}
#endif

static int fps_symbols(void *lib) {
    void *video=dlopen("libgstvideo-1.0.so.0",RTLD_NOW|RTLD_GLOBAL);
    if(!video)return 0;
#define FPS_SYM(variable,handle,name) do { void *symbol=dlsym(handle,name); \
    memcpy(&variable,&symbol,sizeof variable);if(!variable)return 0; } while(0)
    FPS_SYM(fps_writable,lib,"gst_mini_object_make_writable");
    FPS_SYM(fps_info,video,"gst_video_info_from_caps");
    FPS_SYM(fps_map,video,"gst_video_frame_map");
    FPS_SYM(fps_unmap,video,"gst_video_frame_unmap");
    FPS_SYM(fps_caps,lib,"gst_pad_get_current_caps");
    FPS_SYM(fps_unref,lib,"gst_mini_object_unref");
#if R5_DUAL
    FPS_SYM(fps_current,video,"gst_video_aggregator_pad_get_current_buffer");
    FPS_SYM(fps_qset,lib,"gst_mini_object_set_qdata");
    FPS_SYM(fps_qget,lib,"gst_mini_object_get_qdata");
    FPS_SYM(fps_quark,lib,"g_quark_from_static_string");
    FPS_SYM(fps_parent_class,lib,"g_type_class_peek_parent");
    FPS_SYM(fps_type_query,lib,"g_type_query");
    FPS_SYM(fps_type_register,lib,"g_type_register_static");
    FPS_SYM(fps_element_register,lib,"gst_element_register");
    FPS_SYM(fps_factory_make,lib,"gst_element_factory_make");
    FPS_SYM(fps_object_unref,lib,"gst_object_unref");
    fps_input_key[0]=fps_quark("r5-fps-cam0-input-v1");
    fps_input_key[1]=fps_quark("r5-fps-cam1-input-v1");
    fps_pair_key=fps_quark("r5-fps-composed-inputs-v1");
    if(!fps_input_key[0] || !fps_input_key[1] || !fps_pair_key)return 0;
#endif
#undef FPS_SYM
    return 1;
}
static int fps_plane(const GstVideoFrame *f,unsigned p,unsigned rows,size_t *span) {
    uintptr_t address=(uintptr_t)GST_VIDEO_FRAME_PLANE_DATA(f,p);
    int stride=GST_VIDEO_FRAME_PLANE_STRIDE(f,p);
    if(!address || stride<1920)return 0;
    size_t needed=(size_t)(rows-1)*(unsigned)stride+1920;
    for(unsigned i=0;i<GST_VIDEO_MAX_PLANES;i++) {
        uintptr_t base=(uintptr_t)f->map[i].data;size_t size=f->map[i].size;
        if(base && address>=base && address-base<=size && needed<=size-(address-base)) {
            *span=needed;return 1;
        }
    }
    return 0;
}
static int fps_hud_probe(void *pad,void *opaque,void *unused) {
    (void)unused;
    if(fps_error())return GST_PAD_PROBE_DROP;
    GstPadProbeInfo *probe=opaque;GstBuffer *buffer=GST_PAD_PROBE_INFO_BUFFER(probe);
    if(!buffer) { fps_fail();return GST_PAD_PROBE_DROP; }
    uint64_t id[2]={0,0};unsigned visible=1;
#if R5_DUAL
    if(r3_alternating) {
        const struct r3_identity *tag=r3_get_qdata(buffer,r3_identity_key);
        if(!tag || tag->camera>1) { fps_fail();return GST_PAD_PROBE_DROP; }
        unsigned camera=tag->camera;id[camera]=tag->serial;visible=1u<<camera;
        if(fps_last_selected!=(int)camera) { fps_hud_reset(&fps_counts[camera]);fps_last_selected=(int)camera; }
    } else {
        const struct fps_pair *pair=fps_qget((GstMiniObject*)buffer,fps_pair_key);
        if(!pair) { fps_fail();return GST_PAD_PROBE_DROP; }
        id[0]=pair->id[0];id[1]=pair->id[1];visible=3;
    }
#else
    if(++fps_mono_serial==0) { fps_fail();return GST_PAD_PROBE_DROP; }
    id[0]=fps_mono_serial;
#endif
    GstCaps *caps=fps_caps(pad);GstVideoInfo info;
    int valid=caps && fps_info(&info,caps);
    if(caps)fps_unref((GstMiniObject*)caps);
    if(!valid || GST_VIDEO_INFO_FORMAT(&info)!=GST_VIDEO_FORMAT_NV12 ||
       GST_VIDEO_INFO_WIDTH(&info)!=1920 || GST_VIDEO_INFO_HEIGHT(&info)!=1080) {
        fps_fail();return GST_PAD_PROBE_DROP;
    }
    GstBuffer *writable=(GstBuffer*)fps_writable((GstMiniObject*)buffer);
    if(!writable) { fps_fail();return GST_PAD_PROBE_DROP; }
    GST_PAD_PROBE_INFO_DATA(probe)=writable;
    GstVideoFrame frame;
    if(!fps_map(&frame,&info,writable,GST_MAP_WRITE)) { fps_fail();return GST_PAD_PROBE_DROP; }
    if(GST_VIDEO_FRAME_FORMAT(&frame)!=GST_VIDEO_FORMAT_NV12 ||
       GST_VIDEO_FRAME_WIDTH(&frame)!=1920 || GST_VIDEO_FRAME_HEIGHT(&frame)!=1080) {
        fps_unmap(&frame);fps_fail();return GST_PAD_PROBE_DROP;
    }
    size_t ys=0,uvs=0;
    int valid_planes=fps_plane(&frame,0,1080,&ys)&&fps_plane(&frame,1,540,&uvs);
    uintptr_t y=(uintptr_t)GST_VIDEO_FRAME_PLANE_DATA(&frame,0),uv=(uintptr_t)GST_VIDEO_FRAME_PLANE_DATA(&frame,1);
    if(!valid_planes || !(y<uv?uv-y>=ys:y-uv>=uvs)) {
        fps_unmap(&frame);fps_fail();return GST_PAD_PROBE_DROP;
    }
    struct fps_hud_surface surface={GST_VIDEO_FRAME_PLANE_DATA(&frame,0),GST_VIDEO_FRAME_PLANE_DATA(&frame,1),
        GST_VIDEO_FRAME_PLANE_STRIDE(&frame,0),GST_VIDEO_FRAME_PLANE_STRIDE(&frame,1),1920,1080,ys,uvs};
    uint64_t stamp=now_ns();char text[48];
    for(unsigned camera=0;camera<2;camera++)if(visible&(1u<<camera)) {
        unsigned x=16,yy=16;
#if R5_DUAL
        if(!r3_alternating) { x+=camera*960;yy=282; }
#endif
        if(!fps_hud_observe(&fps_counts[camera],stamp,id[camera],id[camera]!=0) ||
           !fps_hud_format(text,sizeof text,camera,&fps_counts[camera]) ||
           !fps_hud_draw(&surface,x,yy,text)) {
            fps_unmap(&frame);fps_fail();return GST_PAD_PROBE_DROP;
        }
    }
    fps_unmap(&frame);
    char line[256];
    snprintf(line,sizeof line,"R5FPS1 F %llu %llu %u %llu %u %u %llu %llu %u %u %llu\n",
        (unsigned long long)stamp,(unsigned long long)++fps_outputs,visible,
        (unsigned long long)id[0],fps_counts[0].valid,fps_counts[0].fps_tenths,(unsigned long long)fps_counts[0].total,
        (unsigned long long)id[1],fps_counts[1].valid,fps_counts[1].fps_tenths,(unsigned long long)fps_counts[1].total);
    emit(line);return GST_PAD_PROBE_OK;
}
static int fps_list_probe(void *pad,void *info,void *data) {
    (void)pad;(void)info;(void)data;fps_fail();return GST_PAD_PROBE_DROP;
}
#endif
