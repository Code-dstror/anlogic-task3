"""Seed51 DUAL SDR: CAM0 left and CAM1 right, explicit lossy preview, one60s trial."""
if __package__:
    from . import dual_sdr_seed51 as release
    from .launch_dual_r3_alternating import main as launch
else:
    import dual_sdr_seed51 as release
    from launch_dual_r3_alternating import main as launch


def main(argv=None):
    return launch(argv, required_profile=release.SIDE_BY_SIDE_PROFILE)


if __name__ == '__main__':
    main()
