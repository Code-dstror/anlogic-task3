/* Optional observation, using public GStreamer 1.22 / GLib APIs only.
 * No Gst struct access, buffer map/ref changes, or native callback work.
 * pad-push pre/post bounds the synchronous downstream call, NOT scanout,
 * render alone, GPU completion or a SOURCE-to-buffer identity mapping.
 */
#ifndef R5_DISPLAY_OBSERVE_H
#define R5_DISPLAY_OBSERVE_H
typedef uintptr_t R5Type;
/* Public GLib GTypeQuery; queried parent sizes avoid Gst object layouts. */
struct r5_type_query { R5Type type; const char *name; unsigned class_size, instance_size; };
static R5Type (*r5_tracer_type)(void);
static void (*r5_query_type)(R5Type, struct r5_type_query *);
static R5Type (*r5_register_type)(R5Type, const char *, unsigned, void (*)(void *, void *),
                                unsigned, void (*)(void *, void *), unsigned);
static void *(*r5_new_object)(R5Type, const char *, ...);
static void (*r5_register_hook)(void *, const char *, void (*)(void));
static unsigned (*r5_caps_size)(const void *);
static int (*r5_caps_fixed)(const void *);
static const void *(*r5_caps_structure)(const void *, unsigned);
static const void *(*r5_caps_features)(const void *, unsigned);
static const char *(*r5_structure_string)(const void *, const char *);
static int (*r5_structure_int)(const void *, const char *, int *);
static unsigned (*r5_features_size)(const void *);
static int (*r5_features_any)(const void *);
static const char *(*r5_feature_nth)(const void *, unsigned);
static int r5_observe_symbols(void *lib) {
#define R5_SYMBOL(variable, name) do { \
    void *symbol=dlsym(lib,name); \
    _Static_assert(sizeof variable==sizeof symbol,"POSIX function pointer width"); \
    memcpy(&variable,&symbol,sizeof variable); \
    if (!variable) { emit("ERROR: display observation public symbol unavailable\n"); return 0; } \
} while(0)
    R5_SYMBOL(r5_tracer_type,"gst_tracer_get_type");
    R5_SYMBOL(r5_query_type,"g_type_query");
    R5_SYMBOL(r5_register_type,"g_type_register_static_simple");
    R5_SYMBOL(r5_new_object,"g_object_new");
    R5_SYMBOL(r5_register_hook,"gst_tracing_register_hook");
    R5_SYMBOL(r5_caps_size,"gst_caps_get_size");
    R5_SYMBOL(r5_caps_fixed,"gst_caps_is_fixed");
    R5_SYMBOL(r5_caps_structure,"gst_caps_get_structure");
    R5_SYMBOL(r5_caps_features,"gst_caps_get_features");
    R5_SYMBOL(r5_structure_string,"gst_structure_get_string");
    R5_SYMBOL(r5_structure_int,"gst_structure_get_int");
    R5_SYMBOL(r5_features_size,"gst_caps_features_get_size");
    R5_SYMBOL(r5_features_any,"gst_caps_features_is_any");
    R5_SYMBOL(r5_feature_nth,"gst_caps_features_get_nth");
#undef R5_SYMBOL
    return 1;
}
struct r5_call { uint64_t seq, begin, end; int flow; };
static struct r5_call r5_calls[CAP];
static _Atomic unsigned r5_head, r5_tail;
static atomic_flag r5_call_busy=ATOMIC_FLAG_INIT;
static _Atomic uint64_t r5_pres, r5_posts, r5_drops, r5_errors;
static _Atomic(void *) r5_target;
static _Thread_local struct { uint64_t seq, begin; unsigned depth; } r5_current;
static void r5_push_pre(void *self, uint64_t stamp, void *pad, void *buffer) {
    (void)self; (void)stamp; (void)buffer;
    if (pad!=atomic_load_explicit(&r5_target,memory_order_acquire)) return;
    if (r5_current.depth++) { atomic_fetch_add(&r5_errors,1); return; }
    r5_current.seq=atomic_fetch_add(&r5_pres,1)+1;
    r5_current.begin=now_ns();
}
static void r5_push_post(void *self, uint64_t stamp, void *pad, int flow) {
    (void)self; (void)stamp;
    if (pad!=atomic_load_explicit(&r5_target,memory_order_acquire)) return;
    if (!r5_current.depth) { atomic_fetch_add(&r5_errors,1); return; }
    if (--r5_current.depth) return;
    uint64_t end=now_ns();
    atomic_fetch_add(&r5_posts,1);
    if (flow || end<r5_current.begin) atomic_fetch_add(&r5_errors,1);
    if (atomic_flag_test_and_set_explicit(&r5_call_busy,memory_order_acquire)) {
        atomic_fetch_add(&r5_drops,1); return;
    }
    unsigned h=atomic_load_explicit(&r5_head,memory_order_relaxed), next=(h+1)%CAP;
    if (next==atomic_load_explicit(&r5_tail,memory_order_acquire)) atomic_fetch_add(&r5_drops,1);
    else {
        r5_calls[h]=(struct r5_call){r5_current.seq,r5_current.begin,end,flow};
        atomic_store_explicit(&r5_head,next,memory_order_release);
    }
    atomic_flag_clear_explicit(&r5_call_busy,memory_order_release);
}
static int r5_observe_start(void *pad) {
    if(!atomic_is_lock_free(&r5_pres) || !atomic_is_lock_free(&r5_target) || !atomic_is_lock_free(&r5_head)) return 0;
    struct r5_type_query q={0}; R5Type parent=r5_tracer_type();
    r5_query_type(parent,&q);
    if (!q.class_size || !q.instance_size || q.class_size>65535 || q.instance_size>65535) return 0;
    R5Type type=r5_register_type(parent,"R5DisplayCallTracer",q.class_size,NULL,q.instance_size,NULL,0);
    if (!type) return 0;
    void *tracer=r5_new_object(type,(const char *)NULL);
    if (!tracer) return 0;
    atomic_store_explicit(&r5_target,pad,memory_order_release);
    r5_register_hook(tracer,"pad-push-pre",(void (*)(void))r5_push_pre);
    r5_register_hook(tracer,"pad-push-post",(void (*)(void))r5_push_post);
    /* Keep tracer and pipeline references throughout the retained session. */
    emit("R5R1 S CONVERTER_SRC_SYNCHRONOUS_PUSH_NOT_RENDER_OR_SCANOUT\n");
    return 1;
}
static uint64_t r5_observe_invalid(void) {
    uint64_t missing=atomic_load(&streams[4].total)>0 && atomic_load(&r5_pres)==0;
    return atomic_load(&r5_drops)+atomic_load(&r5_errors)+missing;
}
static void r5_observe_drain(void) {
    char line[192]; unsigned t=atomic_load_explicit(&r5_tail,memory_order_relaxed);
    unsigned h=atomic_load_explicit(&r5_head,memory_order_acquire);
    while(t!=h) {
        struct r5_call c=r5_calls[t];
#if R5_H265_TAIL
        r5_tail_raw_push_return(c.seq,c.flow);
#endif
        snprintf(line,sizeof line,"R5R1 E %llu %llu %llu %d\n",
            (unsigned long long)c.seq,(unsigned long long)c.begin,(unsigned long long)c.end,c.flow);
        emit(line); t=(t+1)%CAP; atomic_store_explicit(&r5_tail,t,memory_order_release);
    }
}
static void r5_observe_heartbeat(uint64_t stamp) {
    char line[192];
    snprintf(line,sizeof line,"R5R1 H %llu %llu %llu %llu %llu\n",
        (unsigned long long)stamp,(unsigned long long)atomic_load(&r5_pres),
        (unsigned long long)atomic_load(&r5_posts),(unsigned long long)atomic_load(&r5_drops),
        (unsigned long long)atomic_load(&r5_errors)); emit(line);
}
/* Bound complete scalar fields; absent, oversized or non-ASCII stays null.
 * Never report a truncated format/feature prefix as a known value.
 */
static int r5_json_string(char *out, size_t cap, const char *value, size_t limit) {
    size_t n=value ? strnlen(value,limit+1) : 0;
    if (!value || n>limit || cap<2*n+3) { snprintf(out,cap,"null"); return 0; }
    size_t k=0; out[k++]='"';
    for(size_t i=0;i<n;i++) {
        unsigned char c=(unsigned char)value[i];
        if(c<32 || c>126) { snprintf(out,cap,"null"); return 0; }
        if(c=='"' || c=='\\') out[k++]='\\';
        out[k++]=(char)c;
    }
    out[k++]='"';out[k]=0;return 1;
}
static void r5_observe_caps(unsigned channel, const void *caps) {
    unsigned count=caps?r5_caps_size(caps):0;
    int fixed=caps && r5_caps_fixed(caps), width=0,height=0;
    const void *s=count==1 && fixed?r5_caps_structure(caps,0):NULL;
    const void *f=s?r5_caps_features(caps,0):NULL;
    char fmt[132],drm[260],features[1800]="null",line[2600];
    r5_json_string(fmt,sizeof fmt,s?r5_structure_string(s,"format"):NULL,64);
    r5_json_string(drm,sizeof drm,s?r5_structure_string(s,"drm-format"):NULL,128);
    int have_width=s && r5_structure_int(s,"width",&width), have_height=s && r5_structure_int(s,"height",&height);
    unsigned nf=f?r5_features_size(f):0;int any=f && r5_features_any(f), known=f && !any && nf<=8;
    if(known) {
        size_t at=0;features[at++]='[';
        for(unsigned i=0;i<nf;i++) {
            char item[200];
            if(!r5_json_string(item,sizeof item,r5_feature_nth(f,i),96)) { known=0;break; }
            if(i)features[at++]=',';
            size_t n=strlen(item);memcpy(features+at,item,n);at+=n;
        }
        features[at++]=']';features[at]=0;
    }
    if(!known)snprintf(features,sizeof features,"null");
    char w[32]="null",h[32]="null";
    if(have_width)snprintf(w,sizeof w,"%d",width);
    if(have_height)snprintf(h,sizeof h,"%d",height);
    snprintf(line,sizeof line,"R5F1 {\"pad\":%u,\"host_monotonic_ns\":%llu,\"structures\":%u,\"fixed\":%s,\"format\":%s,\"width\":%s,\"height\":%s,\"features\":%s,\"features_total\":%u,\"features_any\":%s,\"features_complete\":%s,\"drm_format\":%s,\"stride\":null,\"offsets\":null,\"modifier\":null}\n",
        channel,(unsigned long long)now_ns(),count,fixed?"true":"false",fmt,w,h,features,nf,any?"true":"false",known?"true":"false",drm);
    emit(line);
}
#endif
