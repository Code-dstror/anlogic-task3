/* Opt-in, bounded Linux KMS timing interposer. No device is opened by this code.
 * Build with public libdrm headers, -shared -fPIC -std=c11 -O2 -ldl -pthread.
 * Set absolute R5_KMS_TRACE_PATH and R5_KMS_TRACE_EXECUTABLE (real /proc/self/exe).
 * Binary ABI v1: little-endian, 128-byte header and 128-byte records; see parser.
 * Records publish only after return; live copies can contain uncommitted slots.
 */
#define _GNU_SOURCE
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#define TRACE_BYTES (8u * 1024u * 1024u)
enum { SET_PLANE=1, PAGE_FLIP, WAIT_VBLANK, HANDLE_EVENT, POLL_WAIT,
       VBLANK_CALLBACK, FLIP_CALLBACK, FLIP2_CALLBACK, SEQUENCE_CALLBACK };
struct header {
    char magic[8];
    uint32_t version, header_bytes, record_bytes, capacity, owner_pid, flags;
    _Atomic uint64_t next, overflow, clock_errors;
    uint64_t initialized_ns;
    uint8_t reserved[64];
};
struct record {
    _Atomic uint32_t committed;
    uint32_t kind;
    uint64_t id, begin_ns, end_ns;
    uint32_t tid;
    int32_t fd;
    uint64_t parent;
    uint32_t crtc, plane, fb, flags;
    int32_t rc, error;
    uint32_t depth, version;
    uint64_t sequence, event_sec, event_usec, user_data, aux0, aux1;
};
_Static_assert(__BYTE_ORDER__==__ORDER_LITTLE_ENDIAN__, "little-endian trace ABI");
_Static_assert(sizeof(struct header)==128, "header ABI");
_Static_assert(sizeof(struct record)==128, "record ABI");
_Static_assert(ATOMIC_LLONG_LOCK_FREE==2, "64-bit atomics must be lock-free");
static struct header *trace;
static _Thread_local uint32_t thread_id, depth;
static _Thread_local uint64_t parent;
/* poll fd is a thread-local association only, not the GstPoll set contents.
 * caller PC plus a saved /proc/<pid>/maps identifies the actual call site. */
static _Thread_local int drm_thread, drm_fd=-1;
static _Thread_local const drmEventContext *event_context;

static uint64_t now_ns(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) {
        if (trace) atomic_fetch_add_explicit(&trace->clock_errors, 1, memory_order_relaxed);
        return 0;
    }
    return (uint64_t)t.tv_sec*1000000000u+(uint64_t)t.tv_nsec;
}
static void child_disable(void) { trace=NULL; }
static void init_failure(void) {
    static const char message[]="ERROR: KMS sync trace initialization failed; observation unavailable\n";
    ssize_t ignored=write(STDERR_FILENO, message, sizeof(message)-1);
    (void)ignored;
}
__attribute__((constructor)) static void initialize(void) {
    int saved=errno;
    const char *path=getenv("R5_KMS_TRACE_PATH");
    const char *executable=getenv("R5_KMS_TRACE_EXECUTABLE");
    char self[PATH_MAX];
    if (!path) { errno=saved; return; }
    ssize_t n=readlink("/proc/self/exe", self, sizeof(self)-1);
    if (!executable || executable[0]!='/' || n<0) goto failed;
    self[n]='\0';
    /* The scanner inherits LD_PRELOAD; only the explicitly selected ELF owns a file. */
    if (strcmp(self, executable)) { errno=saved; return; }
    if (path[0]!='/') goto failed;
    int fd=open(path, O_CREAT|O_EXCL|O_RDWR|O_CLOEXEC|O_NOFOLLOW, 0600);
    if (fd<0) goto failed;
    struct stat st;
    if (fstat(fd,&st) || !S_ISREG(st.st_mode) || fchmod(fd,0600) ||
        ftruncate(fd,TRACE_BYTES)) { close(fd); goto failed; }
    void *map=mmap(NULL,TRACE_BYTES,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    close(fd);
    if (map==MAP_FAILED) goto failed;
    if (pthread_atfork(NULL,NULL,child_disable)) { munmap(map,TRACE_BYTES); goto failed; }
    trace=map;
    memcpy(trace->magic,"R5KMS01\0",8);
    trace->version=1; trace->header_bytes=sizeof(*trace);
    trace->record_bytes=sizeof(struct record);
    trace->capacity=(TRACE_BYTES-sizeof(*trace))/sizeof(struct record);
    trace->owner_pid=(uint32_t)getpid();
    trace->initialized_ns=now_ns();
    errno=saved; return;
failed:
    init_failure(); errno=saved;
}
/* dlsym(RTLD_NEXT) cannot see a provider loaded RTLD_LOCAL by the observer.
 * NOLOAD acquires an already-loaded public SONAME; it never loads a new library. */
static void *resolve(_Atomic(void *) *cache, const char *symbol, const char *soname) {
    void *p=atomic_load_explicit(cache,memory_order_acquire);
    if (p) return p;
    int saved=errno;
    p=dlsym(RTLD_NEXT,symbol);
    if (!p) {
        void *handle=dlopen(soname,RTLD_NOW|RTLD_NOLOAD);
        if (handle) { p=dlsym(handle,symbol); dlclose(handle); }
    }
    if (p) atomic_store_explicit(cache,p,memory_order_release);
    errno=saved;
    return p;
}
static struct record *begin_record(uint32_t kind, int fd, int mark_drm) {
    if (mark_drm) { drm_thread=1; drm_fd=fd; }
    if (!trace) return NULL;
    uint64_t index=atomic_fetch_add_explicit(&trace->next,1,memory_order_relaxed);
    if (index>=trace->capacity) {
        atomic_fetch_add_explicit(&trace->overflow,1,memory_order_relaxed); return NULL;
    }
    struct record *r=(struct record *)(trace+1)+index;
    if (!thread_id) thread_id=(uint32_t)syscall(SYS_gettid);
    r->kind=kind; r->id=index+1; r->tid=thread_id; r->fd=fd;
    r->parent=parent; r->depth=depth; r->begin_ns=now_ns();
    parent=r->id; depth++;
    return r;
}
static void end_record(struct record *r, int rc, int error) {
    if (r) {
        r->end_ns=now_ns(); r->rc=rc; r->error=error;
        parent=r->parent; depth=r->depth;
        atomic_store_explicit(&r->committed,1,memory_order_release);
    }
    errno=error;
}
#define REAL(name, soname) static _Atomic(void *) cache; \
    __typeof__(&name) real=(__typeof__(&name))resolve(&cache,#name,soname)
#define CALL_OR_ERROR(call) (real ? (call) : (errno=ENOSYS,-1))
int drmModeSetPlane(int fd,uint32_t plane,uint32_t crtc,uint32_t fb,uint32_t flags,
                    int32_t x,int32_t y,uint32_t w,uint32_t h,
                    uint32_t sx,uint32_t sy,uint32_t sw,uint32_t sh) {
    int saved=errno; REAL(drmModeSetPlane,"libdrm.so.2");
    struct record *r=begin_record(SET_PLANE,fd,1);
    if (r) { r->plane=plane; r->crtc=crtc; r->fb=fb; r->flags=flags; }
    errno=saved;
    int rc=CALL_OR_ERROR(real(fd,plane,crtc,fb,flags,x,y,w,h,sx,sy,sw,sh));
    int error=errno; end_record(r,rc,error); return rc;
}
int drmModePageFlip(int fd,uint32_t crtc,uint32_t fb,uint32_t flags,void *data) {
    int saved=errno; REAL(drmModePageFlip,"libdrm.so.2");
    struct record *r=begin_record(PAGE_FLIP,fd,1);
    if (r) { r->crtc=crtc; r->fb=fb; r->flags=flags; r->user_data=(uintptr_t)data; }
    errno=saved;
    int rc=CALL_OR_ERROR(real(fd,crtc,fb,flags,data));
    int error=errno; end_record(r,rc,error); return rc;
}
int drmWaitVBlank(int fd,drmVBlankPtr vbl) {
    int saved=errno; REAL(drmWaitVBlank,"libdrm.so.2");
    struct record *r=begin_record(WAIT_VBLANK,fd,1);
    if (r && vbl) {
        r->flags=(uint32_t)vbl->request.type; r->sequence=vbl->request.sequence;
        r->user_data=vbl->request.signal;
        r->crtc=(r->flags&DRM_VBLANK_HIGH_CRTC_MASK)>>DRM_VBLANK_HIGH_CRTC_SHIFT;
        if (!r->crtc && (r->flags&DRM_VBLANK_SECONDARY)) r->crtc=1;
    }
    errno=saved;
    int rc=CALL_OR_ERROR(real(fd,vbl));
    int error=errno;
    if (r && vbl && !rc) { r->aux0=vbl->reply.sequence;
        r->event_sec=(uint64_t)vbl->reply.tval_sec; r->event_usec=(uint64_t)vbl->reply.tval_usec; }
    end_record(r,rc,error); return rc;
}
static struct record *callback_begin(uint32_t kind,int fd,uint64_t seq,
                                    uint64_t sec,uint64_t usec,uint64_t data) {
    struct record *r=begin_record(kind,fd,0);
    if (r) { r->sequence=seq; r->event_sec=sec; r->event_usec=usec; r->user_data=data; }
    return r;
}
#define CALLBACK(name, field, kind) \
static void name(int fd,unsigned seq,unsigned sec,unsigned usec,void *data) { \
    int saved=errno; const drmEventContext *ctx=event_context; \
    struct record *r=callback_begin(kind,fd,seq,sec,usec,(uintptr_t)data); \
    errno=saved; ctx->field(fd,seq,sec,usec,data); \
    int error=errno; end_record(r,0,error); \
}
CALLBACK(vblank_callback,vblank_handler,VBLANK_CALLBACK)
CALLBACK(flip_callback,page_flip_handler,FLIP_CALLBACK)
static void flip2_callback(int fd,unsigned seq,unsigned sec,unsigned usec,unsigned crtc,void *data) {
    int saved=errno; const drmEventContext *ctx=event_context;
    struct record *r=callback_begin(FLIP2_CALLBACK,fd,seq,sec,usec,(uintptr_t)data);
    if (r) r->crtc=crtc;
    errno=saved; ctx->page_flip_handler2(fd,seq,sec,usec,crtc,data);
    int error=errno; end_record(r,0,error);
}
static void sequence_callback(int fd,uint64_t seq,uint64_t ns,uint64_t data) {
    int saved=errno; const drmEventContext *ctx=event_context;
    struct record *r=callback_begin(SEQUENCE_CALLBACK,fd,seq,0,0,data);
    if (r) r->aux0=ns;
    errno=saved; ctx->sequence_handler(fd,seq,ns,data);
    int error=errno; end_record(r,0,error);
}
int drmHandleEvent(int fd,drmEventContextPtr ctx) {
    int saved=errno; REAL(drmHandleEvent,"libdrm.so.2");
    struct record *r=begin_record(HANDLE_EVENT,fd,1);
    drmEventContext copy={0}, original={0};
    const drmEventContext *previous=event_context;
    drmEventContextPtr forwarded=ctx;
    if (r) r->version=ctx ? (uint32_t)ctx->version : 0;
    if (ctx && ctx->version>=1 && ctx->version<=4) {
        /* Never read a field introduced after the caller's context version. */
        copy.version=ctx->version; original.version=ctx->version;
        original.vblank_handler=ctx->vblank_handler;
        copy.vblank_handler=original.vblank_handler ? vblank_callback : NULL;
        if (ctx->version>=2) { original.page_flip_handler=ctx->page_flip_handler;
            copy.page_flip_handler=original.page_flip_handler ? flip_callback : NULL; }
        if (ctx->version>=3) { original.page_flip_handler2=ctx->page_flip_handler2;
            copy.page_flip_handler2=original.page_flip_handler2 ? flip2_callback : NULL; }
        if (ctx->version>=4) { original.sequence_handler=ctx->sequence_handler;
            copy.sequence_handler=original.sequence_handler ? sequence_callback : NULL; }
        event_context=&original; forwarded=&copy;
    } else if (r) r->flags=1; /* Unknown ABI: transparent pass-through, explicit callback gap. */
    errno=saved;
    int rc=CALL_OR_ERROR(real(fd,forwarded));
    int error=errno; event_context=previous;
    end_record(r,rc,error); return rc;
}
/* Public GLib/GStreamer ABI: gint gst_poll_wait(GstPoll *, GstClockTime).
 * Opaque pointer avoids requiring GStreamer headers for this observational shim. */
int gst_poll_wait(void *set,uint64_t timeout) {
    int saved=errno; REAL(gst_poll_wait,"libgstreamer-1.0.so.0");
    struct record *r=drm_thread ? begin_record(POLL_WAIT,drm_fd,0) : NULL;
    if (r) { r->user_data=(uintptr_t)set; r->aux0=timeout;
        r->aux1=(uintptr_t)__builtin_return_address(0); }
    errno=saved;
    int rc=CALL_OR_ERROR(real(set,timeout));
    int error=errno; end_record(r,rc,error); return rc;
}
