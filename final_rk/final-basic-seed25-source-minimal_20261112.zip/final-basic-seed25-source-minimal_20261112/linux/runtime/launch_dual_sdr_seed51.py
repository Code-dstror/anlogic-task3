"""Seed51 only: both eyes color/N2, HDMI fixed CAM0, at most 60s; HDR disabled."""
if __package__:
    from . import dual_sdr_seed51 as release
    from .launch_dual_r3_alternating import main as launch
else:
    import dual_sdr_seed51 as release
    from launch_dual_r3_alternating import main as launch


def main(argv=None):
    return launch(argv, required_profile=release.PROFILE)


if __name__ == '__main__':
    main()
