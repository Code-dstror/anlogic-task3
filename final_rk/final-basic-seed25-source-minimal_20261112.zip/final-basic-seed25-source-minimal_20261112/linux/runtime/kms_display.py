"""Read-only admission of a reviewed, boot-bound KMS selection; no modeset.

The coordinator captures the existing peer display-info query and reviews the
connector/CRTC route before preparing this receipt. This is not a replacement
DRM discovery platform. Hardware buffer import and scanout remain trial results.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

KMS_PLUGIN = '/usr/lib/aarch64-linux-gnu/gstreamer-1.0/libgstkms.so'
KMS_SHA256 = '6e980e68bb7d93d89e179889a2b4eae1e512c92d0e858e76b8280a94d59b106d'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def validate_selection(spec, boot):
    require(spec.get('format') == 'CALFIX_KMS_SELECTION_V1' and spec.get('boot_id') == boot,
            'KMS selection format/boot differs')
    for key in ('connector_id', 'plane_id', 'crtc_id'):
        require(type(spec.get(key)) is int and 0 < spec[key] < 2**31, 'invalid KMS '+key)
    require(type(spec.get('crtc_index')) is int and 0 <= spec['crtc_index'] < 32,
            'invalid KMS CRTC resource index')
    require(spec.get('route_reviewed') is True and spec.get('driver_name') == 'rockchip',
            'explicit reviewed rockchip connector/CRTC route required')
    require(re.fullmatch(r'/sys/class/drm/card[0-9]+-HDMI-A-[0-9]+', spec.get('connector_sysfs', '')),
            'explicit HDMI connector sysfs required')
    query = spec['query']
    require(query.get('status') == 'QUERY_COMPLETED' and query.get('helper_reaped') is True
            and query.get('returncode') == 0 and query.get('driver_name') == 'rockchip'
            and query.get('command', [])[1:] == ['-M', 'rockchip', '-c', '-p'],
            'complete read-only peer modetest query required')
    text = query['stdout']
    require(len(text.encode()) <= 1024*1024 and '\ufffd' not in text and
            hashlib.sha256(text.encode()).hexdigest() == query['stdout_sha256'],
            'modetest output differs or is incomplete')
    require(all(text.count(x+'\n') == 1 for x in ('Connectors:', 'CRTCs:', 'Planes:')),
            'unambiguous modetest resource sections required')
    sections = {name: text.split(name+':\n', 1)[1] for name in ('Connectors', 'CRTCs', 'Planes')}
    connectors = sections['Connectors'].split('CRTCs:\n', 1)[0]
    name = Path(spec['connector_sysfs']).name.split('-', 1)[1]
    match = re.search(r'^'+str(spec['connector_id'])+r'\s+\d+\s+connected\s+'+re.escape(name)+r'\s+.*$', connectors, re.M)
    require(match is not None, 'selected HDMI connector not connected in query')
    block = re.split(r'^\d+\s', connectors[match.end():], maxsplit=1, flags=re.M)[0]
    require(re.search(r'^\s*#\d+\s+1920x1080\s+60\.00\s+1920\s', block, re.M),
            '1080p60 connector mode required')
    crtcs = sections['CRTCs'].split('Planes:\n', 1)[0]
    ids = [int(x) for x in re.findall(r'^(\d+)\s+\d+\s+\(', crtcs, re.M)]
    require(spec['crtc_index'] < len(ids) and ids[spec['crtc_index']] == spec['crtc_id'],
            'CRTC id/index mismatch')
    planes = sections['Planes']
    match = re.search(r'^'+str(spec['plane_id'])+r'\s+\d+\s+\d+\s+\S+\s+\S+\s+\d+\s+(0x[0-9a-fA-F]+)\s*$', planes, re.M)
    require(match is not None and int(match[1], 16) & (1 << spec['crtc_index']),
            'selected plane incompatible with CRTC')
    block = re.split(r'^\d+\s', planes[match.end():], maxsplit=1, flags=re.M)[0]
    formats = re.search(r'^\s*formats:\s*([^\n]+)', block, re.M)
    require(formats is not None and 'NV12' in formats[1].split(), 'selected plane lacks NV12')
    # Route is reviewed against same-boot DRM state, preserved verbatim here.
    route = spec.get('route_evidence', '')
    require(isinstance(route, str) and 0 < len(route.encode()) <= 65536 and
            hashlib.sha256(route.encode()).hexdigest() == spec.get('route_sha256'),
            'route evidence missing or changed')
    connector = re.search(r'^connector\['+str(spec['connector_id'])+r'\]: '+re.escape(name)+r'\n\s*crtc=([^\n]+)', route, re.M)
    crtc = re.search(r'^crtc\['+str(spec['crtc_id'])+r'\]: ([^\n]+)', route, re.M)
    require(connector and crtc and connector[1] == crtc[1] and connector[1] != '(null)',
            'route evidence does not bind connector to selected CRTC')
    stamp = spec.get('captured_monotonic_s')
    require(type(stamp) in (int, float) and stamp > 0, 'KMS capture clock required')
    return spec


def load_selection(path, digest, boot, *, live=False):
    require(re.fullmatch('[0-9a-f]{64}', digest or ''), 'explicit KMS selection SHA256 required')
    path = Path(path)
    require(path.is_absolute() and not path.is_symlink() and path.stat().st_size <= 2*1024*1024,
            'bounded absolute KMS selection file required')
    raw = path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == digest, 'KMS selection file differs')
    spec = validate_selection(json.loads(raw), boot)
    if live:
        require(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == boot, 'live KMS boot differs')
        require(0 <= time.monotonic()-spec['captured_monotonic_s'] <= 120,
                'KMS selection stale; capture once after desktop release before launch')
        connector = Path(spec['connector_sysfs'])
        require((connector/'status').read_text().strip() == 'connected', 'live connector differs')
        try:
            connector_id = (connector/'connector_id').read_text()
        except FileNotFoundError:
            # Some vendor kernels omit this optional attribute. The validated
            # same-boot receipt still binds the connector name/id and CRTC route.
            pass
        else:
            require(int(connector_id) == spec['connector_id'], 'live connector differs')
        result = subprocess.run(['/usr/bin/systemctl', 'is-active', 'lightdm'],
                                capture_output=True, timeout=5)
        require(result.returncode == 3 and result.stdout.strip() == b'inactive',
                'lightdm must already be inactive; admission never stops it')
        check_no_drm_clients()
    return spec


def check_no_drm_clients(proc_root=Path('/proc')):
    # Read-only; permission failures propagate instead of implying no owners.
    for proc in proc_root.glob('[0-9]*'):
        try:
            require((proc/'comm').read_text().strip() not in ('Xorg', 'Xwayland'),
                    'existing Xorg/Xwayland process; no desktop takeover')
            for fd in (proc/'fd').iterdir():
                try:
                    target = os.readlink(fd)
                except FileNotFoundError:
                    continue
                require(not re.fullmatch(r'/dev/dri/card[0-9]+', target),
                        'existing DRM card holder; no takeover')
        except FileNotFoundError:
            continue


def environment(observer, observer_sha256, baseline, selection, *, verify_plugins):
    require(hashlib.sha256(Path(observer).read_bytes()).hexdigest() == observer_sha256,
            'KMS observer differs')
    plugins = json.loads(Path(baseline).read_text())['plugin_files']
    require(plugins and {str(Path(p['path']).parent) for p in plugins} ==
            {'/usr/lib/aarch64-linux-gnu/gstreamer-1.0'}, 'fixed system plugins required')
    if verify_plugins:
        for row in [*plugins, dict(path=KMS_PLUGIN, sha256=KMS_SHA256)]:
            require(hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'],
                    'KMS display plugin differs: '+row['path'])
    env = {k: os.environ[k] for k in ('HOME', 'USER', 'LOGNAME') if k in os.environ}
    env.update(PATH='/usr/bin:/bin', LANG='C', LC_ALL='C', GST_PLUGIN_PATH='', GST_PLUGIN_PATH_1_0='',
        GST_PLUGIN_SYSTEM_PATH='/usr/lib/aarch64-linux-gnu/gstreamer-1.0',
        GST_PLUGIN_SYSTEM_PATH_1_0='/usr/lib/aarch64-linux-gnu/gstreamer-1.0',
        GST_DEBUG_NO_COLOR='1', GST_DEBUG='2,kmssink:5,GST_PERFORMANCE:4',
        R5_KMS_CONNECTOR_ID=str(selection['connector_id']), R5_KMS_PLANE_ID=str(selection['plane_id']))
    return env


def trace_environment(env, observer, run_dir, expected_sha256):
    """Opt-in fixed observation library; never inherit arbitrary preload settings."""
    observer, run_dir = Path(observer), Path(run_dir)
    library = observer.parent/'kms_sync_trace.so'
    require(observer.is_absolute() and run_dir.is_absolute(), 'absolute trace paths required')
    require(re.fullmatch('[0-9a-f]{64}', expected_sha256 or ''), 'pinned trace SHA256 required')
    require(not any(p.is_symlink() for p in (library, *library.parents, run_dir, *run_dir.parents)),
            'trace symlink refused')
    raw = library.read_bytes()
    require(len(raw) >= 20 and raw[:6] == b'\x7fELF\x02\x01' and
            int.from_bytes(raw[16:18], 'little') == 3 and
            int.from_bytes(raw[18:20], 'little') == 183 and
            hashlib.sha256(raw).hexdigest() == expected_sha256, 'trace AArch64 library differs')
    target = run_dir/'kms-sync-trace.bin'
    require(not os.path.lexists(target), 'fresh trace output required')
    require('LD_PRELOAD' not in env and not any(k.startswith('R5_KMS_TRACE_') for k in env),
            'preexisting trace environment refused')
    return dict(env, LD_PRELOAD=str(library), R5_KMS_TRACE_PATH=str(target),
                R5_KMS_TRACE_EXECUTABLE=str(observer))
