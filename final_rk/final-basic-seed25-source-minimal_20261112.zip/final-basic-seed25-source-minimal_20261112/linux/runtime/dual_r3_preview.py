"""Two bounded owned-JPEG workers, one dual MPP/compositor/KMS observer.

Caller must first verify the new executable, plugins and current KMS selection.
No native/FPGA operations here. stop() seals logs and retains both input pipes
and the observer; it is not a safe DRM/MPP release or hot-reopen operation.
"""
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import threading
import time

if __package__:
    from .algorithm_preview import write_bounded, atomic_json
else:
    from algorithm_preview import write_bounded, atomic_json


class DualPreview:
    def __init__(self, output, observer, environment, *, alternating=False, fixed_cam0=False,
                 segment_count=None, side_by_side=False):
        if any(type(value) is not bool for value in (alternating, fixed_cam0, side_by_side)):
            raise ValueError('display modes require explicit bools')
        if sum((alternating, fixed_cam0, side_by_side)) > 1:
            raise ValueError('dual display modes are mutually exclusive')
        self.output, self.observer = Path(output), Path(observer)
        self.environment = dict(environment)
        self.environment.pop('R3_ALTERNATING', None)
        self.environment.pop('R3_CONTROL_FD', None)
        self.alternating = alternating
        self.fixed_cam0 = fixed_cam0
        self.side_by_side = side_by_side
        self.selector_enabled = alternating or fixed_cam0
        self.expected_segments = 1 if fixed_cam0 else 6
        if segment_count is not None:
            if not alternating or type(segment_count) is not int or not 1 <= segment_count <= 6:
                raise ValueError('explicit alternating segment count must be within observer capacity1..6')
            self.expected_segments = segment_count
        self.control_fd = None
        self.selections = []
        self.selector_buffers = self.sink_buffers = 0
        self.selected_by_camera = [0, 0]
        self.last_selector_serial = [0, 0]
        self.identities = {}
        self.last_identity = {}
        self.cv = threading.Condition()
        self.pending = [None, None]
        self.received = [0, 0]
        self.submitted = [0, 0]
        self.dropped = [0, 0]
        self.decoded = [0, 0]
        self.displayed = 0
        self.last_ns = [0, 0, 0]
        self.max_gap_ns = [0, 0, 0]
        self.heartbeat_ns = 0
        self.event_sequences = [0]*7
        self.failure = None
        self.closing = False
        self.process = None
        self.ready, self.log_stop = threading.Event(), threading.Event()
        self.workers = []
        self.started = False
        self.output_created = False

    def _fail(self, error):
        with self.cv:
            if self.failure is None:
                self.failure = str(error)[:512]
            self.closing = True
            self.cv.notify_all()

    def start(self):
        if self.started:
            raise RuntimeError('dual preview is single use')
        self.started = True
        self.output.mkdir(exist_ok=False)
        self.output_created = True
        read1, write1 = os.pipe()
        self.environment['R3_CAM1_FD'] = str(read1)
        inherited = [read1]
        control_read = None
        if self.selector_enabled:
            control_read, self.control_fd = os.pipe()
            os.set_blocking(self.control_fd, False)
            inherited.append(control_read)
            self.environment.update(R3_ALTERNATING='1', R3_CONTROL_FD=str(control_read))
        try:
            self.process = subprocess.Popen([str(self.observer)], stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, pass_fds=tuple(inherited),
                env=self.environment, bufsize=0)
        except BaseException:
            os.close(write1)
            if self.control_fd is not None:
                os.close(self.control_fd)
                self.control_fd = None
            raise
        finally:
            os.close(read1)
            if control_read is not None:
                os.close(control_read)
        self.inputs = [self.process.stdin.fileno(), write1]
        for fd in self.inputs:
            os.set_blocking(fd, False)
        self.log_thread = threading.Thread(target=self._log, daemon=True)
        self.log_thread.start()
        if not self.ready.wait(5):
            self._fail('dual observer startup deadline')
        self.check()
        for camera in (0, 1):
            thread = threading.Thread(target=self._worker, args=(camera,), daemon=True)
            self.workers.append(thread)
            thread.start()
        return self

    def select_camera(self, camera, segment):
        """Send one atomic command, never replay a failed/uncertain selection.

        The caller schedules segments; this method does not sleep or touch the
        FPGA. Snapshot distinguishes active-pad confirmation from real output.
        """
        with self.cv:
            self.check()
            if (not self.selector_enabled or not self.started or self.closing or self.control_fd is None or
                    type(camera) is not int or type(segment) is not int or
                    not 0 <= segment < self.expected_segments or camera != segment % 2 or segment != len(self.selections) or
                    (segment and self.selections[-1]['first_sink'] is None)):
                self._fail('invalid/repeated/out-of-order camera selection; no retry')
                raise RuntimeError(self.failure)
            row = dict(segment=segment, camera=camera, sent_ns=time.monotonic_ns(),
                       request_ns=None, confirm_ns=None, first_selector=None, first_sink=None,
                       first_ajpg=None)
            self.selections.append(row)  # Consume intent even on an uncertain write.
            command = f'SELECT {camera} {segment}\n'.encode('ascii')
            try:
                if os.write(self.control_fd, command) != len(command):
                    raise RuntimeError('short control write')
            except BaseException as error:
                self._fail('camera selection write uncertain; no retry: '+str(error))
                raise RuntimeError(self.failure) from error
            return dict(row)

    def submit(self, item):
        # Router already validated immutable owned bytes; never pass a DMA view.
        if (item.camera not in (0, 1) or type(item.wire) is not bytes or
                type(item.record.jpeg) is not bytes or
                not 4 <= len(item.record.jpeg) <= 4192192 or
                len(item.wire) != 2112+len(item.record.jpeg)):
            raise ValueError('bounded owned v4 camera record required')
        with self.cv:
            self.check()
            camera = item.camera
            if self.closing:
                return False
            self.received[camera] += 1
            if self.pending[camera] is not None:
                self.dropped[camera] += 1
            self.pending[camera] = (item, time.monotonic_ns())
            self.cv.notify_all()
        return True

    def _worker(self, camera):
        count = 0
        try:
            with (self.output/f'cam{camera}-submissions.jsonl').open('xb', buffering=0) as log:
                while True:
                    with self.cv:
                        self.cv.wait_for(lambda: self.closing or self.pending[camera] is not None)
                        if self.closing:
                            break
                        item, received_ns = self.pending[camera]
                        self.pending[camera] = None
                    if (self.selector_enabled or self.side_by_side) and count >= 4800:
                        raise RuntimeError('60s per-camera submission bound exceeded')
                    write_bounded(self.inputs[camera], item.record.jpeg, timeout=2)
                    stamp = time.monotonic_ns()
                    row = dict(camera=camera, session=item.session, epoch=item.epoch,
                        sequence=item.sequence, received_ns=received_ns, submitted_ns=stamp,
                        wire_sha256=hashlib.sha256(item.wire).hexdigest())
                    sample = None
                    if self.selector_enabled:
                        with self.cv:
                            current = self.selections[-1] if self.selections else None
                            if (current is not None and current['camera'] == camera and
                                    received_ns >= current['sent_ns'] and current['first_ajpg'] is None):
                                name = f"segment{current['segment']}-cam{camera}-first-submitted.ajpg"
                                sample = dict(row, file=name,
                                    semantics='FIRST_POST_REQUEST_RECEIVED_AND_SUBMITTED_RECORD_NOT_SINK_FRAME_IDENTITY')
                                current['first_ajpg'] = sample
                        if sample is not None:
                            (self.output/sample['file']).write_bytes(item.wire)
                    if sample is not None:
                        row['segment_sample'] = sample['file']
                    log.write((json.dumps(row)+'\n').encode())
                    count += 1
                    if count <= 3:
                        (self.output/f'cam{camera}-{count}.ajpg').write_bytes(item.wire)
                    with self.cv:
                        self.submitted[camera] += 1
                    if not self.selector_enabled and not self.side_by_side and count > 2400:
                        raise RuntimeError('30s per-camera submission bound exceeded')
        except BaseException as error:
            self._fail(error)

    def _line(self, line):
        if line.startswith('ERROR:'):
            raise RuntimeError(line)
        if 'Pipeline is PREROLLING' in line:
            self.ready.set()
        parts = line.split()
        if parts[:1] == ['R3SW']:
            self._selection_line(parts)
        if parts[:2] == ['R3D2', 'E']:
            if len(parts) != 5:
                raise ValueError('malformed dual event')
            stage, sequence, stamp = map(int, parts[2:])
            if stage not in range(7) or sequence <= 0 or stamp <= 0:
                raise ValueError('invalid dual event')
            if sequence != self.event_sequences[stage]+1:
                raise ValueError('dual event sequence missing/repeated')
            self.event_sequences[stage] = sequence
            index = {0:0, 5:1, 1:2}.get(stage)
            if index is not None:
                with self.cv:
                    previous = self.last_ns[index]
                    if stamp < previous:
                        raise ValueError('dual event clock reversed')
                    if previous:
                        self.max_gap_ns[index] = max(self.max_gap_ns[index], stamp-previous)
                    self.last_ns[index] = stamp
        if parts[:2] == ['R3D2', 'H']:
            if len(parts) != 9:
                raise ValueError('malformed dual heartbeat')
            stamp, cam0, cam1, sink, lost, clock_errors, telemetry = map(int, parts[2:])
            if min(stamp, cam0, cam1, sink, lost, clock_errors, telemetry) < 0 or lost or clock_errors or telemetry:
                raise ValueError('dual observation incomplete')
            with self.cv:
                if stamp < self.heartbeat_ns or any(a < b for a,b in zip(
                        (cam0,cam1,sink), (*self.decoded,self.displayed))):
                    raise ValueError('dual observation counters reversed')
                self.decoded, self.displayed = [cam0, cam1], sink
                self.heartbeat_ns = stamp

    def _selection_line(self, parts):
        with self.cv:
            if not self.selector_enabled:
                raise ValueError('unexpected selector evidence in compositor mode')
            if len(parts) == 5 and parts[1] in ('REQUEST', 'CONFIRM'):
                segment, camera, stamp = map(int, parts[2:])
                if (not 0 <= segment < len(self.selections) or camera != segment % 2 or stamp <= 0):
                    raise ValueError('selection acknowledgement has no matching intent')
                row = self.selections[segment]
                key = 'request_ns' if parts[1] == 'REQUEST' else 'confirm_ns'
                if (row[key] is not None or stamp < row['sent_ns'] or
                        (key == 'confirm_ns' and (row['request_ns'] is None or stamp < row['request_ns']))):
                    raise ValueError('selection acknowledgement repeated/reversed')
                row[key] = stamp
            elif len(parts) == 7 and parts[1] in ('BUFFER', 'FIRST') and parts[2] in ('S', 'K'):
                stage = parts[2]
                segment, camera, serial, stamp = map(int, parts[3:])
                if (not 0 <= segment < len(self.selections) or camera not in (0, 1) or
                        serial <= 0 or stamp <= 0 or self.selections[segment]['request_ns'] is None or
                        stamp < self.selections[segment]['request_ns']):
                    raise ValueError('selector output identity has no matching request')
                if self.fixed_cam0 and camera != 0:
                    raise ValueError('fixed CAM0 selector emitted CAM1')
                identity = dict(segment=segment, camera=camera, serial=serial, monotonic_ns=stamp)
                key = (camera, serial)
                if parts[1] == 'BUFFER':
                    if stage == 'S':
                        if serial <= self.last_selector_serial[camera] or len(self.identities) >= 128:
                            raise ValueError('selector buffer identity repeated/unbounded')
                        self.last_selector_serial[camera] = serial
                        self.identities[key] = identity
                        self.selector_buffers += 1
                    else:
                        source = self.identities.pop(key, None)
                        if source is None or source['segment'] != segment or stamp < source['monotonic_ns']:
                            raise ValueError('sink buffer does not match exact selector identity')
                        self.sink_buffers += 1
                        self.selected_by_camera[camera] += 1
                    self.last_identity[stage] = identity
                else:
                    row = self.selections[segment]
                    key = 'first_selector' if stage == 'S' else 'first_sink'
                    if (camera != row['camera'] or row[key] is not None or self.last_identity.get(stage) != identity):
                        raise ValueError('first target output identity invalid/repeated')
                    row[key] = identity
            else:
                raise ValueError('malformed selector evidence')

    def _log(self):
        pending = b''
        total = 0
        try:
            fd = self.process.stdout.fileno()
            with (self.output/'gstreamer.log').open('xb', buffering=0) as log:
                while not self.log_stop.is_set():
                    if not select.select([fd], [], [], .1)[0]:
                        continue
                    data = os.read(fd, 65536)
                    if not data:
                        raise RuntimeError('dual observer exited/EOF')
                    total += len(data)
                    if total > 16*1024*1024:
                        raise RuntimeError('dual observer log bound exceeded')
                    log.write(data)
                    pending += data
                    while b'\n' in pending:
                        line, pending = pending.split(b'\n', 1)
                        self._line(line.decode('utf-8', errors='replace'))
                    if len(pending) > 65536:
                        raise RuntimeError('dual observer line bound exceeded')
        except BaseException as error:
            self._fail(error)
        finally:
            self.ready.set()

    def check(self):
        if self.failure:
            raise RuntimeError(self.failure)
        if self.process is not None and self.process.poll() is not None:
            raise RuntimeError('dual observer unexpectedly exited')
        if self.selector_enabled:
            with self.cv:
                now = time.monotonic_ns()
                for row in self.selections:
                    if (now-row['sent_ns'] >= 3_000_000_000 and
                            (row['confirm_ns'] is None or row['first_sink'] is None)):
                        self._fail(f"segment{row['segment']} selection/output deadline; no retry")
                        raise TimeoutError(self.failure)

    def _missing_selection_evidence(self):
        return {key: [segment for segment in range(self.expected_segments) if segment >= len(self.selections) or
                      self.selections[segment][key] is None]
                for key in ('request_ns', 'confirm_ns', 'first_selector', 'first_sink', 'first_ajpg')}

    def snapshot(self):
        with self.cv:
            missing = self._missing_selection_evidence() if self.selector_enabled else {}
            return dict(received=list(self.received), submitted=list(self.submitted),
                dropped=list(self.dropped), decoded=list(self.decoded), composite_sink=self.displayed,
                last_ns=list(self.last_ns), max_gap_ns=list(self.max_gap_ns),
                heartbeat_ns=self.heartbeat_ns, failure=self.failure,
                pending=[int(x is not None) for x in self.pending],
                submission_workers_done=all(not t.is_alive() for t in self.workers),
                log_worker_done=not hasattr(self, 'log_thread') or not self.log_thread.is_alive(),
                observer_pid=None if self.process is None else self.process.pid,
                synchronization='NOT_QUALIFIED',
                composition=('INPUT_SELECTOR_FULL_1920x1080' if self.selector_enabled else
                             'CPU_NV12_1920x1080_TWO_960x540_VIEWS'),
                alternating=self.alternating, selections=json.loads(json.dumps(self.selections)),
                fixed_cam0=self.fixed_cam0,
                side_by_side=self.side_by_side,
                display_mode=('FIXED_CAM0' if self.fixed_cam0 else
                              'ALTERNATING_CAM0_CAM1' if self.alternating else
                              'SIDE_BY_SIDE_CAM0_CAM1' if self.side_by_side else 'COMPOSITOR'),
                monitored_receive_and_mpp_cameras=[0, 1],
                expected_segments=self.expected_segments if self.selector_enabled else None,
                missing_selection_evidence=missing,
                selection_evidence_complete=self.selector_enabled and not any(missing.values()),
                alternation_evidence_complete=self.alternating and not any(missing.values()),
                fixed_cam0_evidence_complete=self.fixed_cam0 and not any(missing.values()),
                selector_buffers=self.selector_buffers, selected_sink=self.sink_buffers,
                selected_by_camera=list(self.selected_by_camera),
                selector_identities_in_flight=len(self.identities),
                per_camera_submission_limit=4800 if self.selector_enabled or self.side_by_side else 2400,
                counters_scope='CUMULATIVE_INCLUDING_TAIL_USE_EVENTS_WITH_START_STOP_WINDOW',
                sink_semantics=('DECODED_BUFFER_QDATA_CAMERA_AT_SELECTOR_AND_SINK_INPUT_NOT_PHYSICAL_SCANOUT'
                    if self.selector_enabled else
                    'COMPOSITOR_BUFFERS_MAY_REPEAT_NOT_UNIQUE_CAMERA_FRAMES_OR_PHYSICAL_SCANOUT'),
                resource_release='NOT_PERFORMED_RETAIN_PROCESS_AND_PIPES')

    def close(self):
        with self.cv:
            self.closing = True
            for camera in (0, 1):
                if self.pending[camera] is not None:
                    self.dropped[camera] += 1
                    self.pending[camera] = None
            self.cv.notify_all()
        deadline = time.monotonic()+3
        for worker in self.workers:
            worker.join(max(0, deadline-time.monotonic()))
        if any(worker.is_alive() for worker in self.workers):
            self._fail('dual submission worker remains active; ownership retained')
        time.sleep(.35)
        self.log_stop.set()
        if hasattr(self, 'log_thread'):
            self.log_thread.join(.5)
            if self.log_thread.is_alive():
                self._fail('dual log worker remains active; log is not sealed')
        if self.selector_enabled and any(self._missing_selection_evidence().values()):
            segments = ('one-segment fixed CAM0' if self.fixed_cam0 else 'six-segment'
                        if self.expected_segments == 6 else str(self.expected_segments)+'-segment')
            self._fail(f'incomplete {segments} selection/output/AJPG evidence; retained')
        state = self.snapshot()
        if self.output_created:
            atomic_json(self.output/'preview-final.json', state)
        return state
