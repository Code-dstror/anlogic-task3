#!/bin/sh
set -eu
repro_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec /usr/bin/python3 -B "$repro_root/tools/reproduction_boot.py" --root "$repro_root" "$@"
