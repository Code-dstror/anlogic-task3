"""Opt-in seed25 AI ownership; JPEG video never waits for private inference.

Only the AI worker calls PreparedSession. The receiver offers one immutable
latest product; disabling clears native metadata before retiring the old owner.
An uncertain retirement keeps that owner and prevents another NPU session.
"""
from dataclasses import asdict
import hashlib
import importlib.util
from pathlib import Path
import sys
import threading
import time

PREPARED_SHA256 = 'ca312a74c2dfca4d6b0b9c9d59e1e4878c0a2ea1e408ea8d87dc46474b50d6e7'
OVERLAY_SHA256 = '0d2e97b675853260466d239b02df9852b801f63152fa82fe8bbbf1cbbc5e107b'
SOURCE_FIELDS = ('session', 'epoch', 'sequence', 'camera', 'kind', 'format', 'role')
TTL_NS = 500_000_000


def _runtime(config):
    """Load only the indexed continuous/R3 Python sources; no device access."""
    root = Path(config['ai_async_root']).resolve(strict=True)
    modules = []
    for name, digest in (('prepared_session', PREPARED_SHA256), ('latest_overlay', OVERLAY_SHA256)):
        path = root / (name + '.py')
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('frozen continuous AI source differs: ' + name)
        key = '_seed25_mono_' + name
        existing = sys.modules.get(key)
        if existing is not None:
            if Path(existing.__file__).resolve() != path:
                raise ValueError('foreign frozen AI source already loaded')
            modules.append(existing)
            continue
        spec = importlib.util.spec_from_file_location(key, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module
        try:
            spec.loader.exec_module(module)
        except BaseException:
            sys.modules.pop(key, None)
            raise
        modules.append(module)
    prepared, overlay = modules
    cfg = prepared.CandidateConfig(Path(config['candidate']), Path(config['helper_root']),
        Path(config['private_mpp_library']), Path(config['rga_library']),
        engineering_color_evidence='seed25 original live JPEG; mandatory RGA first-frame color check retained',
        allow_unreported_color=True, duration_s=0)
    def factory(generation, directory):
        return prepared.PreparedSession(generation, directory,
            backend_factory=lambda d, g: prepared.CandidateBackend(cfg, d, g))
    return factory, prepared.FrameIdentity, overlay.LatestOverlay


def _session_snapshot(session):
    value = session.snapshot()
    return dict(value) if isinstance(value, dict) else asdict(value)


def _source(item):
    metadata = item.record.metadata
    source = tuple(getattr(metadata.source, name) for name in SOURCE_FIELDS)
    if any(type(v) is not int or not 0 <= v < 2**32 for v in source):
        raise ValueError('verified explicit SOURCE integers required')
    if tuple(getattr(item, n) for n in ('session', 'epoch', 'sequence', 'camera')) != source[:4]:
        raise ValueError('accepted product and SOURCE differ')
    return source


def eligible(item, session, epoch):
    """Only the APPLIED owner's exact positive epoch and unprocessed CAM0."""
    source = _source(item)
    meta = item.record.metadata
    return (source[:2] == (session, epoch) and source[0] > 0 and source[1] > 0
        and source[3:] == (0, 1, 1, 0) and meta.processing_mode == 128
        and type(meta.record_flags) is int and meta.record_flags == 0
        and type(meta.schema2_processing_enables) is int and meta.schema2_processing_enables == 0
        and type(meta.jpeg_generation) is int and 0 < meta.jpeg_generation < 2**32
        and type(item.record.jpeg) is bytes and 4 <= len(item.record.jpeg) <= 4 * 1024 * 1024)


class MonoYolo:
    """Single background owner for the unchanged prepared NPU backend."""
    def __init__(self, endpoint, session_factory, identity_factory, *, output, cohort,
                 overlay_factory, frame_gate=eligible, clock_ns=time.monotonic_ns):
        self.endpoint, self.factory, self.identity_factory = endpoint, session_factory, identity_factory
        self.output, self.cohort, self.gate, self.clock = Path(output), cohort, frame_gate, clock_ns
        self.overlay = overlay_factory(endpoint, clock_ns=clock_ns, ttl_ns=TTL_NS)
        self.generation = 0
        self.session = None
        self.context = None
        self.desired = False
        self.requested = None
        self.retiring = self.unknown = self.first_result = False
        self.error = None
        self.token = 0
        self.offered = self.results = 0

    def _clear(self):
        self.overlay.configure(enabled=False, generation=self.generation)

    def _stop(self):
        self._clear()
        if self.session is not None and not self.retiring:
            self.retiring = True
            self.session.request_stop()

    def fail(self, error):
        self.error = self.error or type(error).__name__ + ': ' + str(error)[:384]
        try:
            self._stop()
        except BaseException as stop_error:
            self.unknown = True
            self.error += '; retirement unknown: ' + str(stop_error)[:128]

    def set_enabled(self, enabled, *, session=None, epoch=None):
        request = (session, epoch) if enabled else None
        if (enabled, request) != (self.desired, self.requested):
            self._stop()
            self.first_result = False
            if not enabled:
                self.error = None if not self.unknown else self.error
            self.desired, self.requested = enabled, request

    def submit(self, item, received_ns):
        if not self.desired or self.error or self.retiring or self.unknown:
            return False
        if not self.gate(item, *self.requested):
            return False
        source = _source(item)
        if type(received_ns) is not int or not 0 < received_ns <= self.clock() < received_ns + TTL_NS:
            return False
        context = (self.cohort, *source[:2], *source[3:])
        if self.session is None:
            self.generation += 1
            self.context = context
            self.first_result = False
            self.session = self.factory(self.generation, self.output / ('generation-%d' % self.generation))
            self.session.start()
        if context != self.context:
            self._stop()
            return False
        state = _session_snapshot(self.session)
        if not state.get('ready'):
            return False
        self.overlay.configure(enabled=True, generation=self.generation, context=context)
        self.token += 1
        identity = self.identity_factory(source, self.cohort, item.record.metadata.jpeg_generation, self.token)
        accepted = self.session.offer(item.record.jpeg, identity, received_ns)
        self.offered += int(bool(accepted))
        return bool(accepted)

    def pump(self):
        if self.session is not None and not self.unknown:
            state = _session_snapshot(self.session)
            if state.get('error') and self.error is None:
                self.fail(RuntimeError(state['error']))
            if not self.retiring and state.get('state') in ('CLOSED', 'RETAINED', 'DRAINING'):
                self.fail(RuntimeError('AI session stopped without an owner OFF'))
            if self.retiring:
                try:
                    retired = self.session.poll_retired()
                    if type(retired) is not bool:
                        raise RuntimeError('unknown session retirement result')
                    if retired:
                        self.session = None
                        self.context = None
                        self.retiring = False
                except BaseException as error:
                    self.unknown = True
                    self.error = self.error or 'retirement unknown: ' + str(error)[:384]
            elif self.desired and state.get('ready'):
                result = self.session.take_latest()
                if result is not None and self.overlay.submit(result):
                    self.first_result = True
                    self.results += 1
        self.overlay.service()
        return self.snapshot()

    def register_frame(self, pts, identity):
        self.endpoint.register_frame(pts, identity)

    def snapshot(self):
        state = None if self.session is None else _session_snapshot(self.session)
        enabled = self.desired and not self.retiring and self.error is None and bool(state and state.get('ready'))
        return dict(enabled=enabled, desired_enabled=self.desired,
            session=None if self.requested is None else self.requested[0],
            epoch=None if self.requested is None else self.requested[1],
            first_result=self.first_result and enabled, ready=enabled and self.first_result,
            generation=self.generation, error=self.error, retired=self.session is None,
            retained=self.unknown or bool(state and state.get('retained')), retiring=self.retiring,
            offered=self.offered, results=self.results, private_session=state,
            overlay=self.overlay.status(), video_waits_for_ai=False)


class AIWorker:
    """Thread-safe latest JPEG mailbox; no inference on the video thread."""
    def __init__(self, output, config, cohort, *, endpoint, runtime_factory=_runtime,
                 session_factory=None, identity_factory=None, overlay_factory=None,
                 frame_gate=eligible, clock_ns=time.monotonic_ns):
        self.output, self.config, self.cohort, self.endpoint = Path(output), config, cohort, endpoint
        self.runtime_factory = runtime_factory
        self.factories = (session_factory, identity_factory, overlay_factory)
        self.frame_gate, self.clock = frame_gate, clock_ns
        self.cv = threading.Condition()
        self.desired = (False, None, None)
        self.revision = 0
        self.pending = None
        self.closing = self.started = False
        self.native_generation = 0
        self.owner = None
        self.control_error = None
        self.cache = dict(enabled=False, desired_enabled=False, session=None, epoch=None,
            first_result=False, ready=False, error=None, worker_alive=False, retired=True,
            retained=False, video_waits_for_ai=False, dropped=0)
        self.thread = threading.Thread(target=self._run, name='seed25-mono-yolo', daemon=True)

    def start(self):
        with self.cv:
            if self.started:
                raise RuntimeError('one AI worker start only')
            self.started = True
            self.cache.update(worker_alive=True, retired=False)
            self.thread.start()
        return self

    def _clear_locked(self):
        try:
            accepted = self.endpoint.enable(enabled=False, generation=self.native_generation, context=None)
            if accepted != 1:
                raise RuntimeError('native AI OFF rejected')
        except BaseException as error:
            self.control_error = self.control_error or str(error)[:384]
            self.cache['error'] = self.cache.get('error') or self.control_error

    def set_enabled(self, enabled, *, session=None, epoch=None):
        if type(enabled) is not bool:
            raise ValueError('explicit enabled bool required')
        if enabled and (any(type(v) is not int or not 0 < v < 2**32 for v in (session, epoch))):
            raise ValueError('confirmed positive session/epoch required')
        with self.cv:
            if self.closing and enabled:
                return False
            requested = (enabled, session if enabled else None, epoch if enabled else None)
            if requested != self.desired:
                self._clear_locked()
                self.desired = requested
                self.revision += 1
                self.pending = None
                self.cache.update(enabled=False, desired_enabled=enabled, session=requested[1],
                    epoch=requested[2], first_result=False, ready=False)
                self.cv.notify_all()
        return True

    def submit(self, item, received_ns):
        with self.cv:
            if self.closing or not self.desired[0] or self.cache.get('error'):
                return False
            if self.pending is not None:
                self.cache['dropped'] += 1
            self.pending = (self.revision, item, received_ns)
            self.cv.notify_all()
            return True

    def snapshot(self):
        from copy import deepcopy
        with self.cv:
            value = deepcopy(self.cache)
            alive = self.started and self.thread.is_alive()
            value['worker_alive'] = alive
            # A stale pre-start cache cannot authorize retiring the display
            # graph while the AI owner may be allocating native resources.
            if alive and (self.closing or self.owner is not None and self.owner.session is not None):
                value['retired'] = False
                if self.closing:
                    value['retained'] = True
            return value

    def register_frame(self, pts, identity):
        self.endpoint.register_frame(pts, identity)

    def close(self, timeout_s=2):
        if type(timeout_s) not in (int, float) or not 0 <= timeout_s <= 60:
            raise ValueError('bounded close budget required')
        self.set_enabled(False)
        with self.cv:
            self.closing = True
            self._clear_locked()
            self.cv.notify_all()
        if self.started:
            self.thread.join(timeout_s)
        return self.snapshot()

    def _run(self):
        owner = None
        applied = -1
        try:
            factories = self.factories
            if any(value is None for value in factories):
                factories = self.runtime_factory(self.config)
            gate = _EndpointGate(self)
            owner = MonoYolo(gate, factories[0], factories[1], output=self.output,
                cohort=self.cohort, overlay_factory=factories[2], frame_gate=self.frame_gate, clock_ns=self.clock)
            self.owner = owner
            while True:
                with self.cv:
                    revision, request = self.revision, self.desired
                    gate.revision = revision
                    pending, self.pending = self.pending, None
                    closing = self.closing
                try:
                    if self.control_error:
                        owner.fail(RuntimeError(self.control_error))
                    if revision != applied:
                        if owner.desired:
                            owner.set_enabled(False)
                        owner.set_enabled(request[0], session=request[1], epoch=request[2])
                        applied = revision
                    if pending is not None and pending[0] == revision and not closing:
                        owner.submit(pending[1], pending[2])
                    state = owner.pump()
                except BaseException as error:
                    owner.fail(error)
                    state = owner.snapshot()
                with self.cv:
                    self.native_generation = owner.generation
                    if revision == self.revision:
                        self.cache.update(state, worker_alive=True)
                    else:
                        # An OFF racing an earlier offer/result wins before
                        # publication, including a native enable by that offer.
                        self._clear_locked()
                    if closing and state['retired']:
                        break
                    self.cv.wait(.005)
        except BaseException as error:
            if owner is not None:
                owner.fail(error)
            with self.cv:
                self.cache.update(error=type(error).__name__ + ': ' + str(error)[:384],
                    retired=owner is None or owner.session is None,
                    retained=owner is not None and owner.session is not None)
                self._clear_locked()
        finally:
            with self.cv:
                self._clear_locked()
                self.cache.update(worker_alive=False, enabled=False, ready=False, first_result=False)


class _EndpointGate:
    """Serialize OFF against asynchronous enables/results, without inference locks."""
    def __init__(self, worker):
        self.worker = worker
        self.revision = -1

    def _allowed(self, context):
        worker = self.worker
        return (self.revision == worker.revision and not worker.closing and worker.desired[0] and context is not None
            and tuple(context[1:3]) == worker.desired[1:])

    def enable(self, *, enabled, generation, context=None):
        worker = self.worker
        with worker.cv:
            worker.native_generation = max(worker.native_generation, generation)
            if enabled and not self._allowed(context):
                # The command revision will retire this owner on its next turn.
                return worker.endpoint.enable(enabled=False, generation=worker.native_generation, context=None)
            return worker.endpoint.enable(enabled=enabled, generation=generation, context=context)

    def update(self, **values):
        with self.worker.cv:
            if not self._allowed(values.get('context')):
                return 0
            return self.worker.endpoint.update(**values)

    def clear(self, **values):
        with self.worker.cv:
            return self.worker.endpoint.clear(**values)

    def stats(self):
        return self.worker.endpoint.stats()

    def register_frame(self, pts, identity):
        return self.worker.endpoint.register_frame(pts, identity)
