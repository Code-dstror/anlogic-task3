"""Fixed peer owned-reader adapter retaining scalar completion evidence.

No driver/native changes: copy under the view, timestamp, release exactly once,
then feed. The batch identifier is host-local and has no FPGA-time meaning.
"""
from linux.dma_c2h_candidate.c2h_abi import RESULT_CANCELLED, RESULT_COMPLETE
from linux.rk_debug.transport import OwnedRecordReader


class MetadataOwnedRecordReader(OwnedRecordReader):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.batch_sequence = 0
        self.last_batch_size = 0
        self.last_batch_position = None
        self.last_negative_completion = None

    def poll_once(self, timeout_s):
        if self.fault is not None:
            raise RuntimeError('debug receiver is terminal after uncertain transport IO')
        try:
            self.receiver.poll(timeout_s)
            events = []
            batch = self.receiver.receive_available(self.maximum_batch)
            if batch:
                self.batch_sequence += 1
                self.last_batch_size = len(batch)
                self.last_batch_position = None
            for position, lease in enumerate(batch):
                identity = tuple(lease.record_identity)
                metadata = dict(host_slot=lease.slot, transport_generation=lease.generation,
                    transport_result=lease.result, wire_length=lease.length,
                    record_identity=identity, batch_sequence=self.batch_sequence,
                    batch_position=position)
                if (any(type(metadata[key]) is not int for key in (
                        'host_slot', 'transport_generation', 'transport_result', 'wire_length'))
                        or any(type(value) is not int for value in identity)):
                    raise ValueError('completion identity requires stable integer scalars')
                self.records += 1
                self.last_batch_position = position
                if metadata['transport_result'] != RESULT_COMPLETE:
                    self.last_negative_completion = dict(metadata)
                    lease.release()
                    self.safe_errors += 1
                    if (metadata['transport_result'] != RESULT_CANCELLED or
                            getattr(self.inspector, 'state', None) != 'DRAINING'):
                        raise RuntimeError('negative transport completion outside the cancelled STOP tail')
                    events.append(dict(kind='TRANSPORT_RESULT', status='SAFE_NEGATIVE',
                        result=metadata['transport_result'], transport_identity=identity,
                        completion_metadata=metadata))
                    continue
                if not 0 < metadata['wire_length'] <= self.receiver.capacity:
                    raise ValueError('completed record exceeds the established DMA pool')
                if self.limit_reached:
                    lease.release()
                    self.budget_discards += 1
                    events.append(dict(kind='RECORD_LIMIT', status='DRAIN_DISCARD',
                        wire_bytes=metadata['wire_length'], transport_identity=identity,
                        completion_metadata=metadata))
                    continue
                with lease.view() as view:
                    wire = bytes(view)
                if len(wire) != metadata['wire_length']:
                    raise ValueError('owned copy length differs from its completion')
                self.copied_bytes += len(wire)
                host_ns = self.clock()
                lease.release()
                events.append(self.inspector.feed(wire, host_ns=host_ns,
                    transport_identity=identity, completion_metadata=metadata))
                # Typed DROP is a normal inspected result and consumes budget.
                self.inspected_records += 1
            return tuple(events)
        except BaseException as error:
            self.fault = f'{type(error).__name__}: {error}'[:512]
            raise

    def snapshot(self):
        result = super().snapshot()
        result.update(completion_metadata_scope='HOST_SCALARS_BEFORE_RELEASE_NOT_FPGA_EVENT_TIME',
            completion_batches=self.batch_sequence, last_batch_size=self.last_batch_size,
            last_batch_position=self.last_batch_position, batch_position_base=0,
            last_negative_completion=(None if self.last_negative_completion is None
                                      else dict(self.last_negative_completion)))
        return result
