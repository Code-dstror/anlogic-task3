"""One worker owns two MPP inputs, one compositor/KMS and its recording tee."""
from copy import deepcopy
import ctypes
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import threading
import time

try:
    from .unified_stereo_native import StereoHud
    from .unified_stereo_recording import StereoRecording
    from .remote_mono_logs import RollingStream
    from .stereo_display_health import POLICY,StereoDisplayHealth
except ImportError:
    from unified_stereo_native import StereoHud
    from unified_stereo_recording import StereoRecording
    from remote_mono_logs import RollingStream
    from stereo_display_health import POLICY,StereoDisplayHealth

def graph_spec(sink,directory,*,software=False):
    try:from .display_recording import graph_branch
    except ImportError:from display_recording import graph_branch
    decoder='jpegdec ! videoconvert' if software else 'mppjpegdec format=NV12'
    graph=('u3stereocompositor name=stereo_mix background=black start-time-selection=first '
           '! video/x-raw,format=NV12,width=1920,height=1080,framerate=30/1 '
           '! identity name=stereo_final ! '+graph_branch(sink,directory,software=software).replace('framerate=60/1','framerate=30/1'))
    for c in (0,1):
        # Let jpegparse preserve each explicitly supplied PTS. A declared
        # encoded framerate can interpolate it; only the compositor output is
        # clocked at30. Input product rates are measured from strict SOURCE.
        graph+=(' appsrc name=cam%d is-live=true format=time block=false max-buffers=2 leaky-type=downstream '
                'caps="image/jpeg,width=1920,height=1080,framerate=0/1" ! jpegparse ! %s '
                '! video/x-raw,format=NV12,width=1920,height=1080 '
                '! identity name=stereo_decoded%d ! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! stereo_mix.sink_%d')%(c,decoder,c,c)
    return graph

class StereoPreview:
    def __init__(self,output,config,*,boot):
        self.output,self.config,self.boot=Path(output),config,boot
        self.cv=threading.Condition();self.pending=[None,None];self.request=None
        self.ready=threading.Event();self.closing=False;self.started=False
        self.thread=threading.Thread(target=self._run,name='unified-stereo-display',daemon=True)
        self.pipeline=self.hud=self.recorder=None
        self.cache=dict(failure=None,worker_done=False,worker_alive=False,closing=False,received=[0,0],dropped=[0,0],submitted=[0,0],hud=None,recording=None)
        self.realtime=config.get('display_timing_policy')==POLICY
        self.fast_config=config.get('compositor_optimization')
        if self.fast_config is not None:
            if (config.get('firmware_release')!='dual-unified-r5-seed15-stereo' or
                    config.get('profile')!='dual-unified-r5-seed15-stereo-fullscreen-continuous' or
                    not isinstance(self.fast_config,dict) or
                    self.fast_config!=dict(policy='LINEAR_SBS_ONLY_V1',threads_per_eye=2) or
                    type(self.fast_config.get('threads_per_eye')) is not int):
                raise ValueError('explicit R5 SBS optimization configuration required')
        self.frame_timing=config.get('input_frame_timing')
        if 'input_frame_timing' in config:
            if (not self.fast_config or not isinstance(self.frame_timing,dict) or
                    self.frame_timing!=dict(policy='SOURCE_PTS_DURATION_30_V1',duration_ns=33333333) or
                    type(self.frame_timing.get('duration_ns')) is not int):
                raise ValueError('explicit R5 original-PTS frame-duration configuration required')
        self.frame_duration_ns=self.frame_timing['duration_ns'] if self.frame_timing else None

    def start(self):
        with self.cv:
            if self.started:raise RuntimeError('one stereo preview start only')
            self.started=True;self.output.mkdir(mode=0o700);self.thread.start()
        if not self.ready.wait(5):raise TimeoutError('stereo graph setup deadline; owner retained')
        self.check();return self

    def submit(self,item,received_ns):
        with self.cv:
            self.check()
            if self.closing:return False
            c=item.camera;self.cache['received'][c]+=1
            if self.pending[c] is not None:self.cache['dropped'][c]+=1
            self.pending[c]=(item,received_ns);self.cv.notify_all();return True

    def request_layout(self,name,revision):
        with self.cv:
            self.check()
            if self.closing or self.request is not None:raise RuntimeError('stereo layout worker is busy or stopped')
            self.request=(name,revision);self.cv.notify_all()

    def check(self):
        with self.cv:
            if self.cache['failure']:raise RuntimeError(self.cache['failure'])

    def snapshot(self):
        with self.cv:return deepcopy(self.cache)

    def _publish(self):
        hud=self.hud.snapshot();recording=self.recorder.snapshot()
        if hud['error']:raise RuntimeError('stereo identity/HUD error '+str(hud['error']))
        self.recorder.check()
        timing=self.hud.timing_snapshot() if self.realtime else None
        health=self.health.observe(timing,now_ns=time.monotonic_ns()) if self.realtime else None
        scaler=self.hud.fast_snapshot() if self.fast_config else None
        frame_timing=self.hud.duration_snapshot() if self.frame_timing else None
        with self.cv:self.cache.update(hud=hud,timing=timing,display_health=health,scaler=scaler,frame_timing=frame_timing,recording=recording,worker_alive=True,closing=self.closing)
        return hud

    def _push(self,Gst,item,received):
        clock=self.pipeline.get_clock();base=self.pipeline.get_base_time()
        if clock is None or base==Gst.CLOCK_TIME_NONE:raise ValueError('live stereo clock not established')
        pts=int(clock.get_time()-base)
        pts=max(pts,self.last_pts[item.camera]+1);self.last_pts[item.camera]=pts
        self.hud.register(item,pts,received)
        buffer=Gst.Buffer.new_allocate(None,len(item.record.jpeg),None);buffer.fill(0,item.record.jpeg)
        buffer.pts=buffer.dts=pts
        # An input is a frame interval, not an instantaneous point. Preserve
        # its original supplied PTS; do not ask jpegparse to interpolate it.
        buffer.duration=self.frame_duration_ns if self.frame_duration_ns is not None else Gst.CLOCK_TIME_NONE
        if self.sources[item.camera].emit('push-buffer',buffer)!=Gst.FlowReturn.OK:raise RuntimeError('stereo JPEG appsrc rejected input')
        with self.cv:self.cache['submitted'][item.camera]+=1

    def _run(self):
        log=None
        try:
            import gi
            gi.require_version('Gst','1.0');from gi.repository import Gst
            Gst.init(None)
            self.hud=StereoHud(self.config['hud_library'],self.config['hud_sha256'])
            if self.realtime:self.hud.realtime()
            if self.fast_config:self.hud.fast(self.fast_config['threads_per_eye'])
            if self.frame_duration_ns is not None:self.hud.frame_duration(self.frame_duration_ns)
            library_path=Path(self.config['record_library'])
            if hashlib.sha256(library_path.read_bytes()).hexdigest()!=self.config['record_library_sha256']:raise ValueError('sealed native recording library differs')
            self.record_library=SimpleNamespace(lib=ctypes.CDLL(str(library_path)))
            self.recorder=StereoRecording(self.config['recording'],boot=self.boot,output=self.output,hud=self.hud)
            sink=('kmssink name=display_sink driver-name=rockchip sync=false force-modesetting=true skip-vsync=true '
                  'connector-id=%d plane-id=%d')%(self.config['connector_id'],self.config['plane_id'])
            self.pipeline=Gst.parse_launch(graph_spec(sink,str(self.recorder.io_directory)))
            self.hud.attach(self.pipeline);self.hud.layout(self.config.get('initial_layout','both'),1)
            self.sources=[self.pipeline.get_by_name('cam'+str(c)) for c in (0,1)];self.last_pts=[0,0]
            self.recorder.attach(SimpleNamespace(_Gst=Gst,_pipeline=self.pipeline),self.record_library)
            log=RollingStream(self.output/'stereo-preview.jsonl','x',encoding='utf-8');self.bus=self.pipeline.get_bus()
            if self.pipeline.set_state(Gst.State.PLAYING)==Gst.StateChangeReturn.FAILURE:raise RuntimeError('stereo graph failed PLAYING')
            began=time.monotonic();self.health=StereoDisplayHealth(started_ns=time.monotonic_ns()) if self.realtime else None
            self.ready.set();last_log=0;last_count=[0,0,0];last_progress=[began,began,began]
            while True:
                with self.cv:
                    if self.closing:break
                    items=list(self.pending);self.pending=[None,None];request=self.request;self.request=None
                if request is not None:self.hud.layout(*request)
                for entry in items:
                    if entry is not None:self._push(Gst,*entry)
                message=self.bus.pop_filtered(Gst.MessageType.ERROR)
                if message is not None:
                    error,debug=message.parse_error();raise RuntimeError(str(error)+': '+str(debug)[:512])
                state=self._publish();now=time.monotonic()
                for i,key in enumerate(('decoded0','decoded1','frames')):
                    if state[key]!=last_count[i]:last_count[i]=state[key];last_progress[i]=now
                    if now-began>15 and now-last_progress[i]>3:raise TimeoutError('stereo decoder or final frame has stalled')
                if now-last_log>=1:
                    log.write(json.dumps(dict(host_ns=time.monotonic_ns(),hud=state,timing=self.cache.get('timing'),
                        display_health=self.cache.get('display_health'),scaler=self.cache.get('scaler'),
                        frame_timing=self.cache.get('frame_timing'),recording=self.cache['recording']))+'\n');log.flush();last_log=now
                with self.cv:
                    if not self.closing and all(x is None for x in self.pending) and self.request is None:self.cv.wait(.005)
        except BaseException as error:
            with self.cv:self.cache['failure']=type(error).__name__+': '+str(error)[:512]
        finally:
            try:
                if self.hud is not None:self.hud.freeze()
                if self.recorder is not None:
                    final=self.recorder.finish(timeout=12)
                    with self.cv:self.cache['recording_final']=final
                    if final.get('error'):raise RuntimeError(final['error'])
            except BaseException as error:
                with self.cv:self.cache['failure']=self.cache['failure'] or str(error)[:512]
            with self.cv:
                self.closing=True;self.cache.update(worker_done=True,worker_alive=False,closing=True,resources_retained=True)
            try:
                try:from .display_record_seal import durable_json
                except ImportError:from display_record_seal import durable_json
                durable_json(self.output/'stereo-preview-final.json',self.snapshot())
            except BaseException as error:
                with self.cv:self.cache['failure']=self.cache['failure'] or 'final evidence: '+str(error)[:512]
            if log is not None:log.close()
            self.ready.set()

    def close(self,timeout_s=15):
        with self.cv:self.closing=True;self.cv.notify_all()
        if self.started:self.thread.join(timeout_s)
        result=self.snapshot()
        if self.thread.is_alive():result.update(failure=result['failure'] or 'stereo recorder tail still pending',worker_done=False,worker_alive=True)
        return result
