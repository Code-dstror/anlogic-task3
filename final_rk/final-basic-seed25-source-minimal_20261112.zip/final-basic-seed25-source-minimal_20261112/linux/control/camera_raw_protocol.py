"""Use the sealed CAMERA_RAW SDK under one cold owner, without device opens."""
from collections import deque
from dataclasses import asdict
import hashlib
import time
from pathlib import Path
from types import SimpleNamespace

try:
    from . import camera_raw_release as release
    from .display_record_seal import durable_json
except ImportError:
    import camera_raw_release as release
    from display_record_seal import durable_json


class ColdSession:
    def __init__(self,receiver,*,session,on_admitted=None,evidence=None):
        self.receiver=receiver;self.spec=release.session_spec(session);self.name=session;self.on_admitted=on_admitted;self.evidence=evidence
        self.initial_snapshot=None
        self.state='NEW';self.receipt=None;self.profiles=None;self.transactions=None

    def _check_transport(self, info):
        r=self.receiver
        if (not info.transport_drained or info.submitted or info.completed or r.leased_count or r.poll(0) or r.capacity<4194304):
            raise ValueError('fresh stopped N2 DMA pool with no old result/lease required')

    def prepare(self,*,timeout_s=10,poll_interval_s=.001):
        if self.state!='NEW':raise RuntimeError('one cold selection only')
        self.state='PREPARING';r=self.receiver
        try:
            from linux.task3_pipeline import pcie_protocol_v1 as p
            from linux.task3_pipeline.config_transaction import ConfigTransactions
            from linux.task3_pipeline.record_selection import select_record
            from dual_host.stereo_control import select_cold_mode
            from dual_host.camera_shared import SharedStereoReceiver
            info=r.snapshot()
            self._check_transport(info)
            tx=ConfigTransactions(r,timeout_s=timeout_s,poll_interval_s=poll_interval_s);tx.wait_session_ready()
            self.initial_snapshot=dict(host_ns=time.monotonic_ns(),sampling='SEQUENTIAL_CSR_READS_NOT_ATOMIC',source_session=tx.session,
                compiled_profile=tx.capabilities.compiled_profile,camera_present=tx.capabilities.camera_present,
                max_width=tx.capabilities.max_width,max_height=tx.capabilities.max_height,
                mode_epoch=r.read32(p.PCIE_REG_CFG_MODE_EPOCH),active_mode=r.read32(p.PCIE_REG_CFG_ACTIVE_MODE),
                quality=r.read32(p.PCIE_REG_CFG_ACTIVE_QUALITY),control=r.read32(p.PCIE_REG_CONTROL),
                record_version=r.read32(p.PCIE_REG_RECORD_SELECTED_VERSION),
                record_header_length=r.read32(p.PCIE_REG_RECORD_SELECTED_HEADER_LENGTH))
            if self.evidence is not None:self.evidence(dict(state='INITIAL_COLD_SNAPSHOT',source=release.SOURCE,initial=self.initial_snapshot))
            initial=self.initial_snapshot
            if ((initial['compiled_profile'],initial['camera_present'],initial['max_width'],initial['max_height'])!=
                    (p.PCIE_CFG_PROFILE_MONO1920,1,1920,1080) or
                    initial['mode_epoch']!=0 or initial['active_mode']!=p.PCIE_CFG_MODE_COLOR or initial['quality']!=75 or
                    initial['control']&p.PCIE_CONTROL_APP_ENABLE or
                    (initial['record_version'],initial['record_header_length']) not in
                    ((p.PROTOCOL_VERSION,p.FRAME_HEADER_SIZE),(p.PCIE_RECORD_V2_VERSION,p.PCIE_RECORD_V2_HEADER_LENGTH))):
                raise ValueError('fresh MONO COLOR/Q75/epoch0 and valid initial record-v1/64 or v2/192 BOOT required; actual='+repr(initial))
            if self.spec['product']=='jpeg':
                caps=tx.mono_capabilities()
                if caps.enables&63!=63 or caps.modes&5!=5:raise ValueError('requested CAMERA_RAW algorithms/HDR are absent before storage admission')
            if self.on_admitted is not None:self.on_admitted(dict(source=release.SOURCE,session=tx.session))
            if self.spec['product']=='raw':
                from raw_control import select_cold_raw
                from raw_video import RawVideoReceiver
                topology=select_cold_raw(r,cameras=self.spec['cameras'],max_record_bytes=r.capacity,timeout_s=timeout_s,poll_interval_s=poll_interval_s)
                self.profiles=RawVideoReceiver(session=topology.session,mode_epoch=0,cameras=self.spec['cameras'],width=1920,height=1080)
                session=topology.session;selected=dict(product='ARAW',header_bytes=64,record_bytes=2592064)
            else:
                topology=tx if self.spec['cameras']==1 else select_cold_mode(r.read32,r.write32,1,frame_divisor=2,jpeg_quality=75,
                    timeout_s=timeout_s,poll_interval_s=poll_interval_s)
                tx=ConfigTransactions(r,timeout_s=timeout_s,poll_interval_s=poll_interval_s);tx.wait_session_ready()
                expected=(p.PCIE_CFG_PROFILE_MONO1920 if self.spec['cameras']==1 else p.PCIE_CFG_PROFILE_DUAL1920,(1<<self.spec['cameras'])-1,1920,1080)
                if tuple(getattr(tx.capabilities,k) for k in ('compiled_profile','camera_present','max_width','max_height'))!=expected:
                    raise ValueError('actual selected topology CFG differs')
                caps=tx.mono_capabilities();needed=63 if self.spec['cameras']==1 else 15
                if caps.enables&needed!=needed or caps.modes&5!=5:raise ValueError('requested CAMERA_RAW algorithms/HDR are absent')
                selection=select_record(r,p.PCIE_RECORD_V4_VERSION,timeout_s=timeout_s,poll_interval_s=poll_interval_s)
                self.profiles=SharedStereoReceiver(topology,selection,max_record_bytes=r.capacity,cameras=self.spec['cameras'])
                session=self.profiles.session;selected=asdict(selection)
            self.transactions=tx;self.state='PREPARED'
            self.receipt=dict(cold_session=self.name,source=release.SOURCE,bit_sha256=release.BIT,session=session,
                cameras=self.spec['cameras'],product=self.spec['product'],selection=selected,initial_epoch=0,
                sampling='SENSOR_SDR30_CAPTURE_DIV1' if self.spec['cameras']==2 else 'SENSOR_SDR60',
                initial_record_version=initial['record_version'],initial_record_header_length=initial['record_header_length'],sram_readback=False)
            self.receipt['initial_snapshot']=dict(initial)
            return self.receipt
        except BaseException:
            self.state='FAULTED_RETAINED';raise

    def apply(self,mode,*,quality=75):
        if self.spec['product']!='jpeg' or self.state!='PREPARED':raise ValueError('RAW has no live CFG')
        if type(quality) is not int or not 1<=quality<=100:raise ValueError('JPEG quality must be integer 1..100')
        from linux.task3_pipeline import pcie_protocol_v1 as p
        from linux.task3_pipeline.config_transaction import Configuration
        from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
        doc=release.configuration(self.name,mode);base=dict(doc['base']);base['mode']=p.PCIE_CFG_MODE_COLOR
        base['quality']=quality
        return self.profiles.apply(self.transactions,Configuration(**base),MonoConfiguration(**doc['extension']))

    def apply_document(self,document):
        """One complete caller-validated snapshot through the unchanged SDK."""
        if self.spec['product']!='jpeg' or self.state!='PREPARED':raise ValueError('RAW has no live CFG')
        if (type(document) is not dict or set(document)!={'schema','base','extension'} or document['schema']!=2
                or type(document['base']) is not dict or type(document['extension']) is not dict):
            raise ValueError('complete schema2 base/extension document required')
        from linux.task3_pipeline import pcie_protocol_v1 as p
        from linux.task3_pipeline.config_transaction import Configuration
        from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
        base=dict(document['base'])
        if type(base.get('mode')) is str:
            modes={name:getattr(p,'PCIE_CFG_MODE_'+name) for name in ('COLOR','GRAY','GAUSSIAN','HISTOGRAM')}
            if base['mode'] not in modes:raise ValueError('unsupported base mode')
            base['mode']=modes[base['mode']]
        return self.profiles.apply(self.transactions,Configuration(**base),MonoConfiguration(**document['extension']))

    def snapshot(self):return dict(state=self.state,receipt=self.receipt,initial=self.initial_snapshot,bit_sha256=release.BIT,source=release.SOURCE)


class Router:
    def __init__(self,cold,run):
        self.cold,self.run=cold,Path(run);self.samples=[deque(),deque()];self.total=[0,0];self.last_host=None;self.fault=None
        self.saved=set();self.first=[None,None];self.raw_monitor=None;self.last_products=[None,None];self.dehaze_applied=[0,0]
        if cold.spec['product']=='raw':
            try:from .camera_raw_transport import RawTransportMonitor
            except ImportError:from camera_raw_transport import RawTransportMonitor
            self.raw_monitor=RawTransportMonitor(session=cold.receipt['session'],mode_epoch=0)

    def feed(self,wire,*,host_ns,completion_metadata=None,transport_identity=None):
        if self.fault is not None:raise RuntimeError('terminal CAMERA_RAW router')
        try:
            if type(wire) is not bytes or type(host_ns) is not int or host_ns<=0 or self.last_host is not None and host_ns<self.last_host:
                raise ValueError('owned exact record and original monotonic receive time required')
            item=self.cold.profiles.accept(wire)
            if self.cold.spec['product']=='raw':
                self.raw_monitor.observe(item,host_ns)
                item=SimpleNamespace(camera=item.camera,session=item.source_session,epoch=item.mode_epoch,sequence=item.source_sequence,
                    frame=item,wire=wire,completion_metadata=completion_metadata)
            c=item.camera
            if c>=self.cold.spec['cameras']:raise ValueError('unexpected eye')
            samples=self.samples[c]
            while samples and samples[0][0]<=host_ns-60_000_000_000:samples.popleft()
            if len(samples)>=8192:raise ValueError('bounded CAMERA_RAW product window exceeded')
            samples.append((host_ns,item.epoch,item.sequence));self.total[c]+=1;self.first[c]=self.first[c] or host_ns;self.last_host=host_ns
            mode='raw' if self.cold.spec['product']=='raw' else self._mode(item.record.metadata,source_epoch=item.epoch)
            if self.cold.spec['product']=='jpeg':
                m=item.record.metadata
                self.last_products[c]=dict(session=item.session,epoch=item.epoch,sequence=item.sequence,mode=mode,
                    quality=item.wire[22],
                    processing_enables=release.confirmed_processing_mask(m,source_epoch=item.epoch),
                    processing_enables_raw=m.schema2_processing_enables,processing_mode=m.processing_mode,
                    processing_mask_origin='LEGACY_COLOR_BOOT' if m.schema2_processing_enables is None else 'SCHEMA2',
                    hdr_merged=bool(m.record_flags&1),
                    dehaze_requested=m.dehaze_requested,dehaze_applied=m.dehaze_applied,
                    lane_points=None if item.record.s07.f23 is None else item.record.s07.f23.count,job_id=m.job_id,pair_id=m.pair_id)
                self.dehaze_applied[c]+=int(m.dehaze_applied)
            key=(c,mode)
            if key not in self.saved:
                self.saved.add(key);suffix='araw' if self.cold.spec['product']=='raw' else 'ajpg';name='first-'+mode+'-cam'+str(c)+'.'+suffix
                with (self.run/name).open('xb') as stream:stream.write(wire);stream.flush();__import__('os').fsync(stream.fileno())
                durable_json(self.run/(name+'.json'),dict(camera=c,session=item.session,epoch=item.epoch,sequence=item.sequence,
                    host_ns=host_ns,bytes=len(wire),sha256=hashlib.sha256(wire).hexdigest(),completion_metadata=completion_metadata))
            return item
        except BaseException as error:
            from dual_host.camera_shared import AwaitingApplied
            if isinstance(error,AwaitingApplied):raise
            self.fault=type(error).__name__+': '+str(error)[:512]
            if type(wire) is bytes and 0<len(wire)<=4194304:
                try:
                    (self.run/'first-camera-error.bin').write_bytes(wire)
                    durable_json(self.run/'first-camera-error.json',dict(error=self.fault,host_ns=host_ns,
                        transport_identity=transport_identity,completion_metadata=completion_metadata,
                        previous=[list(s)[-2:] for s in self.samples],last_products=self.last_products,sha256=hashlib.sha256(wire).hexdigest()))
                except OSError:pass
            raise

    @staticmethod
    def _mode(meta,*,source_epoch):
        mask=release.confirmed_processing_mask(meta,source_epoch=source_epoch)
        if meta.record_flags&1:return 'hdr' if mask==0 else 'custom'
        return {0:'color',1:'gray',4:'gaussian',8:'histogram',48:'lane',2:'dehaze'}.get(mask,'custom')

    def snapshot(self):
        rows=[]
        for c in range(self.cold.spec['cameras']):
            samples=self.samples[c];end=None if not samples else samples[-1][0]
            windows={}
            for seconds in (10,60):
                selected=[] if end is None else [x for x in samples if x[0]>end-seconds*1_000_000_000]
                complete=end is not None and end-self.first[c]>=seconds*1_000_000_000
                windows[str(seconds)]=dict(complete=complete,unique_products=len(selected),fps=len(selected)/seconds if complete else None)
            rows.append(dict(camera=c,total=self.total[c],last=None if not samples else samples[-1],windows=windows,
                last_product=self.last_products[c],dehaze_applied_frames=self.dehaze_applied[c]))
        return dict(product=self.cold.spec['product'],cameras=rows,fault=self.fault,source_order_policy='strict',
            scope='COMPLETE_HOST_RECORDS_NOT_HDMI_FPS',raw_validation=None if self.raw_monitor is None else self.raw_monitor.snapshot(),raw_isp_display='DEFERRED_BY_USER' if self.cold.spec['product']=='raw' else None)
