"""Unmodified delivered C++17 lane core, bounded typed-point/curve adapter.

Only a display worker calls this API. It never reads images or accesses devices.
The CPU tracker is private to one receiver cohort; timestamps are host receipt
times, converted to seconds after subtracting a monotonic integer origin.
"""
import ctypes as C
import hashlib
import math
from pathlib import Path
import struct
import time

CORE_SHA256 = '5191353846689bc32e7687bbc8a859191b27f4933edd214b587f93adcbb8b3fe'
HANDOFF_SHA256 = '445498d13ca5359ab4a78748d18a9aa836fe1f67ab37a0853a98765c8abb422d'
MAGIC = b'R5C1LN1\0'
HEADER = struct.Struct('<8sIIQ10IQ')
MAX_CURVE_POINTS = 542
PTS_STEP = 1_000_000_000//60


class Point(C.Structure):
    _fields_ = [(name,C.c_int) for name in ('x','y','strength','cls','width')]


class Curve(C.Structure):
    _fields_ = [(name,C.c_int) for name in ('n','support','label','track_id')]+[
        (name,C.c_double*6) for name in ('y','x','tangent')]+[
        (name,C.c_double) for name in ('median_error','p90_error','score')]


PACKED_CURVE_BYTES=2176
PACKED_BYTES=2*PACKED_CURVE_BYTES


class LaneCore:
    """One thread, valid fixed arrays, no image input and no algorithm changes."""
    def __init__(self, library, *, expected_sha256=None,sampler_library=None,sampler_sha256=None):
        path=Path(library).resolve(strict=True)
        if expected_sha256 is not None and hashlib.sha256(path.read_bytes()).hexdigest()!=expected_sha256:
            raise ValueError('C1 core shared library differs')
        if C.sizeof(Point)!=20 or C.sizeof(Curve)!=184:
            raise ValueError('C1 native ABI differs')
        self.lib=C.CDLL(str(path))
        self.lib.lane_create.argtypes=[];self.lib.lane_create.restype=C.c_void_p
        self.lib.lane_destroy.argtypes=[C.c_void_p];self.lib.lane_destroy.restype=None
        self.lib.lane_evaluate.argtypes=[C.POINTER(Curve),C.c_double]
        self.lib.lane_evaluate.restype=C.c_double
        self.lib.lane_process.argtypes=[C.c_void_p,C.POINTER(Point),C.c_int,
            C.c_uint32,C.c_uint32,C.c_uint32,C.c_int,C.c_double,
            C.POINTER(Curve),C.POINTER(C.c_int),C.POINTER(C.c_int)]
        self.lib.lane_process.restype=C.c_int
        self.points=(Point*303)();self.curves=(Curve*2)();self.assignments=(C.c_int*303)()
        self.sampler=None
        if sampler_library is not None:
            sample_path=Path(sampler_library).resolve(strict=True)
            if sampler_sha256 is not None and hashlib.sha256(sample_path.read_bytes()).hexdigest()!=sampler_sha256:
                raise ValueError('C1 sampler shared library differs')
            self.sampler=C.CDLL(str(sample_path))
            self.sampler.c1_lane_sampler_abi.argtypes=[];self.sampler.c1_lane_sampler_abi.restype=C.c_uint32
            self.sampler.c1_lane_sampler_curve_bytes.argtypes=[];self.sampler.c1_lane_sampler_curve_bytes.restype=C.c_uint32
            if self.sampler.c1_lane_sampler_abi()!=1 or self.sampler.c1_lane_sampler_curve_bytes()!=PACKED_CURVE_BYTES:
                raise ValueError('C1 sampler native ABI differs')
            self.sampler.c1_lane_sample.argtypes=[C.c_void_p,C.POINTER(Curve),C.c_uint32,C.c_void_p,C.c_size_t]
            self.sampler.c1_lane_sample.restype=C.c_int
            self._sampled=(C.c_ubyte*PACKED_BYTES)()
            self._evaluate=C.cast(self.lib.lane_evaluate,C.c_void_p)
        elif sampler_sha256 is not None:
            raise ValueError('C1 sampler hash without library')
        self.handle=None;self.reset()

    def reset(self):
        # CPU-only object lifecycle; never a receiver/DMA/display reset.
        if self.handle:self.lib.lane_destroy(self.handle)
        self.handle=self.lib.lane_create()
        if not self.handle:raise MemoryError('lane_create failed')

    def process(self, points, *, session,epoch,sequence,camera,seconds):
        if (len(points)>303 or any(type(v) is not int or not 0<=v<=0xffffffff
                for v in (session,epoch,sequence)) or type(camera) is not int or not 0<=camera<=255
                or not math.isfinite(seconds)):
            raise ValueError('C1 bounded identity/time required')
        previous=None;row_count=0
        for i,p in enumerate(points):
            values=tuple(p[k] for k in ('native_x','native_y','strength','marking_class','width_quarter'))
            x,y,strength,marking,width=values
            if (any(type(v) is not int for v in values) or not 0<=x<1920 or x%2
                    or not 676<=y<=1076 or y%4 or not 0<=strength<=2040
                    or marking not in (1,2) or not 1<=width<=8):
                raise ValueError('invalid C1 native point')
            if previous is not None:
                if y<previous[1] or (y==previous[1] and x-previous[0]<24):
                    raise ValueError('C1 point order or spacing differs')
                row_count=row_count+1 if y==previous[1] else 1
            else:row_count=1
            if row_count>3:raise ValueError('C1 row capacity exceeded')
            self.points[i]=Point(x,y,strength,marking,width);previous=(x,y)
        paths=C.c_int()
        started=time.monotonic_ns()
        n=self.lib.lane_process(self.handle,self.points,len(points),session,epoch,sequence,
            camera,seconds,self.curves,self.assignments,C.byref(paths))
        elapsed=time.monotonic_ns()-started
        if not 0<=n<=2 or not 0<=paths.value<=6:
            raise ValueError('C1 core rejected input or exceeded curve/path bound')
        packed=None
        if self.sampler is not None:
            if self.sampler.c1_lane_sample(self._evaluate,self.curves,n,self._sampled,PACKED_BYTES)!=1:
                raise ValueError('C1 batch sampler rejected native curves')
            packed=bytes(self._sampled)
        curves=[];polylines=[]
        for c in self.curves[:n]:
            if not 3<=c.n<=6 or c.label not in (0,1,2) or not 16<=c.support<=len(points):
                raise ValueError('C1 core output structure differs')
            y=list(c.y[:c.n]);x=list(c.x[:c.n]);tangent=list(c.tangent[:c.n])
            if (not all(math.isfinite(v) for v in y+x+tangent+[c.median_error,c.p90_error,c.score])
                    or any(a>=b for a,b in zip(y,y[1:])) or y[0]<676 or y[-1]>1076):
                raise ValueError('C1 output curve has invalid support/coordinates')
            # Sample only integer rows inside the actual supported y domain.
            # 2px spacing, both supported endpoints included, <=542 vertices.
            if packed is not None:
                offset=len(curves)*PACKED_CURVE_BYTES
                count,label=struct.unpack_from('<II',packed,offset)
                if not 2<=count<=MAX_CURVE_POINTS or label!=c.label:
                    raise ValueError('C1 sampled curve ABI differs')
                poly=list(struct.iter_unpack('<HH',packed[offset+8:offset+8+count*4]))
            else:
                begin,end=math.ceil(y[0]),math.floor(y[-1])
                ys=list(range(begin,end+1,2))
                if ys and ys[-1]!=end:ys.append(end)
                poly=[]
                for yy in ys:
                    xx=self.lib.lane_evaluate(C.byref(c),yy)
                    if not math.isfinite(xx) or not 0<=xx<1920:
                        raise ValueError('C1 curve leaves native display geometry')
                    poly.append((int(math.floor(xx+.5)),yy))
            if not 2<=len(poly)<=MAX_CURVE_POINTS or any(px>=1920 for px,_ in poly):
                raise ValueError('C1 sampled curve bound differs')
            curves.append(dict(y=y,x=x,tangent=tangent,support=c.support,
                label=c.label,track_id=c.track_id,median_error=c.median_error,
                p90_error=c.p90_error,score=c.score))
            polylines.append(poly)
        assignments=list(self.assignments[:len(points)])
        if any(v not in (0,1,2,3) for v in assignments):raise ValueError('C1 invalid support assignments')
        result=dict(curves=curves,assignments=assignments,path_hypotheses=paths.value,
                    polylines=polylines,fit_ns=elapsed)
        if packed is not None:result['packed']=packed
        return result


class FramePackets:
    def __init__(self, core, cohort):
        if not cohort:raise ValueError('explicit receiver cohort required')
        self.core,self.cohort=core,cohort
        self.origin=None;self.previous=None;self.source_type=None;self.previous_ordinal=0

    def packet(self,record,ordinal,received_ns):
        if __package__:
            from .seed1_mode_recipe import L_RECIPE
        else:
            from seed1_mode_recipe import L_RECIPE
        L_RECIPE.validate_record(record)
        if (type(ordinal) is not int or ordinal!=self.previous_ordinal+1 or ordinal>10000
                or type(received_ns) is not int or received_ns<0
                or (self.previous is not None and received_ns<=self.previous)):
            raise ValueError('C1 monotonic receipt/ordinal required')
        s=record.metadata.source
        if any(type(v) is not int or not 0<=v<=0xffffffff for v in (s.session,s.epoch,s.sequence)):
            raise ValueError('C1 requires u32 source identity')
        source_type=(self.cohort,s.camera,s.kind,s.format,s.role)
        if source_type!=self.source_type:
            self.core.reset();self.source_type=source_type
        if self.origin is None:self.origin=received_ns
        summary=L_RECIPE.analysis_summary(record)
        enabled=summary is not None
        if enabled:
            fitted=self.core.process(summary['lane_points'],session=s.session,epoch=s.epoch,
                sequence=s.sequence,camera=s.camera,seconds=(received_ns-self.origin)/1e9)
            status=summary['lane_status'];count=summary['lane_count']
        else:
            # No historical lane survives an ordinary SDR frame/transition.
            self.core.reset()
            fitted=dict(curves=[],assignments=[],polylines=[],path_hypotheses=0,fit_ns=0)
            status=count=0
        curves=fitted['curves'];polys=fitted['polylines']
        lengths=[len(p) for p in polys]+[0]*(2-len(polys))
        labels=[c['label'] for c in curves]+[3]*(2-len(curves))
        pts=ordinal*PTS_STEP
        head=HEADER.pack(MAGIC,len(record.jpeg),int(enabled),pts,s.session,s.epoch,s.sequence,
            s.camera,count,status,*lengths,*labels,fitted['fit_ns'])
        coordinates=b''.join(struct.pack('<HH',x,y) for poly in polys for x,y in poly)
        self.previous,self.previous_ordinal=received_ns,ordinal
        evidence=dict(pts_ns=pts,ordinal=ordinal,source_session=s.session,source_epoch=s.epoch,
            source_sequence=s.sequence,source_camera=s.camera,lane_enabled=enabled,
            lane_status=status,raw_point_count=count,curve_count=len(curves),curves=curves,
            path_hypotheses=fitted['path_hypotheses'],fit_ns=fitted['fit_ns'],
            polyline_points=lengths,polyline_sha256=hashlib.sha256(coordinates).hexdigest(),
            core_input_time_seconds=(received_ns-self.origin)/1e9,
            time_scope='HOST_RECEIPT_MONOTONIC_ORIGIN_NOT_EXPOSURE',
            association='SAME_V4_SOURCE_JPEG_C1_TO_EXACT_DECODED_PTS_AND_SINK')
        return head+coordinates+record.jpeg,evidence
