"""Exact physical-parameter catalogue extracted from seed25's reviewed SDK.

This contains catalogue formatting only; observations still come from the sole
live owner. Generic old r3/high-fps parameter_catalog is deliberately not used.
"""
from linux.task3_pipeline import pcie_protocol_v1 as p
from linux.rk_debug.catalog import BASE_FLAGS, PROCESSING_ENABLES
SOURCE_COMMIT='1a5603c1c8aa58565aa9b5facf40a7478ebcf6ba'
SOURCE_FILE_SHA256='36f292694162b814f621ea25601d69fa9e55d35f9283ab622d8ba9e59caa8af8'

def _parameter(path, minimum, maximum, unit, default, **details):
    row = dict(path=path, access='writable', minimum=minimum, maximum=maximum,
               unit=unit, default=default, **details)
    if minimum == maximum:
        row.update(access='fixed', value=minimum)
    return row

def _parameter_catalog(capabilities, mono):
    """Describe the online JPEG controls of this physical camera profile."""
    base_features = capabilities.features
    quality_default = p.PCIE_CFG_DEFAULT_QUALITY
    if base_features & p.PCIE_CFG_FEATURE_DYNAMIC_QUALITY:
        quality_minimum, quality_maximum = p.PCIE_CFG_MINIMUM_QUALITY, p.PCIE_CFG_MAXIMUM_QUALITY
    else:
        quality_minimum = quality_maximum = quality_default
    budget_available = bool(base_features & p.PCIE_CFG_FEATURE_FRAME_BUDGET)
    restart_available = bool(base_features & p.PCIE_CFG_FEATURE_RESTART)
    base = [
        _parameter('base.mode', p.PCIE_CFG_MODE_COLOR, p.PCIE_CFG_MODE_COLOR, 'enum',
                   p.PCIE_CFG_MODE_COLOR, symbols={'COLOR': p.PCIE_CFG_MODE_COLOR}),
        _parameter('base.quality', quality_minimum, quality_maximum, 'quality', quality_default),
        _parameter('base.flags', 0, int(budget_available), 'bitmask', 0,
                   symbols=dict(BASE_FLAGS) if budget_available else {},
                   depends_on='ADAPTIVE_QUALITY requires nonzero frame_budget'),
        _parameter('base.min_quality', p.PCIE_CFG_MINIMUM_QUALITY, quality_maximum, 'quality',
                   p.PCIE_CFG_MINIMUM_QUALITY, depends_on='min_quality <= quality; used by adaptive quality'),
        _parameter('base.frame_budget', 0, p.MAX_PAYLOAD if budget_available else 0, 'bytes', 0,
                   note='Feedback target for completed JPEG lengths'),
        _parameter('base.restart_mcus', 0, 0xffff if restart_available else 0, 'MCU', 0,
                   note='0 disables restart markers'),
    ]
    modes = {'MONO_SDR': p.PCIE_CFG_V2_MODES_MONO_SDR, 'MONO_HDR': p.PCIE_CFG_V2_MODES_MONO_HDR}
    modes = {name: value for name, value in modes.items() if mono.modes & (1 << value)}
    supported_enables = mono.enables
    if capabilities.camera_present == 3:
        supported_enables &= ~(p.PCIE_CFG_V2_ENABLES_MULTISCALE | p.PCIE_CFG_V2_ENABLES_LANE)
    if not supported_enables & p.PCIE_CFG_V2_ENABLES_MULTISCALE:
        supported_enables &= ~p.PCIE_CFG_V2_ENABLES_LANE
    enables = {name: bit for name, bit in PROCESSING_ENABLES.items() if supported_enables & bit}
    schema2 = [
        _parameter('extension.schema', p.PCIE_CFG_V2_SCHEMA, p.PCIE_CFG_V2_SCHEMA, 'enum', p.PCIE_CFG_V2_SCHEMA),
        _parameter('extension.product_mode', min(modes.values(), default=0), max(modes.values(), default=0),
                   'enum', p.PCIE_CFG_V2_MODES_MONO_SDR, symbols=modes),
        _parameter('extension.processing_enables', 0, sum(enables.values()), 'bitmask', 0,
                   symbols=enables, depends_on='LANE requires MULTISCALE'),
    ]
    if 'MONO_HDR' in modes:
        hdr_fields = [
            ('hdr_ratio', 4, 4, 'log2'),
            ('hdr_black_long', 50, 50, 'RAW10 code'),
            ('hdr_black_short', 50, 50, 'RAW10 code'),
            ('hdr_motion_base', 0, 0x3fff, 'RAW14 code'),
            ('hdr_motion_shift', 0, 15, 'bit'),
            ('hdr_qualification', p.PCIE_CFG_EXT_HDR_QUALIFICATION_REQUIRED,
             p.PCIE_CFG_EXT_HDR_QUALIFICATION_REQUIRED, 'bitmask'),
            ('hdr_max_delta_ns', 0, 0xffffffff, 'ns'),
            ('hdr_max_wait_ns', 1, 0xffffffff, 'ns'),
            ('hdr_max_age_ns', 1, 0xffffffff, 'ns'),
        ]
        for name, minimum, maximum, unit in hdr_fields:
            default = minimum if minimum == maximum else None
            schema2.append(_parameter(f'extension.{name}', minimum, maximum, unit, default,
                                      disabled_value=0, depends_on='Physical DOL2 HDR'))
    schema2.append(_parameter('extension.dehaze_lut_generation', 0, int('DEHAZE' in enables), 'enum', 0,
                              disabled_value=0, depends_on='DEHAZE enable',
                              note='0 and 1 select the built-in estimator'))
    return dict(base=base, schemas={'2': schema2}, constraints={
        'dual_d2_quality': quality_default, 'raw_online_cfg': False, 'host_lut_upload': False,
    })
