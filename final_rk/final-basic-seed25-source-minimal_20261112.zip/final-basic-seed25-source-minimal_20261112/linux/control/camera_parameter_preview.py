"""Display accepted schema2 ISP combinations without a legacy mode176 guard."""
from dataclasses import asdict

try:
    from .camera_mono_yolo_preview import MonoYoloPreview
    from . import camera_raw_release as release
except ImportError:
    from camera_mono_yolo_preview import MonoYoloPreview
    import camera_raw_release as release


class ParameterPreview(MonoYoloPreview):
    def _lane(self,item,received):
        # Router/SharedStereoReceiver already checked the complete actual
        # profile, SOURCE and sparse contexts. Do not change processing_mode,
        # HDR role or flags to satisfy the historical mask48-only inspector.
        mask=release.confirmed_processing_mask(item.record.metadata,source_epoch=item.epoch)
        summary=dict(session=item.session,epoch=item.epoch,sequence=item.sequence,camera=item.camera,
            processing_enables=mask,hdr_merged=bool(item.record.metadata.record_flags&1),
            f22_enabled=bool(mask&16),lane_enabled=bool(mask&32),f22=None,lane_status=None,lane_count=None)
        analysis=item.record.s07
        if mask&16:
            from linux.task3_pipeline.record_v4 import SparseLaneRecords,SparseLaneRecord
            from linux.task3_pipeline.record_v3 import MultiscaleRecord
            if (self.cameras!=1 or not isinstance(analysis,SparseLaneRecords)
                    or analysis.enabled!=mask>>4 or not isinstance(analysis.f22,MultiscaleRecord)):
                raise ValueError('accepted same-source multiscale sparse record required')
            f22=analysis.f22
            summary['f22']=dict(ok=bool(f22.ok),error=f22.error,width=f22.width,height=f22.height,
                threshold=f22.threshold,scales=[asdict(scale)for scale in f22.scales],fused=asdict(f22.fused))
            if analysis.frame_error or f22.error or not f22.ok:
                with self.cv:self.cache['fpga_analysis']=summary
                raise ValueError('FPGA analysis terminal error')
        if not mask&32:
            with self.cv:self.cache['fpga_analysis']=summary
            return None
        if not mask&16 or not isinstance(analysis.f23,SparseLaneRecord):
            raise ValueError('accepted same-source F22/F23 lane record required')
        lane=analysis.f23
        summary.update(lane_status=lane.status,lane_count=lane.count)
        with self.cv:self.cache['fpga_analysis']=summary
        if lane.status not in (0,1) or (lane.status==0)!=(lane.count>0):
            raise ValueError('FPGA lane terminal error')
        points=[dict(native_x=point.native_x,quarter_y=point.quarter_y,native_y=point.native_y,
            strength=point.strength,width_quarter=point.width_quarter,marking_class=point.marking_class)
            for point in lane.points]
        context=(item.session,item.epoch)
        if context!=self.lane_context:
            self.lane_core.reset();self.lane_context=context;self.lane_origin=received
        result=self.lane_core.process(points,session=item.session,epoch=item.epoch,sequence=item.sequence,
            camera=item.camera,seconds=(received-self.lane_origin)/1e9)
        return dict(polylines=result['polylines'],labels=[row['label']for row in result['curves']],
            packed=result.get('packed'),curve_count=len(result['curves']))
