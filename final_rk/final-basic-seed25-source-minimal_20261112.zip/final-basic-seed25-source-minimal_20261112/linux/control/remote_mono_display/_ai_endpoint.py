"""Small ctypes control plane for the private NV12 overlay element.

No libraries are loaded on import. Keep both the GI element and CDLL alive;
the C handle is borrowed. Controls update metadata only, never video pixels.
"""
import ctypes as C
from pathlib import Path


class Context(C.Structure):
    _fields_ = [(n,C.c_uint32) for n in
        ('session','epoch','camera','kind','format','role','cohort_len')] + [('cohort',C.c_char*64)]


class Box(C.Structure):
    _fields_ = [(n,C.c_int32) for n in ('x1','y1','x2','y2','level')] + [('label',C.c_char*48)]


FIELDS = ('abi_version frames_seen overlay_frames passthrough_frames map_failures unsupported_frames '
          'lock_misses metadata_overwrites frame_misses result_updates result_rejects expired_frames '
          'context_resets table_size enabled generation result_sequence result_count copied_bytes draw_ns_total').split()


class Stats(C.Structure):
    _fields_ = [(n,C.c_uint64) for n in FIELDS]


class DmaStats(C.Structure):
    _fields_ = [(n,C.c_uint64) for n in ('sync_starts','sync_ends','sync_failures','dmabuf_frames')]


assert (C.sizeof(Context),C.sizeof(Box),C.sizeof(Stats),C.sizeof(DmaStats)) == (92,68,160,32)


def make_context(key):
    if type(key) is not tuple or len(key)!=7:
        raise ValueError('cohort and six SOURCE context fields required')
    cohort,*numbers=key
    if type(cohort) is not str:
        raise ValueError('explicit cohort required')
    encoded=cohort.encode('ascii')
    if not 1<=len(encoded)<=64 or any(not 33<=b<=126 for b in encoded):
        raise ValueError('bounded printable receiver cohort required')
    if any(type(v) is not int or not 0<=v<2**32 for v in numbers):
        raise ValueError('explicit uint32 SOURCE context required')
    return Context(*numbers,len(encoded),encoded)


def uint(value,bits=64):
    if type(value) is not int or not 0<=value<2**bits:
        raise ValueError('bounded unsigned integer required')
    return value


def gobject_pointer(element):
    # PyGObject exposes an actual PyCapsule; do not assume hash(obj) is a pointer.
    capsule=element.__gpointer__
    get_name=C.pythonapi.PyCapsule_GetName
    get_name.argtypes=[C.py_object];get_name.restype=C.c_char_p
    get_pointer=C.pythonapi.PyCapsule_GetPointer
    get_pointer.argtypes=[C.py_object,C.c_char_p];get_pointer.restype=C.c_void_p
    return get_pointer(capsule,get_name(capsule))


_REGISTERED_LIBRARIES = {}


class NativeLibrary:
    def __init__(self,path):
        self.path=Path(path).resolve(strict=True)
        self.lib=C.CDLL(str(self.path))
        signatures={
            'register_element':([],C.c_int),
            'get_handle':([C.c_void_p],C.c_void_p),
            'enable':([C.c_void_p,C.c_int,C.POINTER(Context),C.c_uint64,C.c_uint64],C.c_int),
            'register_frame':([C.c_void_p,C.c_uint64,C.POINTER(Context),C.c_uint32],C.c_int),
            'update_latest':([C.c_void_p,C.c_uint64,C.POINTER(Context),C.c_uint32,C.c_uint64,C.POINTER(Box),C.c_uint32],C.c_int),
            'clear':([C.c_void_p,C.c_uint64],C.c_int),
            'stats':([C.c_void_p,C.POINTER(Stats)],C.c_int),
            'dma_stats':([C.c_void_p,C.POINTER(DmaStats)],C.c_int)}
        for name,(arguments,result) in signatures.items():
            fn=getattr(self.lib,'y26_async_'+name);fn.argtypes=arguments;fn.restype=result

    def register(self):
        if self.lib.y26_async_register_element()!=1:
            raise RuntimeError('NV12 overlay factory registration failed')
        # GType keeps callback pointers even after an individual graph dies.
        _REGISTERED_LIBRARIES[str(self.path)] = self


class NativeEndpoint:
    def __init__(self,library,element,*,ttl_ns=500_000_000):
        self.library,self.element=library,element
        self.ttl_ns=uint(ttl_ns)
        self.handle=library.lib.y26_async_get_handle(gobject_pointer(element))
        if not self.handle:
            raise ValueError('wrong native overlay element')
        self.registration_errors=0
        self.last_registration_error=None

    def enable(self,*,enabled,generation,context=None):
        if type(enabled) is not bool:
            raise ValueError('explicit enabled bool required')
        ctx=make_context(context) if enabled else None
        return self.library.lib.y26_async_enable(self.handle,int(enabled),
            C.byref(ctx) if ctx is not None else None,uint(generation),self.ttl_ns)

    def update(self,*,generation,context,result_source_seq,received_ns,boxes):
        ctx=make_context(context)
        if type(boxes) is not tuple or len(boxes)>300:
            raise ValueError('bounded immutable boxes required')
        values=(Box*len(boxes))()
        for index,box in enumerate(boxes):
            coords=[box[n] for n in ('x1','y1','x2','y2','level')]
            if any(type(v) is not int or not -(2**31)<=v<2**31 for v in coords):
                raise ValueError('explicit integer coordinates required')
            text=box['label'].encode('ascii')
            if len(text)>47 or any(not 32<=v<=126 for v in text):
                raise ValueError('bounded printable label required')
            values[index]=Box(*coords,text)
        return self.library.lib.y26_async_update_latest(self.handle,uint(generation),C.byref(ctx),
            uint(result_source_seq,32),uint(received_ns),values,len(boxes))

    def clear(self,*,generation):
        return self.library.lib.y26_async_clear(self.handle,uint(generation))

    def register_frame(self,pts,identity):
        try:
            if type(identity) not in (tuple,list) or len(identity)!=8:
                raise ValueError('video identity must include cohort and full SOURCE')
            cohort,session,epoch,sequence,camera,kind,fmt,role=identity
            ctx=make_context((cohort,session,epoch,camera,kind,fmt,role))
            ok=self.library.lib.y26_async_register_frame(self.handle,uint(pts),C.byref(ctx),uint(sequence,32))
            if not ok:self.registration_errors+=1
        except Exception as error:
            self.registration_errors+=1
            self.last_registration_error=str(error)[:256]
        # Metadata problems bypass only overlay; never stop original video.

    def stats(self):
        result=Stats();dma=DmaStats()
        if self.library.lib.y26_async_stats(self.handle,C.byref(result))!=1 or result.abi_version!=1:
            raise RuntimeError('native overlay ABI/stats mismatch')
        if self.library.lib.y26_async_dma_stats(self.handle,C.byref(dma))!=1:
            raise RuntimeError('native DMA stats mismatch')
        return dict(**{name:getattr(result,name) for name in FIELDS},
            dma={name:getattr(dma,name) for name,_ in DmaStats._fields_},
            registration_errors=self.registration_errors,last_registration_error=self.last_registration_error,
            same_frame_required=False,ttl_ns=self.ttl_ns)


class ContextRegistry(dict):
    """Register native metadata before the existing graph pushes that PTS."""
    def __init__(self,endpoint):
        super().__init__();self.endpoint=endpoint

    def __setitem__(self,pts,row):
        if row.get('route')=='original':
            self.endpoint.register_frame(pts,row.get('identity'))
        super().__setitem__(pts,row)
