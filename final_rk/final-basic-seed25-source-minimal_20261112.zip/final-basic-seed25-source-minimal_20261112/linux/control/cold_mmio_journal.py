"""Bounded observations of existing cold-owner calls; no additional device IO.

Keeps first 128 and last 512 operations plus up to 32 writes. Last-read values
are individually timed observations, never an atomic or post-fault BAR dump.
"""
from collections import deque
from copy import deepcopy
import time


class ColdMmioJournal:
    def __init__(self, *, clock=time.monotonic):
        self.clock = clock
        self.phase = 'ADMISSION'
        self.total = 0
        self.first = []
        self.tail = deque(maxlen=512)
        self.writes = []
        self.omitted_writes = 0
        self.last_reads = {}
        self.omitted_read_addresses = 0

    def call(self, operation, offset, callback, value=None):
        if operation not in ('READ', 'WRITE'):
            raise ValueError('explicit READ or WRITE required')
        self.total += 1
        row = dict(sequence=self.total, phase=self.phase, operation=operation,
            offset=offset, begin_monotonic_s=self.clock(), end_monotonic_s=None,
            outcome='CALL_ENTERED_RESULT_NOT_OBSERVED')
        if operation == 'WRITE':
            row['requested_value'] = value
            if len(self.writes) < 32:
                self.writes.append(row)
            else:
                self.omitted_writes += 1
        if len(self.first) < 128:
            self.first.append(row)
        else:
            self.tail.append(row)
        try:
            result = callback(offset) if operation == 'READ' else callback(offset, value)
        except BaseException as error:
            row.update(end_monotonic_s=self.clock(), outcome='CALL_RAISED_IO_EFFECT_NOT_INFERRED',
                error=type(error).__name__+': '+str(error)[:512])
            raise
        row.update(end_monotonic_s=self.clock(), outcome='RETURNED')
        if operation == 'READ':
            row['returned_value'] = result
            key = hex(offset)
            if key in self.last_reads or len(self.last_reads) < 128:
                self.last_reads[key] = row
            else:
                self.omitted_read_addresses += 1
        return result

    def snapshot(self):
        retained = self.first+list(self.tail)
        return deepcopy(dict(total_calls=self.total, operations=retained,
            omitted_operations=self.total-len(retained),
            operations_complete=self.total==len(retained),
            writes=self.writes, omitted_writes=self.omitted_writes,
            last_successful_reads=self.last_reads,
            omitted_read_address_observations=self.omitted_read_addresses,
            bounds=dict(first=128,tail=512,writes=32,read_addresses=128),
            scope='EXISTING_OWNER_CALLS_ONLY_NO_EXTRA_IO_NO_RETRY',
            read_semantics='INDIVIDUALLY_TIMED_CACHED_VALUES_NOT_ATOMIC_NOT_POST_FAILURE_READBACK',
            time_basis='RK_HOST_MONOTONIC_CALL_BOUNDARIES_NOT_FPGA_EVENT_TIMESTAMPS'))
