"""CAMERA_RAW-specific topology/lane metadata over the established HUD ABI."""
import ctypes as C
import struct

try:
    from .unified_stereo_native import StereoHud
    from . import camera_raw_release as release
except ImportError:
    from unified_stereo_native import StereoHud
    import camera_raw_release as release


class CameraHud(StereoHud):
    def __init__(self,path,expected_sha256,*,cameras,product,preview_policy=None):
        if cameras not in (1,2) or product!='jpeg':raise ValueError('JPEG display topology required; RAW receive-only')
        super().__init__(path,expected_sha256)
        self.cameras,self.product=cameras,product;self.latest=None;self._tokens=[0,0];self._details={}
        self.lib.cr_hud_topology.argtypes=[C.c_uint];self.lib.cr_hud_topology.restype=C.c_int
        self.lib.cr_hud_lane.argtypes=[C.c_uint64,C.c_void_p,C.c_uint,C.c_uint];self.lib.cr_hud_lane.restype=C.c_int
        if self.lib.cr_hud_topology(cameras)!=1:raise ValueError('one cold native topology required')
        self.preview_policy=preview_policy
        if preview_policy is not None:
            if (not isinstance(preview_policy,dict) or preview_policy!=release.JPEG_DISPLAY_POLICY or
                    type(preview_policy.get('threads_per_eye')) is not int):
                raise ValueError('explicit CAMERA_RAW JPEG preview policy required')
            self.lib.cr_hud_preview_policy.argtypes=[C.c_uint];self.lib.cr_hud_preview_policy.restype=C.c_int
            self.lib.cr_hud_frame_duration.argtypes=[C.c_uint,C.c_uint64,C.c_uint64];self.lib.cr_hud_frame_duration.restype=C.c_int
            self.lib.cr_hud_duration_stats.argtypes=[C.POINTER(C.c_uint64),C.c_uint];self.lib.cr_hud_duration_stats.restype=C.c_int
            if self.lib.cr_hud_preview_policy(preview_policy['threads_per_eye'])!=1:
                raise RuntimeError('CAMERA_RAW preview policy must be configured before attach/input')

    def register(self,item,pts,received,*,lane=None):
        super().register(item,pts,received)
        period=None
        if self.preview_policy:
            period=release.frame_duration_ns(self.cameras,item.record.metadata.record_flags)
            if self.lib.cr_hud_frame_duration(item.camera,pts,period)!=1:
                raise RuntimeError('CAMERA_RAW exact frame duration rejected')
        details=dict(product='AJPG',job_id=item.record.metadata.job_id)
        # The SDK has already strictly accepted this owned wire. Quality is
        # byte22 of the common AJPG header; retain it on this exact selected
        # token, independently of later CFG requests or other decoder inputs.
        wire=getattr(item,'wire',None)
        if wire is not None:
            if type(wire) is not bytes or len(wire)<64 or wire[:4]!=b'AJPG' or not 1<=wire[22]<=100:
                raise ValueError('verified AJPG quality header required')
            details['quality']=wire[22]
        metadata=item.record.metadata
        if getattr(metadata,'source',None) is not None:
            details.update(processing_enables=release.confirmed_processing_mask(metadata,source_epoch=item.epoch),
                           hdr_merged=bool(metadata.record_flags&1))
        self._tokens[item.camera]+=1;key=(item.camera,self._tokens[item.camera]);self._details[key]=details
        for old in tuple(self._details):
            if old[0]==item.camera and old[1]+640<key[1]:del self._details[old]
        if lane is not None:
            if self.cameras!=1 or self.product!='jpeg':raise ValueError('lane overlay requires mono JPEG')
            if lane.get('packed') is not None:packed=lane['packed']
            else:
                packed=bytearray(4352)
                for i,(points,label) in enumerate(zip(lane['polylines'],lane['labels'])):
                    if i>=2 or not 2<=len(points)<=542:raise ValueError('bounded lane curves required')
                    struct.pack_into('<II',packed,i*2176,len(points),label)
                    for j,(x,y) in enumerate(points):struct.pack_into('<HH',packed,i*2176+8+j*4,x,y)
                packed=bytes(packed)
            if type(packed) is not bytes or len(packed)!=4352:raise ValueError('fixed lane blob required')
            blob=C.create_string_buffer(packed)
            if self.lib.cr_hud_lane(pts,blob,len(packed),lane['curve_count'])!=1:raise RuntimeError('same-frame lane metadata rejected')
        return period

    def frame_timing_snapshot(self):
        fields=('abi enabled missing0 missing1 filled0 filled1 other0 other1 '
                'last_original0 last_original1 last_expected0 last_expected1').split()
        values=(C.c_uint64*len(fields))()
        if self.lib.cr_hud_duration_stats(values,len(values))!=1 or values[0]!=1:
            raise ValueError('CAMERA_RAW input duration ABI differs')
        return dict(zip(fields,map(int,values)))

    def take(self,ordinal,pts):
        value=super().take(ordinal,pts);value['cameras']=value['cameras'][:self.cameras]
        for row in value['cameras']:
            details=self._details.get((row['camera'],row['token']))
            if details is None:raise ValueError('selected frame provenance evicted or unknown')
            row.update(details)
        self.latest=dict(value,ordinal=ordinal);return value
