"""ACTIVE-preserving online CFG patches under the single retained video owner."""
from copy import deepcopy
from dataclasses import asdict
import threading
import time

try:
    from .camera_mono_yolo_owner import MonoYoloOwner
    from .camera_parameter_control import parameter_model,baseline,plain
    from .camera_parameter_preview import ParameterPreview
except ImportError:
    from camera_mono_yolo_owner import MonoYoloOwner
    from camera_parameter_control import parameter_model,baseline,plain
    from camera_parameter_preview import ParameterPreview


def receipt_document(receipt,expected):
    base=asdict(receipt.configuration)
    if base.get('mode')==0 and expected['base'].get('mode')=='COLOR':base['mode']='COLOR'
    return dict(schema=2,base=base,extension=asdict(receipt.extension))


def matches_product(row,proof):
    """Only accepted SDK records or exact selected HUD scalars may qualify."""
    document=proof['document'];base=document['base'];extension=document['extension']
    for key in ('session','epoch','processing_enables','quality'):
        if type(row.get(key)) is not int:return False
    if type(row.get('hdr_merged')) is not bool:return False
    if ((row['session'],row['epoch'],row['processing_enables'],row['hdr_merged'])!=
            (proof['session'],proof['epoch'],extension['processing_enables'],extension['product_mode']==2)):
        return False
    lower=base['min_quality'] if base['flags']&1 else base['quality']
    return lower<=row['quality']<=base['quality']


class ParameterOwner(MonoYoloOwner):
    def __init__(self,*args,parameter_model=None,**kwargs):
        self.parameter_model=parameter_model or globals()['parameter_model']()
        self.parameter_snapshot=None;self.parameter_transaction=None
        kwargs.setdefault('preview_factory',ParameterPreview)
        super().__init__(*args,**kwargs)

    def _capture_parameters(self):
        prior=getattr(self,'parameter_snapshot',None)
        policy=(prior.get('hdr_policy') if prior is not None and prior.get('hdr_policy') is not None
                else self.config.get('hdr_policy'))
        return self.parameter_model.capture(self.cold,confirmed_hdr_policy=policy)

    def _make_reader(self):
        reader=super()._make_reader()
        snapshot=self._capture_parameters()
        self.parameter_snapshot=deepcopy(snapshot)
        self.broker.install_snapshot(snapshot)
        self._event('PARAMETERS_INITIAL_ACTIVE',snapshot=snapshot)
        return reader

    def _start_mode(self,request):
        if self.command is not None or self.mode_pending is not None:
            raise RuntimeError('one parameter/mode/quality transaction at a time')
        key=request['request_id'];expected_baseline=self.broker.transaction_baseline(key)
        original=deepcopy(self.broker.commands[key]['request'])
        want_yolo=(original.get('mode')=='yolo' if original['action']=='mode' else self.broker.current_mode=='yolo')
        if want_yolo and self.cameras!=1:raise ValueError('YOLO requires mono CAM0')
        done=threading.Event()
        state=dict(done=done,request=request,value=None,error=None,precommit_error=None)
        self.command=state
        def apply():
            # Everything before the OFF/intent boundary is read-only. A stale
            # panel or rejected patch therefore leaves the current AI/video on.
            try:
                before=self._capture_parameters()
                if baseline(before)!=expected_baseline:raise ValueError('ACTIVE baseline changed; refresh parameter panel')
                if original['action']=='parameters':
                    document=self.parameter_model.merge_patch(before,original['patch'])
                elif original['action']=='quality':
                    document=self.parameter_model.merge_patch(before,{'base.quality':original['quality']})
                else:document=self.parameter_model.preset(before,original['mode'])
                self.parameter_model.validate_document(before,document)
                if original['action']!='mode' and document==before['active_document']:
                    raise ValueError('configuration has no ACTIVE change')
                if self.stop_event.is_set():raise ValueError('stopped before configuration intent')
            except BaseException as error:
                state['precommit_error']=type(error).__name__+': '+str(error)[:512]
                done.set();return
            try:
                if self.cameras==1:
                    try:self.preview.set_ai(False)
                    except BaseException as error:self.broker.note_ai_error(error)
                # Linearize accepting this one CFG intent with HTTP STOP. A
                # transaction already accepted may finish; no retry is made.
                with self.broker.lock:
                    if self.stop_event.is_set():
                        state['precommit_error']='stopped before configuration intent';return
                    state.update(before=deepcopy(before),document=deepcopy(document),intent=True)
                receipt=self.cold.apply_document(document)
                state['value']=receipt
                if ((receipt.session,receipt.mode_epoch)!=(before['session'],before['epoch']+1)
                        or receipt_document(receipt,document)!=document):
                    raise ValueError('APPLIED full snapshot differs from requested document')
                after=self._capture_parameters()
                if ((after['session'],after['epoch'])!=(receipt.session,receipt.mode_epoch)
                        or after['active_document']!=document):
                    raise ValueError('ACTIVE full snapshot differs from APPLIED document')
                state['after']=deepcopy(after);self.parameter_snapshot=deepcopy(after)
                yolo=want_yolo and plain(document)
                accepted=self.broker.prepare_confirmation(key,before,document,after,yolo=yolo)
                if want_yolo and not yolo:
                    with self.broker.lock:
                        self.broker.commands[key]['ai_transition']='EXITED_INELIGIBLE_CONFIGURATION'
                if accepted and yolo and not self.stop_event.is_set():
                    try:
                        if self.preview.set_ai(True,session=receipt.session,epoch=receipt.mode_epoch) is False:
                            self.broker.note_ai_error('YOLO enable failed; actual FPGA video retained')
                    except BaseException as error:self.broker.note_ai_error(error)
            except BaseException as error:state['error']=type(error).__name__+': '+str(error)[:512]
            finally:done.set()
        seconds=self.config.get('mode_confirmation_s',30)
        self.grace_deadline=self.clock()+seconds
        self.preview.transition_until(time.monotonic_ns()+int(seconds*1e9))
        state['thread']=threading.Thread(target=apply,name='camera-parameter-cfg',daemon=True)
        self._event('PARAMETER_CONFIGURATION_REQUEST',request_id=key,action=original['action'],baseline=expected_baseline)
        state['thread'].start()

    def _configuration_applied(self,request,receipt):
        key=request['request_id'];proof=self.broker.parameter_pending
        if proof is None or receipt_document(receipt,proof['document'])!=proof['document']:
            raise ValueError('full requested/APPLIED configuration proof required')
        self._event('PARAMETER_CONFIGURATION_APPLIED',request_id=key,receipt=asdict(receipt),
            active_snapshot=self.parameter_snapshot)
        return self.broker.confirm_applied(key,receipt)

    def _configuration_video(self,request_id,epoch,rendered):
        proof=self.broker.parameter_pending
        if proof is None or (proof['request_id'],proof['epoch'])!=(request_id,epoch):return False
        # Every active eye needs its real new accepted header. Only visible
        # eyes must also be selected by the compositor; alpha0 eyes may be held.
        products=self.router.last_products[:self.cameras]
        if len(products)!=self.cameras or any(not row or not matches_product(row,proof)for row in products):return False
        if rendered.get('layout')=='both':visible=set(range(self.cameras))
        elif rendered.get('layout') in ('cam0','cam1'):visible={0 if rendered['layout']=='cam0' else 1}
        else:return False
        rows={row['camera']:row for row in rendered.get('cameras',[])}
        if not visible or not visible<=set(range(self.cameras)) or any(
                c not in rows or not matches_product(rows[c],proof)for c in visible):return False
        qualities={c:products[c]['quality'] for c in range(self.cameras)}
        qualities.update({c:rows[c]['quality'] for c in visible})
        completed=self.broker.completed_configuration(request_id,epoch,rendered['ordinal'],qualities)
        self._event('PARAMETER_CONFIGURATION_VIDEO',request_id=request_id,session=proof['session'],
            epoch=epoch,ordinal=rendered['ordinal'],actual_quality=qualities,waiting_ai=not completed)
        return True

    def _control(self,preview):
        if self.command is not None and self.command['done'].is_set() and self.command.get('precommit_error'):
            state=self.command;self.command=None
            self.broker.reject_before_commit(state['request']['request_id'],state['precommit_error'])
            self.grace_deadline=0;self.preview.transition_until(0)
            self._event('PARAMETER_CONFIGURATION_REJECTED',request_id=state['request']['request_id'],error=state['precommit_error'])
        return super()._control(preview)

    def snapshot(self):
        value=super().snapshot()
        value['fpga_parameters']=deepcopy(self.parameter_snapshot)
        return value
