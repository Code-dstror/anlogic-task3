"""Offline by default: seed25 normal same-owner JPEG session rebuild candidate."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
sys.dont_write_bytecode=True
import threading
from types import ModuleType
from uuid import UUID

try:
    from . import camera_raw_release as release
    from .launch_unified_stereo import checked_index
except ImportError:
    import camera_raw_release as release
    from launch_unified_stereo import checked_index


def verify_native_paths(config,control,index):
    """Validate sealed JPEG library files without dlopen, devices or SDK IO."""
    if config.get('product')=='raw':return 'NOT_APPLICABLE_RAW_RECEIVE_ONLY'
    if config.get('product')!='jpeg':raise ValueError('explicit JPEG/RAW product required')
    control=Path(control).resolve(strict=True)
    roles=(('hud_library','hud_sha256','libcamera_raw_hud.so'),
           ('record_library','record_library_sha256','libremote_mono_display.so'),
           ('lane_library','lane_sha256','liblane_tracker.so'),
           ('lane_sampler_library','lane_sampler_sha256','libc1_lane_sampler.so'))
    if 'mono_yolo' in config:
        roles+=(('mono_yolo_overlay_library','mono_yolo_overlay_sha256','libcamera_mono_yolo_overlay.so'),)
    for field,hash_field,name in roles:
        path=control/'lib'/name;value=config.get(field)
        if not isinstance(value,str) or value!=str(path):
            raise ValueError(field+' must name the current control/lib/'+name)
        row=index.get('lib/'+name)
        if (not isinstance(row,dict) or type(row.get('bytes')) is not int or row['bytes']<64 or
                config.get(hash_field)!=row.get('sha256')):
            raise ValueError(field+' sealed size/hash declaration differs')
        try:
            info=path.lstat()
            if not stat.S_ISREG(info.st_mode) or path.resolve(strict=True)!=path or info.st_size!=row['bytes']:
                raise ValueError(field+' must be an ordinary non-symlink sealed file')
            body=path.read_bytes()
        except OSError as error:
            raise ValueError(field+' native file is unavailable: '+str(path)) from error
        if len(body)!=row['bytes'] or hashlib.sha256(body).hexdigest()!=row.get('sha256'):
            raise ValueError(field+' actual native size/SHA256 differs')
        if body[:7]!=b'\x7fELF\x02\x01\x01' or int.from_bytes(body[18:20],'little')!=183:
            raise ValueError(field+' must be an ARM64 little-endian ELF64 library')
    return 'VERIFIED'


def main(argv=None,*,mono_yolo=False,fpga_parameters=False):
    p=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    p.add_argument('--integration-config',type=Path,required=True);p.add_argument('--check-only',action='store_true');p.add_argument('--run',action='store_true')
    p.add_argument('--check-native-files',action='store_true',help='with --check-only, verify actual sealed ARM64 JPEG library paths without loading them')
    p.add_argument('--run-dir',type=Path);p.add_argument('--expected-boot');p.add_argument('--expected-bdf');p.add_argument('--bit-sha256')
    p.add_argument('--joint-cold-confirmed',action='store_true');p.add_argument('--programming-note')
    p.add_argument('--kms-selection',type=Path);p.add_argument('--kms-selection-sha256')
    p.add_argument('--raw-driver-audit',type=Path);p.add_argument('--raw-driver-audit-sha256')
    p.add_argument('--session-driver-audit',type=Path);p.add_argument('--session-driver-audit-sha256')
    a=p.parse_args(argv);sys.dont_write_bytecode=True
    if a.check_native_files and (not a.check_only or a.run):p.error('--check-native-files requires --check-only without --run')
    control=Path(__file__).resolve().parent;index=checked_index(control,'content-index.json')
    if a.integration_config.stat().st_size>32768:raise ValueError('bounded integration config required')
    config=json.loads(a.integration_config.read_text());spec=release.verify_integration(config)
    if spec['product']!='jpeg' or config.get('session_rebuild')!=dict(version=1,ioctl='0xc0404846',policy='SAME_OWNER_JPEG_REBUILD_V1'):
        raise ValueError('explicit seed25 JPEG session rebuild policy required')
    lock=json.loads((control/'camera-runtime-lock.json').read_text())
    if config.get('runtime_index_sha256')!=lock['runtime_index_sha256']:raise ValueError('CAMERA_RAW runtime lock differs')
    runtime=Path(config['runtime_root']).resolve(strict=True);checked_index(runtime,'runtime-index.json',lock['runtime_index_sha256'])
    if (config.get('hud_sha256')!=index['lib/libcamera_raw_hud.so']['sha256'] or
            config.get('record_library_sha256')!=index['lib/libremote_mono_display.so']['sha256']):
        raise ValueError('sealed CAMERA_RAW native libraries differ')
    if a.bit_sha256 is not None and a.bit_sha256!=release.BIT:raise ValueError('exact CAMERA_RAW seed92 bit required')
    native_files=verify_native_paths(config,control,index) if a.run or a.check_native_files else 'NOT_CHECKED'
    ai_assets=None
    if fpga_parameters and (not mono_yolo or config.get('fpga_parameter_policy')!='FINAL_BASIC_PARAMETERS_V1'):
        raise ValueError('explicit final_basic FPGA parameter policy and mono YOLO application required')
    if mono_yolo:
        try:from .camera_mono_yolo_assets import verify_packaged,verify_live_dependencies
        except ImportError:from camera_mono_yolo_assets import verify_packaged,verify_live_dependencies
        if config.get('mono_yolo_policy')!='MONO_CAM0_ASYNC_NPU_FINAL_HDMI_V1':
            raise ValueError('explicit mono YOLO application policy required')
        ai_assets=verify_packaged(config['mono_yolo'],control)
    if a.check_only or not a.run:
        print(json.dumps(dict(status='OFFLINE_ADAPTED_NOT_BOARD_ACCEPTANCE',cold_session=config['cold_session'],cameras=spec['cameras'],
            product=spec['product'],modes=release.modes(config['cold_session'])+(
                [dict(id='yolo',label='YOLO 多目标检测与测距',rk_ai=True)] if mono_yolo and spec['cameras']==1 else []),max_seconds=None,max_commands=None,
            bit_sha256=release.BIT,source_commit=release.SOURCE,hardware_actions=0,
            raw_driver='TARGET_SESSION_DRIVER_BUILD_AND_LOAD_AUDIT_REQUIRED',
            raw_isp_display='DEFERRED_BY_USER',hdmi=spec['product']=='jpeg',native_files=native_files,
            mono_yolo_assets=ai_assets,
            fpga_parameters='OWNER_CAPS_ACTIVE_READ_REQUIRED' if fpga_parameters else None),ensure_ascii=False));return 0
    if (a.bit_sha256!=release.BIT or not a.joint_cold_confirmed or not a.programming_note or not a.expected_boot or
            str(UUID(a.expected_boot))!=a.expected_boot or a.run_dir is None):raise ValueError('current boot/joint-cold/programming receipts required')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=a.expected_boot:raise ValueError('actual boot differs')
    sys.path[:0]=[str(control),str(runtime)]
    if mono_yolo:
        if spec['cameras']==1:verify_live_dependencies(config['mono_yolo'])
        sys.path.insert(0,config['mono_yolo']['ai_runner_root'])
        os.environ.update(Y26_RGB_SWAP_NATIVE='0',Y26_RGA_IMPORT_CACHE='1')
    from launch_calfix_algorithm_trial import trial_guards
    from handoff import save_new
    if any(os.path.lexists(path) for path in trial_guards(a.expected_boot)):raise ValueError('prior native/video attempt this boot; no hot reopen')
    if spec['product']=='jpeg':
        if a.kms_selection is None or a.kms_selection_sha256 is None:raise ValueError('current exclusive KMS receipt required')
        from kms_display import load_selection
        selected=load_selection(a.kms_selection,a.kms_selection_sha256,a.expected_boot,live=True)
        if (config['connector_id'],config['plane_id'])!=(selected['connector_id'],selected['plane_id']):raise ValueError('KMS route differs')
        import dual_r3_driver as driver
        if a.session_driver_audit is None or a.session_driver_audit_sha256 is None:
            raise ValueError('exact target session-driver audit required; existing N2 KO is insufficient')
        from camera_session_driver import check_target
        target=check_target(a.session_driver_audit,a.session_driver_audit_sha256,boot=a.expected_boot,source_hashes=lock['session_driver_source_sha256'],expected_bdf=a.expected_bdf)
        from fps_hud import verify_libraries
        verify_libraries('dual')
    else:
        if a.raw_driver_audit is None or a.raw_driver_audit_sha256 is None:raise ValueError('RAW target-built module audit required; SDK candidate is not load-qualified')
        from camera_raw_driver import check_target
        target=check_target(a.raw_driver_audit,a.raw_driver_audit_sha256,boot=a.expected_boot,source_hashes=lock['raw_source_sha256'],expected_bdf=a.expected_bdf)
    run=a.run_dir
    if not run.is_absolute() or run.exists() or '..' in run.parts or not run.parent.is_dir() or any(q.is_symlink() for q in (run,*run.parents)):
        raise ValueError('fresh absolute ordinary run directory required')
    space=os.statvfs(run.parent)
    if space.f_bavail*space.f_frsize<256*1024*1024:raise ValueError('256MiB free local evidence reserve required')
    os.environ.update(GST_REGISTRY=str(run/'gst-registry.bin'),GST_REGISTRY_1_0=str(run/'gst-registry.bin'),GST_DEBUG='2',OPENBLAS_NUM_THREADS='1')
    if 'linux' in sys.modules:raise ValueError('fresh standalone CAMERA_RAW process required')
    namespace=ModuleType('linux');namespace.__path__=[str(runtime/'peer/linux')];sys.modules['linux']=namespace
    sys.path.insert(0,str(runtime/'peer'))
    if spec['product']=='jpeg':
        from display_recording import admit
        from circular_recording import require_replay_leases
        require_replay_leases(config['recording']);admit(config['recording'],boot=a.expected_boot,require_space=False)
    from camera_session_control import Broker,ControlServer
    from camera_session_owner import SessionOwner as CameraOwner
    if mono_yolo:
        from camera_mono_yolo_control import Broker,ControlServer
        from camera_mono_yolo_owner import MonoYoloOwner as CameraOwner
    if fpga_parameters:
        from camera_parameter_control import Broker,ControlServer
        from camera_parameter_owner import ParameterOwner as CameraOwner
    from linux.dma_c2h_candidate.receiver import Receiver
    from linux.rk_debug.cli import hold_retained_owner
    stop=threading.Event();holder={}
    def cached(key):return holder['owner'].cached().get(key) if 'owner' in holder else None
    broker=Broker(stop,session=config['cold_session'],confirmation_timeout_s=config['mode_confirmation_s'],
        recording_provider=lambda:cached('recording'),source_rates_provider=lambda:cached('source_rates'),
        allow_topology_rebuild=config.get('allow_topology_rebuild',True),
        **(dict(ai_provider=lambda:(cached('preview') or {}).get('ai')) if mono_yolo else {}))
    server=ControlServer(broker,**({'origin':config['control_origin']} if 'control_origin' in config else {}));run.mkdir(mode=0o700)
    save_new(trial_guards(a.expected_boot)[3],dict(boot=a.expected_boot,profile=config['cold_session'],bit_sha256=release.BIT,run_dir=str(run)))
    save_new(run/'programming.json',dict(note=a.programming_note,bit_sha256=release.BIT,sram_readback=False,boot=a.expected_boot))
    signal.signal(signal.SIGINT,lambda *_:stop.set());signal.signal(signal.SIGTERM,lambda *_:stop.set())
    threading.Thread(target=server.serve_forever,daemon=True).start();receiver=owner=None;report=dict(state='STARTUP_RESULT_UNKNOWN_RETAINED')
    try:
        try:
            receiver=Receiver(target['device'],nonblocking=True)
            owner=CameraOwner(receiver,config,boot=a.expected_boot,run=run,stop_event=stop,broker=broker);holder['owner']=owner
            report=owner.run()
        except BaseException as error:
            stop.set();report=dict(state='FAULTED_RETAINED',failure=type(error).__name__+': '+str(error)[:512])
            try:broker.stopped(report['failure'])
            except BaseException as failure:report['control_report_error']=str(failure)[:512]
        save_new(run/'result.json',report)
    finally:hold_retained_owner((receiver,owner,broker,server),report)


if __name__=='__main__':raise SystemExit(main())
