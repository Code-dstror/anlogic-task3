"""Verify a CLOSED final-display MP4 against every emitted encoded AU."""
import hashlib
import json
import os
from pathlib import Path


NS=1_000_000_000


def _duration(data,boxes):
    found=[]
    def walk(start,end,depth=0):
        if depth>6:raise ValueError('MP4 nesting')
        for kind,a,b in boxes(data,start,end):
            if kind in (b'moov',b'trak',b'mdia',b'minf',b'stbl'):walk(a,b,depth+1)
            elif kind==b'mdhd':
                payload=data[a:b]
                if payload[0]==0:found.append(int.from_bytes(payload[16:20],'big'))
                elif payload[0]==1:found.append(int.from_bytes(payload[24:32],'big'))
                else:raise ValueError('MP4 time version')
    walk(0,len(data))
    if len(found)!=1 or found[0]<=0:raise ValueError('one positive MP4 duration required')
    return found[0]


def verify_mp4(data,encoded,*,parser,boxes):
    sizes,pts,scale=parser(data)
    if len(encoded)<len(sizes):return None
    selected=encoded[:len(sizes)]
    if sizes!=[x['size'] for x in selected]:raise ValueError('MP4 sample sizes differ from emitted AUs')
    if any(b['ordinal']!=a['ordinal']+1 or b['pts']<=a['pts'] or b['monotonic']<=a['monotonic'] for a,b in zip(selected,selected[1:])):
        raise ValueError('encoded frame identity/time order differs')
    first=selected[0]
    # Subtracting independently quantized endpoints permits one mux tick.
    tolerance=(NS+scale-1)//scale
    for sample,event in zip(pts,selected):
        if abs((sample-pts[0])*NS//scale-(event['pts']-first['pts']))>tolerance:
            raise ValueError('MP4 PTS differs from common display time')
    duration=_duration(data,boxes)-pts[0]
    if duration<=pts[-1]-pts[0]:raise ValueError('last MP4 sample duration missing')
    return dict(selected=selected,count=len(sizes),scale=scale,pts=pts,
        monotonic_start_ns=first['monotonic'],monotonic_end_ns=first['monotonic']+duration*NS//scale,
        duration_ns=duration*NS//scale,maximum_pts_error_ns=tolerance)


def durable_json(path,value):
    path=Path(path);temporary=path.with_name(path.name+'.pending')
    body=(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    with temporary.open('xb') as f:f.write(body);f.flush();os.fsync(f.fileno())
    os.replace(temporary,path)
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)


def seal_file(path,encoded,*,parser,boxes,boot,recording_id,published_root=None):
    path=Path(path)
    if path.is_symlink() or not path.name.endswith('.partial.mp4'):raise ValueError('closed partial basename required')
    before=path.stat()
    if not 24<=before.st_size<=16*1024*1024:raise ValueError('closed segment exceeds16MiB')
    data=path.read_bytes();verified=verify_mp4(data,encoded,parser=parser,boxes=boxes)
    if verified is None:return None
    after=path.stat()
    if (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):raise ValueError('CLOSED file changed')
    with path.open('rb') as f:os.fsync(f.fileno())
    target=path.with_name(path.name.replace('.partial.mp4','.mp4'))
    if target.exists():raise ValueError('sealed filename already exists')
    os.rename(path,target)
    fd=os.open(target.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
    sha=hashlib.sha256(data).hexdigest()
    identity=dict(recording_id=recording_id,boot_id=boot,relative_path=target.name,sha256=sha)
    asset=dict(asset_id=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest(),
        recording_id=recording_id,boot_id=boot,recording_root=str(published_root or target.parent),relative_path=target.name,
        bytes=len(data),sha256=sha,available=True,state='CLOSED_VERIFIED',
        monotonic_start_ns=verified['monotonic_start_ns'],monotonic_end_ns=verified['monotonic_end_ns'],
        pts_start_ns=verified['selected'][0]['pts'],pts_end_ns=verified['selected'][0]['pts']+verified['duration_ns'],
        utc_start_ns=None,utc_end_ns=None,clock_quality='UNKNOWN',
        metadata=dict(sample_count=verified['count'],format='HEVC_HVC1_FINAL_HDMI_NV12',
            scope='SAME_POST_OVERLAY_BUFFERS_AS_KMS_INPUT_NOT_PHYSICAL_SCANOUT',time_origin='COMMON_POST_OVERLAY_CLOCK_MONOTONIC'))
    durable_json(target.with_suffix('.json'),dict(schema=1,asset=asset,encoded=verified['selected'],
        mp4_pts=verified['pts'],mp4_timescale=verified['scale']))
    return asset,verified['count']
