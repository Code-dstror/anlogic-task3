"""Fixed compositor metadata/HUD ABI, with no library load during import."""
import ctypes as C
import hashlib
from pathlib import Path

INPUT_FIELDS='pts token session epoch sequence camera jpeg_session slot generation received'.split()
STATS_FIELDS='abi error frames pending registered0 registered1 decoded0 decoded1 used0 used1 valid0 valid1 fps0_tenths fps1_tenths layout revision cache_replaced0 cache_replaced1'.split()
TIMING_FIELDS=('abi enabled qos_updates stale_drops duplicate_single_drops last_accepted_ns original_pts '
               'schedule_lag_ns max_schedule_lag_ns age0_ns age1_ns last_new0_ns last_new1_ns '
               'visible_mask new_inputs0 new_inputs1 slot_lag_budget_ns input_age_budget_ns').split()
DURATION_FIELDS=('abi enabled duration_ns missing0 missing1 filled0 filled1 other0 other1 '
                 'last_original_duration0 last_original_duration1').split()

class Input(C.Structure):
    _fields_=[(n,C.c_uint64) for n in INPUT_FIELDS]

class Output(C.Structure):
    _fields_=[(n,C.c_uint64) for n in ('ordinal','pts','stamp','layout','revision')]+[('camera',Input*2)]

assert C.sizeof(Input)==80 and C.sizeof(Output)==200

class StereoHud:
    def __init__(self,path,expected_sha256):
        body=Path(path).read_bytes()
        if hashlib.sha256(body).hexdigest()!=expected_sha256:raise ValueError('fixed stereo HUD library required')
        self.lib=C.CDLL(str(path));p=C.c_void_p;u=C.c_uint64
        for name,args,result in [('register',[],C.c_int),('attach',[p],C.c_int),('input',[C.POINTER(u)],C.c_int),
            ('layout',[C.c_uint,u],C.c_int),('take',[u,u,C.POINTER(Output)],C.c_int),('stats',[C.POINTER(u)],C.c_int),('freeze',[],C.c_int)]:
            fn=getattr(self.lib,'u3_hud_'+name);fn.argtypes=args;fn.restype=result
        self.lib.u3_hud_realtime_configure.argtypes=[];self.lib.u3_hud_realtime_configure.restype=C.c_int
        self.lib.u3_hud_realtime_stats.argtypes=[C.POINTER(u),C.c_uint];self.lib.u3_hud_realtime_stats.restype=C.c_int
        if self.lib.u3_hud_register()!=1:raise RuntimeError('stereo compositor registration failed')

    def attach(self,pipeline):
        # GI's native pointer conversion is shared with the already qualified
        # recorder endpoint. It does not open a receiver or change its owner.
        try:from .remote_mono_display._ai_endpoint import gobject_pointer
        except ImportError:from remote_mono_display._ai_endpoint import gobject_pointer
        if self.lib.u3_hud_attach(gobject_pointer(pipeline))!=1:raise RuntimeError('stereo native graph attach failed')

    def register(self,item,pts,received):
        m=item.record.metadata
        values=(C.c_uint64*10)(pts,0,item.session,item.epoch,item.sequence,item.camera,m.jpeg_session,m.jpeg_slot,m.jpeg_generation,received)
        if self.lib.u3_hud_input(values)!=1:raise RuntimeError('stereo exact input metadata rejected')

    def layout(self,name,revision):
        if name not in ('both','cam0','cam1') or type(revision) is not int or revision<=0:raise ValueError('explicit stereo layout/revision required')
        if self.lib.u3_hud_layout(('both','cam0','cam1').index(name),revision)!=1:raise RuntimeError('stereo layout request rejected')

    def take(self,ordinal,pts):
        value=Output()
        if self.lib.u3_hud_take(ordinal,pts,C.byref(value))!=1:raise ValueError('actual composed SOURCE pair differs from recorded common frame')
        return dict(layout=('both','cam0','cam1')[value.layout],layout_revision=int(value.revision),
                    composed_host_ns=int(value.stamp),common_original_pts=int(value.pts),
                    cameras=[{n:int(getattr(x,n)) for n in INPUT_FIELDS} for x in value.camera],
                    pairing='ACTUAL_COMPOSITOR_INPUTS_NOT_EQUAL_SEQUENCE_OR_EXPOSURE_SYNC')

    def snapshot(self):
        values=(C.c_uint64*len(STATS_FIELDS))()
        if self.lib.u3_hud_stats(values)!=1 or values[0]!=1:raise ValueError('stereo HUD ABI differs')
        return dict(zip(STATS_FIELDS,map(int,values)))

    def freeze(self):
        if self.lib.u3_hud_freeze()!=1:raise RuntimeError('stereo final output freeze failed')

    def realtime(self):
        if self.lib.u3_hud_realtime_configure()!=1:raise RuntimeError('realtime policy must be admitted once before graph attach')

    def timing_snapshot(self):
        values=(C.c_uint64*len(TIMING_FIELDS))()
        if self.lib.u3_hud_realtime_stats(values,len(values))!=1 or values[0]!=1:raise ValueError('stereo timing ABI differs')
        return dict(zip(TIMING_FIELDS,map(int,values)))

    def fast(self,threads):
        if type(threads) is not int or threads not in range(1,5):
            raise ValueError('explicit converter threads per eye in 1..4 required')
        fn=self.lib.u3_hud_fast_configure
        fn.argtypes=[C.c_uint];fn.restype=C.c_int
        if fn(threads)!=1:raise RuntimeError('SBS optimization must be admitted once before graph attach')

    def fast_snapshot(self):
        fields='abi enabled threads_per_eye pad_mask applications resampler'.split()
        values=(C.c_uint64*len(fields))()
        fn=self.lib.u3_hud_fast_stats
        fn.argtypes=[C.POINTER(C.c_uint64),C.c_uint];fn.restype=C.c_int
        if fn(values,len(values))!=1 or values[0]!=1:raise ValueError('stereo scaler ABI differs')
        return dict(zip(fields,map(int,values)))

    def frame_duration(self,duration_ns):
        if type(duration_ns) is not int or duration_ns!=33333333:
            raise ValueError('explicit R5 1/30s input frame duration required')
        fn=self.lib.u3_hud_duration_configure
        fn.argtypes=[C.c_uint64];fn.restype=C.c_int
        if fn(duration_ns)!=1:raise RuntimeError('input duration must be admitted once before graph attach')

    def duration_snapshot(self):
        values=(C.c_uint64*len(DURATION_FIELDS))()
        fn=self.lib.u3_hud_duration_stats
        fn.argtypes=[C.POINTER(C.c_uint64),C.c_uint];fn.restype=C.c_int
        if fn(values,len(values))!=1 or values[0]!=1:raise ValueError('stereo input duration ABI differs')
        return dict(zip(DURATION_FIELDS,map(int,values)))
