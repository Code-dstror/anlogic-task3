"""Mono AI extension; existing MPP/compositor/FPS and final-record tee remain."""
import ctypes
import hashlib
from pathlib import Path
import uuid

try:
    from .camera_session_preview import SessionPreview
    from .camera_mono_yolo_ai import AIWorker
    from .remote_mono_display._ai_endpoint import NativeLibrary,NativeEndpoint
except ImportError:
    from camera_session_preview import SessionPreview
    from camera_mono_yolo_ai import AIWorker
    from remote_mono_display._ai_endpoint import NativeLibrary,NativeEndpoint


class MonoYoloPreview(SessionPreview):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.ai=None;self.ai_endpoint=None;self.ai_library=None
        self.ai_cohort='seed25-'+uuid.uuid4().hex
        self.ai_baseline=0
        self.ai_control_error=None

    def _graph(self,sink,directory):
        graph=super()._graph(sink,directory)
        if self.cameras!=1:return graph
        path=Path(self.config['mono_yolo_overlay_library'])
        if hashlib.sha256(path.read_bytes()).hexdigest()!=self.config['mono_yolo_overlay_sha256']:
            raise ValueError('sealed mono YOLO overlay differs')
        self.ai_library=NativeLibrary(path)
        self.ai_library.lib.y26_mono_selected_source_abi.restype=ctypes.c_int
        if self.ai_library.lib.y26_mono_selected_source_abi()!=1:
            raise ValueError('selected SOURCE bridge ABI differs')
        self.ai_library.register()
        seam='! identity name=stereo_final !'
        if graph.count(seam)!=1:raise ValueError('final source/HUD graph seam differs')
        return graph.replace(seam,'! y26asyncoverlay name=ai_overlay '+seam,1)

    def _graph_ready(self,Gst):
        if self.cameras!=1:return
        self.ai_endpoint=NativeEndpoint(self.ai_library,self.pipeline.get_by_name('ai_overlay'))
        self.ai=AIWorker(self.output/'mono-yolo',self.config['mono_yolo'],self.ai_cohort,
                         endpoint=self.ai_endpoint).start()

    def set_ai(self,enabled,*,session=None,epoch=None):
        if self.cameras!=1 or self.ai is None:raise ValueError('YOLO requires ready mono CAM0 JPEG preview')
        try:
            if enabled:self.ai_baseline=self.ai_endpoint.stats()['overlay_frames']
            self.ai.set_enabled(enabled,session=session,epoch=epoch)
            if enabled:self.ai_control_error=None
            return True
        except BaseException as error:
            self.ai_control_error=type(error).__name__+': '+str(error)[:384]
            return False

    def _push(self,Gst,item,received):
        super()._push(Gst,item,received)
        if self.ai is not None:self.ai.submit(item,received)

    def _publish(self):
        hud=super()._publish()
        if self.ai is not None:
            try:
                state=self.ai.snapshot()
                native=self.ai_endpoint.stats()
                state.update(native_overlay=native,
                    output_confirmed=bool(state.get('ready') and native['enabled'] and
                        native['generation']==state.get('generation') and native['overlay_frames']>self.ai_baseline))
                if self.ai_control_error:state.update(error=self.ai_control_error,ready=False,output_confirmed=False)
            except BaseException as error:
                self.ai_control_error=type(error).__name__+': '+str(error)[:384]
                state=dict(error=self.ai_control_error,ready=False,output_confirmed=False,video_waits_for_ai=False)
            with self.cv:self.cache['ai']=state
        return hud

    def _graph_finish(self):
        if self.ai is not None:
            try:final=self.ai.close(timeout_s=3)
            except BaseException as error:final=dict(error=str(error)[:384],retired=False,retained=True)
            with self.cv:self.cache['ai_final']=final

    def retire_for_rebuild(self,timeout_s=15):
        if self.ai is not None:
            result=self.ai.close(timeout_s=min(3,timeout_s))
            if result.get('worker_alive') or not result.get('retired'):
                raise RuntimeError('AI retirement unconfirmed; retain old graph before rebuild')
        return super().retire_for_rebuild(timeout_s=timeout_s)
