from pathlib import Path
import os
import stat


ROLL_BYTES=16*1024*1024
MAX_RESULT_BYTES=1024*1024

class RollingStream:
    def __init__(self,path,mode='x',encoding=None,**kwargs):
        self.path=Path(path);self.binary='b' in mode;self.encoding=encoding or 'utf-8'
        self.stream=_path_open(self.path,mode,encoding=None if self.binary else self.encoding)
        self.bytes=0
    def write(self,value):
        raw=bytes(value) if isinstance(value,(bytes,bytearray,memoryview)) else value.encode(self.encoding)
        if self.bytes+len(raw)>ROLL_BYTES:
            self.stream.close()
            for i in (3,2,1):
                source=Path(str(self.path)+'.'+str(i-1)) if i>1 else self.path
                target=Path(str(self.path)+'.'+str(i))
                if source.exists():os.replace(source,target)
            self.stream=_path_open(self.path,'wb' if self.binary else 'w',encoding=None if self.binary else self.encoding)
            self.bytes=0
        self.bytes+=len(raw);return self.stream.write(value)
    def flush(self):return self.stream.flush()
    def close(self):return self.stream.close()
    def __getattr__(self,name):return getattr(self.stream,name)
    def __enter__(self):return self
    def __exit__(self,*args):self.close()


_path_open=Path.open


def prepare_result_channel(path):
    """Create the single-use protocol FIFO before the runner reports READY."""
    path=Path(path)
    if path.name!='frames.jsonl':raise ValueError('explicit AI result channel required')
    os.mkfifo(path,0o600)  # Existing files/symlinks are errors, never replaced.


class ResultStream:
    """Persistent FIFO protocol plus independent bounded rolling audit.

    The FIFO is never renamed/truncated. Its reader retains one fd for the
    session. A complete bounded JSONL row is passed exactly once; blocking pipe
    backpressure preserves the existing one-frame/result/ACK lease handshake.
    """
    def __init__(self,path,mode,encoding=None,**kwargs):
        path=Path(path)
        if mode!='w' or encoding not in (None,'utf-8') or not stat.S_ISFIFO(path.lstat().st_mode):
            raise ValueError('continuous AI results require the owned text FIFO')
        self.protocol=_path_open(path,'w',encoding='utf-8',buffering=1)
        try:self.audit=RollingStream(path.with_name('frames-audit.jsonl'),'x',encoding='utf-8')
        except BaseException:
            self.protocol.close()
            raise
        self.pending=''
        self.closed=False

    def write(self,value):
        if self.closed:raise ValueError('AI result stream is closed')
        if type(value) is not str:raise TypeError('AI result JSONL text required')
        combined=self.pending+value
        if len(combined.encode('utf-8'))>MAX_RESULT_BYTES:
            raise ValueError('AI result JSONL exceeds1MiB')
        if '\n' not in combined:
            self.pending=combined
            return len(value)
        if not combined.endswith('\n') or combined.count('\n')!=1:
            raise ValueError('one complete AI result row per publication required')
        # A partial .write call is buffered only in this bounded Python object;
        # neither consumer nor rolling audit can see a half row on rotation.
        self.protocol.write(combined)
        self.protocol.flush()
        self.audit.write(combined)
        self.pending=''
        return len(value)

    def flush(self):
        self.protocol.flush();self.audit.flush()

    def close(self):
        if self.closed:return
        self.closed=True
        try:self.protocol.close()
        finally:self.audit.close()

    def __enter__(self):return self
    def __exit__(self,*args):self.close()


def rolling_open(path,mode='r',*args,**kwargs):
    if path.name=='frames.jsonl' and any(v in mode for v in ('x','w','a')):
        return ResultStream(path,mode,**kwargs)
    names=('events.jsonl','steps.jsonl','preview-observations.jsonl','published-prepared.jsonl','source-gaps.jsonl')
    if path.name in names and any(v in mode for v in ('x','w','a')):
        return RollingStream(path,mode,**kwargs)
    return _path_open(path,mode,*args,**kwargs)



def install():
    Path.open=rolling_open
