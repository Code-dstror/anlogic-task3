"""Exact, scoped continuous derivatives of the frozen prepared AI sources.

Packaging calls adapt_prepared() on its COPY of prepared_session.py. The child
uses this file as a wrapper around the unchanged installed candidate runner;
its original __file__/imports and native environment remain intact. No module
is monkeypatched in the owner and no candidate/installed file is rewritten.
"""
import hashlib
from pathlib import Path
import sys
if __package__:
    from .remote_mono_logs import install as install_logs
else:
    from remote_mono_logs import install as install_logs


PREPARED_SHA256 = '37f1a6b2b61b713097231f4264162e1e818ae5162a932f06ec5703033acb85f4'
RUNNER_SHA256 = 'a714adf12d91d225028b3a9adb98604bc29f0fdd1414b118863a62edeee0513f'
WINDOW_FRAMES = 4096


def _checked(source, expected, label):
    if type(source) is not bytes or hashlib.sha256(source).hexdigest() != expected:
        raise ValueError('continuous AI requires the frozen ' + label + ' source')
    return source.decode('utf-8')


def _replace(source, old, new):
    if source.count(old) != 1:
        raise ValueError('continuous AI source seam differs: ' + old[:80])
    return source.replace(old, new)


def adapt_prepared(source):
    text = _checked(source, PREPARED_SHA256, 'prepared_session')
    replacements = (
        ('max_duration_s=180, clock_ns=time.monotonic_ns',
         'max_duration_s=None, clock_ns=time.monotonic_ns'),
        ('if type(max_duration_s) not in (int, float) or not 0 < max_duration_s <= 180:',
         'if max_duration_s is not None and (type(max_duration_s) not in (int, float) or not 0 < max_duration_s <= 180):'),
        ('if (self._started_ns is not None and not self._stop.is_set()',
         'if (self._duration is not None and self._started_ns is not None and not self._stop.is_set()'),
        ('if self._clock() - started >= self._duration * 1e9:',
         'if self._duration is not None and self._clock() - started >= self._duration * 1e9:'),
        ('duration_s: int = 180', 'duration_s: int = 0'),
        ('if type(self.duration_s) is not int or not 1 <= self.duration_s <= 180:',
         'if type(self.duration_s) is not int or not 0 <= self.duration_s <= 180:'),
        ("raise ValueError('runner duration must be1..180 seconds')",
         "raise ValueError('runner duration must be0 (continuous) or1..180 seconds')"),
        ('and frames.is_file():',
         'and (frames.is_fifo() if cfg.duration_s == 0 else frames.is_file()):'),
        ('self._result_fd = os.open(frames, os.O_RDONLY)',
         'self._result_fd = os.open(frames, os.O_RDONLY | (os.O_NONBLOCK if cfg.duration_s == 0 else 0))'),
        ('        self.child = self._child_factory(argv, env=environment, stdout=self._log, stderr=subprocess.STDOUT)',
         '        if cfg.duration_s == 0:\n'
         '            from remote_mono_ai_continuous import runner_command\n'
         '            argv = runner_command(argv)\n'
         '        self.child = self._child_factory(argv, env=environment, stdout=self._log, stderr=subprocess.STDOUT)'),
    )
    for old, new in replacements:
        text = _replace(text, old, new)
    compile(text, '<continuous-prepared-session>', 'exec')
    return text.encode('utf-8')


def adapt_runner(source):
    text = _checked(source, RUNNER_SHA256, 'runner')
    replacements = (
        ('a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)',
         'a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)\n'
         '    if a.duration_s == 0:\n'
         '        from remote_mono_logs import prepare_result_channel\n'
         "        prepare_result_channel(a.output/'frames.jsonl')"),
        ('samples=collections.defaultdict(list)',
         'samples=collections.defaultdict(lambda: collections.deque(maxlen=4096)) if a.duration_s == 0 else collections.defaultdict(list)'),
        ('seen=set()', 'seen=collections.deque(maxlen=4096) if a.duration_s == 0 else set()'),
        ("if counts['frames']>=60000:raise RuntimeError('Timing buffer cap reached')",
         "if a.duration_s > 0 and counts['frames']>=60000:raise RuntimeError('Timing buffer cap reached')"),
        ("seen.add(desc['original_frame_key'])",
         "(seen.append if a.duration_s == 0 else seen.add)(desc['original_frame_key'])"),
        ('if first is not None and (time.monotonic_ns()-first)/1e9>=a.duration_s:break',
         'if a.duration_s > 0 and first is not None and (time.monotonic_ns()-first)/1e9>=a.duration_s:break'),
        ('unique_source_frames=len(seen)',
         'continuous=a.duration_s == 0,timing_window_frames=4096 if a.duration_s == 0 else None,'
         'unique_source_frames_window=len(set(seen)) if a.duration_s == 0 else None,'
         'unique_source_frames=None if a.duration_s == 0 else len(seen)'),
        ('unique_original_frame_rate=len(seen)/elapsed if elapsed else None,replayed_observations=counts[\'frames\']-len(seen)',
         'unique_original_frame_rate=len(seen)/elapsed if elapsed and a.duration_s > 0 else None,'
         "replayed_observations=counts['frames']-len(seen) if a.duration_s > 0 else None"),
        ('# <=300s x120fps fits60000; stop rather than silently clip timing samples.',
         '# Continuous mode retains only4096 timing/key samples; finite mode keeps the original cap.'),
    )
    for old, new in replacements:
        text = _replace(text, old, new)
    compile(text, '<continuous-candidate-runner>', 'exec')
    return text.encode('utf-8')


def runner_command(argv):
    """Preserve private environment/arguments; replace only the child script."""
    if (type(argv) is not list or len(argv) < 4 or argv[1] != '-B'
            or Path(argv[2]).name != 'runner.py' or argv.count('--duration-s') != 1):
        raise ValueError('unexpected prepared runner command')
    position = argv.index('--duration-s')
    if position + 1 >= len(argv) or argv[position + 1] != '0':
        raise ValueError('continuous wrapper requires explicit --duration-s 0')
    source = Path(argv[2]).resolve(strict=True)
    # Qualification occurs before spawning; the child checks the source again.
    _checked(source.read_bytes(), RUNNER_SHA256, 'runner')
    return argv[:2] + [str(Path(__file__).resolve()), '--runner-source', str(source), '--'] + argv[3:]


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) < 4 or args[0] != '--runner-source' or args[2] != '--':
        raise ValueError('expected --runner-source PATH -- runner arguments')
    forwarded = args[3:]
    if (forwarded.count('--duration-s') != 1 or
            forwarded.index('--duration-s') + 1 >= len(forwarded) or
            forwarded[forwarded.index('--duration-s') + 1] != '0'):
        raise ValueError('continuous runner requires explicit --duration-s 0')
    source = Path(args[1]).resolve(strict=True)
    derived = adapt_runner(source.read_bytes())
    original_open=Path.open
    install_logs()
    try:
        sys.argv = [str(source)] + forwarded
        sys.path[0] = str(source.parent)
        scope = dict(__name__='__main__', __file__=str(source), __package__=None,
                     __cached__=None, __spec__=None)
        exec(compile(derived, str(source), 'exec'), scope)
    finally:
        Path.open=original_open


if __name__ == '__main__':
    main()
