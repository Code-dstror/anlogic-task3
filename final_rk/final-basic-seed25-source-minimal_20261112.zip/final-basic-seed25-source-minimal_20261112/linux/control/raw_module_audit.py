"""Build the fixed native source against a private completed-kernel snapshot.

This entry point performs ordinary-file work only. It neither loads a module nor
turns the resulting files into a target environment admission receipt.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import time


SOURCE_COMMIT = 'a650568da1b54532548469be304d9cd644857bd6'
SOURCE_PREFIX = 'linux/dma_c2h_candidate/'
SOURCE_HASHES = {
    'Makefile': '26d41a41a97c6caa8c14b83501d1e5c72dde60a6dc6dc8e4f73218186c9d9a9c',
    'ph1a_c2h.c': '55d651d5493b29b49638cf8a5485d07016d3f39d27953b48928265a18ff42d94',
    'c2h_uapi.h': '163479e9b6832f303da6be288891bf424a48d0435c493c8588162de4b9b670fe',
    'c2h_hw_abi.h': 'bef673e83fc67d670e77fd91ea67b0d52ebaca640e8de10f4ac7be40495e6c49',
    'c2h_legacy_policy.h': 'a6501a95fa9ea10901a698299f0953d0c6bc01930987df6a11ac9cf53e9a242b',
    'c2h_lifecycle.h': '20ba8a963e5942d640ef221b263ee6044901088ed2d42c412350c122c30ced8f',
}
CRITICAL_HEADERS = ('.config', 'Module.symvers', 'Makefile',
                    'include/config/auto.conf', 'include/config/kernel.release',
                    'include/generated/autoconf.h', 'include/generated/utsrelease.h',
                    'include/generated/compile.h', 'scripts/module.lds')
PARAMETER_TYPES = {'slots': 'uint', 'capacity': 'uint', 'poll_ms': 'uint',
                   'drain_ms': 'uint', 'dma_bits': 'uint', 'irq_hint': 'bool',
                   'target_bdf': 'charp'}
CONFIG_KEYS = ('ARM64', 'MODULES', 'MODULE_UNLOAD', 'MODVERSIONS',
               'MODULE_SRCVERSION_ALL', 'MODULE_SIG', 'MODULE_SIG_ALL',
               'MODULE_SIG_FORCE', 'TRIM_UNUSED_KSYMS', 'PCI', 'PCI_MSI',
               'HAS_DMA', 'COMPAT', 'SMP', 'PREEMPT', 'PREEMPT_VOLUNTARY',
               'PREEMPT_NONE', 'PREEMPT_DYNAMIC', 'LTO_NONE', 'CFI_CLANG',
               'RANDSTRUCT_NONE', 'DEBUG_INFO_BTF_MODULES')
PROTECTED_INPUT_ROOTS = (Path('/home/uisrc/mlk-sdk-3576-v1.1.0'),
                         Path('/home/uisrc/work/anlogic-task3/local_refs/official_package'))


def writable_path(path):
    """Prevent future replay from writing the original SDK/official inputs."""
    path = Path(path)
    resolved = path.resolve()
    for root in PROTECTED_INPUT_ROOTS:
        protected = root.resolve()
        if resolved == protected or resolved.is_relative_to(protected):
            raise ValueError('writable destination is a protected input: '+str(path))
    for candidate in (path.absolute(), resolved):
        if any(pair == ('local_refs', 'official_package')
               for pair in zip(candidate.parts, candidate.parts[1:])):
            raise ValueError('writable destination is a protected input: '+str(path))
    return path


def regular_bytes(path):
    """Pin and check an ordinary file before any content-open callback."""
    path = Path(path)
    pin = os.open(path, os.O_PATH | os.O_NOFOLLOW | os.O_CLOEXEC)
    fd = None
    try:
        info = os.fstat(pin)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('ordinary file required: '+str(path))
        fd = os.open('/proc/self/fd/'+str(pin), os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            return stream.read()
    finally:
        if fd is not None:
            os.close(fd)
        os.close(pin)


def file_record(path):
    raw = regular_bytes(path)
    return {'path': str(Path(path).absolute()), 'bytes': len(raw),
            'sha256': sha256(raw).hexdigest()}


def write_json(path, value):
    writable_path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def toolchain_identity(cross_compile, env):
    result = {}
    for tool in ('gcc', 'ld', 'as', 'nm', 'ar', 'objcopy'):
        invocation = cross_compile+tool
        resolved = Path(shutil.which(invocation) or invocation).resolve(strict=True)
        result[tool] = {**file_record(resolved), 'invocation': invocation,
                        'version': subprocess.check_output([invocation, '--version'], env=env, text=True).strip()}
    cc1 = subprocess.check_output([cross_compile+'gcc', '-print-prog-name=cc1'], env=env, text=True).strip()
    result['cc1'] = file_record(Path(cc1).resolve(strict=True))
    return result


def verify_source(source):
    source = Path(source)
    records = {}
    for name, expected in SOURCE_HASHES.items():
        record = file_record(source/name)
        if record['sha256'] != expected:
            raise ValueError('fixed native source differs: '+name)
        records[name] = record
    return records


def extract_source(repo, destination):
    """Extract compilation inputs only; never merge the source commit tree."""
    destination = writable_path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    records = {}
    for name, expected in SOURCE_HASHES.items():
        obj = SOURCE_COMMIT+':'+SOURCE_PREFIX+name
        raw = subprocess.check_output(['git', '-C', str(repo), 'show', obj])
        if sha256(raw).hexdigest() != expected:
            raise ValueError('Git object bytes differ from fixed native source: '+name)
        target = destination/name
        if target.exists() or target.is_symlink():
            if regular_bytes(target) != raw:
                raise ValueError('existing source destination differs: '+str(target))
        else:
            target.write_bytes(raw)
        records[name] = {**file_record(target), 'git_path': SOURCE_PREFIX+name,
                         'git_blob': subprocess.check_output(
                             ['git', '-C', str(repo), 'rev-parse', obj], text=True).strip()}
    return {'source_commit': SOURCE_COMMIT, 'overlays': [], 'files': records}


def _separate(destination, *inputs):
    target = Path(destination).resolve()
    for value in inputs:
        root = Path(value).resolve()
        if target == root or target.is_relative_to(root) or root.is_relative_to(target):
            raise ValueError('private snapshot must be disjoint from kernel inputs')


def prepare_headers(kernel_source, kernel_output, destination):
    """Copy a completed build's headers/tools; all later make writes stay here.

    Caller must wait for the kernel writer to finish before this operation.
    The copied files use independent inodes; no source/output symlinks or
    hardlinked copies redirect make to the original kernel tree.
    """
    kernel_source, kernel_output, destination = map(Path, (kernel_source, kernel_output, destination))
    writable_path(destination)
    _separate(destination, kernel_source, kernel_output)
    for name in ('vmlinux', 'arch/arm64/boot/Image', 'System.map', '.config', 'Module.symvers'):
        if not stat.S_ISREG((kernel_output/name).stat(follow_symlinks=False).st_mode):
            raise ValueError('completed kernel output missing ordinary file: '+name)
    if destination.exists():
        raise ValueError('snapshot destination must be new: '+str(destination))
    destination.mkdir(parents=True)
    # No top-level generated output Makefile/source symlink is copied. The
    # real source Makefile makes this a standalone in-tree header snapshot.
    shutil.copy2(kernel_source/'Makefile', destination/'Makefile')
    for relative in ('include', 'scripts', 'arch/arm64/include'):
        shutil.copytree(kernel_source/relative, destination/relative, symlinks=True)
    shutil.copy2(kernel_source/'arch/arm64/Makefile', destination/'arch/arm64/Makefile')
    if kernel_output.resolve() != kernel_source.resolve():
        for relative in ('include', 'scripts', 'arch/arm64/include/generated'):
            if (kernel_output/relative).is_dir():
                shutil.copytree(kernel_output/relative, destination/relative,
                                symlinks=True, dirs_exist_ok=True)
    for name in ('.config', 'Module.symvers', 'modules.order', 'modules.builtin'):
        if (kernel_output/name).is_file():
            shutil.copy2(kernel_output/name, destination/name)
    if 'CONFIG_DEBUG_INFO_BTF_MODULES=y' in regular_bytes(destination/'.config').decode():
        shutil.copy2(kernel_output/'vmlinux', destination/'vmlinux')
    records = {name: file_record(destination/name) for name in CRITICAL_HEADERS}
    inventory = []
    for path in sorted(destination.rglob('*')):
        relative = str(path.relative_to(destination))
        if path.is_symlink():
            # Keep only relative links which resolve inside the private copy.
            # Unused dtc architecture links may be dangling inside the copy.
            if Path(os.readlink(path)).is_absolute() or not path.resolve().is_relative_to(destination.resolve()):
                raise ValueError('header snapshot symlink escapes private copy: '+relative)
            inventory.append({'relative_path': relative, 'symlink': os.readlink(path)})
        elif path.is_file():
            inventory.append({'relative_path': relative, **file_record(path)})
    manifest = {'schema': 1, 'kind': 'PRIVATE_COMPLETED_KERNEL_HEADER_SNAPSHOT',
                'source': str(kernel_source.resolve()), 'output': str(kernel_output.resolve()),
                'destination': str(destination.resolve()), 'critical_inputs': records,
                'files': inventory, 'copy_method': 'shutil.copy2/copytree; no hardlinks',
                'linked_kernel': {name: file_record(kernel_output/name)
                                  for name in ('vmlinux', 'arch/arm64/boot/Image', 'System.map')}}
    write_json(destination/'header-snapshot.json', manifest)
    return manifest


def parse_config(raw):
    result = {}
    for line in raw.decode().splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            key, value = line[7:].split('=', 1)
            result[key] = value
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            result[line[9:-11]] = 'n'
    return result


def module_info(raw):
    """Decode ELF64 little-endian AArch64 module identity and actual imports."""
    if len(raw) < 64 or raw[:6] != b'\x7fELF\x02\x01':
        raise ValueError('little-endian ELF64 required')
    elf_type, machine = struct.unpack_from('<HH', raw, 16)
    if (elf_type, machine) != (1, 183):
        raise ValueError('AArch64 ET_REL module required')
    offset = struct.unpack_from('<Q', raw, 40)[0]
    size, count, names_index = struct.unpack_from('<HHH', raw, 58)
    if size != 64 or not 0 < count < 65535 or names_index >= count or offset+64*count > len(raw):
        raise ValueError('invalid ELF section table')
    rows = [struct.unpack_from('<IIQQQQIIQQ', raw, offset+64*i) for i in range(count)]
    def body(row):
        start, length = row[4:6]
        if row[1] == 8:
            return b''
        if start+length > len(raw):
            raise ValueError('ELF section outside ordinary file')
        return raw[start:start+length]
    def string(table, index):
        end = table.find(b'\0', index)
        if not 0 <= index < len(table) or end < 0:
            raise ValueError('invalid ELF string')
        return table[index:end].decode('ascii')
    names = body(rows[names_index])
    sections = {string(names, row[0]): (row, body(row)) for row in rows}
    modinfo = {}
    for entry in sections.get('.modinfo', (None, b''))[1].split(b'\0'):
        if b'=' in entry:
            key, value = entry.decode('ascii').split('=', 1)
            modinfo.setdefault(key, []).append(value)
    build_ids = []
    note = sections.get('.note.gnu.build-id', (None, b''))[1]
    pos = 0
    while pos < len(note):
        if pos+12 > len(note):
            raise ValueError('truncated build-id note')
        namesz, descsz, kind = struct.unpack_from('<III', note, pos)
        name_start = pos+12
        desc_start = name_start+(namesz+3)//4*4
        end = desc_start+descsz
        if end > len(note):
            raise ValueError('truncated build-id descriptor')
        if note[name_start:name_start+namesz] == b'GNU\0' and kind == 3:
            build_ids.append(note[desc_start:end].hex())
        pos = end+(-descsz % 4)
    if len(build_ids) != 1 or not build_ids[0]:
        raise ValueError('one nonempty GNU build-id required')
    symbols = []
    if '.symtab' not in sections:
        raise ValueError('module symbol table required for export audit')
    row, table = sections['.symtab']
    if row[6] >= count or row[9] != 24 or len(table) % 24:
        raise ValueError('invalid module symbol table')
    strings = body(rows[row[6]])
    for start in range(0, len(table), 24):
        name, info, _, index, _, _ = struct.unpack_from('<IBBHQQ', table, start)
        if info >> 4 in (1, 2) and index == 0:
            symbols.append(string(strings, name))
    versions = {}
    if '__versions' in sections:
        data = sections['__versions'][1]
        if len(data) % 64:
            raise ValueError('invalid Linux 6.1 module versions section')
        for start in range(0, len(data), 64):
            crc, name = struct.unpack_from('<Q56s', data, start)
            versions[name.split(b'\0', 1)[0].decode('ascii')] = f'0x{crc:08x}'
    def one(name, required=False):
        values = modinfo.get(name, [])
        if len(values) > 1 or (required and len(values) != 1):
            raise ValueError('module metadata requires a single '+name)
        return values[0] if values else None
    name, vermagic = one('name', True), one('vermagic', True)
    srcversion = one('srcversion')
    if 'srcversion' in modinfo and not srcversion:
        raise ValueError('present srcversion must be nonempty')
    parameters = {}
    for value in modinfo.get('parmtype', []):
        param, kind = value.split(':', 1)
        if param in parameters:
            raise ValueError('duplicate module parameter type')
        parameters[param] = kind
    return {'elf_type': elf_type, 'elf_class': 64, 'machine': 'AArch64',
            'build_id': build_ids[0], 'name': name, 'vermagic': vermagic,
            'srcversion': {'status': 'PRESENT' if 'srcversion' in modinfo else 'MISSING', 'value': srcversion},
            'parameters': parameters, 'modinfo': modinfo, 'undefined_symbols': sorted(set(symbols)),
            'versions_section_present': '__versions' in sections, 'symbol_versions': versions,
            'this_module_bytes': sections.get('.gnu.linkonce.this_module', ((0,)*6, b''))[0][5],
            'signature_appended': raw.endswith(b'~Module signature appended~\n'),
            'sections': sorted(sections)}


def audit_exports(info, symvers_raw, config):
    exports = {}
    for line in symvers_raw.decode().splitlines():
        columns = line.split()
        if len(columns) >= 4:
            crc, name, provider, kind = columns[:4]
            exports[name] = {'crc': crc, 'provider': provider, 'kind': kind,
                             'namespace': columns[4] if len(columns) > 4 else ''}
    imports = info['undefined_symbols']
    missing = sorted(set(imports)-set(exports))
    if missing:
        raise ValueError('undefined module imports absent from candidate Module.symvers: '+', '.join(missing))
    modversions = config.get('MODVERSIONS') == 'y'
    if modversions:
        expected = set(imports) | {'module_layout'}
        for name in expected:
            if (name not in info['symbol_versions'] or name not in exports or
                    int(info['symbol_versions'][name], 16) != int(exports[name]['crc'], 16)):
                raise ValueError('module/candidate export CRC mismatch: '+name)
    elif info['versions_section_present']:
        raise ValueError('unexpected symbol versions with CONFIG_MODVERSIONS disabled')
    return {'undefined_count': len(imports), 'missing': [],
            'exports': {name: exports[name] for name in imports},
            'modversions': modversions, 'CRC_comparison': 'MATCHED' if modversions else 'NOT_APPLICABLE_CONFIG_MODVERSIONS_DISABLED',
            'limit': 'Exact candidate build inputs; target loader, ABI execution and hardware remain unverified.'}


def build_native(source, headers, cross_compile, report_path, *, jobs=2):
    source, headers, report_path = map(Path, (source, headers, report_path))
    for path in (source, headers, report_path):
        writable_path(path)
    _separate(source, headers)
    if jobs < 1 or jobs > 16:
        raise ValueError('native build jobs must be 1..16')
    before = verify_source(source)
    snapshot = json.loads(regular_bytes(headers/'header-snapshot.json'))
    for name in CRITICAL_HEADERS:
        if file_record(headers/name) != snapshot['critical_inputs'][name]:
            raise ValueError('private completed-kernel header input changed: '+name)
    config = parse_config(regular_bytes(headers/'.config'))
    for name in ('ARM64', 'MODULES', 'PCI', 'HAS_DMA', 'COMPAT'):
        if config.get(name) != 'y':
            raise ValueError('fixed native build requires CONFIG_'+name+'=y')
    # No shell, no install target, and no ambient Kbuild redirect to another tree.
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('KBUILD_', 'KCONFIG_', 'LLVM')) and
           key not in ('ARCH', 'SRCARCH', 'CROSS_COMPILE', 'CC', 'LD', 'AR', 'NM',
                       'OBJCOPY', 'OBJDUMP', 'STRIP', 'KCFLAGS', 'KAFLAGS', 'KCPPFLAGS',
                       'CFLAGS_MODULE', 'AFLAGS_MODULE', 'CFLAGS_KERNEL', 'AFLAGS_KERNEL',
                       'MAKEFLAGS', 'MFLAGS', 'GNUMAKEFLAGS', 'MAKEOVERRIDES',
                       'KERNELRELEASE', 'LOCALVERSION', 'EXTRAVERSION')}
    env.update({'LC_ALL': 'C', 'TZ': 'UTC'})
    toolchain = toolchain_identity(cross_compile, env)
    command = ['make', '-C', str(headers.resolve()), 'M='+str(source.resolve()),
               'ARCH=arm64', 'CROSS_COMPILE='+cross_compile, 'W=1', 'V=1', '-j'+str(jobs), 'modules']
    report = {'schema': 1, 'status': 'BUILD_STARTED', 'source_commit': SOURCE_COMMIT,
              'source_overlays': [], 'source_inputs': before,
              'header_snapshot': file_record(headers/'header-snapshot.json'),
              'critical_kernel_inputs': snapshot['critical_inputs'],
              'linked_kernel': snapshot['linked_kernel'], 'command': command,
              'compiler_version': toolchain['gcc']['version'], 'toolchain': toolchain,
              'environment': {'LC_ALL': 'C', 'TZ': 'UTC', 'ambient_Kbuild_redirects_removed': True},
              'config': {key: config.get(key, 'NOT_RECORDED_IN_CONFIG') for key in CONFIG_KEYS},
              'runtime_status': 'TARGET_NOT_LOADED_ENVIRONMENT_NOT_VERIFIED',
              'observed_boot_id': None, 'observed_kernel_build_id': None,
              'observed_loaded_module_build_id': None,
              'limits': ['No module load, device open, target execution or board admission.',
                         'No new native lifecycle/UAPI/IRQ-mode changes.']}
    report_path.parent.mkdir(parents=True, exist_ok=True)
    write_json(report_path, report)
    stdout = report_path.with_suffix('.stdout.log')
    stderr = report_path.with_suffix('.stderr.log')
    writable_path(stdout)
    writable_path(stderr)
    started = time.time()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result = subprocess.run(command, cwd=source, env=env, stdout=out, stderr=err, check=False)
    report.update({'returncode': result.returncode, 'elapsed_seconds': round(time.time()-started, 3),
                   'stdout': file_record(stdout), 'stderr': file_record(stderr),
                   'source_unchanged': verify_source(source) == before,
                   'status': 'BUILD_FAILED' if result.returncode else 'BUILD_LINKED'})
    write_json(report_path, report)
    if result.returncode:
        raise RuntimeError('native build failed; see '+str(report_path))
    try:
        raw = regular_bytes(source/'ph1a_c2h.ko')
        info = module_info(raw)
        if info['name'] != 'ph1a_c2h' or info['parameters'] != PARAMETER_TYPES or info['modinfo'].get('alias'):
            raise ValueError('fixed native identity/parameters/dynamic-ID policy differ')
        release = regular_bytes(headers/'include/config/kernel.release').decode().strip()
        if info['vermagic'].split()[0] != release:
            raise ValueError('module vermagic differs from exact candidate release')
        report.update({'module': {**file_record(source/'ph1a_c2h.ko'), **info},
                       'exports': audit_exports(info, regular_bytes(headers/'Module.symvers'), config),
                       'build_records': {name: file_record(source/name) for name in
                                         ('.ph1a_c2h.o.cmd', '.ph1a_c2h.mod.o.cmd', '.ph1a_c2h.ko.cmd', 'ph1a_c2h.mod.c')},
                       'critical_headers_unchanged': all(file_record(headers/name) == record
                                                         for name, record in snapshot['critical_inputs'].items()),
                       'status': 'FILE_BUILT_AND_VERIFIED_TARGET_NOT_LOADED'})
        if not report['critical_headers_unchanged']:
            raise ValueError('native build changed critical candidate headers')
    except Exception as exc:
        report.update({'status': 'POST_LINK_VERIFICATION_FAILED', 'error': str(exc)})
        write_json(report_path, report)
        raise
    write_json(report_path, report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    extract = sub.add_parser('extract')
    extract.add_argument('--repo', required=True)
    extract.add_argument('--destination', required=True)
    extract.add_argument('--index', required=True)
    prepare = sub.add_parser('prepare-headers')
    prepare.add_argument('--kernel-source', required=True)
    prepare.add_argument('--kernel-output', required=True)
    prepare.add_argument('--destination', required=True)
    prepare.add_argument('--kernel-writer-completed', action='store_true', required=True)
    build = sub.add_parser('build')
    build.add_argument('--source', required=True)
    build.add_argument('--headers', required=True)
    build.add_argument('--cross-compile', required=True)
    build.add_argument('--report', required=True)
    build.add_argument('--jobs', type=int, default=2)
    args = parser.parse_args(argv)
    if args.action == 'extract':
        writable_path(args.index)
        result = extract_source(args.repo, args.destination)
        write_json(args.index, result)
    elif args.action == 'prepare-headers':
        result = prepare_headers(args.kernel_source, args.kernel_output, args.destination)
    else:
        result = build_native(args.source, args.headers, args.cross_compile, args.report, jobs=args.jobs)
    print(json.dumps({'status': result.get('status', result.get('kind', 'FIXED_SOURCE_EXTRACTED')),
                      'source_commit': SOURCE_COMMIT}, indent=2))


if __name__ == '__main__':
    main()
