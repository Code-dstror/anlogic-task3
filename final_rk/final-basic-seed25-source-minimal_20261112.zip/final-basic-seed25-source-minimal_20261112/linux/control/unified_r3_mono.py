"""Fixed seed8 MONO identity over a sealed implementation dependency.

The old FPS runtime is a library dependency, never authority for the new image.
Actual execution gets its own bit/source/profile and an exact cold contract.
The first R3 hardware readback is still pending; mismatch never relaxes a guard.
"""
import hashlib
import json
import os
from pathlib import Path
import threading
from types import MappingProxyType

RELEASE_ID = 'dual-unified-r3-seed8-mono'
SOURCE = 'dfea9eee53ebad3917d562d8c1e9f3bff30e8f4b'
BIT = '45f4b416b167c8db0e439998bc2203af59d07776c4d7ac53572fc7b1946cdbb5'
PACKAGE_SHA256 = '204ecc5ae22f7d7bc57b1fff34121fe981666c5a8a9580c2d1f57c08de043037'
BIT_PRODUCT = 'DUAL_UNIFIED_R3'
BIT_LABEL = 'DUAL_UNIFIED_R3_dfea9eee_seed8'
PROFILE = 'dual-unified-r3-seed8-remote-continuous'
SCOPE = 'DUAL_UNIFIED_R3_SEED8_CAM0_EIGHT_MODES_FINAL_HDMI_CIRCULAR_V1'
BASE_PROFILE = 'dual-hdr-seed1-mono-lane-overlay-10-60-10'
BASE_INDEX = 'bcc61838144953f9d98cf17e749e4ecd3bf1610853024b75b8eb182f68537d56'
DEPENDENCY_ROLE = 'SEALED_IMPLEMENTATION_LIBRARY_NOT_FIRMWARE_AUTHORITY'
POLICY_FILE = 'unified-r3-mono-policy.json'
POLICY_SHA256 = '47c77f957d459f802456e849a29070e01a8ab5af9526c5f08d0edc86a940645b'
LEGACY_BIT = '0e4de42629bd48f000782feeec65493dda8cf9126749b80dcc44e62211e4230e'
LEGACY_SOURCE = '06a122ee7060d56c5a4f783112cb727209c54ed5'
# Fixed copy of the checked engineering recipe, also bound by POLICY_SHA256.
# Identity import must work before the sealed runtime is added to sys.path.
HDR_POLICY = MappingProxyType(dict(hdr_ratio=4, hdr_black_long=50,
    hdr_black_short=50, hdr_motion_base=64, hdr_motion_shift=3,
    hdr_qualification=15, hdr_max_delta_ns=50_000_000,
    hdr_max_wait_ns=100_000_000, hdr_max_age_ns=1_000_000_000))


def configuration(hdr=False):
    if type(hdr) is not bool:
        raise ValueError('explicit SDR/HDR choice required')
    # No new exposure, tone or timing defaults are introduced by this release.
    fields={key:value if hdr else 0 for key,value in HDR_POLICY.items()}
    return dict(schema=2,base=dict(mode='COLOR',quality=75,flags=0,min_quality=1,
        frame_budget=0,restart_mcus=0),extension=dict(schema=2,product_mode=2 if hdr else 0,
        processing_enables=0,**fields,dehaze_lut_generation=0))


def source_at_or_after(sequence, first):
    return (type(sequence) is int and type(first) is int and
            0 <= sequence < 2**32 and 0 <= first < 2**32 and
            ((sequence - first) & 0xffffffff) < 0x80000000)


def verify_policy(root):
    body = (Path(root) / POLICY_FILE).read_bytes()
    if hashlib.sha256(body).hexdigest() != POLICY_SHA256:
        raise ValueError('Unified R3 MONO policy differs')
    value = json.loads(body)
    if (value['release_id'], value['source_commit'], value['bit_sha256'],
            value['package_sha256'], value['topology'], value['camera'],
            value['width'], value['height'], value['record_version'],
            value['header_bytes'], value['dual_allowed']) != (
            RELEASE_ID, SOURCE, BIT, PACKAGE_SHA256, 'MONO', 0,
            1920, 1080, 4, 2112, False):
        raise ValueError('Unified R3 fixed identity/record contract differs')
    if value['hdr_policy'] != HDR_POLICY:
        raise ValueError('Unified R3 must preserve the checked HDR recipe')
    return value


def verify_integration(config):
    expected = dict(release_id=RELEASE_ID, source_commit=SOURCE,
                    bit_sha256=BIT, package_sha256=PACKAGE_SHA256)
    if (config.get('firmware_release') != RELEASE_ID or
            config.get('firmware') != expected or
            config.get('runtime_role') != DEPENDENCY_ROLE or
            config.get('runtime_index_sha256') != BASE_INDEX or
            config.get('base_profile') != BASE_PROFILE or
            config.get('continuous') is not True or
            not isinstance(config.get('recording'),dict) or
            config['recording'].get('retention') != dict(mode='circular',low_water_bytes=2*1024**3,target_free_bytes=3*1024**3)):
        raise ValueError('dedicated Unified R3 MONO integration required')
    return expected


def _save_new(path, value):
    if path is None:
        return
    path = Path(path)
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('real fresh R3 evidence path required')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def input_fault_capture(run):
    """Keep the first owned packet without masking its original strict error."""
    run = Path(run)
    lock = threading.Lock()
    saved = False

    def capture(wire, error, *, host_ns=None):
        nonlocal saved
        with lock:
            if saved:
                return
            saved = True
            value = dict(release_id=RELEASE_ID, bit_sha256=BIT, source_commit=SOURCE,
                         error=str(error)[:2048], host_ns=host_ns,
                         completion_identity='UNKNOWN_NOT_INVENTED', captured=False)
            try:
                if type(wire) is bytes and 0 < len(wire) <= 4194304:
                    path = run / 'unified-r3-first-strict-error.ajpg'
                    with path.open('xb') as stream:
                        stream.write(wire)
                        stream.flush()
                        os.fsync(stream.fileno())
                    value.update(captured=True, bytes=len(wire),
                                 sha256=hashlib.sha256(wire).hexdigest(), file=path.name)
                else:
                    value['capture_reason'] = 'bounded owned bytes unavailable'
                _save_new(run / 'unified-r3-first-strict-error.json', value)
            except Exception as failure:
                # The SDK still reports the original receive/configuration
                # fault if the evidence storage itself has failed.
                value['capture_error'] = str(failure)[:512]
            capture.state = value

    capture.state = None
    return capture


def cold_admission(read32, *, base_cold, evidence_path=None, on_admitted=None):
    """Read-only before SELECT/START. Save mismatches; do not guess new caps."""
    reads = []
    proof = dict(release_id=RELEASE_ID, bit_sha256=BIT, source_commit=SOURCE,
                 contract='EXACT_REUSED_CFG1_SCHEMA2_RECORD4_STEREO_ABI2_MONO_BOOT',
                 qualification='CONSERVATIVE_EXPECTED_CONTRACT_NOT_PRIOR_R3_BOARD_RESULT',
                 sram_readback=False, reads=reads)

    def traced(offset):
        value = read32(offset)
        reads.append(dict(offset=hex(offset), value=value if type(value) is int else repr(value)[:100]))
        if len(reads) > 128:
            raise ValueError('R3 cold read evidence bound exceeded')
        return value

    try:
        result = base_cold(traced, source=SOURCE)
        if (result.get('source'), result.get('topology'), result.get('record_version'),
                result.get('header_bytes')) != (SOURCE, 'MONO', 4, 2112):
            raise ValueError('R3 cold guard returned a different contract')
    except BaseException as error:
        proof.update(status='REJECTED_BEFORE_SELECT_START_AND_RECLAIM', error=str(error))
        _save_new(evidence_path, proof)
        raise
    proof.update(status='MATCHED_CONSERVATIVE_CONTRACT', session=result['session'])
    _save_new(evidence_path, proof)
    # Actual SD reclamation is deliberately after the image's cold contract,
    # before the existing owner applies any configuration or starts video.
    if on_admitted is not None:
        on_admitted(result)
    return dict(result, bit_sha256=BIT, release_id=RELEASE_ID,
                contract_qualification=proof['qualification'])


def activate_policy(policy, *, evidence_path=None, on_admitted=None):
    """One fixed release in one fresh process; historical entries stay intact."""
    if (policy.BIT != LEGACY_BIT or policy.SOURCE != LEGACY_SOURCE or
            policy.PROFILE != 'dual-hdr-seed1-remote-mono600' or policy.UNLIMITED):
        raise ValueError('Unified R3 activation requires a fresh legacy implementation process')
    if __package__:
        from .unified_r3_epochs import UnifiedEpochs
    else:
        from unified_r3_epochs import UnifiedEpochs
    policy.BIT, policy.SOURCE = BIT, SOURCE
    policy.configuration = configuration
    policy.FIRMWARE_RELEASE, policy.FIRMWARE_LABEL = RELEASE_ID, BIT_LABEL
    policy.CONTINUOUS_PROFILE, policy.CONTINUOUS_SCOPE = PROFILE, SCOPE
    policy.Epochs = UnifiedEpochs
    policy.SOURCE_AT_OR_AFTER = source_at_or_after
    policy.COLD_ADMISSION = lambda read, base_cold: cold_admission(
        read, base_cold=base_cold, evidence_path=evidence_path, on_admitted=on_admitted)
