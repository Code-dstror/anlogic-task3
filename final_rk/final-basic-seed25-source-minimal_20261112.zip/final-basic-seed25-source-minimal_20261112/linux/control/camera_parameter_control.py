"""Cached parameter queue; only the existing owner reads or writes CFG."""
from copy import deepcopy
from pathlib import Path
import re

try:
    from .camera_mono_yolo_control import Broker as MonoBroker
    from .unified_stereo_control import ControlServer as LayoutServer
except ImportError:
    from camera_mono_yolo_control import Broker as MonoBroker
    from unified_stereo_control import ControlServer as LayoutServer


def parameter_model():
    try:from . import camera_fpga_parameters
    except ImportError:import camera_fpga_parameters
    return camera_fpga_parameters


def baseline(snapshot):
    return {key:snapshot[key] for key in ('session','epoch','fingerprint')}


def document_mode(document):
    extension=document['extension']
    if extension['product_mode']==2:return 'hdr' if extension['processing_enables']==0 else 'custom'
    return {0:'color',1:'gray',4:'gaussian',8:'histogram',48:'lane',2:'dehaze'}.get(
        extension['processing_enables'],'custom')


def plain(document):
    return document['extension']['product_mode']==0 and document['extension']['processing_enables']==0


class Broker(MonoBroker):
    def __init__(self,*args,parameter_model=None,**kwargs):
        self.parameter_model=parameter_model or globals()['parameter_model']()
        self.fpga_parameters=None;self.parameter_pending=None;self.actual_quality={}
        super().__init__(*args,**kwargs)

    def install_snapshot(self,snapshot):
        with self.lock:
            if (not isinstance(snapshot,dict) or not isinstance(snapshot.get('active_document'),dict)
                    or type(snapshot.get('session')) is not int or snapshot['session']<=0
                    or type(snapshot.get('epoch')) is not int or snapshot['epoch']<0
                    or not isinstance(snapshot.get('fingerprint'),str) or not snapshot['fingerprint']):
                raise ValueError('actual stable CFG snapshot required')
            self.fpga_parameters=deepcopy(snapshot)
            self.cfg_session=snapshot['session']

    def submit(self,request):
        with self.lock:
            if not isinstance(request,dict):raise ValueError('exact command object required')
            key=request.get('request_id')
            if isinstance(key,str) and key in self.commands:
                if self.commands[key]['request']!=request:raise ValueError('request ID reused')
                return deepcopy(self.commands[key])
            action=request.get('action')
            if action not in ('parameters','quality','mode'):return super().submit(request)
            snapshot=self.fpga_parameters
            if snapshot is None or self.spec['product']!='jpeg':raise ValueError('actual JPEG ACTIVE panel not ready')
            if action=='parameters':return self._submit_parameters(request,snapshot)
            # Pure cached validation before queueing either convenience entry.
            if action=='quality':
                document=self.parameter_model.merge_patch(snapshot,{'base.quality':request.get('quality')})
            else:document=self.parameter_model.preset(snapshot,request.get('mode'))
            self.parameter_model.validate_document(snapshot,document)
            result=super().submit(request)
            entry=self.commands[key];entry['baseline']=deepcopy(baseline(snapshot))
            entry['requested_document']=deepcopy(document)
            self.parameter_pending=None
            return deepcopy(entry)

    def _submit_parameters(self,request,snapshot):
        self._sync_stop()
        if set(request)!={'run_id','revision','request_id','action','patch','baseline'}:
            raise ValueError('exact parameter command fields required')
        revision=request['revision'];key=request['request_id'];patch=request['patch'];supplied=request['baseline']
        if (request['run_id']!=self.run_id or type(revision) is not int or revision<0
                or type(patch) is not dict or not patch or len(patch)>64
                or any(not isinstance(name,str) or len(name)>128 or type(value) not in (bool,int,str)
                       for name,value in patch.items())
                or not isinstance(supplied,dict) or any(k not in supplied for k in ('session','epoch','fingerprint'))
                or type(supplied['session']) is not int or type(supplied['epoch']) is not int
                or not isinstance(supplied['fingerprint'],str) or len(supplied['fingerprint'])>128
                or {k:supplied[k]for k in ('session','epoch','fingerprint')}!=baseline(snapshot)):
            raise ValueError('exact scalar patch and current session/epoch/fingerprint baseline required')
        prefix=self.run_id+'-'+str(revision)+'-'
        if (type(key) is not str or not key.startswith(prefix)
                or re.fullmatch(r'[A-Za-z0-9_-]{8,48}',key[len(prefix):]) is None):
            raise ValueError('fresh run/revision nonce required')
        if revision!=self.revision or not self._available():raise ValueError('owner busy, stale or stopped')
        document=self.parameter_model.merge_patch(snapshot,patch)
        self.parameter_model.validate_document(snapshot,document)
        if document==snapshot['active_document']:raise ValueError('parameter patch has no change')
        entry=dict(request=deepcopy(request),baseline=deepcopy(baseline(snapshot)),
            requested_document=deepcopy(document),configuration_mode='custom',status='QUEUED',confirmation=None)
        self.commands[key]=entry;self.total_commands+=1;self.revision+=1
        self.pending=key;self.phase='QUEUED';self._deadline=self.clock()+self.confirmation_timeout_s
        self.ai_failure=None;self.expected_ai=None;self.parameter_pending=None
        while len(self.commands)>64:self.commands.popitem(last=False)
        return deepcopy(entry)

    def take(self):
        with self.lock:
            request=super().take()
            if request is not None and request['action']=='parameters':
                return dict(request,action='mode',mode='custom',_parameter_request=True)
            return request

    def transaction_baseline(self,request_id):
        with self.lock:return deepcopy(self.commands[request_id]['baseline'])

    def prepare_confirmation(self,request_id,before,document,after,*,yolo):
        """Called by the sole CFG worker after real APPLIED and ACTIVE agree."""
        with self.lock:
            if self._cancelled_by_stop():return False
            entry=self.commands[request_id]
            if (self.pending!=request_id or self.phase!='VERIFYING_VIDEO'
                    or baseline(before)!=entry['baseline'] or after['session']!=before['session']
                    or after['epoch']<=before['epoch'] or after['active_document']!=document):
                raise ValueError('actual same-session new APPLIED/ACTIVE document required')
            entry.update(requested_document=deepcopy(document),configuration_mode='yolo' if yolo else document_mode(document),
                applied_session=after['session'],applied_epoch=after['epoch'],applied_quality=document['base']['quality'],
                active_fingerprint=after['fingerprint'])
            self.parameter_pending=dict(request_id=request_id,session=after['session'],epoch=after['epoch'],
                document=deepcopy(document),yolo=yolo)
            self.expected_ai=(after['session'],after['epoch']) if yolo else None
            self.install_snapshot(after)
            return True

    def confirm_applied(self,request_id,receipt):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            expected=self.parameter_pending
            if (expected is None or expected['request_id']!=request_id or self.pending!=request_id
                    or (receipt.session,receipt.mode_epoch)!=(expected['session'],expected['epoch'])):
                raise ValueError('exact prepared APPLIED proof required')
            self.commands[request_id]['status']='APPLIED_WAITING_REAL_VIDEO'
            return True

    def reject_before_commit(self,request_id,error):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            if self.pending!=request_id:raise ValueError('matching uncommitted request required')
            self.commands[request_id].update(status='CONFIG_REJECTED_VIDEO_CONTINUES',error=str(error)[:512])
            self.pending=None;self._deadline=None;self.phase='READY';self._heartbeat=self.clock()
            return True

    def completed_configuration(self,request_id,epoch,ordinal,actual_quality):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            proof=self.parameter_pending
            if (proof is None or proof['request_id']!=request_id or proof['epoch']!=epoch
                    or self.pending!=request_id or type(ordinal) is not int or ordinal<=self.frame_ordinal):
                raise ValueError('new actual selected/accepted record proof required')
            if self.clock()>self._deadline:raise TimeoutError('parameter video confirmation deadline exceeded')
            self.actual_quality=deepcopy(actual_quality)
            self.quality=proof['document']['base']['quality']
            self.commands[request_id]['video_confirmation']=dict(session=proof['session'],epoch=epoch,
                frame_ordinal=ordinal,actual_quality=deepcopy(actual_quality))
            if proof['yolo']:
                self.ai_video=(request_id,epoch,ordinal)
                self.commands[request_id]['status']='WAITING_AI_RESULT'
                return False
            return self._finish_configuration(request_id,epoch,ordinal)

    def _finish_configuration(self,request_id,epoch,ordinal,*,ai_error=None):
        proof=self.parameter_pending;entry=self.commands[request_id]
        self.current_mode='color' if ai_error else entry['configuration_mode']
        self.mode_epoch=epoch;self.frame_ordinal=ordinal;self.quality=proof['document']['base']['quality']
        action=entry['request']['action']
        entry.update(status='AI_FAILED_VIDEO_CONTINUES' if ai_error else
            'QUALITY_VIDEO_CONFIRMED' if action=='quality' else 'VIDEO_CONFIRMED',
            confirmation=dict(action=action,session=proof['session'],mode_epoch=epoch,frame_ordinal=ordinal,
                mode=self.current_mode,quality=self.quality,actual_quality=deepcopy(self.actual_quality),
                active_document=deepcopy(proof['document']),active_fingerprint=entry['active_fingerprint']))
        if ai_error:entry['error']=str(ai_error)[:512]
        self.pending=self._deadline=self.parameter_pending=self.ai_video=self.expected_ai=None
        self.phase='READY';self._heartbeat=self.clock()
        return True

    def confirm_ai(self,state):
        with self.lock:
            if self.ai_video is None or self._cancelled_by_stop():return False
            if self.clock()>self._deadline:
                self._fail_ai('YOLO first result deadline exceeded');return False
            if (not isinstance(state,dict) or not state.get('ready') or not state.get('output_confirmed')
                    or state.get('error') or (state.get('session'),state.get('epoch'))!=self.expected_ai):return False
            key,epoch,ordinal=self.ai_video
            self.ai_failure=None
            return self._finish_configuration(key,epoch,ordinal)

    def _fail_ai(self,error):
        key,epoch,ordinal=self.ai_video
        self.ai_failure=str(error)[:512]
        self._finish_configuration(key,epoch,ordinal,ai_error=self.ai_failure)

    def completed_topology(self,*args,**kwargs):
        result=super().completed_topology(*args,**kwargs)
        if result:
            with self.lock:self.parameter_pending=None;self.actual_quality={}
        return result

    def state(self):
        result=super().state()
        with self.lock:
            result.update(fpga_parameters=deepcopy(self.fpga_parameters),actual_quality=deepcopy(self.actual_quality))
            # The HTTP server has a 64KiB response bound. Keep complete CFG
            # documents in the owner journal/current panel, not repeated in
            # every historical command of an unlimited session.
            result['commands_retained']=len(self.commands)
            result['commands_history_window']=16
            result['commands']=result['commands'][-16:]
            for entry in result['commands']:
                entry.pop('requested_document',None)
                confirmation=entry.get('confirmation')
                if isinstance(confirmation,dict):confirmation.pop('active_document',None)
        return result


class ControlServer(LayoutServer):
    def __init__(self,broker,**kwargs):
        super().__init__(broker,page=Path(__file__).with_name('camera_parameter_control.html'),**kwargs)
