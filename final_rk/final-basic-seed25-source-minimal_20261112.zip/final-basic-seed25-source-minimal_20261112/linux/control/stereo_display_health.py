"""Video freshness over actual selected inputs, separate from decode throughput."""

POLICY='REALTIME_VISIBLE_SOURCE_V1'


class StereoDisplayHealth:
    def __init__(self,*,started_ns,initial_timeout_ns=15_000_000_000,stall_timeout_ns=3_000_000_000):
        if type(started_ns) is not int or started_ns<=0:raise ValueError('positive host monotonic start required')
        self.started=started_ns;self.initial_timeout=initial_timeout_ns;self.stall_timeout=stall_timeout_ns
        self.last_now=started_ns;self.last_accepted=0

    def observe(self,timing,*,now_ns):
        if type(now_ns) is not int or now_ns<self.last_now:raise ValueError('display health clock moved backwards')
        self.last_now=now_ns
        if timing.get('abi')!=1 or timing.get('enabled')!=1:raise ValueError('admitted realtime timing evidence required')
        stamp=timing['last_accepted_ns'];mask=timing['visible_mask']
        if type(stamp) is not int or stamp<self.last_accepted or stamp>now_ns:raise ValueError('invalid actual output clock')
        self.last_accepted=stamp
        if not stamp:
            if now_ns-self.started>self.initial_timeout:raise TimeoutError('no fresh stereo output within startup deadline')
            return dict(status='WAITING_FIRST_REAL_OUTPUT',visible_mask=0)
        if mask not in (1,2,3):raise ValueError('actual visible camera mask required')
        ages=[]
        for camera in (0,1):
            if not mask&(1<<camera):continue
            new=timing['last_new%d_ns'%camera];age=timing['age%d_ns'%camera]
            if type(new) is not int or not 0<new<=stamp or type(age) is not int or age<0:raise ValueError('invalid selected input freshness')
            if age>timing['input_age_budget_ns']:raise ValueError('stale visible input passed common display/record admission')
            age_now=now_ns-new;ages.append(age_now)
            if age_now>self.stall_timeout:raise TimeoutError('visible CAM%d stopped selecting new SOURCE'%camera)
        if now_ns-stamp>self.stall_timeout:raise TimeoutError('fresh final output has stalled')
        return dict(status='FRESH',visible_mask=mask,last_accepted_ns=stamp,
                    visible_progress_age_ns=max(ages),scope='SELECTED_SOURCE_AT_COMPOSITION_NOT_PHYSICAL_HDMI_SCAN')
