"""Seed25 mono-first 4G application with optional asynchronous RK YOLO mode."""
try:
    from .launch_camera_session import main
except ImportError:
    from launch_camera_session import main

if __name__=='__main__':raise SystemExit(main(mono_yolo=True))
