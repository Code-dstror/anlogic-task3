"""Revalidate the qualified prebuilt driver for an identical live BSP kernel."""
import gzip
import hashlib
import json
import os
from pathlib import Path

try:
    from . import camera_session_driver as session
    from . import camera_raw_driver as raw
except ImportError:
    import camera_session_driver as session
    import camera_raw_driver as raw


def revalidate(original,ko,boot,source_hashes,*,live_kernel):
    """Pure receipt constructor; caller captures fresh kernel identity first.

    Retains the complete original build receipt and its original boot. This is
    explicitly a new-boot identity check, never a claim of rebuilding the KO.
    """
    origin_boot=original.get('runtime',{}).get('boot_id')
    module,info=session.validate_audit(original,boot=origin_boot,source_hashes=source_hashes)
    expected=dict(machine='aarch64',release='6.1.99',kernel_build_id=raw.KERNEL_BUILD,config_sha256=raw.KERNEL_CONFIG)
    if live_kernel!=expected:raise ValueError('BSP kernel differs; this prebuilt module cannot be loaded')
    body=Path(ko).read_bytes()
    if len(body)!=module['bytes'] or hashlib.sha256(body).hexdigest()!=module['sha256']:
        raise ValueError('qualified prebuilt module differs')
    try:from .raw_module_audit import module_info
    except ImportError:from raw_module_audit import module_info
    raw.validate_module_bytes(body,info,module_info)
    receipt=dict(status='PREBUILT_TARGET_REVALIDATED_NOT_LOADED',runtime=dict(original['runtime'],boot_id=boot),
        revalidation='EXACT_KERNEL_IDENTITY_AND_UNCHANGED_KO',origin_build_audit=original,
        module=dict(module,path=str(Path(ko).resolve(strict=True))))
    session.validate_audit(receipt,boot=boot,source_hashes=source_hashes)
    return receipt


def live_identity():
    from dual_r3_driver import note_build_id
    return dict(machine=os.uname().machine,release=os.uname().release,
        kernel_build_id=note_build_id(Path('/sys/kernel/notes').read_bytes()),
        config_sha256=hashlib.sha256(gzip.decompress(Path('/proc/config.gz').read_bytes())).hexdigest())
