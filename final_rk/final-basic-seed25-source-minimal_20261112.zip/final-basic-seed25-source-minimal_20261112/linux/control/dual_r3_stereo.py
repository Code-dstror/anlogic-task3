"""Fixed seed2 cold DUAL_JPEG/N2 admission and persistent SOURCE routing.

Linux transport only. The caller owns/serializes one native Receiver throughout
prepare -> SELECT v4 -> START/receive/STOP. This module never opens, starts,
closes, resets or recovers a device, and supplies no runtime CFG entry point.
Imports of the fixed-package SDK are lazy so ordinary module import is inert.
"""
from dataclasses import asdict
from copy import deepcopy
import time

if __package__:
    from . import dual_sdr_seed51 as seed51
    from .cold_mmio_journal import ColdMmioJournal
    from .dual_r3 import (BIT, SOURCE, VERSION, HEADER_BYTES, MAX_RECORD_BYTES,
                          MAX_JPEG_BYTES, STEREO_READ_OFFSETS, cold_admission)
else:
    import dual_sdr_seed51 as seed51
    from cold_mmio_journal import ColdMmioJournal
    from dual_r3 import (BIT, SOURCE, VERSION, HEADER_BYTES, MAX_RECORD_BYTES,
                         MAX_JPEG_BYTES, STEREO_READ_OFFSETS, cold_admission)

PROFILE = 'dual-r3-stereo-color-n2-kms30'
FRAME_DIVISOR = 2
STEREO_EXTRA_READ_OFFSETS = (0xf8c, 0xfa0)
STEREO_COLD_WRITE_OFFSETS = (0xf8c, 0xf90, 0xfa0)
RECORD_SELECT_WRITE_OFFSETS = (0x290, 0x294, 0x298, 0x29c)
REQUIRED_READ_OFFSETS = STEREO_READ_OFFSETS + STEREO_EXTRA_READ_OFFSETS


class StereoAdmissionError(RuntimeError):
    """Cold/session/source validation failure; native ownership is retained."""


def _camera_values(value, name):
    if (type(value) is not dict or set(value) != {0, 1} or
            any(type(v) is not int or not 0 <= v <= 0xffffffff for v in value.values()) or
            (name == 'source_sessions' and any(v == 0 for v in value.values()))):
        raise ValueError(name+' requires explicit CAM0/CAM1 u32 values')
    return dict(value)


class ColdStereoPreparation:
    """One intent, same native fd, fixed Q75/N2, no START or runtime CFG.

    Requires a reviewed stereo-capable KO/Python policy. The old MONO KO cannot
    perform this operation. New kernel write offsets must also use its existing
    record-write running/active guard. An error, including copyout uncertainty,
    permanently faults this helper; the caller retains its Receiver unchanged.
    """
    def __init__(self, receiver, *, evidence=None, profile=None):
        rescues = getattr(seed51, 'LOSSY_PROFILES', getattr(seed51, 'RESCUE_PROFILES',
                          (getattr(seed51, 'RESCUE_PROFILE', None),)))
        hdr_seed1 = profile == 'dual-hdr-seed1-dual-drop-stale-cam0-cam1'
        if profile not in (None, seed51.PROFILE, *rescues) and not hdr_seed1:
            raise ValueError('unknown cold stereo release profile; HDR is not permitted')
        self.profile = PROFILE if profile is None else profile
        self.bit = BIT if profile is None else seed51.BIT
        self.source = SOURCE if profile is None else seed51.SOURCE
        if hdr_seed1:
            if __package__:
                from . import dual_hdr_seed1 as release
            else:
                import dual_hdr_seed1 as release
            self.bit,self.source = release.BIT,release.SOURCE
        self.evidence = evidence
        self.evidence_error = None
        self.partial = {}
        self.journal = None
        self.failed_phase = None
        self.receiver = receiver
        self.state = 'NEW'
        self.failure = None
        self.receipt = None

    def snapshot(self):
        return deepcopy(dict(state=self.state, failure=self.failure,
            profile=self.profile, bit_sha256=self.bit, fpga_source=self.source,
            failed_phase=self.failed_phase, partial=self.partial,
            receipt_complete=self.receipt is not None,
            evidence_error=self.evidence_error,
            mmio=None if self.journal is None else self.journal.snapshot(),
            hardware_snapshot='NO_EXTRA_READS_AFTER_FAILURE'))

    def _checkpoint(self):
        if self.evidence is not None:
            try:
                self.evidence(self.snapshot())
            except BaseException as error:
                self.evidence_error = type(error).__name__+': '+str(error)[:512]
                raise

    def _native_cold(self):
        info = self.receiver.snapshot()
        expected = dict(user_abi=2, slots=2, capacity=MAX_RECORD_BYTES,
                        running=0, quarantined=0, submitted=0, completed=0)
        if (any(type(getattr(info, key, None)) is not int or getattr(info, key) != val
                for key, val in expected.items()) or
                type(self.receiver.leased_count) is not int or self.receiver.leased_count != 0):
            raise StereoAdmissionError('stereo requires the fresh native owner, no START/descriptors/leases')
        return info

    def prepare(self, *, timeout_s=3., poll_interval_s=.001,
                clock=time.monotonic, sleep=time.sleep):
        if self.state != 'NEW':
            raise StereoAdmissionError('stereo preparation already attempted; no retry/reopen')
        self.state = 'PREPARING'
        self.journal = ColdMmioJournal(clock=clock)
        try:
            self._checkpoint()
            from dual_host.stereo_control import select_cold_mode
            from linux.task3_pipeline.record_selection import select_record
            before = self._native_cold()
            self.partial['native_before'] = asdict(before)
            def read(offset):
                return self.journal.call('READ', offset, self.receiver.read32)
            admission = cold_admission(read, source=self.source)
            self.partial['cold_mono'] = admission
            self._checkpoint()
            phase = ['TOPOLOGY']

            def write(offset, value):
                allowed = (STEREO_COLD_WRITE_OFFSETS if phase[0] == 'TOPOLOGY'
                           else RECORD_SELECT_WRITE_OFFSETS)
                if offset not in allowed:
                    raise StereoAdmissionError('stereo trial forbids this MMIO write: '+hex(offset))
                self._native_cold()
                self.journal.call('WRITE', offset, self.receiver.write32, value)

            self.journal.phase = 'TOPOLOGY'
            topology = select_cold_mode(read, write, 1,
                timeout_s=timeout_s, poll_interval_s=poll_interval_s,
                frame_divisor=FRAME_DIVISOR, jpeg_quality=75, monotonic=clock, sleep=sleep)
            self.partial['topology_returned'] = asdict(topology)
            if (topology.mode, topology.cfg_session, topology.frame_divisor, topology.jpeg_quality) != (
                    1, admission['session'], FRAME_DIVISOR, 75):
                raise StereoAdmissionError('cold DUAL_JPEG acknowledgement differs')
            self.state = 'TOPOLOGY_APPLIED'
            self.partial['topology_validated'] = True
            self._checkpoint()
            phase[0] = self.journal.phase = 'RECORD_SELECT'
            bar = type('OwnedBar', (), dict(read32=staticmethod(read),
                                           write32=staticmethod(write)))()
            selected = select_record(bar, VERSION, timeout_s=timeout_s,
                poll_interval_s=poll_interval_s, clock=clock, sleep=sleep)
            self.partial['record_selection_returned'] = asdict(selected)
            if (selected.version, selected.header_length, selected.session) != (
                    VERSION, HEADER_BYTES, admission['session']):
                raise StereoAdmissionError('v4 SELECT source session/header differs')
            self.partial['record_selection_validated'] = True
            self.state = 'RECORD_SELECTED'
            self._checkpoint()
            self.journal.phase = 'FINAL_NATIVE_CHECK'
            after = self._native_cold()
            self.partial['native_after'] = asdict(after)
            self.receipt = dict(profile=self.profile, bit_sha256=self.bit, fpga_source=self.source,
                cold_mono=admission, topology=asdict(topology), record_selection=asdict(selected),
                native_before=asdict(before), native_after=asdict(after),
                source_sessions={0:topology.cfg_session, 1:topology.cfg_session},
                source_epochs={0:0, 1:0}, native_started=False,
                topology_order='SAME_OWNER_COLD_APPLY_N2_THEN_SELECT_V4_THEN_CALLER_START',
                hardware_validation='NOT_ESTABLISHED_BY_SOFTWARE_ACK_ALONE',
                physical_sync='NOT_QUALIFIED')
            self.state = 'PREPARED'
            self._checkpoint()
            return self.receipt
        except BaseException as error:
            self.failed_phase = self.journal.phase
            self.state = 'FAULTED'
            self.failure = type(error).__name__+': '+str(error)[:512]
            try:
                self._checkpoint()
            except BaseException:
                pass  # Preserve the original protocol/IO error; expose evidence_error.
            raise


def validate_color_record(record):
    """Only bounded physical CAM0/1 RAW10/SINGLE v4 pure COLOR records."""
    from linux.task3_pipeline import pcie_protocol_v1 as p
    m, a = record.metadata, record.s07
    s = None if m is None else m.source
    if (s is None or (record.width, record.height) != (1920, 1080) or
            s.camera not in (0, 1) or not 3*s.camera <= m.jpeg_slot < 3*(s.camera+1) or
            (s.kind, s.format, s.role) != (p.PCIE_RECORD_V2_SOURCE_PHYSICAL,
                p.PCIE_RECORD_V2_FORMAT_RAW10, p.PCIE_RECORD_V2_ROLE_SINGLE) or
            m.processing_mode != p.PCIE_RECORD_V2_MODE_SCHEMA2_TAG or
            m.record_flags or m.validity_flags & p.PCIE_RECORD_V2_FLAG_HDR_PRODUCT or
            m.processing_member or a is None or a.enabled or a.frame_error or
            any(getattr(a, name) is not None for name in ('f22','f23','f24','f25')) or
            not 4 <= len(record.jpeg) <= MAX_JPEG_BYTES):
        raise StereoAdmissionError('stereo trial requires bounded CAM0/1 physical RAW10 SINGLE pure COLOR without analysis')
    return record


class StereoSourceRouter:
    """Persistent per-camera SDK ordering, never pair by same sequence number.

    One instance per receiver lifetime. Both SOURCE sessions are explicit and
    independently checked; this cold trial normally supplies the same BOOT CFG
    session for both. JPEG session, sequence and slot generations remain camera
    local. Epoch changes are forbidden without a separately authorized profile.
    Invalid input latches a terminal fault before any downstream decoder call.
    """
    def __init__(self, *, source_sessions, source_epochs=None, source_order_policy='strict'):
        if source_order_policy not in ('strict', 'drop_stale'):
            raise ValueError('unknown SOURCE order policy')
        self.sessions = _camera_values(source_sessions, 'source_sessions')
        self.epochs = _camera_values({0:0, 1:0} if source_epochs is None else source_epochs,
                                     'source_epochs')
        self.source_order_policy = source_order_policy
        self._drop_type = ()
        if source_order_policy == 'strict':
            # Keep the original SDK path and dependencies for old strict bundles.
            from dual_host.dual_records import DualRecordDemux
            self.demux = {camera:DualRecordDemux(record_version=VERSION,
                           source_session=self.sessions[camera]) for camera in (0, 1)}
        else:
            if __package__:
                from .stereo_source_order import SourceOrderDemux, SourceOrderDrop
            else:
                from stereo_source_order import SourceOrderDemux, SourceOrderDrop
            self._drop_type = SourceOrderDrop
            self.demux = {camera:SourceOrderDemux(record_version=VERSION,
                           source_session=self.sessions[camera], source_epoch=self.epochs[camera],
                           source_order_policy=source_order_policy) for camera in (0, 1)}
        self.faulted = False
        self.failure = None
        self.last_sequence = {}
        self.sequence_missing = [0, 0]
        self.drop_duplicate_source = [0, 0]
        self.drop_backward_source = [0, 0]

    def accept(self, wire):
        if self.faulted:
            raise StereoAdmissionError('stereo SOURCE router faulted; no later record permitted')
        try:
            from linux.stream_diag.records import parse_record
            from linux.task3_pipeline import pcie_protocol_v1 as p
            owned = bytes(wire)
            if not HEADER_BYTES+4 <= len(owned) <= MAX_RECORD_BYTES:
                raise StereoAdmissionError('stereo complete owned record exceeds the native pool bound')
            header = dict(zip(p.FRAME_HEADER_FIELD_NAMES,
                              p.FRAME_HEADER_STRUCT.unpack(owned[:p.FRAME_HEADER_SIZE])))
            if header['quality'] != 75:
                raise StereoAdmissionError('stereo record changed the fixed cold Q75 policy')
            record = validate_color_record(parse_record(owned, expected_version=VERSION))
            source = record.metadata.source
            if source.epoch != self.epochs[source.camera]:
                raise StereoAdmissionError('unexpected per-camera SOURCE epoch; runtime CFG forbidden')
            item = self.demux[source.camera].accept(owned)
            if isinstance(item, self._drop_type):
                if item.reason == 'DROP_DUPLICATE_SOURCE':
                    self.drop_duplicate_source[item.camera] += 1
                elif item.reason == 'DROP_BACKWARD_SOURCE':
                    self.drop_backward_source[item.camera] += 1
                else:
                    raise StereoAdmissionError('unknown typed SOURCE drop reason')
                return item
            previous = self.last_sequence.get(item.camera)
            if previous is not None:
                self.sequence_missing[item.camera] += ((item.sequence-previous)&0xffffffff)-1
            self.last_sequence[item.camera] = item.sequence
            return item
        except BaseException as error:
            self.faulted = True
            self.failure = type(error).__name__+': '+str(error)
            raise

    def snapshot(self):
        return dict(record_version=VERSION, faulted=self.faulted, failure=self.failure,
                    source_order_policy=self.source_order_policy,
                    source_sessions=dict(self.sessions), source_epochs=dict(self.epochs),
                    cameras=[dict(camera=c,records=self.demux[c].frames[c],
                        accepted=self.demux[c].frames[c],
                        drop_duplicate_source=self.drop_duplicate_source[c],
                        drop_backward_source=self.drop_backward_source[c],
                        jpeg_bytes=self.demux[c].jpeg_bytes[c],last_sequence=self.last_sequence.get(c),
                        last_accepted_sequence=self.last_sequence.get(c),
                        sequence_missing=self.sequence_missing[c]) for c in (0,1)],
                    sequence_missing_semantics='FORWARD_SEQUENCE_GAPS_NOT_TRANSPORT_LOSS_N2_GAPS_AND_SOURCE_DROPS_ARE_NOT_ADDITIVE',
                    physical_sync='NOT_QUALIFIED', pairing='NONE_INDEPENDENT_CAMERA_STREAMS')
