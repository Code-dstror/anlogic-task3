"""Unlimited normal mono/dual rebuild commands, with real new-session confirmation."""
from copy import deepcopy
import re
try:
    from .camera_raw_control import Broker as CameraBroker
    from .unified_stereo_control import ControlServer as LayoutServer
    from . import camera_raw_release as release
except ImportError:
    from camera_raw_control import Broker as CameraBroker
    from unified_stereo_control import ControlServer as LayoutServer
    import camera_raw_release as release
from pathlib import Path

REBUILD_SECONDS = 120  # Sum of bounded drain/BOOT/select/first-video stages plus overhead.


class Broker(CameraBroker):
    def __init__(self, *args, allow_topology_rebuild=True, **kwargs):
        if type(allow_topology_rebuild) is not bool:raise ValueError('explicit topology policy required')
        self.allow_topology_rebuild=allow_topology_rebuild
        super().__init__(*args, **kwargs)
        self.session_generation = 0
        self.cfg_session = None
        self.rebuild_stage = None

    def submit(self, request):
        if not isinstance(request, dict) or request.get('action') != 'topology':
            return super().submit(request)
        if not self.allow_topology_rebuild:
            raise ValueError('本复现包按冷启动选择目数；共同断电、下载同bit后重新选择')
        with self.lock:
            self._sync_stop()
            if set(request) != {'run_id','revision','request_id','action','cameras'}:
                raise ValueError('exact topology command fields required')
            if request['run_id'] != self.run_id or type(request['revision']) is not int:
                raise ValueError('stale run/revision')
            key = request['request_id']
            prefix = self.run_id+'-'+str(request['revision'])+'-'
            if (type(key) is not str or not key.startswith(prefix)
                    or re.fullmatch(r'[A-Za-z0-9_-]{8,48}',key[len(prefix):]) is None):
                raise ValueError('fresh run/revision nonce required')
            if type(request['cameras']) is not int or request['cameras'] not in (1,2):
                raise ValueError('JPEG mono/dual only')
            if key in self.commands:
                if self.commands[key]['request'] != request:
                    raise ValueError('request ID reused')
                return deepcopy(self.commands[key])
            if (request['revision'] != self.revision or not self._available()
                    or request['cameras'] == self.spec['cameras']):
                raise ValueError('already selected, busy or stale owner')
            entry = dict(request=deepcopy(request),status='QUEUED',confirmation=None)
            self.commands[key] = entry
            self.total_commands += 1
            self.revision += 1
            self.pending = key
            self.phase = 'QUEUED'
            self._deadline = self.clock()+REBUILD_SECONDS
            while len(self.commands)>64:
                self.commands.popitem(last=False)
            return deepcopy(entry)

    def topology_queued(self):
        with self.lock:
            return (self.phase == 'QUEUED' and self.pending is not None
                    and self.commands[self.pending]['request']['action'] == 'topology')

    def rebuilding(self, request_id, stage):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():
                return False
            if self.pending != request_id or self.phase != 'VERIFYING_VIDEO':
                raise ValueError('matching topology worker required')
            self.rebuild_stage = stage
            self.commands[request_id]['status'] = stage
            return True

    def completed_topology(self, request_id, *, cfg_session, old_session, rendered):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():
                return False
            if self.pending != request_id or self.phase != 'VERIFYING_VIDEO':
                raise ValueError('topology command not pending')
            entry = self.commands[request_id]
            cameras = entry['request']['cameras']
            rows = rendered.get('cameras', [])
            if (type(cfg_session) is not int or not cfg_session or cfg_session == old_session
                    or rendered.get('layout') != 'cam0' or not rendered.get('ordinal')
                    or {r['camera'] for r in rows} != set(range(cameras))
                    or any(r.get('session') != cfg_session or r.get('epoch') != 0 for r in rows)):
                raise ValueError('new topology needs actual fresh-session products/output')
            self.session_name = 'mono-jpeg' if cameras == 1 else 'dual-jpeg'
            self.spec = release.session_spec(self.session_name)
            self.mode_rows = release.modes(self.session_name)
            self.current_mode = 'color'
            self.mode_epoch = 0
            self.cfg_session = cfg_session
            self.session_generation += 1
            self.current = 'cam0'
            self.layout_revision = rendered['layout_revision']
            self.frame_ordinal = rendered['ordinal']
            entry.update(status='VIDEO_CONFIRMED',confirmation=dict(
                old_session=old_session,new_session=cfg_session,cameras=cameras,
                generation=self.session_generation,ordinal=self.frame_ordinal))
            self.pending = self._deadline = self.rebuild_stage = None
            self.phase = 'READY'
            self._heartbeat = self.clock()
            return True

    def state(self):
        value = super().state()
        with self.lock:
            value.update(topology_rebuild=self.allow_topology_rebuild,topology_cameras=self.spec['cameras'],
                         session_generation=self.session_generation,cfg_session=self.cfg_session,
                         rebuild_stage=self.rebuild_stage,
                         cold_selection=('同一owner正常排空后重建图像会话，切换时视频短暂中断' if self.allow_topology_rebuild
                             else '目数在本次冷启动锁定；切换单/双目需共同断电并重新下载同bit'))
        return value


class ControlServer(LayoutServer):
    def __init__(self, broker, **kwargs):
        super().__init__(broker,page=Path(__file__).with_name('camera_session_control.html'),**kwargs)
