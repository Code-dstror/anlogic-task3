"""Opt-in mono YOLO command with real video and first AI-result confirmation."""
from copy import deepcopy
from pathlib import Path
import re
try:
    from .camera_session_control import Broker as SessionBroker
    from .unified_stereo_control import ControlServer as LayoutServer
except ImportError:
    from camera_session_control import Broker as SessionBroker
    from unified_stereo_control import ControlServer as LayoutServer

YOLO=dict(id='yolo',label='YOLO 多目标检测与测距',enables=0,target_fps=60,rk_ai=True)


class Broker(SessionBroker):
    def __init__(self,*args,ai_provider=lambda:None,**kwargs):
        super().__init__(*args,**kwargs)
        self.ai_provider=ai_provider;self.ai_video=None;self.ai_failure=None;self.expected_ai=None
        self.quality=75;self.expected_configuration=None
        self._modes()

    def submit(self,request):
        if isinstance(request,dict) and request.get('action')=='quality':
            return self._submit_quality(request)
        if (isinstance(request,dict) and request.get('mode')=='yolo'
                and request.get('request_id') not in self.commands):
            ai=self.ai_provider() or {}
            if ai.get('retained') and not ai.get('retired'):
                raise ValueError('old AI resources retained; other video modes remain available')
        result=super().submit(request)
        if result['status']=='QUEUED' and request.get('action')=='mode':
            with self.lock:
                entry=self.commands[request['request_id']]
                entry.setdefault('requested_quality',self.quality)
                entry.setdefault('configuration_mode',request['mode'])
                self.ai_failure=None;self.expected_ai=None;self.expected_configuration=None
        return result

    def _submit_quality(self,request):
        with self.lock:
            self._sync_stop()
            if set(request)!={'run_id','revision','request_id','action','quality'}:
                raise ValueError('exact JPEG quality command fields required')
            quality=request['quality'];key=request['request_id'];revision=request['revision']
            if (request['run_id']!=self.run_id or type(revision) is not int or revision<0
                    or type(quality) is not int or not 1<=quality<=100):
                raise ValueError('fresh run/revision and integer JPEG quality 1..100 required')
            prefix=self.run_id+'-'+str(revision)+'-'
            if (type(key) is not str or not key.startswith(prefix)
                    or re.fullmatch(r'[A-Za-z0-9_-]{8,48}',key[len(prefix):]) is None):
                raise ValueError('fresh run/revision nonce required')
            if key in self.commands:
                if self.commands[key]['request']!=request:raise ValueError('request ID reused')
                return deepcopy(self.commands[key])
            if (self.spec['product']!='jpeg' or revision!=self.revision or not self._available()
                    or quality==self.quality):
                raise ValueError('JPEG quality already selected, busy, stopped or unavailable')
            entry=dict(request=deepcopy(request),status='QUEUED',confirmation=None,
                requested_quality=quality,configuration_mode=self.current_mode)
            self.commands[key]=entry;self.total_commands+=1;self.revision+=1
            self.pending=key;self.phase='QUEUED';self._deadline=self.clock()+self.confirmation_timeout_s
            self.ai_failure=None;self.expected_ai=None;self.expected_configuration=None
            while len(self.commands)>64:self.commands.popitem(last=False)
            return deepcopy(entry)

    def take(self):
        with self.lock:
            request=super().take()
            if request is not None and request['action']=='quality':
                entry=self.commands[request['request_id']]
                return dict(request,action='mode',mode=entry['configuration_mode'],_quality_request=True)
            return request

    def command_quality(self,request_id):
        with self.lock:return self.commands[request_id]['requested_quality']

    def _command_mode(self,entry):
        return entry.get('configuration_mode',entry['request'].get('mode'))

    def applied_configuration(self,request_id,session,epoch,quality):
        """Exact real APPLIED scalar, before any new-header/video confirmation."""
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            entry=self.commands.get(request_id)
            if (entry is None or self.pending!=request_id or self.phase!='VERIFYING_VIDEO'
                    or any(type(v) is not int or not 0<v<2**32 for v in (session,epoch))
                    or type(quality) is not int or quality!=entry['requested_quality']
                    or self.cfg_session is not None and session!=self.cfg_session):
                raise ValueError('actual pending CFG session/epoch/quality required')
            if entry['request']['action']=='quality':
                if epoch<=self.mode_epoch:raise ValueError('new quality epoch required')
                entry.update(status='QUALITY_APPLIED_WAITING_REAL_VIDEO',applied_epoch=epoch)
            else:
                super().mode_applied(request_id,epoch)
            self.expected_configuration=(request_id,session,epoch,quality)
            entry['applied_session']=session;entry['applied_quality']=quality
            return True

    def expect_ai(self,request_id,session,epoch):
        with self.lock:
            if self._cancelled_by_stop():return False
            if self.pending!=request_id or self._command_mode(self.commands[request_id])!='yolo':
                raise ValueError('matching pending mono YOLO request required')
            if any(type(v) is not int or not 0<v<2**32 for v in (session,epoch)):
                raise ValueError('actual positive CFG session/epoch required')
            self.expected_ai=(session,epoch)
            return True

    def note_ai_error(self,error):
        with self.lock:self.ai_failure=str(error)[:512]

    def _modes(self):
        self.mode_rows=[r for r in self.mode_rows if r['id']!='yolo']
        if self.spec['cameras']==1 and self.spec['product']=='jpeg':self.mode_rows.append(deepcopy(YOLO))

    def completed_topology(self,*args,**kwargs):
        result=super().completed_topology(*args,**kwargs)
        if result:
            with self.lock:
                self._modes();self.ai_video=None;self.ai_failure=None;self.expected_ai=None
                self.quality=75;self.expected_configuration=None
        return result

    def completed_mode(self,request_id,epoch,frame_ordinal,*,session=None,quality=None):
        with self.lock:
            entry=self.commands.get(request_id)
            if entry is None:raise ValueError('pending configuration required')
            if self.expected_configuration is not None:
                if (any(type(v) is not int for v in (session,epoch,quality))
                        or (request_id,session,epoch,quality)!=self.expected_configuration):
                    return False
                if (self._cancelled_by_stop() or self.phase!='VERIFYING_VIDEO' or self.pending!=request_id
                        or type(frame_ordinal) is not int or frame_ordinal<=self.frame_ordinal):return False
                self.quality=quality
                entry['video_confirmation']=dict(session=session,mode_epoch=epoch,quality=quality,
                    frame_ordinal=frame_ordinal)
            if self._command_mode(entry)!='yolo':
                result=self._complete_entry(request_id,epoch,frame_ordinal)
                if result:self.ai_video=None;self.ai_failure=None;self.expected_ai=None
                return result
            self._owner()
            if self._cancelled_by_stop():return False
            if (self.phase!='VERIFYING_VIDEO' or self.pending!=request_id or entry.get('applied_epoch')!=epoch
                    or self.expected_ai is None or self.expected_ai[1]!=epoch
                    or type(frame_ordinal) is not int or frame_ordinal<=self.frame_ordinal):
                raise ValueError('actual mono SDR epoch video required before YOLO')
            self.ai_video=(request_id,epoch,frame_ordinal)
            entry['status']='WAITING_AI_RESULT'
            return False

    def _complete_entry(self,request_id,epoch,ordinal):
        entry=self.commands[request_id]
        if entry['request']['action']!='quality':
            result=super().completed_mode(request_id,epoch,ordinal)
        else:
            self._owner()
            if self._cancelled_by_stop():return False
            if (self.phase!='VERIFYING_VIDEO' or self.pending!=request_id or entry.get('applied_epoch')!=epoch
                    or self.expected_configuration is None or type(ordinal) is not int or ordinal<=self.frame_ordinal):
                raise ValueError('new actual quality/header/video confirmation required')
            if self.clock()>self._deadline:raise TimeoutError('JPEG quality video confirmation deadline exceeded')
            self.current_mode=entry['configuration_mode'];self.mode_epoch=epoch;self.frame_ordinal=ordinal
            entry.update(status='QUALITY_VIDEO_CONFIRMED',confirmation=dict(mode_epoch=epoch,
                frame_ordinal=ordinal,session=entry['applied_session'],quality=self.quality,
                mode=self.current_mode,action='quality'))
            self.pending=None;self._deadline=None;self.phase='READY';self._heartbeat=self.clock()
            result=True
        if result:
            entry['confirmation'].update(quality=self.quality)
            if 'applied_session' in entry:entry['confirmation']['session']=entry['applied_session']
            self.expected_configuration=None
        return result

    def confirm_ai(self,state):
        with self.lock:
            if self.ai_video is None or self._cancelled_by_stop():return False
            if self.clock()>self._deadline:
                self._fail_ai('YOLO first result deadline exceeded')
                return False
            key,epoch,ordinal=self.ai_video
            if (not isinstance(state,dict) or not state.get('ready') or not state.get('output_confirmed')
                    or (state.get('session'),state.get('epoch'))!=self.expected_ai or state.get('error')):return False
            result=self._complete_entry(key,epoch,ordinal)
            if result:self.ai_video=None;self.ai_failure=None
            return result

    def check_timeout(self):
        with self.lock:
            if self._cancelled_by_stop():return False
            state=self.ai_provider() or {}
            if self.ai_video is not None and (self.ai_failure or state.get('error') or self.clock()>self._deadline):
                self._fail_ai(self.ai_failure or state.get('error') or 'YOLO first result deadline exceeded')
                return False
        return super().check_timeout()

    def _fail_ai(self,error):
        key,epoch,ordinal=self.ai_video
        self.ai_failure=error
        self.commands[key].update(status='AI_FAILED_VIDEO_CONTINUES',error=self.ai_failure)
        self.current_mode='color';self.mode_epoch=epoch;self.frame_ordinal=ordinal
        self.ai_video=None;self.expected_ai=None;self.pending=None;self._deadline=None;self.phase='READY'
        self.expected_configuration=None
        self._heartbeat=self.clock()

    def state(self):
        result=super().state()
        result.update(ai=self.ai_provider(),ai_failure=self.ai_failure,quality=self.quality,
            jpeg_quality_control=self.spec['product']=='jpeg',quality_min=1,quality_max=100)
        return result


class ControlServer(LayoutServer):
    def __init__(self,broker,**kwargs):
        super().__init__(broker,page=Path(__file__).with_name('camera_mono_yolo_control.html'),**kwargs)
