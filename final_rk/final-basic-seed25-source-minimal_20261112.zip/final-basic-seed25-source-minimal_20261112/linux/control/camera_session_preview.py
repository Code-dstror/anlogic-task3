"""Normal rebuild retirement of display-only resources; faults remain retained."""
import ctypes as C
import os
try:
    from .camera_raw_preview import CameraPreview
    from .remote_mono_display._ai_endpoint import gobject_pointer
except ImportError:
    from camera_raw_preview import CameraPreview
    from remote_mono_display._ai_endpoint import gobject_pointer


class SessionPreview(CameraPreview):
    retire_requested = False

    def retire_for_rebuild(self, timeout_s=15):
        self.retire_requested = True
        result = self.close(timeout_s=timeout_s)
        if result.get('failure') or not result.get('graph_retired'):
            raise RuntimeError('display session retirement unconfirmed; retain owner')
        return result

    def _run(self):
        super()._run()
        if not self.retire_requested or self.cache.get('failure'):
            return
        try:
            from gi.repository import Gst
            final = self.cache.get('recording_final', {})
            if not final.get('all_common_frames_encoded_and_sealed'):
                raise RuntimeError('recording seal required before graph retirement')
            self.recorder._thread.join(1)
            if self.recorder._thread.is_alive():
                raise RuntimeError('recording worker not joined')
            if self.pipeline.set_state(Gst.State.NULL) == Gst.StateChangeReturn.FAILURE:
                raise RuntimeError('display NULL transition rejected')
            answer, state, pending = self.pipeline.get_state(2*Gst.SECOND)
            if answer != Gst.StateChangeReturn.SUCCESS or state != Gst.State.NULL or pending != Gst.State.VOID_PENDING:
                raise RuntimeError('display tasks not stopped')
            pointer = gobject_pointer(self.pipeline)
            native = self.recorder.native
            native.lib.y26_record_retire.argtypes = [C.c_void_p, C.c_void_p]
            native.lib.y26_record_retire.restype = C.c_int
            if native.lib.y26_record_retire(native.handle, pointer) != 1:
                raise RuntimeError('recording callbacks not retired')
            native.handle = None
            native.elements = []
            self.pipeline.get_bus().set_sync_handler(None, None)
            self.hud.lib.cr_hud_retire.argtypes = [C.c_void_p]
            self.hud.lib.cr_hud_retire.restype = C.c_int
            if self.hud.lib.cr_hud_retire(pointer) != 1:
                raise RuntimeError('HUD session not retired')
            if self.lane_core is not None and self.lane_core.handle:
                self.lane_core.lib.lane_destroy(self.lane_core.handle)
                self.lane_core.handle = None
            if self.recorder.directory_fd is not None:
                os.close(self.recorder.directory_fd)
                self.recorder.directory_fd = None
            self.sources = []
            self.bus = None
            self.pipeline = None
            self.cache.update(graph_retired=True, resources_retained=False)
        except BaseException as error:
            with self.cv:
                self.cache['failure'] = type(error).__name__+': '+str(error)[:512]
