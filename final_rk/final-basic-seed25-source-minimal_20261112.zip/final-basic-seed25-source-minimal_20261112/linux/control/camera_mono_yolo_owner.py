"""YOLO selects FPGA plain SDR; all NPU work stays in the preview AI worker."""
import threading
import time
from dataclasses import asdict
try:
    from .camera_session_owner import SessionOwner
    from .camera_mono_yolo_preview import MonoYoloPreview
except ImportError:
    from camera_session_owner import SessionOwner
    from camera_mono_yolo_preview import MonoYoloPreview


class MonoYoloOwner(SessionOwner):
    def __init__(self,*args,**kwargs):
        kwargs.setdefault('preview_factory',MonoYoloPreview)
        super().__init__(*args,**kwargs)

    def _start_mode(self,request):
        if self.command is not None or self.mode_pending is not None:
            raise RuntimeError('one mode transaction at a time')
        if request['mode']=='yolo' and self.cameras!=1:raise ValueError('YOLO is mono CAM0 only')
        quality=(self.broker.command_quality(request['request_id'])
                 if hasattr(self.broker,'command_quality') else 75)
        if self.cameras==1:
            try:self.preview.set_ai(False)
            except BaseException as error:self.broker.note_ai_error(error)
        done=threading.Event();self.command=dict(done=done,request=request,value=None,error=None)
        state=self.command
        def apply():
            try:
                mode='color' if request['mode']=='yolo' else request['mode']
                receipt=(self.cold.apply(mode,quality=quality) if quality!=75 or request.get('_quality_request')
                         else self.cold.apply(mode))
                state['value']=receipt
                if request['mode']=='yolo' and not self.stop_event.is_set():
                    if self.broker.expect_ai(request['request_id'],receipt.session,receipt.mode_epoch):
                        try:
                            if self.preview.set_ai(True,session=receipt.session,epoch=receipt.mode_epoch) is False:
                                self.broker.note_ai_error('YOLO enable failed; original SDR video retained')
                        except BaseException as error:self.broker.note_ai_error(error)
            except BaseException as error:state['error']=type(error).__name__+': '+str(error)[:512]
            finally:done.set()
        seconds=self.config.get('mode_confirmation_s',30)
        self.grace_deadline=self.clock()+seconds
        self.preview.transition_until(time.monotonic_ns()+int(seconds*1e9))
        self.command['thread']=threading.Thread(target=apply,name='mono-yolo-cfg',daemon=True)
        self._event('JPEG_QUALITY_REQUEST' if request.get('_quality_request') else 'MODE_REQUEST',
            request_id=request['request_id'],mode=request['mode'],quality=quality)
        self.command['thread'].start()

    def _configuration_applied(self,request,receipt):
        session=receipt.session;quality=receipt.configuration.quality
        if session!=self.cold.receipt['session']:
            raise ValueError('APPLIED is from a different active CFG session')
        event='JPEG_QUALITY_APPLIED' if request.get('_quality_request') else 'MODE_APPLIED'
        self._event(event,request_id=request['request_id'],receipt=asdict(receipt),quality=quality)
        accepted=self.broker.applied_configuration(request['request_id'],session,receipt.mode_epoch,quality)
        if accepted:
            self.quality_applied=(request['request_id'],session,receipt.mode_epoch,quality)
        return accepted

    def _configuration_video(self,request_id,epoch,rendered):
        proof=getattr(self,'quality_applied',None)
        if proof is None or proof[:1]!=(request_id,) or proof[2]!=epoch:return False
        _,session,_,quality=proof
        rows={row['camera']:row for row in rendered.get('cameras',[])}
        if (set(rows)!=set(range(self.cameras)) or any(
                any(type(rows[c].get(key)) is not int for key in ('session','epoch','quality'))
                or (rows[c].get('session'),rows[c].get('epoch'),rows[c].get('quality'))!=(session,epoch,quality)
                for c in range(self.cameras))):return False
        completed=self.broker.completed_mode(request_id,epoch,rendered['ordinal'],session=session,quality=quality)
        if completed:
            action=self.broker.commands[request_id]['request']['action']
            self._event('JPEG_QUALITY_VIDEO_CONFIRMED' if action=='quality' else 'MODE_VIDEO_CONFIRMED',
                request_id=request_id,session=session,mode_epoch=epoch,quality=quality,ordinal=rendered['ordinal'])
        self.quality_applied=None
        return True

    def _control(self,preview):
        if not self.rebuild and self.broker.topology_queued() and self.cameras==1:self.preview.set_ai(False)
        if self.stop_event.is_set() and self.cameras==1 and self.preview is not None:self.preview.set_ai(False)
        super()._control(preview)
        state=preview.get('ai') or {}
        if self.broker.confirm_ai(state):
            self._event('YOLO_VIDEO_AND_RESULT_CONFIRMED',session=state['session'],epoch=state['epoch'],generation=state.get('generation'))
        if self.broker.ai_failure and self.cameras==1:self.preview.set_ai(False)
