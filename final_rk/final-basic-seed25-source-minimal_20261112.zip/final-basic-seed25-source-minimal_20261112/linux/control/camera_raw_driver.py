"""Read-only admission of a separately target-built RAW KO; never load/bind."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat

KERNEL_BUILD='3029de626e5b93ec060106f70b361766bd9a7132'
KERNEL_CONFIG='86900cf569565d74a2b6d5ca32a35d2ca68c25ea71ef9fc4e2816a0acb4e8956'
PARAMETER_TYPES=dict(slots='uint',capacity='uint',poll_ms='uint',drain_ms='uint',dma_bits='uint',irq_hint='bool',target_bdf='charp')


def validate_audit(value,*,boot,source_hashes):
    if (value.get('status')!='TARGET_BUILD_AUDIT_PASSED_NOT_LOADED' or value.get('boot_id')!=boot or
            value.get('kernel')!=dict(release='6.1.99',build_id=KERNEL_BUILD,config_sha256=KERNEL_CONFIG) or
            value.get('audit_exports',{}).get('status')!='PASSED' or
            value.get('original_headers_unchanged') is not True or value.get('private_source_hashes_verified') is not True):
        raise ValueError('this boot needs a real matched target-build RAW module audit; SDK candidate is not admitted')
    rows=value.get('source_inputs',{})
    if set(rows)!=set(source_hashes) or any(rows[n].get('sha256')!=sha for n,sha in source_hashes.items()):
        raise ValueError('target RAW module must use exact delivered six sources')
    module=value.get('module',{});info=value.get('module_info',{})
    exports=value['audit_exports'];undefined=info.get('undefined_symbols')
    if (info.get('name')!='ph1a_c2h' or not re.fullmatch(r'[0-9a-f]{40}',info.get('build_id','')) or
            info.get('elf_type')!=1 or info.get('elf_class')!=64 or info.get('machine')!='AArch64' or
            info.get('parameters')!=PARAMETER_TYPES or info.get('modinfo',{}).get('alias') or
            info.get('vermagic')!='6.1.99 SMP mod_unload aarch64' or
            info.get('srcversion')!=dict(status='MISSING',value=None) or info.get('this_module_bytes')!=832 or
            info.get('versions_section_present') is not False or info.get('symbol_versions')!={} or info.get('signature_appended') is not False or
            type(undefined) is not list or not undefined or len(undefined)!=len(set(undefined)) or
            exports.get('missing')!=[] or exports.get('modversions') is not False or
            exports.get('undefined_count')!=len(undefined) or set(exports.get('exports',{}))!=set(undefined) or
            not re.fullmatch(r'[0-9a-f]{64}',module.get('sha256','')) or type(module.get('bytes')) is not int or module['bytes']<=0):
        raise ValueError('target RAW module ELF audit incomplete')
    return module,info


def validate_module_bytes(body,claimed_info,parser):
    actual=parser(body)
    if actual!=claimed_info:raise ValueError('actual RAW KO ELF differs from its target-build audit')
    return actual


def check_target(audit_path,audit_sha,*,boot,source_hashes,expected_bdf=None):
    # Only explicit --run calls this function, after all sealed-file checks.
    from dual_r3_driver import note_build_id,PARAMETERS
    path=Path(audit_path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size>32*1024*1024:raise ValueError('bounded ordinary RAW audit required')
    body=path.read_bytes()
    if hashlib.sha256(body).hexdigest()!=audit_sha:raise ValueError('RAW target-build audit SHA differs')
    module,info=validate_audit(json.loads(body),boot=boot,source_hashes=source_hashes)
    if (Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=boot or os.uname().machine!='aarch64' or os.uname().release!='6.1.99' or
            note_build_id(Path('/sys/kernel/notes').read_bytes())!=KERNEL_BUILD or
            hashlib.sha256(gzip.decompress(Path('/proc/config.gz').read_bytes())).hexdigest()!=KERNEL_CONFIG):
        raise ValueError('actual RAW target kernel/boot differs')
    ko=Path(module['path'])
    if not ko.is_absolute() or ko.is_symlink() or not ko.is_file() or ko.stat().st_size!=module['bytes'] or hashlib.sha256(ko.read_bytes()).hexdigest()!=module['sha256']:
        raise ValueError('target-built RAW KO file differs')
    # This sealed private helper has only stdlib imports. Do not introduce the
    # SDK's linux namespace before launcher's fresh-process admission boundary.
    from raw_module_audit import module_info
    validate_module_bytes(ko.read_bytes(),info,module_info)
    root=Path('/sys/bus/pci/devices')
    devices=[p for p in root.iterdir() if (p/'vendor').read_text().strip()=='0x1edb' and (p/'device').read_text().strip()=='0xabcd']
    if len(devices)!=1:raise ValueError('one actual FPGA PCIe endpoint required')
    device=devices[0];bdf=device.name
    if not re.fullmatch(r'[0-9a-f]{4}:[0-9a-f]{2}:[0-1][0-9a-f]\.[0-7]',bdf) or expected_bdf is not None and bdf!=expected_bdf:
        raise ValueError('actual RAW BDF differs')
    module_dir=Path('/sys/module/ph1a_c2h');driver=Path('/sys/bus/pci/drivers/ph1a_c2h_candidate')
    if (device/'driver').resolve(strict=True)!=driver or (driver/'module').resolve(strict=True)!=module_dir:
        raise ValueError('RAW endpoint driver/module association differs')
    if note_build_id((module_dir/'notes/.note.gnu.build-id').read_bytes())!=info['build_id']:raise ValueError('loaded RAW module differs from target audit')
    for name,value in dict(PARAMETERS,target_bdf=bdf).items():
        actual=(module_dir/'parameters'/name).read_text().strip()
        if actual not in (('N','0') if name=='irq_hint' else (str(value),)):raise ValueError('RAW DMA parameter differs: '+name)
    dev=Path('/dev')/('ph1a_c2h_'+bdf);misc=Path('/sys/class/misc')/dev.name;node=dev.stat()
    if not stat.S_ISCHR(node.st_mode) or (misc/'device').resolve(strict=True)!=device.resolve(strict=True):raise ValueError('RAW native node differs')
    if (misc/'dev').read_text().strip()!=str(os.major(node.st_rdev))+':'+str(os.minor(node.st_rdev)):raise ValueError('RAW node major/minor differs')
    from handoff import owner_scan
    scan=owner_scan()
    if (type(scan) is not dict or type(scan.get('owners')) is not list or type(scan.get('errors')) is not list or scan['owners'] or scan['errors']):
        raise ValueError('RAW native owner scan is not empty or incomplete')
    if [p.name for p in Path('/dev').glob('ph1a_c2h*')]!=[dev.name] or Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=boot:
        raise ValueError('RAW node/boot changed during admission')
    return dict(device=str(dev),bdf=bdf,boot_id=boot,module_build_id=info['build_id'],module_sha256=module['sha256'],native_opened=False)
