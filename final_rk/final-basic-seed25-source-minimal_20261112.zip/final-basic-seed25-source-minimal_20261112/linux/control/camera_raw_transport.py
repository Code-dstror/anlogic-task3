"""Receive-only ARAW validation and bounded per-eye transmission evidence.

No device/SDK imports, controls, decoding or display. Accept complete C2H
records only. The transport owner retains its own slot/generation metadata.
ARAW has no payload checksum: a host SHA256 identifies received bytes, and
does not prove sensor image correctness or undetected wire corruption.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import struct


HEADER = struct.Struct("<IHHIHHIII4BQQ16s")
FULL_HD_PAYLOAD_BYTES = 2592000
FULL_HD_RECORD_BYTES = 2592064


class RawTransportError(ValueError):
    pass


@dataclass(frozen=True)
class RawSource:
    width: int
    height: int
    source_sequence: int
    source_session: int
    mode_epoch: int
    camera: int
    bayer_phase: int
    capture_time_ns: int | None
    job_id: int


@dataclass(frozen=True)
class RawFrame(RawSource):
    payload: memoryview


def parse_araw(record: bytes | bytearray | memoryview) -> RawFrame:
    """Validate exact delivered length and borrow a readonly RAW10 payload.

    The caller must retain the C2H buffer lease until it has consumed this view.
    Source sequence is per eye; SOURCE session and mode_epoch are checked by
    RawTransportMonitor against the owner's observed applied configuration.
    """
    try:
        view = memoryview(record).cast("B").toreadonly()
    except (TypeError, ValueError, BufferError) as exc:
        raise RawTransportError("ARAW requires a contiguous byte buffer") from exc
    if len(view) < 64:
        raise RawTransportError("truncated ARAW header")
    (magic, version, header, size, width, height, sequence, session, epoch,
     camera, fmt, bayer, flags, timestamp, job, reserved) = HEADER.unpack_from(view)
    if (magic, version, header) != (0x57415241, 1, 64):
        raise RawTransportError("ARAW magic/version/header")
    if reserved != bytes(16) or flags & ~1:
        raise RawTransportError("ARAW reserved fields")
    if fmt != 1 or camera not in (0, 1) or bayer not in range(4):
        raise RawTransportError("ARAW RAW10 format/camera/Bayer phase")
    if not session or not job:
        raise RawTransportError("ARAW SOURCE session/job")
    if not width or width % 4 or not height:
        raise RawTransportError("ARAW dimensions need complete four-pixel groups per row")
    if size != width * height * 5 // 4 or size > 16777216 or len(view) != 64 + size:
        raise RawTransportError("ARAW dimensions/payload/delivered length differ")
    return RawFrame(width, height, sequence, session, epoch, camera, bayer,
                    timestamp if flags & 1 else None, job, view[64:])


def unpack_raw10(payload, sample_count: int | None = None) -> list[int]:
    """Decode continuous little-endian 10-bit groups (not MIPI RAW10 packing).

    Four samples p0,p1,p2,p3 are one little-endian 40-bit integer
    p0 | p1<<10 | p2<<20 | p3<<30. Useful for offline golden tests and small
    received previews; receive-only monitoring never demosaics these samples.
    """
    data = memoryview(payload).cast("B")
    if len(data) % 5:
        raise RawTransportError("RAW10 needs complete five-byte groups")
    count = len(data) // 5 * 4
    if sample_count is not None and sample_count != count:
        raise RawTransportError("RAW10 sample count differs")
    result = []
    for offset in range(0, len(data), 5):
        group = int.from_bytes(data[offset:offset + 5], "little")
        result.extend((group >> shift) & 1023 for shift in (0, 10, 20, 30))
    return result


class RawTransportMonitor:
    """Strict per-eye SOURCE checks, bounded state, explicit receive evidence.

    This observer does not consume C2H itself. accept(record, host_ns) receives
    an exact transport record from the existing owner. Separate monitor objects
    are required after session/epoch changes; sequence wrap is rejected.
    """
    def __init__(self, *, session: int, mode_epoch: int, cameras=(0, 1),
                 width=1920, height=1080, payload_hash_interval_ns=1000000000):
        if (type(session) is not int or not 0 < session < 2**32
                or type(mode_epoch) is not int or not 0 <= mode_epoch < 2**32
                or tuple(cameras) not in ((0,), (1,), (0, 1))
                or type(width) is not int or width <= 0 or width % 4
                or type(height) is not int or height <= 0
                or width * height * 5 // 4 > 16777216
                or type(payload_hash_interval_ns) is not int or payload_hash_interval_ns < 0):
            raise RawTransportError("invalid RAW monitor applied SOURCE/geometry")
        self.session, self.mode_epoch = session, mode_epoch
        self.cameras, self.width, self.height = tuple(cameras), width, height
        self.payload_hash_interval_ns = payload_hash_interval_ns
        self._eyes = {eye: {"frames": 0, "payload_bytes": 0, "record_bytes": 0,
                            "source_gaps": 0, "first_host_ns": None, "last_host_ns": None,
                            "first_source_sequence": None, "last_source": None,
                            "last_payload_sha256": None, "last_hashed_source": None,
                            "last_hashed_host_ns": None, "hashed_frames": 0,
                            "last_samples": None}
                      for eye in self.cameras}

    def accept(self, record, host_ns: int) -> RawFrame:
        frame = parse_araw(record)
        self.observe(frame, host_ns)
        return frame

    def observe(self, frame, host_ns: int) -> dict:
        """Accept an already validated package RawVideoFrame with the same fields.

        Use accept() when the caller has not validated reserved wire fields.
        The first frame of each eye is hashed; subsequent full-payload hashes
        are sampled using host monotonic time and payload_hash_interval_ns.
        An interval of zero hashes every frame for offline golden checks.
        Hash source/time remain explicit when the latest frame is not hashed.
        """
        try:
            source = RawSource(**{key: getattr(frame, key) for key in RawSource.__dataclass_fields__})
            payload = memoryview(frame.payload).cast("B")
        except (AttributeError, TypeError, ValueError) as exc:
            raise RawTransportError("parsed ARAW fields/payload missing") from exc
        if ((source.source_session, source.mode_epoch) != (self.session, self.mode_epoch)
                or source.camera not in self._eyes
                or (source.width, source.height) != (self.width, self.height)
                or source.bayer_phase not in range(4)
                or type(source.source_sequence) is not int or not 0 <= source.source_sequence < 2**32
                or type(source.job_id) is not int or not 0 < source.job_id < 2**64
                or len(payload) != self.width * self.height * 5 // 4
                or type(host_ns) is not int or host_ns <= 0):
            raise RawTransportError("ARAW SOURCE/payload differs from applied configuration")
        eye = self._eyes[source.camera]
        previous = eye["last_source"]
        if previous is not None:
            if (source.source_sequence <= previous["source_sequence"]
                    or source.bayer_phase != previous["bayer_phase"]
                    or host_ns < eye["last_host_ns"]):
                raise RawTransportError("ARAW per-eye sequence/Bayer/host order changed")
            eye["source_gaps"] += source.source_sequence - previous["source_sequence"] - 1
        if not eye["frames"]:
            eye["first_host_ns"] = host_ns
            eye["first_source_sequence"] = source.source_sequence
        eye["frames"] += 1
        eye["payload_bytes"] += len(payload)
        eye["record_bytes"] += len(payload) + 64
        eye["last_host_ns"] = host_ns
        eye["last_source"] = asdict(source)
        if (eye["last_hashed_host_ns"] is None or
                host_ns - eye["last_hashed_host_ns"] >= self.payload_hash_interval_ns):
            eye["last_payload_sha256"] = hashlib.sha256(payload).hexdigest()
            eye["last_hashed_source"] = dict(eye["last_source"])
            eye["last_hashed_host_ns"] = host_ns
            eye["hashed_frames"] += 1
        eye["last_samples"] = unpack_raw10(payload[:20])
        return dict(eye["last_source"])

    def snapshot(self) -> dict:
        eyes = {}
        for camera, row in self._eyes.items():
            evidence = dict(row)
            evidence["last_source"] = dict(row["last_source"]) if row["last_source"] else None
            evidence["last_hashed_source"] = (dict(row["last_hashed_source"])
                                              if row["last_hashed_source"] else None)
            evidence["last_samples"] = list(row["last_samples"]) if row["last_samples"] else None
            elapsed = ((row["last_host_ns"] - row["first_host_ns"]) / 1e9
                       if row["frames"] > 1 else None)
            evidence["observed_receive_fps"] = ((row["frames"] - 1) / elapsed if elapsed else None)
            eyes[str(camera)] = evidence
        return {"status": "RAW_COMPLETE_RECORDS_OBSERVED" if all(r["frames"] for r in self._eyes.values())
                else "WAITING_FOR_EACH_SELECTED_EYE",
                "source_session": self.session, "mode_epoch": self.mode_epoch,
                "width": self.width, "height": self.height, "eyes": eyes,
                "payload_hash_interval_ns": self.payload_hash_interval_ns,
                "scope": "HOST_ARAW_TRANSPORT_ONLY",
                "isp_processed": False, "displayed": False,
                "payload_wire_checksum": "NOT_PRESENT_IN_ARAW_V1"}
