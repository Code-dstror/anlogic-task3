"""Fixed seed2 MONO F22/C1 data admission; no fitting, overlay or device I/O.

The caller first uses the fixed SDK parse_record(..., expected_version=4).
Protocol field, padding, point ordering and status/count validation remain in
that parser. Valid error terminals are retained for counters and owner fail-stop;
NO_CANDIDATES is a normal current empty observation.
"""
if __package__:
    from .dual_r3 import MAX_JPEG_BYTES
else:
    from dual_r3 import MAX_JPEG_BYTES

PROCESSING_ENABLES = 48
PROCESSING_MODE = 176
SPARSE_ENABLES = 3


class LaneRecordError(ValueError):
    pass


def validate_lane_record(record):
    """Validate this profile after the complete immutable v4 record parser."""
    from linux.task3_pipeline import pcie_protocol_v1 as p
    from linux.task3_pipeline.record_v4 import SparseLaneRecords, SparseLaneRecord
    m, a = record.metadata, record.s07
    s = None if m is None else m.source
    if (s is None or (record.width, record.height) != (1920, 1080) or s.camera != 0 or
            not 0 <= m.jpeg_slot <= 2 or
            (s.kind, s.format, s.role) != (p.PCIE_RECORD_V2_SOURCE_PHYSICAL,
                p.PCIE_RECORD_V2_FORMAT_RAW10, p.PCIE_RECORD_V2_ROLE_SINGLE) or
            m.processing_mode != PROCESSING_MODE or m.record_flags or m.processing_member or
            not isinstance(a, SparseLaneRecords) or a.enabled != SPARSE_ENABLES or
            a.f22 is None or not isinstance(a.f23, SparseLaneRecord) or
            a.f24 is not None or a.f25 is not None or
            not 4 <= len(record.jpeg) <= MAX_JPEG_BYTES):
        raise LaneRecordError('R3 MONO lane requires bounded CAM0 physical RAW10 SINGLE v4 F22+C1 mode176/sparse3 without HDR')
    context = (s.session | s.epoch << 32 | s.sequence << 64 | s.camera << 96 |
               s.kind << 104 | s.format << 112 | 1 << 120 | 1 << 144)
    if (s.sequence != record.sequence or a.context != context or
            a.f22.context != context or a.f23.context != context):
        raise LaneRecordError('R3 MONO lane SOURCE and F22/C1 contexts differ')
    return record


def analysis_summary(record):
    """Old inspector counter keys plus complete current C1 data and status.

    sparse_frame_error remains a separate overall diagnostic. It does not turn
    a successful F23 terminal into a failed lane or erase its valid points.
    The sole owner decides its fail-stop policy from these explicit counters.
    """
    record = validate_lane_record(record)
    a, lane = record.s07, record.s07.f23
    names = {0:'OK', 1:'NO_CANDIDATES', 128:'LOCAL_ERROR', 129:'SOURCE_ERROR'}
    if lane.status not in names:
        raise LaneRecordError('R3 MONO lane has unknown typed status; complete v4 parsing required')
    if (not 0 <= lane.count <= 303 or (lane.status == 0) != (lane.count > 0) or
            (lane.status == 129 and not a.frame_error)):
        raise LaneRecordError('R3 MONO lane status/count/frame_error disagree')
    negative = []
    if a.f22.error or not a.f22.ok:
        negative.append('f22')
    failure = None
    if lane.status in (128, 129):
        negative.append('f23')
        failure = 'C1_'+names[lane.status]
    return dict(negative_analysis_terminals=negative, sparse_frame_error=bool(a.frame_error),
        lane_status=lane.status, lane_status_name=names[lane.status], lane_count=lane.count,
        lane_failure_reason=failure, lane_context=lane.context,
        lane_roi_quarter=[lane.roi_begin,lane.roi_end],
        lane_points=[dict(native_x=point.native_x, quarter_y=point.quarter_y,
            native_y=point.native_y, strength=point.strength,
            width_quarter=point.width_quarter, marking_class=point.marking_class)
            for point in lane.points],
        lane_processing_scope='FPGA_C1_DATA_ONLY_NO_RK_FIT_OR_OVERLAY')
