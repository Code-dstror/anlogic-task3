"""final_basic only: owner-observed HDR/ISP/JPEG panels and mono RK YOLO."""
try:
    from .launch_camera_session import main
except ImportError:
    from launch_camera_session import main

if __name__=='__main__':raise SystemExit(main(mono_yolo=True,fpga_parameters=True))
