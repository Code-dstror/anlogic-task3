"""Versioned same-fd ioctl, separate from the general legacy MMIO whitelist."""
from dataclasses import asdict, dataclass
import struct
import time

VERSION = 1
QUERY, SOURCE_OFF, DRAIN_STOP, RESET_ONCE, ACCEPT_BOOT = range(5)
IDLE, SOURCE_DISABLED, DMA_STOPPED, RESET_REQUESTED, BOOT_READY, FAULTED = range(6)
OBSERVABLE_IDLE, HOST_DRAINED, FRESH_BOOT, DRAIN_STOP_ELIGIBLE = 1, 2, 4, 8
FORMAT = struct.Struct('=8I2Q4I')
IOCTL = (3 << 30) | (FORMAT.size << 16) | (ord('H') << 8) | 0x46
DIAGNOSTIC_FORMAT = struct.Struct('=24Ii3I2Q')
DIAGNOSTIC_IOCTL = (3 << 30) | (DIAGNOSTIC_FORMAT.size << 16) | (ord('H') << 8) | 0x47
DIAGNOSTIC_FIELDS = ('phase identity_failures capabilities control legacy_status native_status '
    'native_error ready_mask sending_mask raw_status jpeg_status cfg_session active_session '
    'cfg_status cfg_error stereo_status stereo_error product ready leased active slots '
    'reset_issued flags submitted completed').split()
SOURCE_SDK = 'CAMERA_RAW_R2_1a5603c1_seed25_Linux_Debug_20261110'


def owner_key(identity):
    values = asdict(identity)
    # Generation is the last attempted DMA descriptor allocation, not fd identity.
    values.pop('generation',None)
    return tuple(sorted(values.items()))


@dataclass(frozen=True)
class State:
    phase: int
    cfg_session: int
    legacy_status: int
    native_status: int
    submitted: int
    completed: int
    ready: int
    leased: int
    reset_issued: int
    flags: int


class SessionControl:
    def __init__(self, receiver, *, evidence=None):
        self.receiver = receiver
        self.identity = receiver.owner_identity()
        self.key = owner_key(self.identity)
        self.generation = self.identity.generation
        self.bound_session = None
        self.attempts = set()
        self.evidence = evidence

    def _evidence(self, expected, action, kind, payload):
        if self.evidence is None:
            return None
        try:
            self.evidence(f'{expected:08x}-{action}-{kind}.json', dict(
                schema=1, host_ns=time.monotonic_ns(), action=action,
                expected_cfg_session=expected, owner=dict(self.key), **payload))
        except BaseException as error:
            return error
        return None

    def startup_snapshot(self):
        """One intended owner's readonly startup observations, before prepare."""
        from linux.task3_pipeline import pcie_protocol_v1 as p
        self._check_owner()
        state = self.query()
        value = dict(schema=1, host_ns=time.monotonic_ns(),
            sampling='SEQUENTIAL_READS_NOT_ATOMIC', owner=asdict(self.receiver.owner_identity()),
            state=asdict(state), capabilities=self.receiver.read32(p.PCIE_REG_CAPABILITIES),
            native=asdict(self.receiver.snapshot()), leased=self.receiver.leased_count,
            unread=bool(self.receiver.poll(0)))
        self._check_owner()
        return value

    def diagnostic(self):
        """One fixed-field readonly ioctl on the existing exclusive Receiver."""
        self._check_owner()
        raw = bytearray(DIAGNOSTIC_FORMAT.pack(1,128,0,0,*([0]*26)))
        self.receiver._io.ioctl(DIAGNOSTIC_IOCTL,raw)
        values = DIAGNOSTIC_FORMAT.unpack(raw)
        if values[:4] != (1,128,0,0):
            raise RuntimeError('session diagnostic response identity differs')
        value = dict(zip(DIAGNOSTIC_FIELDS,values[4:],strict=True))
        if value['phase'] not in range(6) or value['flags'] & ~15:
            raise RuntimeError('unknown session diagnostic response')
        self._check_owner()
        return dict(schema=1, source_sdk=SOURCE_SDK, host_ns=time.monotonic_ns(),
            sampling='SEQUENTIAL_KERNEL_CSR_READS_NOT_ATOMIC', **value)

    def _check_owner(self):
        current = self.receiver.owner_identity()
        if owner_key(current) != self.key or current.generation < self.generation:
            raise RuntimeError('session rebuild owner changed or generation regressed')
        self.generation = current.generation

    def call(self, action, expected=0):
        if type(action) is not int or action not in range(5):
            raise ValueError('known session action required')
        if type(expected) is not int or not 0 <= expected <= 0xffffffff or action and not expected:
            raise ValueError('mutation requires exact old CFG session')
        self._check_owner()
        raw = bytearray(FORMAT.pack(VERSION, action, expected, 0, *([0]*10)))
        evidence_error = None
        if action:
            if self.bound_session is not None and expected != self.bound_session:
                state = self.query()
                if action != SOURCE_OFF or state.phase != IDLE or state.cfg_session != expected:
                    raise RuntimeError('cannot replace an active rebuild binding')
                self.attempts.clear()
            self.bound_session = expected
            # The action is spent even if the syscall/copy-out outcome is unknown.
            key = (expected, action)
            if key in self.attempts:
                raise RuntimeError('session mutation already attempted; no retry')
            self.attempts.add(key)
            evidence_error = self._evidence(expected, action, 'intent', dict(
                outcome='NOT_YET_CALLED', generation=self.generation))
        try:
            self.receiver._io.ioctl(IOCTL, raw)
        except OSError as error:
            if action:
                diagnostic = dict(outcome='SYSCALL_ERROR_ACCEPTANCE_UNKNOWN',
                    errno=error.errno, error=type(error).__name__+': '+str(error)[:512])
                if evidence_error is not None:
                    diagnostic['intent_evidence_error'] = str(evidence_error)[:512]
                # Exactly one readonly QUERY on this Receiver. It cannot replay
                # the spent action and its failure cannot replace the cause.
                try:
                    diagnostic['readonly_query'] = asdict(self.query())
                except BaseException as query_error:
                    diagnostic['readonly_query_error'] = type(query_error).__name__+': '+str(query_error)[:512]
                self._evidence(expected, action, 'error', diagnostic)
            raise
        values = FORMAT.unpack(raw)
        if values[:4] != (VERSION, action, expected, 0):
            raise RuntimeError('session ioctl response identity differs')
        state = State(*values[4:])
        if (state.phase not in range(6) or state.flags & ~15 or state.reset_issued not in (0,1)
                or state.completed > state.submitted):
            raise RuntimeError('unknown session driver response')
        if action and state.phase != {SOURCE_OFF:SOURCE_DISABLED,DRAIN_STOP:DMA_STOPPED,
                                      RESET_ONCE:RESET_REQUESTED,ACCEPT_BOOT:BOOT_READY}[action]:
            raise RuntimeError('session action did not enter its required phase')
        self._check_owner()
        if action:
            response_error = self._evidence(expected, action, 'response', dict(
                outcome='RETURNED', state=asdict(state), generation=self.generation))
            if evidence_error is not None or response_error is not None:
                raise RuntimeError('session action evidence failed; action spent, owner retained') from (evidence_error or response_error)
        return state

    def query(self):
        return self.call(QUERY)
