"""Batched native taps for the single post-overlay display/record fan-out."""
import ctypes as C

try:
    from .remote_mono_display._ai_endpoint import gobject_pointer
except ImportError:
    from remote_mono_display._ai_endpoint import gobject_pointer


FIELDS='kind ordinal original_pts monotonic pts size duration flags'.split()


class Event(C.Structure):
    _fields_=[(n,C.c_uint64) for n in FIELDS]


class NativeRecord:
    def __init__(self,library,pipeline):
        self.library=library;self.lib=library.lib
        p=C.c_void_p;u=C.c_uint64
        for name,args,result in (
            ('attach',[p,p,p,p,p],p),('read',[p,C.POINTER(Event),C.c_uint],C.c_uint),
            ('stats',[p,C.POINTER(u)],C.c_int),('fail',[p,u],C.c_int),('finish',[p],C.c_int)):
            f=getattr(self.lib,'y26_record_'+name);f.argtypes=args;f.restype=result
        elements=[pipeline.get_by_name(n) for n in ('record_tee','record_stamp','record_encoded','display_sink','record_queue')]
        if any(x is None for x in elements):raise ValueError('one complete final-display recording branch required')
        self.elements=elements
        self.handle=self.lib.y26_record_attach(*(gobject_pointer(x) for x in elements))
        if not self.handle:raise RuntimeError('native recording taps rejected')
        self.batch=(Event*512)()

    def read(self):
        n=self.lib.y26_record_read(self.handle,self.batch,len(self.batch))
        return [{name:int(getattr(self.batch[i],name)) for name in FIELDS} for i in range(n)]

    def stats(self):
        values=(C.c_uint64*9)()
        if self.lib.y26_record_stats(self.handle,values)!=1 or values[0]!=1:raise RuntimeError('recording ABI differs')
        return dict(zip('abi error closing common input encoded display queued first_monotonic_ns'.split(),map(int,values)))

    def fail(self):self.lib.y26_record_fail(self.handle,100)

    def finish(self):
        if self.lib.y26_record_finish(self.handle)!=1:raise RuntimeError('recording EOS request rejected')
