"""Offline packaging and ordinary-file preflight for the frozen mono AI route.

The bit identity and hardware admission belong to the caller. No module here
imports AI code, loads a library, probes a device or contacts a board.
"""
import hashlib
import json
from pathlib import Path
import stat

CONTROL = Path('/home/uisrc/下载/DUAL_UNIFIED_R3_seed8_单目4G循环录像准备_20261106/control')
HELPER = Path('/home/uisrc/work/anlogic-task3/out/mono-r2-board-validation-20261102-01/payload')
CONTROL_INDEX_SHA256 = '8085f8578399d6bad3251972154e51522aab9291edd387dd877a4d3d1e4b03a1'
HELPER_INDEX_SHA256 = 'f26568df67a0b82b7a107dc772a61950be0a860209359f13aeb2670d6aecb9d7'
MPP_PATH = '/userdata/final-basic-seed25-repro/board-assets/userdata/rk-dehaze-live-fixed-6e72b9ebf/libdehaze_mpp.so'
MPP = dict(bytes=72336, sha256='3cf56e04693cda88ee2d47bc0b9a4c6c8dd548c333127eacf8f3b311231ba329')
RGA_SHA256 = '0244cf2e23c985deeb773e01f67b132ec89141505c9a1e5842ae58e57fc6c556'
SCHEMA = 'SEED25_MONO_YOLO_ASSETS_V1'


def row(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def _regular(path):
    path = Path(path)
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError as error:
        raise ValueError('missing ordinary AI dependency file: ' + str(path)) from error
    if not stat.S_ISREG(mode):
        raise ValueError('ordinary AI dependency file required: ' + str(path))
    return path.read_bytes()


def _check(path, expected):
    body = _regular(path)
    if row(body) != {key: expected[key] for key in ('bytes', 'sha256')}:
        raise ValueError('AI dependency SHA/length mismatch: ' + str(path))
    return body


def _relative(name):
    path = Path(name)
    if not isinstance(name, str) or not name or path.is_absolute() or '..' in path.parts or path.as_posix() != name:
        raise ValueError('unsafe AI source member: ' + str(name))
    return path


def _indexed(root, expected_sha):
    root = Path(root)
    body = _regular(root / 'content-index.json')
    if row(body)['sha256'] != expected_sha:
        raise ValueError('sealed AI source index differs: ' + str(root))
    index = json.loads(body)
    if not isinstance(index, dict) or not index:
        raise ValueError('nonempty sealed AI index required')
    # Check the whole indexed source before any destination write, including
    # entries outside the small subset copied into this new package.
    for name, expected in index.items():
        relative = _relative(name)
        for parent in relative.parents:
            if parent != Path('.') and (root / parent).is_symlink():
                raise ValueError('symlink directory in AI source: ' + name)
        _check(root / relative, expected)
    return index, body


def _write(path, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as output:
        output.write(body)


def _json(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def copy_assets(output, target, *, sources=None):
    """Copy checked sources into a fresh output/control; return integration keys.

    sources is an explicit host-fixture seam. Production uses the two frozen
    roots above. External historical model/library paths are never read here.
    """
    if not isinstance(target, str) or not target.startswith('/userdata/') or '..' in Path(target).parts:
        raise ValueError('independent absolute /userdata target required')
    roots = sources or dict(control=CONTROL, control_sha256=CONTROL_INDEX_SHA256,
                            helper=HELPER, helper_sha256=HELPER_INDEX_SHA256)
    control_source, helper_source = Path(roots['control']), Path(roots['helper'])
    ci, cb = _indexed(control_source, roots['control_sha256'])
    hi, hb = _indexed(helper_source, roots['helper_sha256'])
    operation_body = _check(helper_source / 'operation.json', hi['operation.json'])
    operation = json.loads(operation_body)
    required = ('ai_async/prepared_session.py', 'ai_async/latest_overlay.py',
                'remote_mono_ai_continuous.py', 'remote_mono_logs.py')
    files = {}
    origins = {}
    for name in required:
        destination = name if name.startswith('ai_async/') else 'ai_runner/' + name
        files[destination] = _check(control_source / name, ci[name])
        origins[destination] = dict(source=str(control_source / name), **ci[name])
    for name, expected in hi.items():
        if (name.startswith('candidate/') or name.startswith('mpp_helpers/')
                or name in ('prepare_one_frame.py', 'board_libs/liby26_prepared_rgb2.so')):
            destination = 'ai_helper/' + name
            files[destination] = _check(helper_source / name, expected)
            origins[destination] = dict(source=str(helper_source / name), **expected)
    if not any(name.startswith('ai_helper/candidate/') for name in files):
        raise ValueError('frozen candidate source tree missing')
    rga = files['ai_helper/board_libs/liby26_prepared_rgb2.so']
    if sources is None and row(rga)['sha256'] != RGA_SHA256:
        raise ValueError('mandatory no-CPU-color RGA differs')
    prefix = target.rstrip('/') + '/control'
    config = dict(ai_async_root=prefix + '/ai_async',
        candidate=prefix + '/ai_helper/candidate', helper_root=prefix + '/ai_helper',
        private_mpp_library=MPP_PATH, rga_library=prefix + '/ai_helper/board_libs/liby26_prepared_rgb2.so',
        ai_runner_root=prefix + '/ai_runner', ai_assets_schema=SCHEMA)
    dependencies = {}
    directories = {}
    for name, resource in operation['resources'].items():
        if resource.get('is_file') is True:
            dependencies[name] = dict(path=resource['path'], bytes=resource['bytes'],
                sha256=resource['sha256'], origin='HISTORICAL_BOARD_READ_20261102',
                required_for_live=name not in ('video', 'replay_library'))
        else:
            directories[name] = dict(path=resource['path'],
                status='HISTORICAL_DIRECTORY_REFERENCE_NOT_A_FILE_SHA_PROOF')
    dependencies['private_mpp_library'] = dict(path=MPP_PATH, **MPP, required_for_live=True,
        origin='HISTORICAL_STATIC_LIBRARIES_20261102',
        origin_index_sha256='d97471974fca83231336a6dc7e2fd9bf7704752efa243d22055bcf9b69247914')
    dependencies['mandatory_rga'] = dict(path=config['rga_library'], **row(rga),
        required_for_live=True, packaged='ai_helper/board_libs/liby26_prepared_rgb2.so',
        origin='SEALED_HELPER_INDEX')
    lock = dict(schema=SCHEMA, status='EXTERNAL_DEPENDENCIES_PENDING_FRESH_ORDINARY_FILE_SHA_CHECK',
        checked_board_today=False, files=dependencies, directory_references=directories,
        check_policy='READ_ONLY_REGULAR_FILE_SHA_BEFORE_YOLO_START_NO_DEVICE_IO',
        hardware_qualification='UNCHANGED_CALLER_OWNED_NOT_GRANTED_BY_ASSET_PACKAGING')
    files['ai_provenance/dependencies.json'] = _json(lock)
    files['ai_provenance/r3-control-content-index.json'] = cb
    files['ai_provenance/helper-content-index.json'] = hb
    files['ai_provenance/historical-operation.json'] = operation_body
    files['ai_provenance/copy-origins.json'] = _json(origins)
    package_index = {name: row(body) for name, body in sorted(files.items())}
    index_body = _json(dict(schema=SCHEMA, files=package_index))
    files['ai_provenance/packaged-index.json'] = index_body
    control = Path(output) / 'control'
    for name in files:
        if (control / name).exists() or (control / name).is_symlink():
            raise ValueError('fresh AI asset destination required: ' + name)
    for name, body in files.items():
        _write(control / name, body)
    config.update(ai_assets_index=prefix + '/ai_provenance/packaged-index.json',
        ai_assets_index_sha256=row(index_body)['sha256'],
        ai_dependency_lock=prefix + '/ai_provenance/dependencies.json',
        ai_dependency_lock_sha256=row(files['ai_provenance/dependencies.json'])['sha256'],
        ai_readiness=lock['status'])
    verify_packaged(config, control)
    return config


def _mapped(config, path, control):
    prefix = str(Path(config['ai_assets_index']).parent.parent)
    try:
        relative = Path(path).relative_to(prefix)
    except ValueError as error:
        raise ValueError('AI packaged path outside control: ' + str(path)) from error
    return Path(control) / _relative(relative.as_posix())


def verify_packaged(config, control):
    """Verify copied source/config/library bytes without importing any AI code."""
    if config.get('ai_assets_schema') != SCHEMA:
        raise ValueError('explicit mono AI assets schema required')
    index_path = _mapped(config, config['ai_assets_index'], control)
    body = _regular(index_path)
    if row(body)['sha256'] != config['ai_assets_index_sha256']:
        raise ValueError('packaged AI index SHA mismatch')
    index = json.loads(body)
    if index.get('schema') != SCHEMA:
        raise ValueError('packaged AI index schema mismatch')
    for name, expected in index['files'].items():
        relative = _relative(name)
        for parent in relative.parents:
            if parent != Path('.') and (Path(control) / parent).is_symlink():
                raise ValueError('symlink AI package directory: ' + name)
        _check(Path(control) / relative, expected)
    lock_path = _mapped(config, config['ai_dependency_lock'], control)
    lock_body = _regular(lock_path)
    if row(lock_body)['sha256'] != config['ai_dependency_lock_sha256']:
        raise ValueError('AI dependency lock SHA mismatch')
    # Bind caller integration paths to the files that were actually indexed.
    expected_paths = dict(ai_async_root='ai_async', candidate='ai_helper/candidate',
        helper_root='ai_helper', ai_runner_root='ai_runner',
        rga_library='ai_helper/board_libs/liby26_prepared_rgb2.so')
    for key, suffix in expected_paths.items():
        if _mapped(config, config[key], control) != Path(control) / suffix:
            raise ValueError('AI integration path differs: ' + key)
    if config['private_mpp_library'] != MPP_PATH:
        raise ValueError('frozen private MPP path differs')
    return dict(status='PACKAGED_SOURCE_HASHES_VERIFIED_NO_HARDWARE', files=len(index['files']),
        external_dependencies='PENDING_FRESH_READ_ONLY_CHECK', hardware_actions=0)


def verify_live_dependencies(config):
    """Next-session local ordinary-file hashes only; never opens a device node."""
    control = Path(config['ai_assets_index']).parent.parent
    verify_packaged(config, control)
    body = _regular(config['ai_dependency_lock'])
    lock = json.loads(body)
    checked = []
    for name, expected in lock['files'].items():
        if expected.get('required_for_live') is True:
            _check(expected['path'], expected)
            checked.append(name)
    return dict(status='LIVE_ORDINARY_FILE_DEPENDENCIES_VERIFIED_NO_DEVICE_IO', checked=checked,
        directory_references='NOT_FILE_HASH_QUALIFIED', hardware_actions=0)
