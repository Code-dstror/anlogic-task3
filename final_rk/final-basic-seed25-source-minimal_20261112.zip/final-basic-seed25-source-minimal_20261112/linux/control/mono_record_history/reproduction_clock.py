"""Per-session clock ledger; explicit offline local time is never NTP proof."""
import argparse
import json
import os
from pathlib import Path
import signal
import threading
import time
from .clock_ledger import build_segments,local_sample,anchored_sample
from .clock_probe import sample
from .live_index import update_clock


def atomic_json(path,value):
    path=Path(path);temporary=path.with_suffix('.tmp')
    with temporary.open('w',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(temporary,path)


class SessionClock:
    def __init__(self,directory,index,boot,policy,*,operator_confirmed=False,reference=None):
        if policy not in ('NETWORK_VERIFIED','NETWORK_ANCHORED','LOCAL_UNVERIFIED'):
            raise ValueError('explicit clock policy required')
        if policy=='LOCAL_UNVERIFIED' and operator_confirmed is not True:
            raise ValueError('operator must confirm local date before recording')
        self.directory=Path(directory);self.index=Path(index);self.boot=boot;self.policy=policy
        self.samples=[];self.number=0;self.previous=None
        self.reference=reference
        self.local_anchor=(time.monotonic_ns(),time.time_ns())
        if policy=='NETWORK_ANCHORED':
            if not isinstance(reference,dict) or reference.get('boot_id')!=boot:raise ValueError('fresh same-boot network reference required')
            anchored_sample(reference,self.local_anchor[0],observed_realtime_ns=self.local_anchor[1])
        self.prefix=boot+'-repro-'+str(time.monotonic_ns()).zfill(20)
        self.directory.mkdir(parents=True,exist_ok=True)

    def observe(self):
        mono=time.monotonic_ns();wall=time.time_ns()
        if self.policy=='LOCAL_UNVERIFIED':
            current=local_sample(self.boot,mono,self.local_anchor[1]+mono-self.local_anchor[0],operator_confirmed=True)
            current.update(observed_realtime_ns=wall,semantics='Operator-confirmed initial wall time plus continuous monotonic clock; absolute accuracy unverified')
        elif self.policy=='NETWORK_ANCHORED':current=anchored_sample(self.reference,mono,observed_realtime_ns=wall)
        else:current=sample()
        if current['boot_id']!=self.boot:raise RuntimeError('clock observer boot changed')
        self.samples.append(current)
        # Rotate with an overlapping observation, preserving adjacent interval
        # continuity. Each file stays well below the reader's 4MiB bound.
        value=dict(schema=1,boot_id=self.boot,policy=self.policy,samples=self.samples)
        body=json.dumps(value)
        if len(self.samples)>256 or len(body.encode())>2*1024*1024:
            previous=self.samples[-2];self.samples=[previous,current];self.number+=1
            value['samples']=self.samples
        path=self.directory/(self.prefix+'-'+str(self.number).zfill(8)+'.json')
        atomic_json(path,value)
        segments=build_segments(self.samples[-2:])
        if segments:update_clock(self.index,self.boot,segments)
        self.previous=current
        return dict(valid=current['valid'],policy=self.policy,path=str(path),segments=len(segments))


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--clock-dir',type=Path,required=True);p.add_argument('--index',type=Path,required=True)
    p.add_argument('--policy',choices=['NETWORK_VERIFIED','NETWORK_ANCHORED','LOCAL_UNVERIFIED'],required=True)
    p.add_argument('--operator-confirmed',action='store_true');p.add_argument('--boot',required=True)
    p.add_argument('--stop-file',type=Path)
    p.add_argument('--network-reference',type=Path)
    a=p.parse_args(argv)
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=a.boot:raise ValueError('boot changed')
    reference=json.loads(a.network_reference.read_text()) if a.network_reference else None
    clock=SessionClock(a.clock_dir,a.index,a.boot,a.policy,operator_confirmed=a.operator_confirmed,reference=reference)
    stop=threading.Event()
    for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda *_:stop.set())
    while True:
        result=clock.observe()
        atomic_json(a.clock_dir/('observer-status-'+a.boot+'.json'),result)
        if stop.is_set() or a.stop_file and a.stop_file.exists():break
        stop.wait(5)
    return 0

if __name__=='__main__':raise SystemExit(main())
