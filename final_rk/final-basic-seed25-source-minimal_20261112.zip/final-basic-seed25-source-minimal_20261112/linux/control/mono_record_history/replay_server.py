"""Loopback-only, read-only sealed MP4 replay with bounded aggregate bandwidth.

Expose only through a separately approved private tunnel (for example Tailscale
Serve). Optional algorithm proxy forwards bounded requests to the single video owner.
No hardware access, shell execution, file upload or public bind is offered.
"""
import datetime
import hashlib
from http.client import HTTPConnection, HTTPException
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json
import itertools
import logging
import os
from pathlib import Path
import re
import stat
import threading
import time
from urllib.parse import urlsplit,parse_qs
from .catalog import query_assets
from .live_index import query_assets as query_live_assets,lookup_by_id,MEDIA_NAME,ID
from .retention import media_lease
import sqlite3


def parse_utc(text):
    value=datetime.datetime.fromisoformat(text.replace('Z','+00:00'))
    if value.tzinfo is None:raise ValueError('explicit UTC offset required')
    return int(value.timestamp()*1_000_000_000)


def byte_range(header,size):
    if not header:return 0,size-1,False
    match=re.fullmatch(r'bytes=(\d*)-(\d*)',header)
    if not match or not any(match.groups()):raise ValueError('one valid byte range required')
    left,right=match.groups()
    if not left:
        length=int(right)
        if length<=0:raise ValueError('zero suffix range')
        return max(0,size-length),size-1,True
    start=int(left);end=min(int(right),size-1) if right else size-1
    if start>=size or end<start:raise ValueError('unsatisfiable range')
    return start,end,True


class Pacer:
    def __init__(self,bytes_per_second):
        if not 1<=bytes_per_second<=2_000_000:raise ValueError('bandwidth must be 1..2000000 bytes/s')
        self.rate=bytes_per_second;self.lock=threading.Lock();self.next=0
    def reserve(self,size):
        with self.lock:
            now=time.monotonic();self.next=max(now,self.next)+size/self.rate;wait=self.next-now
        if wait>0:time.sleep(wait)


class ReplayServer(ThreadingHTTPServer):
    daemon_threads=True
    request_queue_size=4
    def __init__(self,address,catalog_path=None,*,bytes_per_second=1_500_000,algorithm_control=False,live_index=None):
        if address[0]!='127.0.0.1':raise ValueError('loopback bind only; use private authenticated tunnel')
        self.algorithm_control=algorithm_control
        self.connections=threading.BoundedSemaphore(4)
        self.catalog_path=Path(catalog_path) if catalog_path is not None else None
        self.live_index=Path(live_index) if live_index is not None else None
        self.slots=threading.BoundedSemaphore(2);self.pacer=Pacer(bytes_per_second)
        super().__init__(address,ReplayHandler)
    def process_request(self,request,client_address):
        if not self.connections.acquire(blocking=False):self.shutdown_request(request);return
        try:super().process_request(request,client_address)
        except BaseException:self.connections.release();raise
    def process_request_thread(self,request,client_address):
        try:super().process_request_thread(request,client_address)
        finally:self.connections.release()
    def load_catalog(self):
        path=self.catalog_path
        if path is None:return dict(schema=1,recording_id='LIVE',boot_id='PER_ASSET',assets=[])
        if path.is_symlink():raise ValueError('catalog symlink')
        files=sorted(itertools.islice(path.glob('*.json'),257)) if path.is_dir() else [path]
        if not 1<=len(files)<=256:raise ValueError('catalog count bound')
        catalogs=[];total=0
        for file in files:
            total+=file.stat().st_size
            if file.is_symlink() or total>16*1024*1024:raise ValueError('catalog bound/symlink')
            fd=os.open(file,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            with os.fdopen(fd,'rb') as source:
                if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):raise ValueError('catalog must be ordinary file')
                raw=source.read(16*1024*1024+1)
                if len(raw)>16*1024*1024:raise ValueError('catalog size grew')
            data=json.loads(raw)
            if data.get('schema')!=1:raise ValueError('catalog schema')
            catalogs.append(data)
        assets=[];seen=set()
        for catalog in catalogs:
            for row in catalog['assets']:
                if row['asset_id'] in seen:raise ValueError('duplicate asset ID')
                seen.add(row['asset_id'])
                assets.append(dict(row,recording_root=catalog['recording_root'],recording_id=catalog['recording_id'],boot_id=catalog['boot_id']))
        assets.sort(key=lambda a:(a.get('utc_start_ns') is None,a.get('utc_start_ns') or 0,a['recording_id'],a['relative_path']))
        return dict(schema=1,recording_id='MULTI_SESSION',boot_id='PER_ASSET',assets=assets)

    def asset_page(self,catalog,*,start=None,end=None,unknown=False,limit=100,offset=0,order='asc'):
        if order not in ('asc','desc'):raise ValueError('explicit asc/desc order required')
        if self.live_index is not None:
            try:return query_live_assets(self.live_index,start_utc_ns=start,end_utc_ns=end,
                include_unknown=unknown,limit=limit,offset=offset,legacy_assets=catalog['assets'],order=order)
            except sqlite3.Error as error:
                logging.getLogger(__name__).exception('live replay index query failed')
                raise OSError('live index unavailable') from error
        if type(limit) is not int or not 1<=limit<=200 or type(offset) is not int or not 0<=offset<2**63:
            raise ValueError('invalid page limit/offset')
        rows=query_assets(catalog,start_utc_ns=start,end_utc_ns=end,include_unknown=unknown)
        if order=='desc':
            rows.sort(key=lambda row:(row.get('utc_start_ns') is None,-(row.get('utc_start_ns') or 0),row['asset_id']))
        more=len(rows)>offset+limit
        return dict(assets=rows[offset:offset+limit],has_more=more,next_offset=offset+limit if more else None)

    def lookup_asset(self,catalog,asset_id):
        rows=[x for x in catalog['assets'] if x.get('asset_id')==asset_id and x.get('available') and x.get('state')=='CLOSED_VERIFIED']
        if self.live_index is not None:
            try:live=lookup_by_id(self.live_index,asset_id)
            except sqlite3.Error as error:
                logging.getLogger(__name__).exception('live replay index lookup failed')
                raise OSError('live index unavailable') from error
            if live is not None:rows.append(live)
        if len(rows)>1:raise ValueError('ambiguous asset ID between catalogs/live index')
        return rows[0] if rows else None


class ReplayHandler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def setup(self):
        super().setup();self.connection.settimeout(15)
    def log_message(self,*args):pass
    def response_headers(self,status,length,kind,extra=None):
        self._response_started=True
        self.send_response(status);self.send_header('Content-Length',str(length));self.send_header('Content-Type',kind)
        self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
        if self.server.live_index is not None:
            self.send_header('X-Recording-Leases','1')
            self.send_header('X-Recording-Index',hashlib.sha256(str(self.server.live_index.absolute()).encode()).hexdigest())
        for k,v in (extra or {}).items():self.send_header(k,v)
        self.end_headers()
    def body(self,status,body,kind='application/json; charset=utf-8',extra=None):
        self.response_headers(status,len(body),kind,extra)
        if self.command!='HEAD':self.wfile.write(body)
    def control_proxy(self):
        if not self.server.algorithm_control:
            self.body(503,b'{"error":"algorithm control not enabled"}');return
        body=None
        if self.command=='POST':
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=1024 or self.headers.get('Transfer-Encoding') is not None:
                    raise ValueError('bounded request required')
                body=self.rfile.read(length)
                if len(body)!=length:raise ValueError('short body')
            except ValueError:
                self.body(400,b'{"error":"invalid command body"}');self.close_connection=True;return
        headers={key:self.headers[key] for key in ('Host','Origin','X-Control-Token','Content-Type') if key in self.headers}
        connection=HTTPConnection('127.0.0.1',8766,timeout=3)
        try:
            connection.request(self.command,self.path,body=body,headers=headers)
            response=connection.getresponse();data=response.read(65537)
            if len(data)>65536:raise ValueError('control response exceeds bound')
            extra={key:response.getheader(key) for key in ('Content-Security-Policy',) if response.getheader(key)}
            self.body(response.status,data,response.getheader('Content-Type','application/json'),extra=extra)
        except (OSError,ValueError,HTTPException):
            self.body(503,b'{"error":"video owner unavailable; no automatic retry"}')
        finally:connection.close()
    def do_POST(self):
        self._response_started=False
        if self.path=='/control/api/command':self.control_proxy()
        else:self.body(404,b'{"error":"not found"}')
    def do_HEAD(self):self.do_GET()
    def do_GET(self):
        self._response_started=False
        if self.command=='GET' and self.path in ('/control','/control/','/control/api/state'):
            self.control_proxy();return
        if not self.server.slots.acquire(blocking=False):
            self.body(503,b'{"error":"busy"}',extra={'Retry-After':'2'});return
        try:
            parsed=urlsplit(self.path)
            if parsed.path=='/':
                self.body(200,Path(__file__).with_name('replay.html').read_bytes(),'text/html; charset=utf-8');return
            catalog=self.server.load_catalog()
            if parsed.path=='/api/recordings':
                args=parse_qs(parsed.query);start=parse_utc(args['start'][0]) if 'start' in args else None;end=parse_utc(args['end'][0]) if 'end' in args else None
                if start is not None and end is not None and start>=end:raise ValueError('end must exceed start')
                for name in ('start','end','unknown','limit','offset','order'):
                    if name in args and len(args[name])!=1:raise ValueError('duplicate query parameter')
                limit=int(args.get('limit',['100'])[0]);offset=int(args.get('offset',['0'])[0])
                page=self.server.asset_page(catalog,start=start,end=end,unknown=args.get('unknown',['0'])==['1'],limit=limit,offset=offset,order=args.get('order',['asc'])[0])
                rows=page['assets']
                public=[]
                for row in rows:
                    item={k:row.get(k) for k in ('asset_id','relative_path','bytes','clock_quality','pts_start_ns','pts_end_ns','sample_count','recording_id','boot_id')}
                    for k in ('utc_start_ns','utc_end_ns'):
                        n=row.get(k);item[k.replace('_ns','')]=datetime.datetime.fromtimestamp(n/1e9,datetime.timezone.utc).isoformat() if n is not None else None
                    item['sample_count']=row.get('metadata',{}).get('sample_count')
                    item['url']='/media/'+row['asset_id'];public.append(item)
                self.body(200,json.dumps(dict(recording_id=catalog['recording_id'],boot_id=catalog['boot_id'],assets=public,
                    has_more=page['has_more'],next_offset=page['next_offset'],limit=limit,offset=offset),ensure_ascii=False).encode());return
            if parsed.path.startswith('/media/') and not parsed.query:
                asset_id=parsed.path.removeprefix('/media/')
                if not ID.fullmatch(asset_id):self.body(404,b'{"error":"not available"}');return
                if self.server.live_index is None:
                    row=self.server.lookup_asset(catalog,asset_id)
                    if row is None:self.body(404,b'{"error":"not available"}');return
                    self.media(catalog,row);return
                # Lookup is inside the shared lease: an earlier query page
                # may be stale after circular reclamation, but an active file
                # response keeps its identity and contents until it finishes.
                with media_lease(self.server.live_index,asset_id):
                    row=self.server.lookup_asset(catalog,asset_id)
                    if row is None:self.body(404,b'{"error":"not available"}');return
                    self.media(catalog,row);return
            self.body(404,b'{"error":"not found"}')
        except (ValueError,KeyError,TypeError,json.JSONDecodeError):self.body(400,b'{"error":"invalid request or catalog"}')
        except (BrokenPipeError,ConnectionResetError,TimeoutError):self.close_connection=True
        except OSError:
            if self._response_started:self.close_connection=True
            else:self.body(409,b'{"error":"recording unavailable or storage changed"}')
        finally:self.server.slots.release()
    def media(self,catalog,row):
        name=row['relative_path'];root=Path(row['recording_root'])
        if not MEDIA_NAME.fullmatch(name) or not root.is_absolute() or any(p.is_symlink() for p in (root,*root.parents)):
            raise ValueError('unsafe recording path')
        directory=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:
            descriptor=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=directory)
            with os.fdopen(descriptor,'rb') as stream:
                st=os.fstat(stream.fileno())
                if not stat.S_ISREG(st.st_mode) or st.st_dev!=os.fstat(directory).st_dev or st.st_size!=row['bytes'] or st.st_size>16*1024*1024:raise OSError('recording changed')
                digest=hashlib.sha256()
                for chunk in iter(lambda:stream.read(65536),b''):digest.update(chunk)
                if digest.hexdigest()!=row['sha256']:raise OSError('recording hash changed')
                etag='"'+row['sha256']+'"';requested=self.headers.get('Range') if self.command=='GET' else None
                if self.headers.get('If-Range') not in (None,etag):requested=None
                try:start,end,partial=byte_range(requested,st.st_size)
                except ValueError:self.body(416,b'',extra={'Content-Range':f'bytes */{st.st_size}'});return
                extra={'Accept-Ranges':'bytes','ETag':etag}
                if partial:extra['Content-Range']=f'bytes {start}-{end}/{st.st_size}'
                # BaseHTTPRequestHandler stores request headers in self.headers.
                ReplayHandler.response_headers(self,206 if partial else 200,end-start+1,'video/mp4',extra)
                if self.command=='HEAD':return
                stream.seek(start);remaining=end-start+1
                while remaining:
                    chunk=stream.read(min(32768,remaining))
                    if not chunk:raise OSError('short read after publication')
                    self.server.pacer.reserve(len(chunk));self.wfile.write(chunk);remaining-=len(chunk)
        finally:os.close(directory)
