"""Read-only import of sealed recording evidence; no filesystem-clock inference.

Verification covers container tables and AU identity, not decoder correctness,
codec-level compliance, sensor timestamps, or power-loss durability.
"""
import bisect
import hashlib
import io
import itertools
import json
import os
from pathlib import Path
import re
import stat
import struct
import tempfile

from .clock_ledger import map_interval

MAX_JSON = 4 * 1024 * 1024
MAX_LOG = 64 * 1024 * 1024
MAX_MP4 = 64 * 1024 * 1024
MAX_SAMPLES = 16384
MAX_AUS = 200000
MAX_FILES = 4096
MAX_CLOCK_SEGMENTS = 4096
MAX_HEVC_DESCRIPTIONS = 16
NAME = re.compile(r'segment-([0-9]{5})\.mp4\Z')
SHA = re.compile(r'[0-9a-f]{64}\Z')


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _identity(value):
    return _hash(json.dumps(value, sort_keys=True, separators=(',', ':'),
                            ensure_ascii=False).encode())


def _integer(value, label, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError('invalid ' + label)
    return value


def _checked_root(path):
    absolute = Path(path).absolute()
    if any(part.is_symlink() for part in (absolute, *absolute.parents)):
        raise ValueError('symlink recording/trial root or parent refused')
    return absolute.resolve(strict=True)


def _read(root, relative, limit):
    """Walk pinned directory FDs; reject symlinks, devices, FIFOs and races."""
    parts = Path(relative).parts
    if not parts or any(p in ('', '.', '..') for p in parts) or Path(relative).is_absolute():
        raise ValueError('unsafe relative path')
    directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory)
            directory = child
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        try:
            before = os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or not 0 <= before.st_size <= limit:
                raise ValueError('nonregular or oversized evidence file')
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                data = stream.read(limit + 1)
            after = os.fstat(fd)
            if len(data) != before.st_size or len(data) > limit or (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                raise ValueError('evidence changed during read')
            return data
        finally:
            os.close(fd)
    finally:
        os.close(directory)


def _boxes(data, start=0, end=None):
    end = len(data) if end is None else end
    count = 0
    while start < end:
        count += 1
        if count > 10000 or start + 8 > end:
            raise ValueError('invalid MP4 box count/header')
        size, kind = struct.unpack_from('>I4s', data, start)
        header = 8
        if size == 1:
            if start + 16 > end:
                raise ValueError('truncated extended MP4 box')
            size = struct.unpack_from('>Q', data, start + 8)[0]
            header = 16
        elif size == 0:
            size = end - start
        if size < header or start + size > end:
            raise ValueError('invalid MP4 box extent')
        yield kind, start + header, start + size
        start += size


def _compatible_hevc_descriptions(stsd):
    """Bounded descriptions for one HEVC stream, retaining per-entry color tags.

    Existing single-description imports keep their historical structural
    qualification (including the small zero-geometry test fixture). Multiple
    entries require real matching visual geometry and an identical validated
    standalone decoder configuration. We do not guess SPS compatibility or
    rewrite colr/VUI, and do not treat distinct hvc1/hev1 tags as another codec.
    """
    count=struct.unpack_from('>I',stsd,4)[0]
    if not 1<=count<=MAX_HEVC_DESCRIPTIONS:raise ValueError('HEVC sample description count bound')
    entries=list(itertools.islice(_boxes(stsd,8),MAX_HEVC_DESCRIPTIONS+1))
    if len(entries)!=count:raise ValueError('sample description count mismatch')
    shared=None
    for codec,start,end in entries:
        if codec not in (b'hvc1',b'hev1'):raise ValueError('expected HEVC sample description')
        if end-start<78:raise ValueError('truncated HEVC visual sample entry')
        configs=[stsd[a:b] for kind,a,b in _boxes(stsd,start+78,end) if kind==b'hvcC']
        if len(configs)!=1 or len(configs[0])<23 or configs[0][0]!=1:
            raise ValueError('missing/truncated HEVC decoder configuration')
        if count==1:continue
        visual=stsd[start:end];width,height=struct.unpack_from('>HH',visual,24)
        reference=struct.unpack_from('>H',visual,6)[0]
        depth=struct.unpack_from('>H',visual,74)[0]
        if not width or not height or reference!=1 or depth!=24:
            raise ValueError('invalid multi-description HEVC geometry/depth/reference')
        config=configs[0]
        if (len(config)>65536 or not config[1]&31 or not config[12] or
                config[13]&0xf0!=0xf0 or config[15]&0xfc!=0xfc or
                config[16]&0xfc!=0xfc or config[17]&0xf8!=0xf8 or config[18]&0xf8!=0xf8 or
                config[21]&3==2 or not 1<=config[22]<=64):
            raise ValueError('invalid multi-description HEVC configuration header')
        profile=config[1]&31;chroma=config[16]&3
        luma_depth=config[17]&7;chroma_depth=config[18]&7
        if (profile not in (1,2,3) or chroma!=1 or
                max(luma_depth,chroma_depth)>(2 if profile==2 else 0)):
            raise ValueError('unsupported multi-description HEVC profile/chroma/bit depth')
        cursor=23;nal_count=0;types=set()
        for unused in range(config[22]):
            if cursor+3>len(config):raise ValueError('truncated HEVC configuration array')
            header=config[cursor];kind=header&63
            amount=struct.unpack_from('>H',config,cursor+1)[0];cursor+=3
            if header&0x40 or not amount or nal_count+amount>256 or kind in types:
                raise ValueError('invalid/bounded HEVC configuration array')
            types.add(kind);nal_count+=amount
            for unused_nal in range(amount):
                if cursor+2>len(config):raise ValueError('truncated HEVC NAL length')
                size=struct.unpack_from('>H',config,cursor)[0];cursor+=2
                if size<2 or cursor+size>len(config):raise ValueError('truncated HEVC configuration NAL')
                if config[cursor]&0x80 or (config[cursor]>>1)&63!=kind or not config[cursor+1]&7:
                    raise ValueError('HEVC configuration NAL header differs')
                cursor+=size
        if cursor!=len(config) or not {32,33,34}<=types:
            raise ValueError('incomplete standalone HEVC parameter sets')
        compatibility=(width,height,depth,config)
        if shared is not None and compatibility!=shared:
            raise ValueError('incompatible HEVC sample descriptions')
        shared=compatibility
    return count


def _mp4(data):
    tables = {}
    mdats = []
    top = list(_boxes(data))
    if not {b'ftyp', b'moov', b'mdat'} <= {v[0] for v in top}:
        raise ValueError('unsealed MP4 container')
    def walk(start, end, depth=0):
        if depth > 6:
            raise ValueError('MP4 nesting limit')
        for kind, a, b in _boxes(data, start, end):
            if kind in (b'moov', b'trak', b'mdia', b'minf', b'stbl'):
                walk(a, b, depth + 1)
            elif kind == b'mdat':
                mdats.append((a, b))
            elif kind in (b'mdhd', b'stsd', b'stsz', b'stts', b'ctts', b'stco', b'co64', b'stsc'):
                if kind in tables:
                    raise ValueError('multiple MP4 tracks/tables unsupported')
                tables[kind] = data[a:b]
    walk(0, len(data))
    def table(kind, minimum):
        value = tables[kind]
        if len(value) < minimum:
            raise ValueError('truncated MP4 table')
        return value
    mdhd = table(b'mdhd', 24)
    if mdhd[0] not in (0, 1) or (mdhd[0] == 1 and len(mdhd) < 36):
        raise ValueError('invalid mdhd version/extent')
    scale = struct.unpack_from('>I', mdhd, 20 if mdhd[0] else 12)[0]
    duration = struct.unpack_from('>Q' if mdhd[0] else '>I', mdhd, 24 if mdhd[0] else 16)[0]
    if not scale:
        raise ValueError('zero MP4 timescale')
    stsd = table(b'stsd', 8)
    description_count=_compatible_hevc_descriptions(stsd)
    stsz = table(b'stsz', 12)
    fixed, count = struct.unpack_from('>II', stsz, 4)
    if not 0 < count <= MAX_SAMPLES or len(stsz) != (12 if fixed else 12 + 4 * count):
        raise ValueError('invalid sample-size table')
    sizes = [fixed] * count if fixed else list(struct.unpack_from('>' + str(count) + 'I', stsz, 12))
    if not all(sizes):
        raise ValueError('empty MP4 sample')
    def runs(kind, signed=False):
        payload = table(kind, 8)
        n = struct.unpack_from('>I', payload, 4)[0]
        if n > MAX_SAMPLES or len(payload) != 8 + n * 8:
            raise ValueError('invalid MP4 timing runs')
        values = []
        for i in range(n):
            amount, value = struct.unpack_from('>I' + ('i' if signed else 'I'), payload, 8 + i * 8)
            if not amount or len(values) + amount > count:
                raise ValueError('timing count exceeds sample count')
            values.extend([value] * amount)
        if len(values) != count:
            raise ValueError('sample/timing counts differ')
        return values
    deltas = runs(b'stts')
    if not all(deltas) or sum(deltas) != duration:
        raise ValueError('invalid MP4 durations')
    if b'ctts' in tables and (not tables[b'ctts'] or tables[b'ctts'][0] not in (0, 1)):
        raise ValueError('invalid ctts version')
    offsets = runs(b'ctts', tables[b'ctts'][0] == 1) if b'ctts' in tables else [0] * count
    pts = []
    dts = 0
    for delta, offset in zip(deltas, offsets):
        pts.append(dts + offset)
        dts += delta
    if any(b <= a for a, b in zip(pts, pts[1:])):
        raise ValueError('reordered/nonincreasing MP4 PTS unsupported')
    if (b'stco' in tables) == (b'co64' in tables):
        raise ValueError('expected one chunk offset table')
    chunks = table(b'stco' if b'stco' in tables else b'co64', 8)
    n = struct.unpack_from('>I', chunks, 4)[0]
    stride = 4 if b'stco' in tables else 8
    if not 0 < n <= count or len(chunks) != 8 + n * stride:
        raise ValueError('invalid MP4 chunks')
    chunk_offsets = struct.unpack_from('>' + str(n) + ('I' if stride == 4 else 'Q'), chunks, 8)
    stsc = table(b'stsc', 8)
    nr = struct.unpack_from('>I', stsc, 4)[0]
    if not 0 < nr <= n or len(stsc) != 8 + nr * 12:
        raise ValueError('invalid sample-to-chunk table')
    mappings = [struct.unpack_from('>III', stsc, 8 + i * 12) for i in range(nr)]
    if mappings[0][0] != 1 or any(not v[1] or not 1<=v[2]<=description_count or v[0] > n for v in mappings) or any(b[0] <= a[0] for a, b in zip(mappings, mappings[1:])):
        raise ValueError('invalid chunk mapping')
    index = mapping = 0
    previous_end = -1
    for chunk, offset in enumerate(chunk_offsets, 1):
        while mapping + 1 < len(mappings) and mappings[mapping + 1][0] <= chunk:
            mapping += 1
        amount = mappings[mapping][1]
        if index + amount > count:
            raise ValueError('chunk sample overflow')
        end = offset + sum(sizes[index:index + amount])
        if offset < previous_end or not any(a <= offset < end <= b for a, b in mdats):
            raise ValueError('sample payload outside mdat or overlapping chunks')
        previous_end = end
        index += amount
    if index != count:
        raise ValueError('unmapped MP4 samples')
    return sizes, pts, scale


def _events(log):
    aus, closed, accumulated = [], [], 0
    for line in io.StringIO(log.decode('utf-8', errors='strict')):
        p = line.split()
        if p[:2] == ['R5REC1', 'AU']:
            if len(p) != 8 or len(aus) >= MAX_AUS:
                raise ValueError('invalid/bounded AU journal')
            ordinal, pts, duration, size, total, flags = map(int, p[2:])
            accumulated += size
            if ordinal != len(aus) + 1 or pts < 0 or size <= 0 or total != accumulated or (aus and pts <= aus[-1][1]):
                raise ValueError('AU order/identity/size mismatch')
            aus.append((ordinal, pts, duration, size))
        elif p[:2] == ['R5REC1', 'CLOSED']:
            if len(p) != 4 or len(closed) >= MAX_FILES:
                raise ValueError('invalid CLOSED journal')
            closed.append(tuple(map(int, p[2:])))
    if not aus or not closed or len({v[0] for v in closed}) != len(closed) or any(b[0] <= a[0] or b[1] <= a[1] for a, b in zip(closed, closed[1:])) or closed[-1][1] != aus[-1][1]:
        raise ValueError('missing/duplicate AU or CLOSED journal')
    return aus, closed


def build_catalog(recording_dir, trial_dir, *, clock_segments=()):
    """Return a snapshot; only CLOSED_VERIFIED assets may be served or queried."""
    root = _checked_root(recording_dir)
    trial = _checked_root(trial_dir)
    clock_segments = tuple(itertools.islice(clock_segments, MAX_CLOCK_SEGMENTS + 1))
    if len(clock_segments) > MAX_CLOCK_SEGMENTS:
        raise ValueError('clock segment count bound')
    manifest_bytes = _read(root, 'manifest.json', MAX_JSON)
    manifest = json.loads(manifest_bytes)
    context_bytes = _read(trial, 'trial-context.json', MAX_JSON)
    context = json.loads(context_bytes)
    boot = context.get('expected_boot')
    if not isinstance(boot, str) or not boot or len(boot) > 128:
        raise ValueError('missing context expected_boot identity')
    anchor = manifest['anchor']
    first_pts = _integer(anchor['first_pts_ns'], 'first PTS')
    first_received = _integer(anchor['first_received_monotonic_ns'], 'first receipt')
    log_bytes = _read(trial, 'preview/gstreamer.log', MAX_LOG)
    aus, closed = _events(log_bytes)
    if aus[0][1] != first_pts:
        raise ValueError('first AU does not match receipt anchor')
    entries = manifest['samples']
    if not isinstance(entries, list) or not entries or len(entries) > MAX_FILES:
        raise ValueError('invalid/bounded manifest samples')
    recording_id = _identity(dict(boot_id=boot, first_pts_ns=first_pts,
        first_received_monotonic_ns=first_received,
        source_directory=manifest.get('storage', {}).get('directory'),
        candidate=manifest.get('recording_candidate')))
    pts_values = [v[1] for v in aus]
    assets = []
    seen = set()
    for position, entry in enumerate(entries):
        name = entry.get('file') if isinstance(entry, dict) else None
        expected_sha = entry.get('sha256') if isinstance(entry, dict) else None
        expected_size = entry.get('bytes') if isinstance(entry, dict) else None
        asset = dict(asset_id=_identity([recording_id, name, expected_sha]),
            relative_path=name if isinstance(name, str) and NAME.fullmatch(name) else None,
            available=False, state='INVALID', bytes=expected_size, sha256=expected_sha,
            pts_start_ns=None, pts_end_ns=None, monotonic_start_ns=None,
            monotonic_end_ns=None, utc_start_ns=None, utc_end_ns=None,
            clock_quality='UNKNOWN', uncertainty_ns=None, clock_segment_id=None,
            metadata={})
        assets.append(asset)
        try:
            if not isinstance(name, str) or not NAME.fullmatch(name) or name in seen:
                raise ValueError('unsafe/duplicate/nonsealed manifest filename')
            seen.add(name)
            if not isinstance(expected_sha, str) or not SHA.fullmatch(expected_sha):
                raise ValueError('invalid manifest SHA256')
            _integer(expected_size, 'file size', 1)
            if expected_size > MAX_MP4 or len(closed) != len(entries):
                raise ValueError('file bound or CLOSED/manifest count mismatch')
            file_id = int(NAME.fullmatch(name).group(1))
            if closed[position] != (file_id, entry.get('fragment_close_running_time_ns')):
                raise ValueError('CLOSED/manifest order or boundary mismatch')
            lower = first_pts if position == 0 else closed[position - 1][1]
            upper = closed[position][1]
            start = bisect.bisect_left(pts_values, lower)
            stop = bisect.bisect_left(pts_values, upper) if position + 1 < len(entries) else bisect.bisect_right(pts_values, upper)
            selected = aus[start:stop]
            if not selected or selected[0][1] != lower or (position + 1 == len(entries) and selected[-1][1] != upper):
                raise ValueError('CLOSED boundary not matched to actual AU')
            duration = selected[-1][2]
            end_pts = selected[-1][1] + duration if 0 < duration < 1_000_000_000 else None
            asset.update(pts_start_ns=selected[0][1], pts_end_ns=end_pts,
                monotonic_start_ns=first_received + selected[0][1] - first_pts,
                monotonic_end_ns=first_received + end_pts - first_pts if end_pts is not None else None)
            asset['metadata'].update(first_au_ordinal=selected[0][0], last_au_ordinal=selected[-1][0],
                last_au_pts_ns=selected[-1][1], sample_count=len(selected),
                end_duration_known=end_pts is not None,
                time_semantics='host callback receipt, not sensor exposure or trusted UTC')
            try:
                data = _read(root, name, MAX_MP4)
            except FileNotFoundError:
                asset['state'] = 'MISSING'
                continue
            asset['metadata'].update(observed_bytes=len(data), observed_sha256=_hash(data))
            if len(data) != expected_size or _hash(data) != expected_sha:
                raise ValueError('recording hash/size mismatch')
            sizes, sample_pts, scale = _mp4(data)
            if sizes != [v[3] for v in selected]:
                raise ValueError('MP4 sample sizes do not match ordered AUs')
            if any(abs((p - sample_pts[0]) * 1_000_000_000 - (v[1] - selected[0][1]) * scale) > 1_000_000_000 for p, v in zip(sample_pts, selected)):
                raise ValueError('MP4 PTS does not match AU within one quantization tick')
            if asset['monotonic_end_ns'] is not None:
                asset.update(map_interval(clock_segments, boot,
                    asset['monotonic_start_ns'], asset['monotonic_end_ns']))
            asset.update(available=True, state='CLOSED_VERIFIED')
        except (OSError, ValueError, KeyError, TypeError, struct.error) as error:
            asset['metadata']['error'] = str(error)
    return dict(schema=1, boot_id=boot, recording_id=recording_id,
        recording_root=str(root), assets=assets,
        metadata=dict(manifest_sha256=_hash(manifest_bytes), context_sha256=_hash(context_bytes),
            au_log_sha256=_hash(log_bytes), clock_policy='Only same-boot ledger coverage; old realtime anchor ignored',
            verification_scope='Sealed-file hash, bounded MP4 tables and ordered AU/PTS; no codec or decode qualification'))


def query_assets(catalog, start_utc_ns=None, end_utc_ns=None, include_unknown=False):
    """Half-open intersection; unknown dates only appear by explicit opt-in."""
    for value in (start_utc_ns, end_utc_ns):
        if value is not None:
            _integer(value, 'query UTC')
    if start_utc_ns is not None and end_utc_ns is not None and start_utc_ns >= end_utc_ns:
        raise ValueError('empty/reversed query interval')
    output = []
    for asset in catalog['assets']:
        if not asset.get('available') or asset.get('state') != 'CLOSED_VERIFIED':
            continue
        start, end = asset.get('utc_start_ns'), asset.get('utc_end_ns')
        if start is None or end is None:
            if include_unknown and start_utc_ns is None and end_utc_ns is None:
                output.append(asset)
        elif (end_utc_ns is None or start < end_utc_ns) and (start_utc_ns is None or end > start_utc_ns):
            output.append(asset)
    return output


def write_catalog(path, catalog):
    """Atomically publish; failure before replace preserves the old version.

    A directory fsync failure after replace propagates: the new version may be
    visible but its persistence is unconfirmed. No rollback or crash claim.
    """
    path = Path(path).absolute()
    data = (json.dumps(catalog, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    if len(data) > MAX_JSON:
        raise ValueError('catalog size bound')
    parent = path.parent.resolve(strict=True)
    directory = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    temporary = None
    try:
        def staged(payload):
            fd, name = tempfile.mkstemp(prefix='.' + path.name + '.', dir=parent)
            try:
                with os.fdopen(fd, 'wb') as stream:
                    stream.write(payload)
                    stream.flush()
                    os.fsync(stream.fileno())
            except BaseException:
                os.unlink(name)
                raise
            return name
        temporary = staged(data)
        os.fsync(directory)
        os.replace(temporary, path.name, dst_dir_fd=directory)
        temporary = None
        os.fsync(directory)
    finally:
        if temporary is not None:
            os.unlink(temporary)
        os.close(directory)
