"""Durable incremental publication of sealed files, with bounded query pages.

The caller verifies MP4/AU closure. Publication independently pins and hashes
the ordinary file. UTC is derived only from stored same-boot qualified ledger
coverage; caller wall clocks, filenames and mtimes are never time authority.
There is no session duration or database asset-count limit.
"""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat

from .clock_ledger import map_interval, MAPPED_QUALITIES

MAX_MEDIA_BYTES=16*1024*1024
MAX_ASSET_BYTES=65536
MAX_PAGE=200
MEDIA_NAME=re.compile(r'segment-[0-9]{5,20}\.mp4\Z')
ID=re.compile(r'[A-Za-z0-9_-]{1,128}\Z')
TIME_FIELDS=('utc_start_ns','utc_end_ns','clock_quality','uncertainty_ns','clock_segment_id')
SCHEMA='''
CREATE TABLE IF NOT EXISTS assets (
 asset_id TEXT PRIMARY KEY, recording_id TEXT NOT NULL, boot_id TEXT NOT NULL,
 recording_root TEXT NOT NULL, relative_path TEXT NOT NULL,
 monotonic_start_ns INTEGER, monotonic_end_ns INTEGER,
 utc_start_ns INTEGER, utc_end_ns INTEGER, clock_quality TEXT NOT NULL,
 identity_json TEXT NOT NULL, asset_json TEXT NOT NULL,
 UNIQUE(recording_root,relative_path)
);
CREATE INDEX IF NOT EXISTS assets_time ON assets(utc_start_ns,asset_id);
CREATE INDEX IF NOT EXISTS assets_page_order ON assets((utc_start_ns IS NULL),utc_start_ns,recording_id,length(relative_path),relative_path,asset_id);
CREATE INDEX IF NOT EXISTS assets_boot_time ON assets(boot_id,clock_quality,monotonic_end_ns);
CREATE TABLE IF NOT EXISTS clock_segments (
 segment_id TEXT NOT NULL, boot_id TEXT NOT NULL,
 start_ns INTEGER NOT NULL, end_ns INTEGER NOT NULL, segment_json TEXT NOT NULL,
 PRIMARY KEY(boot_id,segment_id)
);
CREATE INDEX IF NOT EXISTS segments_boot_time ON clock_segments(boot_id,start_ns,end_ns);
PRAGMA user_version=1;
'''


def _json(value):
    text=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
    if len(text.encode())>MAX_ASSET_BYTES:raise ValueError('asset/clock record exceeds64KiB')
    return text


def _int(value,name,*,nullable=False):
    if value is None and nullable:return
    if type(value) is not int or not 0<=value<2**63:raise ValueError('invalid '+name)


def _label(value,name):
    if type(value) is not str or not 1<=len(value)<=128 or any(ord(c)<33 or ord(c)>126 for c in value):
        raise ValueError('explicit bounded '+name+' required')


def _asset(asset):
    if type(asset) is not dict:raise ValueError('asset object required')
    row=json.loads(_json(asset))
    if not isinstance(row.get('asset_id'),str) or not ID.fullmatch(row['asset_id']):raise ValueError('invalid asset_id')
    for name in ('recording_id','boot_id'):_label(row.get(name),name)
    if row.get('available') is not True or row.get('state')!='CLOSED_VERIFIED':raise ValueError('sealed verified asset required')
    if not isinstance(row.get('relative_path'),str) or not MEDIA_NAME.fullmatch(row['relative_path']):raise ValueError('sealed MP4 basename required')
    if type(row.get('recording_root')) is not str or not Path(row['recording_root']).is_absolute():raise ValueError('absolute recording root required')
    _int(row.get('bytes'),'bytes')
    if not 0<row['bytes']<=MAX_MEDIA_BYTES:raise ValueError('media file exceeds16MiB or is empty')
    if not isinstance(row.get('sha256'),str) or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError('SHA256 required')
    for name in ('monotonic_start_ns','monotonic_end_ns'):_int(row.get(name),name,nullable=True)
    a,b=row.get('monotonic_start_ns'),row.get('monotonic_end_ns')
    if b is not None and (a is None or b<=a):raise ValueError('invalid monotonic interval')
    if type(row.get('metadata')) is not dict:raise ValueError('asset metadata required')
    _int(row['metadata'].get('sample_count'),'sample_count')
    if not row['metadata']['sample_count']:raise ValueError('nonempty sealed MP4 required')
    # Time authority is the ledger below, including when the caller supplied
    # plausible UTC values. Reingest after backfill must not undo that mapping.
    for name in TIME_FIELDS:row.pop(name,None)
    return row


def _verify_file(row):
    root=Path(row['recording_root'])
    if any(p.is_symlink() for p in (root,*root.parents)):raise ValueError('symlink recording root')
    directory=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        fd=os.open(row['relative_path'],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=directory)
        with os.fdopen(fd,'rb') as stream:
            before=os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_size!=row['bytes']:raise ValueError('recording size/type changed')
            digest=hashlib.sha256()
            for chunk in iter(lambda:stream.read(65536),b''):digest.update(chunk)
            after=os.fstat(stream.fileno())
            if ((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=
                    (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
                    or digest.hexdigest()!=row['sha256']):raise ValueError('recording changed or SHA256 differs')
    finally:os.close(directory)


def _db_path(db):
    path=Path(db).absolute()
    if any(p.is_symlink() for p in (path,*path.parents)):raise ValueError('symlink database path')
    if path.exists() and not stat.S_ISREG(path.stat().st_mode):raise ValueError('ordinary SQLite database required')
    return path


@contextmanager
def _connect(db,*,write=False):
    path=_db_path(db)
    if not path.exists() and not write:
        yield None
        return
    if write and not path.exists():
        try:os.close(os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600))
        except FileExistsError:pass
    connection=sqlite3.connect(path if write else path.as_uri()+'?mode=ro',uri=not write,timeout=5)
    connection.row_factory=sqlite3.Row
    try:
        connection.execute('PRAGMA busy_timeout=5000')
        if write:
            connection.execute('PRAGMA journal_mode=WAL')
            connection.execute('PRAGMA synchronous=FULL')
            version=connection.execute('PRAGMA user_version').fetchone()[0]
            if version not in (0,1):raise ValueError('unsupported live index schema')
            connection.executescript(SCHEMA)
            connection.execute('BEGIN IMMEDIATE')
        elif connection.execute('PRAGMA user_version').fetchone()[0]!=1:
            raise ValueError('unsupported live index schema')
        yield connection
        if write:connection.commit()
    except BaseException:
        if write:connection.rollback()
        raise
    finally:connection.close()


def _mapping(connection,row):
    a,b=row.get('monotonic_start_ns'),row.get('monotonic_end_ns')
    segments=[]
    if a is not None and b is not None:
        values=connection.execute('SELECT segment_json FROM clock_segments WHERE boot_id=? AND start_ns<? AND end_ns>? ORDER BY start_ns LIMIT 32769',
            (row['boot_id'],b,a))
        segments=[json.loads(v[0]) for v in values]
    return map_interval(segments,row['boot_id'],a,b)


def ingest_verified_asset(db,asset):
    """Hash a sealed file, then durably publish once; conflicts never replace."""
    row=_asset(asset)
    # Reject a bad first file without creating an index/lease namespace. The
    # verification inside the lease below remains authoritative for commit.
    if not _db_path(db).exists():_verify_file(row)
    # Publication and replay use the same cross-process read lease. A queued
    # publication cannot reinsert a stale identity after reclamation unlinks
    # its verified media file and completes its pending journal entry.
    from .retention import media_lease
    with media_lease(db,row['asset_id']):
        return _ingest_leased(db,row)


def _ingest_leased(db,row):
    _verify_file(row)
    row['recording_root']=str(Path(row['recording_root']).resolve(strict=True))
    identity=_json(row)
    with _connect(db,write=True) as connection:
        previous=connection.execute('SELECT identity_json FROM assets WHERE asset_id=?',(row['asset_id'],)).fetchone()
        if previous is not None:
            if previous[0]!=identity:raise ValueError('asset_id already belongs to different content/context')
            return dict(asset_id=row['asset_id'],inserted=False)
        row.update(_mapping(connection,row))
        try:
            connection.execute('INSERT INTO assets VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                (row['asset_id'],row['recording_id'],row['boot_id'],row['recording_root'],row['relative_path'],
                 row.get('monotonic_start_ns'),row.get('monotonic_end_ns'),row['utc_start_ns'],row['utc_end_ns'],
                 row['clock_quality'],identity,_json(row)))
        except sqlite3.IntegrityError as error:raise ValueError('sealed file already published under another asset identity') from error
    return dict(asset_id=row['asset_id'],inserted=True)


def update_clock(db,boot_id,clock_segments):
    """Persist same-boot ledger intervals and backfill only exact coverage."""
    _label(boot_id,'boot_id')
    if type(clock_segments) not in (list,tuple) or len(clock_segments)>32768:raise ValueError('bounded clock batch required')
    rows=[]
    for segment in clock_segments:
        if type(segment) is not dict:raise ValueError('clock segment object required')
        row=json.loads(_json(segment));a,b=row.get('start_monotonic_ns'),row.get('end_monotonic_ns')
        if row.get('boot_id')!=boot_id or map_interval([row],boot_id,a,b)['clock_quality'] not in MAPPED_QUALITIES:
            raise ValueError('qualified exact same-boot clock segment required')
        rows.append(row)
    updated=0
    with _connect(db,write=True) as connection:
        for row in rows:
            text=_json(row);previous=connection.execute('SELECT segment_json FROM clock_segments WHERE boot_id=? AND segment_id=?',(boot_id,row['segment_id'])).fetchone()
            if previous:
                if previous[0]!=text:raise ValueError('clock segment identity conflict')
                continue
            a,b=row['start_monotonic_ns'],row['end_monotonic_ns']
            if connection.execute('SELECT 1 FROM clock_segments WHERE boot_id=? AND start_ns<? AND end_ns>? LIMIT 1',(boot_id,b,a)).fetchone():
                raise ValueError('overlapping ledger coverage is ambiguous')
            connection.execute('INSERT INTO clock_segments VALUES (?,?,?,?,?)',(row['segment_id'],boot_id,a,b,text))
        if rows:
            lower=min(r['start_monotonic_ns'] for r in rows);upper=max(r['end_monotonic_ns'] for r in rows);last=''
            while True:
                batch=connection.execute("SELECT asset_id,asset_json FROM assets WHERE boot_id=? AND clock_quality='UNKNOWN' AND asset_id>? AND monotonic_start_ns<? AND monotonic_end_ns>? ORDER BY asset_id LIMIT 128",(boot_id,last,upper,lower)).fetchall()
                if not batch:break
                for stored in batch:
                    last=stored['asset_id'];asset=json.loads(stored['asset_json']);mapping=_mapping(connection,asset)
                    if mapping['clock_quality'] not in MAPPED_QUALITIES:continue
                    asset.update(mapping)
                    connection.execute('UPDATE assets SET utc_start_ns=?,utc_end_ns=?,clock_quality=?,asset_json=? WHERE asset_id=?',
                        (asset['utc_start_ns'],asset['utc_end_ns'],asset['clock_quality'],_json(asset),last));updated+=1
    return dict(updated=updated)


def lookup_by_id(db,asset_id):
    if not isinstance(asset_id,str) or not ID.fullmatch(asset_id):return None
    with _connect(db) as connection:
        if connection is None:return None
        row=connection.execute('SELECT asset_json FROM assets WHERE asset_id=?',(asset_id,)).fetchone()
        return None if row is None else json.loads(row[0])


def query_assets(db,*,start_utc_ns=None,end_utc_ns=None,include_unknown=False,limit=100,offset=0,legacy_assets=(),order='asc'):
    """Bounded chronological/session/segment pages, optionally merging old catalogs.

    Offset is a position in the current result set, not a frozen snapshot;
    publishing/backfilling during navigation may move rows. asset_id lets the
    browser deduplicate repeated rows. Refresh restarts from page zero.
    """
    if type(limit) is not int or not 1<=limit<=MAX_PAGE:raise ValueError('page limit must be1..200')
    _int(offset,'offset')
    for v,n in ((start_utc_ns,'start UTC'),(end_utc_ns,'end UTC')):_int(v,n,nullable=True)
    if start_utc_ns is not None and end_utc_ns is not None and start_utc_ns>=end_utc_ns:raise ValueError('empty/reversed UTC interval')
    if type(include_unknown) is not bool:raise ValueError('include_unknown must be bool')
    if order not in ('asc','desc'):raise ValueError('explicit asc/desc order required')
    # TEMP legacy rows are bounded by the existing catalog loader's16MiB.
    # SQL merges/pages them without reading the unbounded live table into RAM.
    with _connect(db) as stored:
        connection=stored or sqlite3.connect(':memory:')
        try:
            connection.execute('CREATE TEMP TABLE legacy (asset_id TEXT PRIMARY KEY,utc_start_ns INTEGER,utc_end_ns INTEGER,recording_id TEXT,relative_path TEXT,asset_json TEXT)')
            for row in legacy_assets:
                if row.get('available') and row.get('state')=='CLOSED_VERIFIED':
                    if stored and stored.execute('SELECT 1 FROM assets WHERE asset_id=?',(row['asset_id'],)).fetchone():raise ValueError('asset ID collides between catalog and live index')
                    connection.execute('INSERT INTO legacy VALUES (?,?,?,?,?,?)',(row['asset_id'],row.get('utc_start_ns'),row.get('utc_end_ns'),row['recording_id'],row['relative_path'],_json(row)))
            known='utc_start_ns IS NOT NULL AND utc_end_ns IS NOT NULL';parameters=[]
            if start_utc_ns is not None:known+=' AND utc_end_ns>?';parameters.append(start_utc_ns)
            if end_utc_ns is not None:known+=' AND utc_start_ns<?';parameters.append(end_utc_ns)
            where='('+known+')'
            if include_unknown and start_utc_ns is None and end_utc_ns is None:where+=' OR utc_start_ns IS NULL OR utc_end_ns IS NULL'
            columns='asset_id,utc_start_ns,utc_end_ns,recording_id,relative_path,asset_json'
            union='SELECT '+columns+' FROM legacy'
            if stored:union+=' UNION ALL SELECT '+columns+' FROM assets'
            ordering=('utc_start_ns IS NULL,utc_start_ns,recording_id,length(relative_path),relative_path,asset_id'
                      if order=='asc' else 'utc_start_ns IS NULL,utc_start_ns DESC,recording_id,length(relative_path) DESC,relative_path DESC,asset_id')
            values=connection.execute('SELECT asset_json FROM ('+union+') WHERE '+where+' ORDER BY '+ordering+' LIMIT ? OFFSET ?',parameters+[limit+1,offset]).fetchall()
            more=len(values)>limit
            return dict(assets=[json.loads(row[0]) for row in values[:limit]],has_more=more,next_offset=offset+limit if more else None)
        finally:
            if stored is None:connection.close()
