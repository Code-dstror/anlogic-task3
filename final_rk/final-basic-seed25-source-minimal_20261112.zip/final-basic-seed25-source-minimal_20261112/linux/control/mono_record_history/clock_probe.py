"""Read-only bounded NTP cross-check. No clock setting, RTC writes or service changes."""
import multiprocessing
import ipaddress
import json
import os
from pathlib import Path
import secrets
import socket
import struct
import subprocess
import time
from .clock_ledger import qualify_sample,build_segments,NS

NTP_EPOCH=2208988800
DEFAULT_SERVERS=('time.cloudflare.com','0.pool.ntp.org')


def timestamp(raw):
    sec,fraction=struct.unpack('!II',raw)
    value=(sec-NTP_EPOCH)*NS+(fraction*NS)//2**32
    if not 946684800*NS <= value < 2085978496*NS:
        raise ValueError('NTP era0 timestamp outside supported 2000..2036 interval')
    return value


def parse_response(data,nonce,mono_before,mono_after,wall_before,wall_after,peer_ip):
    if len(data)!=48 or data[24:32]!=nonce or (data[0]&7)!=4 or ((data[0]>>3)&7) not in (3,4) or data[0]>>6==3 or not 1<=data[1]<=15:
        raise ValueError('unmatched, unsynchronized or unsupported NTP reply')
    rtt=mono_after-mono_before
    if not 0<rtt<=3*NS or abs((wall_after-wall_before)-rtt)>250_000_000:
        raise ValueError('invalid elapsed time or local clock stepped during probe')
    received,transmitted=timestamp(data[32:40]),timestamp(data[40:48]);processing=transmitted-received
    if processing<0 or processing>rtt:raise ValueError('invalid server turnaround')
    root_delay=struct.unpack('!i',data[4:8])[0]*NS//65536
    dispersion=struct.unpack('!I',data[8:12])[0]*NS//65536
    uncertainty=(rtt-processing)//2+max(0,root_delay)//2+dispersion+1_000_000
    if uncertainty>NS:raise ValueError('NTP error bound exceeds one second')
    return dict(valid=True,peer_ip=peer_ip,stratum=data[1],monotonic_ns=(mono_before+mono_after)//2,
                utc_ns=(received+transmitted)//2,uncertainty_ns=uncertainty,rtt_ns=rtt,
                wall_midpoint_ns=(wall_before+wall_after)//2,authenticated=False)


def select_peer_address(answers,exclude_peer_ips=()):
    """Select an actual resolved IPv4 endpoint, never independent DNS labels."""
    if type(exclude_peer_ips) not in (tuple,list,set,frozenset) or len(exclude_peer_ips)>64:
        raise ValueError('bounded excluded peer IP collection required')
    excluded={str(ipaddress.IPv4Address(value)) for value in exclude_peer_ips}
    for info in answers:
        if info[0]!=socket.AF_INET or info[1]!=socket.SOCK_DGRAM:continue
        actual=str(ipaddress.IPv4Address(info[4][0]))
        if actual not in excluded:return info
    raise ValueError('no independent resolved IPv4 peer candidate')


def probe(server,*,exclude_peer_ips=(),timeout_s=3):
    try:
        if type(timeout_s) not in (int,float) or not 0<timeout_s<=3:raise ValueError('bounded UDP timeout required')
        info=select_peer_address(socket.getaddrinfo(server,123,socket.AF_INET,socket.SOCK_DGRAM),exclude_peer_ips)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout_s);sock.connect(info[4]);nonce=secrets.token_bytes(8)
            peer_ip=str(ipaddress.IPv4Address(sock.getpeername()[0]))
            if peer_ip in {str(ipaddress.IPv4Address(value)) for value in exclude_peer_ips}:
                raise ValueError('connected peer is not independent')
            request=bytes([0x23])+bytes(39)+nonce
            m1=time.monotonic_ns();w1=time.time_ns();sock.send(request);data=sock.recv(512);w4=time.time_ns();m4=time.monotonic_ns()
            result=parse_response(data,nonce,m1,m4,w1,w4,peer_ip)
        return dict(result,server=server)
    except (OSError,ValueError) as exc:return dict(valid=False,server=server,error=type(exc).__name__+': '+str(exc))


def _worker(server,connection,exclude_peer_ips=(),timeout_s=3):
    try:connection.send(probe(server,exclude_peer_ips=exclude_peer_ips,timeout_s=timeout_s))
    finally:connection.close()


def ntpq_peer_candidates(text,exclude_peer_ips=()):
    """Only discover associated global IPv4 endpoints; never import NTP times.

    Selection markers and numeric remote addresses are the only authority
    taken from ntpq. Delay/offset/jitter/stratum/time columns are deliberately
    unused; every selected address still needs a fresh validated UDP response.
    """
    if type(text) is not str or len(text.encode('utf-8'))>65536:raise ValueError('bounded ntpq output required')
    excluded={str(ipaddress.IPv4Address(value)) for value in exclude_peer_ips}
    rows=[];seen=set(excluded)
    for line in text.splitlines()[:256]:
        value=line.lstrip()
        if not value or value[0] not in ('*','+'):continue
        fields=value[1:].split()
        if len(fields)<10:continue
        try:peer=ipaddress.IPv4Address(fields[0])
        except ipaddress.AddressValueError:continue
        if (not peer.is_global or peer.is_multicast or peer.is_reserved or
                peer.is_loopback or peer.is_link_local or peer.is_unspecified):continue
        address=str(peer)
        if address in seen:
            if value[0]=='*':
                for existing in rows:
                    if existing['peer_ip']==address:existing['selection']='*'
            continue
        seen.add(address);rows.append(dict(peer_ip=address,selection=value[0]))
    rows.sort(key=lambda row:row['selection']!='*')
    return rows


def discover_associated_peers(deadline,exclude_peer_ips=()):
    """Read-only bounded daemon query, used solely as a candidate address list."""
    remaining=deadline-time.monotonic()
    audit=dict(source='ntpq -pn association discovery only; not time verification',
               excluded_peer_ips=sorted(exclude_peer_ips),network_deadline=deadline)
    if remaining<=0:return [],dict(audit,error='no original network deadline remains')
    timeout=min(.5,remaining)
    try:
        result=subprocess.run(['ntpq','-pn'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',timeout=timeout,
            close_fds=True)
        audit['returncode']=result.returncode
        if result.returncode:raise ValueError('ntpq association query failed')
        candidates=ntpq_peer_candidates(result.stdout,exclude_peer_ips)
        # Preserve an auditable output identity without confusing daemon
        # offset/time fields with a fresh external cross-check.
        import hashlib
        return candidates,dict(audit,timeout_s=timeout,output_sha256=hashlib.sha256(result.stdout.encode()).hexdigest(),
                               candidate_peers=candidates)
    except (OSError,ValueError,subprocess.TimeoutExpired) as error:
        return [],dict(audit,timeout_s=timeout,error=type(error).__name__+': '+str(error)[:200])


def _associated_fallback(results,servers,context,jobs,deadline,receive):
    used=set();missing=[]
    for index,row in enumerate(results):
        try:peer=str(ipaddress.IPv4Address(row.get('peer_ip'))) if row.get('valid') is True else None
        except (ipaddress.AddressValueError,TypeError):peer=None
        if peer is None or peer in used:missing.append(index)
        else:used.add(peer)
    if not missing:return results
    candidates,audit=discover_associated_peers(deadline,used)
    retry=[]
    for index,candidate in zip(missing,candidates):
        remaining=deadline-time.monotonic()
        if remaining<=0:break
        peer=candidate['peer_ip'];parent,child=context.Pipe(duplex=False)
        process=context.Process(target=_worker,args=(peer,child,tuple(sorted(used)),min(3,remaining)))
        process.start();child.close();jobs.append((peer,parent,process));retry.append((index,candidate,parent))
        used.add(peer)
    retried=set()
    for index,candidate,parent in retry:
        previous=results[index];peer=candidate['peer_ip'];value=receive(peer,parent)
        if value.get('valid') is True and value.get('peer_ip')!=peer:
            value=dict(value,valid=False,error='associated peer response identity differs')
        results[index]=dict(value,configured_server=servers[index],previous_configured_attempt=previous,
            fallback_source=dict(audit,selected_peer=peer,selection=candidate['selection'],
                                 verification='fresh probe()/parse_response(), never ntpq time/offset'))
        retried.add(index)
    for index in missing:
        if index not in retried:
            results[index]=dict(results[index],configured_server=servers[index],fallback_source=audit)
    return results


def bounded_probes(servers):
    # DNS as well as UDP must be bounded. Only these disposable network workers
    # can be terminated on timeout; they never own recording or hardware FDs.
    context=multiprocessing.get_context('spawn');jobs=[];deadline=time.monotonic()+8
    try:
        for server in servers:
            parent,child=context.Pipe(duplex=False)
            process=context.Process(target=_worker,args=(server,child));process.start();child.close()
            jobs.append((server,parent,process))
        def receive(server,parent):
            try:
                value=parent.recv() if parent.poll(max(0,deadline-time.monotonic())) else dict(valid=False,server=server,error='DNS/UDP timeout')
            except EOFError:value=dict(valid=False,server=server,error='network worker exited')
            return value
        results=[receive(server,parent) for server,parent,process in jobs]
        if (len(results)==2 and all(row.get('valid') is True for row in results)
                and results[0].get('peer_ip')==results[1].get('peer_ip')):
            duplicate=results[1];peer=results[0].get('peer_ip')
            remaining=deadline-time.monotonic()
            if peer is not None and remaining>0:
                # A single independent selection attempt uses ONLY remaining
                # time from the original8s DNS+UDP deadline. Never turn two
                # labels for one IP into two independent references.
                server=servers[1];parent,child=context.Pipe(duplex=False)
                process=context.Process(target=_worker,args=(server,child,(peer,),min(3,remaining)))
                process.start();child.close();jobs.append((server,parent,process))
                replacement=receive(server,parent)
                if replacement.get('valid') is True and replacement.get('peer_ip') in (None,peer):
                    replacement=dict(replacement,valid=False,error='independent peer selection failed')
                results[1]=dict(replacement,previous_duplicate_attempt=duplicate,excluded_peer_ips=[peer])
            else:
                results[1]=dict(duplicate,valid=False,error='duplicate peer; no remaining independent-source deadline')
        # Do not silently replace explicitly configured custom sources. Only
        # the default discovery policy opts into existing ntpd associations.
        if tuple(servers)==DEFAULT_SERVERS:
            results=_associated_fallback(results,servers,context,jobs,deadline,receive)
        return results
    finally:
        for server,parent,process in jobs:
            parent.close();process.join(timeout=.1)
            if process.is_alive():process.terminate();process.join(timeout=1)


def sample(servers=DEFAULT_SERVERS):
    if len(servers)!=2 or len(set(servers))!=2:raise ValueError('exactly two distinct configured server names')
    before=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    probes=bounded_probes(servers)
    mono=time.monotonic_ns();wall=time.time_ns();after=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    if before!=after:raise ValueError('boot changed')
    return qualify_sample(before,mono,wall,probes)


def atomic_write(path,value):
    path=Path(path);temporary=path.with_name(path.name+'.tmp-'+secrets.token_hex(8))
    try:
        with temporary.open('x',encoding='utf-8') as stream:
            json.dump(value,stream,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
        os.replace(temporary,path)
        fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)


def collect(directory,*,servers=DEFAULT_SERVERS,count=1,interval=30):
    if not 1<=count<=4096 or not 1<=interval<=60:raise ValueError('bounded sample count/interval required')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    import fcntl
    with (directory/(boot+'.lock')).open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for index in range(count):
            if index:time.sleep(interval)
            candidates=sorted(directory.glob(boot+'-[0-9][0-9][0-9][0-9].json'))
            path=candidates[-1] if candidates else directory/(boot+'-0000.json')
            if path.is_symlink() or (path.exists() and path.stat().st_size>4*1024*1024):raise ValueError('clock ledger path/size')
            old=json.loads(path.read_text()) if path.exists() else dict(schema=1,boot_id=boot,samples=[])
            if old.get('boot_id')!=boot:raise ValueError('boot mismatch')
            if len(old['samples'])>=128:
                number=int(path.stem[-4:])+1
                if number>9999:raise ValueError('ledger sequence bound')
                path=directory/(boot+'-'+str(number).zfill(4)+'.json')
                if path.exists():raise ValueError('new ledger path already exists')
                old=dict(schema=1,boot_id=boot,samples=old['samples'][-1:])
            value=sample(servers);old['samples'].append(value);old['segments']=build_segments(old['samples'])
            atomic_write(path,old)
    return path
