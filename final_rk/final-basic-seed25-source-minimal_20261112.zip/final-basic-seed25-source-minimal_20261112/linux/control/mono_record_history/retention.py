"""Reclaim only indexed final-HDMI clips through recoverable deletion jobs.

All publishers and replay readers must hold media_lease(shared) over file
verification plus index commit / lookup plus response respectively. The shared
namespace has256 immutable stripes, coordinated across processes by flock.
Never delete its files while any publisher/reader/retention owner is alive.

Media/sidecar verification and filesystem work occur outside SQLite's short
write transactions. A committed pending job removes availability first; crash
recovery never recreates an asset. Only the two preverified files are removed.
"""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import threading

from .live_index import _connect,_db_path,MEDIA_NAME,TIME_FIELDS,MAX_MEDIA_BYTES

LOW_WATER_BYTES=2*1024**3
TARGET_FREE_BYTES=3*1024**3
STRIPES=256
FORMAT='HEVC_HVC1_FINAL_HDMI_NV12'
MAX_SIDECAR=4*1024**2
SCHEMA=(
 'CREATE TABLE IF NOT EXISTS retention_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS retention_pending (asset_id TEXT PRIMARY KEY,recording_root TEXT NOT NULL,relative_path TEXT NOT NULL,receipt TEXT NOT NULL,last_error TEXT)',
 'CREATE TABLE IF NOT EXISTS retention_audit (sequence INTEGER PRIMARY KEY AUTOINCREMENT,asset_id TEXT NOT NULL,receipt TEXT NOT NULL)',
 'CREATE TABLE IF NOT EXISTS retention_totals (singleton INTEGER PRIMARY KEY CHECK(singleton=1),deleted_clips INTEGER NOT NULL,deleted_bytes INTEGER NOT NULL)',
 'INSERT OR IGNORE INTO retention_totals VALUES (1,0,0)',
 '''CREATE TRIGGER IF NOT EXISTS retention_no_pending_insert BEFORE INSERT ON assets
 WHEN EXISTS(SELECT 1 FROM retention_pending WHERE asset_id=NEW.asset_id OR
 (recording_root=NEW.recording_root AND relative_path=NEW.relative_path))
 BEGIN SELECT RAISE(ABORT,'asset deletion pending'); END''',
)


def _json(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def _identity(st):return dict(dev=st.st_dev,ino=st.st_ino)
def _same(st,expected):return _identity(st)==expected
def _boot():return Path('/proc/sys/kernel/random/boot_id').read_text().strip()


def _real_path(path):
    path=Path(path).absolute()
    if any(p.is_symlink() for p in (path,*path.parents)):raise OSError('symlink path refused: '+str(path))
    return path


def _open_directory(path):
    path=_real_path(path);fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    if not _same(path.stat(),_identity(os.fstat(fd))):
        os.close(fd);raise OSError('directory path changed')
    return fd


def _init_schema(db):
    with _connect(db,write=True) as connection:
        for statement in SCHEMA:connection.execute(statement)


@contextmanager
def _namespace_setup(db):
    """Serialize first-use schema/stripe setup across readers and publishers."""
    db=_db_path(db);path=_real_path(db.parent/'.media-leases-setup.lock')
    fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
    try:
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_size:
            raise OSError('ordinary empty lease setup lock required')
        fcntl.flock(fd,fcntl.LOCK_EX)
        if not _same(path.stat(),_identity(st)):raise OSError('lease setup lock replaced')
        yield
    finally:os.close(fd)


def _namespace(db):
    with _namespace_setup(db):
        return _namespace_locked(db)


def _namespace_locked(db):
    """Pin the lock directory/files; same-boot replacement is an error.

    A new boot has no surviving prior fd holders, so filesystem device-number
    changes across cold boots may safely establish a new identity receipt.
    """
    db=_db_path(db);boot=_boot();expected=None
    def read_receipt():
        with _connect(db) as connection:
            if connection is None:return None
            try:row=connection.execute("SELECT value FROM retention_meta WHERE key='leases'").fetchone()
            except Exception as error:
                if 'no such table: retention_meta' not in str(error):raise
                row=None
            return json.loads(row[0]) if row is not None else None
    try:expected=read_receipt()
    except ValueError as error:
        if str(error)!='unsupported live index schema':raise
        # An independent clock writer may just have created the empty SQLite
        # file. The normal writer admits version0 and waits for its schema
        # transaction; unsupported nonzero versions still fail closed.
        _init_schema(db);expected=read_receipt()
    directory=db.parent/'media-leases'
    if expected is not None and expected['boot']==boot:
        fd=_open_directory(directory)
        if not _same(os.fstat(fd),expected['directory']):os.close(fd);raise OSError('media lease directory replaced')
        return fd,expected
    _init_schema(db)
    directory.mkdir(mode=0o700,exist_ok=True);fd=_open_directory(directory)
    try:
        files=[]
        for stripe in range(STRIPES):
            lock=os.open(f'{stripe:03d}.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600,dir_fd=fd)
            try:
                st=os.fstat(lock)
                if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_size:raise OSError('ordinary empty single-link media lease required')
                files.append(_identity(st))
            finally:os.close(lock)
        current=dict(boot=boot,directory=_identity(os.fstat(fd)),files=files)
        if len({(v['dev'],v['ino']) for v in files})!=STRIPES:raise OSError('media lease stripes alias')
        os.fsync(fd)
        with _connect(db,write=True) as connection:
            row=connection.execute("SELECT value FROM retention_meta WHERE key='leases'").fetchone()
            saved=json.loads(row[0]) if row else None
            if saved is not None and saved['boot']==boot and saved!=current:raise OSError('media lease namespace changed')
            connection.execute("INSERT OR REPLACE INTO retention_meta VALUES ('leases',?)",(_json(current),))
        if not _same(directory.stat(),current['directory']):raise OSError('media lease directory changed during setup')
        return fd,current
    except BaseException:os.close(fd);raise


@contextmanager
def media_lease(db,asset_id,exclusive=False,blocking=True):
    """Shared read/publish lease or exclusive delete lease; yield the held fd.

    An exclusive nonblocking conflict raises BlockingIOError. The caller must
    retain the shared lease until publication or the complete response ends.
    """
    if type(asset_id) is not str or not 1<=len(asset_id)<=128:raise ValueError('bounded asset identity required')
    if type(exclusive) is not bool or type(blocking) is not bool:raise ValueError('explicit lease booleans required')
    directory,expected=_namespace(db);lock=None
    try:
        stripe=int.from_bytes(hashlib.sha256(asset_id.encode()).digest()[:2],'big')%STRIPES
        name=f'{stripe:03d}.lock'
        lock=os.open(name,os.O_RDWR|os.O_NOFOLLOW,dir_fd=directory)
        st=os.fstat(lock)
        if not stat.S_ISREG(st.st_mode) or not _same(st,expected['files'][stripe]):raise OSError('media lease file replaced')
        fcntl.flock(lock,(fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)|(0 if blocking else fcntl.LOCK_NB))
        visible=os.stat(name,dir_fd=directory,follow_symlinks=False)
        if (not _same(visible,expected['files'][stripe]) or
                not _same(_real_path(Path(db).absolute().parent/'media-leases').stat(),expected['directory'])):
            raise OSError('media lease namespace replaced while acquiring')
        yield lock
    finally:
        if lock is not None:os.close(lock)
        os.close(directory)


class RetentionStore:
    def __init__(self,db,mount,*,storage_admitted=False):
        if type(storage_admitted) is not bool:raise ValueError('explicit storage admission required')
        self.db=_db_path(db);self.mount=_real_path(mount);self.recordings=self.mount/'recordings'
        self.boot=_boot();self.storage_admitted=storage_admitted
        self._operation=threading.RLock();self._closed=False;self._last_error=None
        self.mount_fd=_open_directory(self.mount)
        try:
            self.parent_fd=_open_directory(self.recordings)
            self.mount_identity=_identity(os.fstat(self.mount_fd));self.parent_identity=_identity(os.fstat(self.parent_fd))
            if self.mount_identity['dev']!=self.parent_identity['dev']:raise OSError('recordings must be on the admitted SD filesystem')
            _init_schema(self.db);fd,unused=_namespace(self.db);os.close(fd)
            self.db_identity=_identity(self.db.stat())
        except BaseException:
            if hasattr(self,'parent_fd'):os.close(self.parent_fd)
            os.close(self.mount_fd);raise

    def _check(self):
        if self._closed:raise ValueError('retention store is closed')
        for path,identity in ((self.mount,self.mount_identity),(self.recordings,self.parent_identity),(self.db,self.db_identity)):
            if not _same(_real_path(path).stat(),identity):raise OSError('retention storage/index path replaced')

    def free_bytes(self):
        with self._operation:
            self._check();st=os.fstatvfs(self.parent_fd);return st.f_frsize*st.f_bavail

    def _scope(self,asset):
        if (type(asset) is not dict or type(asset.get('metadata')) is not dict or
                type(asset.get('recording_root')) is not str):return False
        root=Path(asset.get('recording_root',''))
        return (asset.get('available') is True and asset.get('state')=='CLOSED_VERIFIED' and
            asset.get('metadata',{}).get('format')==FORMAT and root.parent==self.recordings and
            re.fullmatch(r'mono-final-[A-Za-z0-9_-]{1,128}',root.name) is not None and
            asset.get('recording_id')==root.name and isinstance(asset.get('relative_path'),str) and
            MEDIA_NAME.fullmatch(asset['relative_path']) is not None)

    def _root(self,root,expected=None):
        root=Path(root)
        if root.parent!=self.recordings or not re.fullmatch(r'mono-final-[A-Za-z0-9_-]{1,128}',root.name):raise OSError('recording root outside retention scope')
        fd=os.open(root.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=self.parent_fd)
        identity=_identity(os.fstat(fd))
        if identity['dev']!=self.parent_identity['dev'] or expected is not None and identity!=expected:
            os.close(fd);raise OSError('recording directory replaced or filesystem changed')
        visible=os.stat(root.name,dir_fd=self.parent_fd,follow_symlinks=False)
        if not stat.S_ISDIR(visible.st_mode) or not _same(visible,identity):os.close(fd);raise OSError('recording directory path changed')
        return fd,identity

    def _file(self,directory,name,limit,*,missing=False):
        try:fd=os.open(name,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW,dir_fd=directory)
        except FileNotFoundError:
            if missing:return None
            raise
        try:
            before=os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or not 0<before.st_size<=limit:
                raise OSError('ordinary bounded single-link retention file required')
            if before.st_dev!=self.parent_identity['dev']:raise OSError('file is on another filesystem')
            digest=hashlib.sha256();chunks=[]
            with os.fdopen(fd,'rb',closefd=False) as stream:
                for chunk in iter(lambda:stream.read(65536),b''):digest.update(chunk);chunks.append(chunk)
            after=os.fstat(fd);visible=os.stat(name,dir_fd=directory,follow_symlinks=False)
            if ((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=
                    (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) or
                    not stat.S_ISREG(visible.st_mode) or not _same(visible,_identity(before))):
                raise OSError('file changed during verification')
            return dict(name=name,**_identity(before),bytes=before.st_size,sha256=digest.hexdigest()),b''.join(chunks)
        finally:os.close(fd)

    def _validate(self,stored):
        asset=json.loads(stored['asset_json'])
        if not self._scope(asset):raise ValueError('not a managed final-HDMI clip')
        directory,root_identity=self._root(asset['recording_root'])
        try:
            media,unused=self._file(directory,asset['relative_path'],MAX_MEDIA_BYTES)
            if media['bytes']!=asset['bytes'] or media['sha256']!=asset['sha256']:raise ValueError('indexed media size/SHA differs')
            sidecar,body=self._file(directory,Path(asset['relative_path']).with_suffix('.json').name,MAX_SIDECAR)
            data=json.loads(body);original=dict(data['asset'])
            for name in TIME_FIELDS:original.pop(name,None)
            if type(data.get('schema')) is not int or data['schema']!=1 or original!=json.loads(stored['identity_json']):raise ValueError('sidecar asset identity differs')
            count=asset['metadata']['sample_count'];encoded=data['encoded'];pts=data['mp4_pts']
            if (type(count) is not int or not 1<=count<=16384 or not isinstance(encoded,list) or
                    len(encoded)!=count or not isinstance(pts,list) or len(pts)!=count or
                    type(data['mp4_timescale']) is not int or data['mp4_timescale']<=0):raise ValueError('sidecar AU/sample evidence differs')
            if any(type(p) is not int or p<0 for p in pts) or any(b<=a for a,b in zip(pts,pts[1:])):raise ValueError('sidecar MP4 PTS differs')
            total=0;previous=None
            for row in encoded:
                if row.get('kind')!=3 or any(type(row.get(k)) is not int or row[k]<0 for k in ('ordinal','pts','monotonic','size')) or not row['ordinal'] or not row['size']:
                    raise ValueError('sidecar encoded AU identity invalid')
                if previous and (row['ordinal']!=previous['ordinal']+1 or row['pts']<=previous['pts'] or row['monotonic']<=previous['monotonic']):raise ValueError('sidecar AU order differs')
                total+=row['size'];previous=row
            if total>media['bytes'] or encoded[0]['monotonic']!=asset['monotonic_start_ns']:raise ValueError('sidecar AU/media extent differs')
            return dict(schema=1,asset_id=asset['asset_id'],asset=asset,identity_json=stored['identity_json'],
                original_rowid=stored['original_rowid'],mount=self.mount_identity,recordings=self.parent_identity,
                root=root_identity,files=[media,sidecar],deleted_bytes=media['bytes']+sidecar['bytes'],
                origin_boot=self.boot,verified_boot=self.boot)
        finally:os.close(directory)

    def _checkpoint(self,stage,receipt):pass # Fault-injection seam; no production IO.

    def _mark_pending(self,receipt):
        asset=receipt['asset']
        with _connect(self.db,write=True) as connection:
            current=connection.execute('SELECT rowid AS original_rowid,identity_json,asset_json FROM assets WHERE asset_id=?',(asset['asset_id'],)).fetchone()
            if current is None:return False
            if current['original_rowid']!=receipt['original_rowid'] or current['identity_json']!=receipt['identity_json']:raise ValueError('candidate index identity changed')
            receipt['asset']=json.loads(current['asset_json']) # May contain newer qualified UTC.
            connection.execute('INSERT INTO retention_pending VALUES (?,?,?,?,NULL)',
                (asset['asset_id'],asset['recording_root'],asset['relative_path'],_json(receipt)))
            self._checkpoint('pending_inserted',receipt)
            connection.execute('DELETE FROM assets WHERE asset_id=?',(asset['asset_id'],))
            self._checkpoint('index_removed',receipt)
        self._checkpoint('pending_committed',receipt);return True

    def _validate_receipt(self,receipt):
        if type(receipt) is not dict:raise ValueError('pending receipt object required')
        asset=receipt.get('asset',{})
        if type(asset) is not dict or type(receipt.get('schema')) is not int or receipt['schema']!=1 or not self._scope(asset) or receipt.get('asset_id')!=asset.get('asset_id'):
            raise ValueError('pending asset outside retention scope')
        names=[asset['relative_path'],Path(asset['relative_path']).with_suffix('.json').name]
        files=receipt.get('files')
        if not isinstance(files,list) or len(files)!=2 or any(type(v) is not dict for v in files) or [v.get('name') for v in files]!=names:
            raise ValueError('pending file names differ from verified pair')
        for value in files:
            if (any(type(value.get(k)) is not int or value[k]<0 for k in ('dev','ino','bytes')) or
                    not value['bytes'] or not isinstance(value.get('sha256'),str) or
                    not re.fullmatch('[0-9a-f]{64}',value['sha256'])):raise ValueError('pending file receipt invalid')
        if receipt.get('deleted_bytes')!=sum(v['bytes'] for v in files):raise ValueError('pending byte receipt differs')
        if (files[0]['bytes']!=asset.get('bytes') or files[0]['sha256']!=asset.get('sha256') or
                files[0]['bytes']>MAX_MEDIA_BYTES or files[1]['bytes']>MAX_SIDECAR):raise ValueError('pending file receipt differs from indexed media')
        for key in ('mount','recordings','root'):
            value=receipt.get(key)
            if type(value) is not dict or set(value)!= {'dev','ino'} or any(type(v) is not int or v<0 for v in value.values()):
                raise ValueError('pending directory identity invalid')
        original=dict(asset)
        for name in TIME_FIELDS:original.pop(name,None)
        if original!=json.loads(receipt['identity_json']):raise ValueError('pending immutable asset identity differs')
        for key in ('origin_boot','verified_boot'):
            if not isinstance(receipt.get(key),str) or not 1<=len(receipt[key])<=128:raise ValueError('pending boot identity invalid')
        missing=receipt.get('recovery_missing_files',[])
        if type(missing) is not list or len(missing)>2 or any(name not in names for name in missing):
            raise ValueError('pending missing-file receipt differs')

    def _repin(self,receipt):
        """VFAT inode numbers may change across mounts. Reverify content only
        after the caller has independently admitted this SD by UUID and CID.
        Same-boot identity checks remain strict; origin_boot is never lost.
        """
        if not self.storage_admitted:raise OSError('cross-boot recovery requires fresh same-SD UUID/CID admission')
        updated=json.loads(_json(receipt));missing=[]
        updated.pop('recovery_root_missing',None)
        try:directory,identity=self._root(receipt['asset']['recording_root'])
        except FileNotFoundError:
            directory=None;identity=receipt['root'];updated['recovery_root_missing']=True
            missing=[row['name'] for row in receipt['files']]
        if directory is not None:
            try:
                files=[]
                for expected in receipt['files']:
                    found=self._file(directory,expected['name'],MAX_SIDECAR if expected['name'].endswith('.json') else MAX_MEDIA_BYTES,missing=True)
                    if found is None:missing.append(expected['name']);files.append(expected)
                    else:
                        actual=found[0]
                        if (actual['name'],actual['bytes'],actual['sha256'])!=(expected['name'],expected['bytes'],expected['sha256']):
                            raise OSError('cross-boot pending content differs')
                        files.append(actual)
                updated['files']=files
            finally:os.close(directory)
        self._check()
        updated.update(mount=self.mount_identity,recordings=self.parent_identity,root=identity,
            verified_boot=self.boot,recovery_missing_files=missing)
        with _connect(self.db,write=True) as connection:
            current=connection.execute('SELECT receipt FROM retention_pending WHERE asset_id=?',(receipt['asset_id'],)).fetchone()
            if current is None:return None
            if json.loads(current[0])!=receipt:raise ValueError('pending receipt changed during cross-boot verification')
            connection.execute('UPDATE retention_pending SET receipt=?,last_error=NULL WHERE asset_id=?',(_json(updated),receipt['asset_id']))
        self._checkpoint('repinned',updated)
        return updated

    def _delete_pending(self,receipt):
        self._check();self._validate_receipt(receipt)
        with _connect(self.db) as connection:
            active=connection.execute('SELECT receipt FROM retention_pending WHERE asset_id=?',(receipt['asset_id'],)).fetchone()
        if active is None:return False
        if json.loads(active[0])!=receipt:raise ValueError('pending receipt changed before filesystem work')
        if receipt['verified_boot']!=self.boot:
            receipt=self._repin(receipt)
            if receipt is None:return False
        if receipt['mount']!=self.mount_identity or receipt['recordings']!=self.parent_identity:
            raise OSError('pending job belongs to another storage identity')
        root=receipt['asset']['recording_root']
        if receipt.get('recovery_root_missing'):
            try:os.stat(Path(root).name,dir_fd=self.parent_fd,follow_symlinks=False)
            except FileNotFoundError:
                os.fsync(self.parent_fd);return self._finish_job(receipt)
            raise OSError('pending directory reappeared after recovery verification')
        try:directory,unused=self._root(root,receipt['root'])
        except FileNotFoundError:
            os.fsync(self.parent_fd)
            return self._finish_job(receipt)
        try:
            # Check all remaining files before touching either. Missing files
            # are allowed ONLY because this committed receipt verified them.
            for expected in receipt['files']:
                value=self._file(directory,expected['name'],MAX_SIDECAR if expected['name'].endswith('.json') else MAX_MEDIA_BYTES,missing=True)
                if value is not None and expected['name'] in receipt.get('recovery_missing_files',[]):
                    raise OSError('file appeared after missing-file recovery verification')
                if value is not None and value[0]!=expected:raise OSError('pending file replaced or SHA changed')
            for index,expected in enumerate(receipt['files']):
                self._check()
                visible=os.stat(Path(root).name,dir_fd=self.parent_fd,follow_symlinks=False)
                if not stat.S_ISDIR(visible.st_mode) or not _same(visible,receipt['root']):raise OSError('pending directory replaced')
                try:st=os.stat(expected['name'],dir_fd=directory,follow_symlinks=False)
                except FileNotFoundError:continue
                if not stat.S_ISREG(st.st_mode) or not _same(st,dict(dev=expected['dev'],ino=expected['ino'])) or st.st_size!=expected['bytes']:
                    raise OSError('pending unlink identity differs')
                os.unlink(expected['name'],dir_fd=directory)
                self._checkpoint('media_unlinked' if index==0 else 'sidecar_unlinked',receipt)
            os.fsync(directory);self._checkpoint('directory_synced',receipt)
        finally:os.close(directory)
        return self._finish_job(receipt)

    def _finish_job(self,receipt):
        with _connect(self.db,write=True) as connection:
            job=connection.execute('SELECT receipt FROM retention_pending WHERE asset_id=?',(receipt['asset_id'],)).fetchone()
            if job is None:return False # A prior recovery already committed completion.
            if json.loads(job[0])!=receipt:raise ValueError('pending receipt changed')
            row=connection.execute('SELECT identity_json FROM assets WHERE asset_id=?',(receipt['asset_id'],)).fetchone()
            if row is not None and row[0]!=receipt['identity_json']:raise ValueError('different asset appeared during retention')
            connection.execute('DELETE FROM assets WHERE asset_id=?',(receipt['asset_id'],))
            connection.execute('INSERT INTO retention_audit(asset_id,receipt) VALUES (?,?)',(receipt['asset_id'],_json(receipt)))
            connection.execute('DELETE FROM retention_audit WHERE sequence NOT IN (SELECT sequence FROM retention_audit ORDER BY sequence DESC LIMIT 128)')
            connection.execute('UPDATE retention_totals SET deleted_clips=deleted_clips+1,deleted_bytes=deleted_bytes+? WHERE singleton=1',(receipt['deleted_bytes'],))
            connection.execute('DELETE FROM retention_pending WHERE asset_id=?',(receipt['asset_id'],))
        self._checkpoint('completed',receipt)
        return True

    def _candidates(self):
        last=0;prefix=str(self.recordings/'mono-final-')
        while True:
            with _connect(self.db) as connection:
                rows=connection.execute('SELECT rowid AS original_rowid,* FROM assets WHERE rowid>? AND substr(recording_root,1,?)=? AND instr(asset_json,?)>0 ORDER BY rowid LIMIT 128',
                    (last,len(prefix),prefix,'"format":"'+FORMAT+'"')).fetchall()
            if not rows:return
            for row in rows:last=row['original_rowid'];yield row

    def _error(self,error):self._last_error=str(error)[:512]

    def reclaim_one(self,stop_event=None):
        with self._operation:
            self._check();busy=skipped=0
            for stored in self._candidates():
                if stop_event is not None and stop_event.is_set():break
                try:
                    with media_lease(self.db,stored['asset_id'],exclusive=True,blocking=False):
                        self._check();receipt=self._validate(stored);self._checkpoint('validated',receipt)
                        if not self._mark_pending(receipt):continue
                        self._delete_pending(receipt)
                        return dict(deleted_clips=1,deleted_bytes=receipt['deleted_bytes'],busy=busy,skipped=skipped,asset_id=receipt['asset_id'])
                except BlockingIOError:busy+=1
                except (OSError,ValueError,KeyError,TypeError) as error:self._error(error);skipped+=1
            return dict(deleted_clips=0,deleted_bytes=0,busy=busy,skipped=skipped)

    def recover_pending(self,max_items=8,stop_event=None):
        if type(max_items) is not int or max_items<0:raise ValueError('nonnegative job budget required')
        totals=dict(deleted_clips=0,deleted_bytes=0,busy=0,skipped=0)
        with self._operation:
            self._check()
            with _connect(self.db) as connection:jobs=connection.execute('SELECT receipt FROM retention_pending ORDER BY rowid LIMIT ?',(max_items,)).fetchall()
            for job in jobs:
                if stop_event is not None and stop_event.is_set():break
                receipt=json.loads(job[0])
                try:
                    with media_lease(self.db,receipt['asset_id'],exclusive=True,blocking=False):
                        if self._delete_pending(receipt):
                            totals['deleted_clips']+=1;totals['deleted_bytes']+=receipt['deleted_bytes']
                except BlockingIOError:totals['busy']+=1
                except (OSError,ValueError,KeyError,TypeError) as error:
                    self._error(error);totals['skipped']+=1
                    with _connect(self.db,write=True) as connection:connection.execute('UPDATE retention_pending SET last_error=? WHERE asset_id=?',(self._last_error,receipt['asset_id']))
        return dict(totals,free_bytes=self.free_bytes(),pending=self.snapshot()['pending'])

    def reclaim(self,target_free_bytes,max_items=8,stop_event=None):
        if type(target_free_bytes) is not int or target_free_bytes<0 or type(max_items) is not int or max_items<0:raise ValueError('nonnegative target/job budget required')
        totals=dict(deleted_clips=0,deleted_bytes=0,busy=0,skipped=0)
        # Recovery has priority over selecting new assets; it cannot resurrect
        # visibility even when capacity is already above the target.
        with self._operation:
            recovered=self.recover_pending(max_items=max_items,stop_event=stop_event)
            for key in totals:totals[key]+=recovered[key]
            remaining=max_items-totals['deleted_clips']-totals['busy']-totals['skipped']
            for unused in range(max(0,remaining)):
                if stop_event is not None and stop_event.is_set() or self.free_bytes()>=target_free_bytes:break
                result=self.reclaim_one(stop_event=stop_event)
                for key in totals:totals[key]+=result[key]
                if not result['deleted_clips']:break
            free=self.free_bytes()
            return dict(totals,free_bytes=free,reached_target=free>=target_free_bytes,pending=self.snapshot()['pending'])

    def snapshot(self):
        with _connect(self.db) as connection:
            values=connection.execute('SELECT deleted_clips,deleted_bytes FROM retention_totals WHERE singleton=1').fetchone()
            pending=connection.execute('SELECT count(*) FROM retention_pending').fetchone()[0]
            audit=connection.execute('SELECT count(*) FROM retention_audit').fetchone()[0]
        return dict(deleted_clips=values[0],deleted_bytes=values[1],pending=pending,audit_entries=audit,
                    last_error=self._last_error,closed=self._closed,byte_scope='VERIFIED_MEDIA_PLUS_SIDECAR_LOGICAL_BYTES_NOT_FILESYSTEM_BLOCKS')

    def close(self):
        with self._operation:
            if self._closed:return
            self._closed=True;os.close(self.parent_fd);os.close(self.mount_fd)

    def __enter__(self):return self

    def __exit__(self,*unused):self.close()
