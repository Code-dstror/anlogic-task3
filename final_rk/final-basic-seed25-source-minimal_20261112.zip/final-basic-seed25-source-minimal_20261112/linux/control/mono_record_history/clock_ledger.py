"""Bounded UTC evidence intervals. Never set a clock or extrapolate old footage.

A NETWORK_VERIFIED sample requires two distinct NTP peers, agreement, bounded
uncertainty and agreement with local CLOCK_REALTIME. NTP here is not authenticated.
Only adjacent good samples form coverage; an invalid sample breaks continuity.
"""
import hashlib
import json

NS = 1_000_000_000
MAX_GAP_NS = 90 * NS
MAX_UNCERTAINTY_NS = NS
MAPPED_QUALITIES = ('NETWORK_VERIFIED', 'NETWORK_ANCHORED', 'LOCAL_UNVERIFIED')


def local_sample(boot_id, monotonic_ns, realtime_ns, *, operator_confirmed):
    """Map operator-approved local wall time without claiming external accuracy."""
    if (not isinstance(boot_id, str) or not boot_id or operator_confirmed is not True
            or any(type(v) is not int or v <= 0 for v in (monotonic_ns, realtime_ns))):
        raise ValueError('explicit operator-approved local clock required')
    return dict(boot_id=boot_id, monotonic_ns=monotonic_ns, realtime_ns=realtime_ns,
        utc_ns=realtime_ns, uncertainty_ns=0, valid=True, clock_quality='LOCAL_UNVERIFIED',
        operator_confirmed=True, absolute_accuracy='UNKNOWN',
        semantics='RK wall time confirmed by operator; not network/RTC accuracy verification')


def anchored_sample(reference, monotonic_ns, *, observed_realtime_ns):
    """Project a fresh initial NTP reference on monotonic time, clearly labelled.

    Later WAN outages do not erase recording dates. This is deliberately not
    NETWORK_VERIFIED: oscillator drift after the initial check is unverified.
    """
    if not isinstance(reference,dict):raise ValueError('initial network reference required')
    verified=qualify_sample(reference['boot_id'],reference['monotonic_ns'],
                            reference['realtime_ns'],reference['probes'])
    if not verified['valid'] or verified['utc_ns']!=reference.get('utc_ns'):
        raise ValueError('initial NTP reference did not independently qualify')
    delta=monotonic_ns-reference['monotonic_ns']
    if type(monotonic_ns) is not int or delta<0:raise ValueError('same-boot monotonic clock required')
    projected=reference['utc_ns']+delta
    return dict(boot_id=reference['boot_id'],monotonic_ns=monotonic_ns,realtime_ns=projected,
        observed_realtime_ns=observed_realtime_ns,utc_ns=projected,valid=True,
        uncertainty_ns=verified['uncertainty_ns'],clock_quality='NETWORK_ANCHORED',initial_network_reference=reference,
        absolute_accuracy='INITIAL_REFERENCE_ONLY_SUBSEQUENT_DRIFT_UNVERIFIED',
        semantics='Initial two-peer NTP time plus continuous CLOCK_MONOTONIC; ignores later wall-clock steps')


def qualify_sample(boot_id, monotonic_ns, realtime_ns, probes):
    if not isinstance(boot_id, str) or not boot_id or any(type(v) is not int or v <= 0 for v in (monotonic_ns, realtime_ns)):
        raise ValueError('boot and positive integer clock pair required')
    row = dict(boot_id=boot_id, monotonic_ns=monotonic_ns, realtime_ns=realtime_ns,
               valid=False, clock_quality='UNKNOWN', probes=probes,
               semantics='NTP cross-check, not cryptographic authentication or sensor exposure time')
    if len(probes) != 2 or len({p.get('peer_ip') for p in probes}) != 2:
        return dict(row, reason='two distinct responding NTP peer IPs required')
    estimates, errors = [], []
    for p in probes:
        if not p.get('valid') or any(type(p.get(k)) is not int for k in ('monotonic_ns','utc_ns','uncertainty_ns')):
            return dict(row, reason='invalid NTP probe')
        age = monotonic_ns-p['monotonic_ns']
        if not 0 <= age <= 15*NS or not 0 <= p['uncertainty_ns'] <= MAX_UNCERTAINTY_NS:
            return dict(row, reason='stale or uncertain NTP probe')
        estimates.append(p['utc_ns']+age)
        errors.append(p['uncertainty_ns']+age//10000)  # 100 ppm drift allowance
    if abs(estimates[0]-estimates[1]) > 250_000_000:
        return dict(row, reason='NTP peers disagree by more than 250ms')
    utc = sum(estimates)//2
    uncertainty = max(abs(v-utc)+e for v,e in zip(estimates,errors))
    if uncertainty > MAX_UNCERTAINTY_NS or abs(realtime_ns-utc) > uncertainty+250_000_000:
        return dict(row, reason='RK realtime does not match independently checked time',
                    reference_utc_ns=utc, realtime_error_ns=realtime_ns-utc)
    return dict(row, valid=True, clock_quality='NETWORK_VERIFIED', utc_ns=utc,
                uncertainty_ns=uncertainty, realtime_error_ns=realtime_ns-utc)


def build_segments(samples):
    if len(samples) > 4096:
        raise ValueError('one clock ledger limited to 4096 samples; rotate rather than overwrite')
    result, previous = [], None
    for current in samples:
        quality = current.get('clock_quality')
        valid = (current.get('valid') is True and quality in MAPPED_QUALITIES
                 and (quality != 'LOCAL_UNVERIFIED' or current.get('operator_confirmed') is True)
                 and (quality != 'NETWORK_ANCHORED' or isinstance(current.get('initial_network_reference'),dict))
                 and isinstance(current.get('boot_id'),str) and bool(current['boot_id'])
                 and all(type(current.get(k)) is int and current[k] > 0 for k in ('monotonic_ns','realtime_ns','utc_ns'))
                 and type(current.get('uncertainty_ns')) is int and 0 <= current['uncertainty_ns'] <= MAX_UNCERTAINTY_NS)
        if not valid:
            previous = None
            continue
        if (previous and previous['boot_id'] == current['boot_id']
                and previous['clock_quality'] == quality):
            delta = current['monotonic_ns']-previous['monotonic_ns']
            utc_delta = current['utc_ns']-previous['utc_ns']
            wall_delta = current['realtime_ns']-previous['realtime_ns']
            tolerance = previous['uncertainty_ns']+current['uncertainty_ns']+max(delta,0)//10000
            if 0 < delta <= MAX_GAP_NS and utc_delta > 0 and abs(utc_delta-delta) <= tolerance and abs(wall_delta-delta) <= 250_000_000:
                row = dict(boot_id=current['boot_id'], start_monotonic_ns=previous['monotonic_ns'],
                    end_monotonic_ns=current['monotonic_ns'], start_utc_ns=previous['utc_ns'],
                    end_utc_ns=current['utc_ns'], uncertainty_ns=max(previous['uncertainty_ns'],current['uncertainty_ns'])+delta//10000,
                    clock_quality=quality)
                if quality == 'LOCAL_UNVERIFIED':
                    row.update(operator_confirmed=True, absolute_accuracy='UNKNOWN')
                if quality == 'NETWORK_ANCHORED':
                    reference=current['initial_network_reference']
                    if previous.get('initial_network_reference')!=reference or reference.get('boot_id')!=current['boot_id']:continue
                    checked=anchored_sample(reference,current['monotonic_ns'],observed_realtime_ns=current.get('observed_realtime_ns'))
                    if checked['utc_ns']!=current['utc_ns']:continue
                    row.update(initial_network_reference=reference,absolute_accuracy=checked['absolute_accuracy'])
                row['segment_id']=hashlib.sha256(json.dumps(row,sort_keys=True).encode()).hexdigest()
                result.append(row)
        previous = current
    return result


def map_interval(segments, boot_id, start_ns, end_ns):
    unknown = dict(utc_start_ns=None,utc_end_ns=None,clock_quality='UNKNOWN',uncertainty_ns=None,clock_segment_id=None)
    if any(type(v) is not int for v in (start_ns,end_ns)) or start_ns < 0 or end_ns <= start_ns:
        return unknown
    if len(segments)>32768:return unknown
    rows=[]
    for row in segments:
        if row.get('boot_id') != boot_id or row.get('clock_quality') not in MAPPED_QUALITIES:continue
        if row['clock_quality']=='LOCAL_UNVERIFIED' and row.get('operator_confirmed') is not True:return unknown
        if row['clock_quality']=='NETWORK_ANCHORED':
            try:
                reference=row['initial_network_reference']
                if reference.get('boot_id')!=boot_id:return unknown
                a=anchored_sample(reference,row['start_monotonic_ns'],observed_realtime_ns=None)
                b=anchored_sample(reference,row['end_monotonic_ns'],observed_realtime_ns=None)
                if a['utc_ns']!=row['start_utc_ns'] or b['utc_ns']!=row['end_utc_ns']:return unknown
            except (KeyError,TypeError,ValueError):return unknown
        keys=('start_monotonic_ns','end_monotonic_ns','start_utc_ns','end_utc_ns','uncertainty_ns')
        if any(type(row.get(k)) is not int for k in keys):return unknown
        a,b=row['start_monotonic_ns'],row['end_monotonic_ns']
        if not isinstance(row.get('segment_id'),str) or not row['segment_id']:return unknown
        if abs((row['end_utc_ns']-row['start_utc_ns'])-(b-a))>2*row['uncertainty_ns']+max(b-a,0)//10000:return unknown
        if not 0 < b-a <= MAX_GAP_NS or row['end_utc_ns'] <= row['start_utc_ns'] or not 0 <= row['uncertainty_ns'] <= MAX_UNCERTAINTY_NS+MAX_GAP_NS//10000:return unknown
        if a < end_ns and b > start_ns:rows.append(row)
    rows.sort(key=lambda r:r['start_monotonic_ns'])
    cursor=start_ns;selected=[]
    for row in rows:
        a,b=row['start_monotonic_ns'],row['end_monotonic_ns']
        if a > cursor or (selected and a != cursor):return unknown
        if selected and (row['start_utc_ns'] != selected[-1]['end_utc_ns'] or
                row['clock_quality'] != selected[-1]['clock_quality']):return unknown
        cursor=min(end_ns,b);selected.append(row)
    if cursor != end_ns or not selected:return unknown
    def at(row,t):
        return row['start_utc_ns']+(t-row['start_monotonic_ns'])*(row['end_utc_ns']-row['start_utc_ns'])//(row['end_monotonic_ns']-row['start_monotonic_ns'])
    return dict(utc_start_ns=at(selected[0],start_ns),utc_end_ns=at(selected[-1],end_ns),
                clock_quality=selected[0]['clock_quality'],
                uncertainty_ns=(max(r['uncertainty_ns'] for r in selected)
                    if selected[0]['clock_quality']=='NETWORK_VERIFIED' else None),
                clock_segment_id=[r['segment_id'] for r in selected])
