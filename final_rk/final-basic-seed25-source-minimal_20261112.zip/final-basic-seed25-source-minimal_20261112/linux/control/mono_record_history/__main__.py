"""Opt-in offline import, network time evidence and loopback playback commands."""
import argparse
import json
import itertools
from pathlib import Path
import time
from .catalog import build_catalog,write_catalog
from .clock_probe import collect,sample
from .clock_ledger import build_segments,map_interval
from .replay_server import ReplayServer


def load_segments(directory,boot_id=None):
    if directory is None:return []
    files=sorted(itertools.islice(Path(directory).glob((boot_id+'-*.json') if boot_id else '*.json'),257))
    if len(files)>256:raise ValueError('clock input file bound; choose relevant boot files')
    segments=[];seen=set()
    for path in files:
        if path.is_symlink() or path.stat().st_size>4*1024*1024:raise ValueError('clock input bound')
        value=json.loads(path.read_text())
        # Recompute from observed samples, never trust a hand-edited segment list.
        for row in build_segments(value['samples']):
            if row['segment_id'] not in seen:seen.add(row['segment_id']);segments.append(row)
    return segments


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='op',required=True)
    s=sub.add_parser('probe');s.add_argument('--clock-dir',type=Path,required=True);s.add_argument('--count',type=int,default=1);s.add_argument('--interval',type=int,default=30);s.add_argument('--live-index',type=Path)
    s=sub.add_parser('index');s.add_argument('--recording',type=Path,required=True);s.add_argument('--trial',type=Path,required=True);s.add_argument('--clock-dir',type=Path);s.add_argument('--output',type=Path,required=True)
    s=sub.add_parser('ready');s.add_argument('--clock-dir',type=Path,required=True)
    s=sub.add_parser('serve');s.add_argument('--catalog',type=Path);s.add_argument('--live-index',type=Path);s.add_argument('--port',type=int,default=8765);s.add_argument('--bytes-per-second',type=int,default=1500000);s.add_argument('--algorithm-control',action='store_true')
    args=p.parse_args()
    if args.op=='probe':
        path=collect(args.clock_dir,count=args.count,interval=args.interval)
        if args.live_index is not None:
            from .live_clock_sync import sync_ledger
            sync_ledger(path,args.live_index)
        print(path)
    elif args.op=='index':
        catalog=build_catalog(args.recording,args.trial)
        segments=load_segments(args.clock_dir,catalog['boot_id'])
        for asset in catalog['assets']:
            if asset['available']:
                start,end=asset['monotonic_start_ns'],asset['monotonic_end_ns']
                relevant=[s for s in segments if start is not None and end is not None and s['start_monotonic_ns']<end and s['end_monotonic_ns']>start]
                asset.update(map_interval(relevant,catalog['boot_id'],start,end))
        write_catalog(args.output,catalog)
        print(json.dumps(dict(recording_id=catalog['recording_id'],assets=len(catalog['assets']),available=sum(a['available'] for a in catalog['assets']),utc_known=sum(a.get('utc_start_ns') is not None for a in catalog['assets']))))
    elif args.op=='ready':
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();now=time.monotonic_ns()
        rows=[r for r in load_segments(args.clock_dir,boot) if r['boot_id']==boot and 0<=now-r['end_monotonic_ns']<=60_000_000_000]
        # Gate new recordings with a fresh independent check, not merely an old stamp file.
        current=sample()
        ready=bool(rows) and current['valid']
        print(json.dumps(dict(ready=ready,boot_id=boot,reason='fresh bracketed interval plus current external check',current=current)))
        if not ready:raise SystemExit(2)
    else:
        if args.catalog is None and args.live_index is None:p.error('serve requires --catalog or --live-index')
        with ReplayServer(('127.0.0.1',args.port),args.catalog,bytes_per_second=args.bytes_per_second,algorithm_control=args.algorithm_control,live_index=args.live_index) as server:
            print('Loopback historical replay ready',flush=True);server.serve_forever()

if __name__=='__main__':main()
