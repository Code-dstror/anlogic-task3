"""Opt-in clock evidence, sealed recording catalog and private historical replay."""
