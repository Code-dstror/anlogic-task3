"""Backfill verified clip time after sealing, independently of video lifetime."""
import json
from pathlib import Path

from .clock_ledger import build_segments
from .live_index import update_clock


def sync_ledger(path,database):
    path=Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size>4*1024*1024:
        raise ValueError('bounded ordinary clock ledger required')
    ledger=json.loads(path.read_text())
    segments=build_segments(ledger['samples'])
    result=update_clock(database,ledger['boot_id'],segments)
    return dict(result,boot_id=ledger['boot_id'],segments=len(segments))
