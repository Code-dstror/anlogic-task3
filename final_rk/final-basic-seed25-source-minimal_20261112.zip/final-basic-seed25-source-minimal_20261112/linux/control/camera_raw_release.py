"""CAMERA_RAW R2 seed25 bindings; qualified dual recipes unchanged."""
from pathlib import Path

SOURCE='1a5603c1c8aa58565aa9b5facf40a7478ebcf6ba'
BIT='eee7eff50323a8a5c7ddc850d3873e1dda13473debbfe8a690bcb6bab17ac362'
PACKAGE_SHA256='cba5e2126259af71a5da931ea7f55490611154e3524b6505c28e363a9041cd0e'
BIT_LABEL='CAMERA_RAW_R2_1a5603c1_seed25'
BIT_FILENAME='camera_raw_r2_1a5603c1_seed25.bit'
RELEASE_ID='camera-raw-r2-seed25-session-v1'
JPEG_DISPLAY_POLICY=dict(policy='SOURCE_INTERVAL_LINEAR_V1',threads_per_eye=2)
SOURCE_ARCHIVE=Path('/home/uisrc/下载/CAMERA_RAW_R2_1a5603c1_seed25_Linux_Debug_20261110.zip')
BASE_INDEX='c0966e6eb797d20d4d3453aee0785e1fb56e0a6b9be137409387d1dd520e70d6'
HDR_POLICY=dict(hdr_ratio=4,hdr_black_long=50,hdr_black_short=50,
    hdr_motion_base=64,hdr_motion_shift=3,hdr_qualification=15,
    hdr_max_delta_ns=50_000_000,hdr_max_wait_ns=100_000_000,hdr_max_age_ns=1_000_000_000)
HDR_POLICY_ORIGIN='UNCHANGED_CHECKED_R3_MONO_ENGINEERING_RECIPE_47c77f957d459f802456e849a29070e01a8ab5af9526c5f08d0edc86a940645b'
SESSIONS={
    'mono-jpeg':dict(cameras=1,product='jpeg',label='单目 JPEG',sdr_fps=60,hdr_fps=30),
    'dual-jpeg':dict(cameras=2,product='jpeg',label='双目 JPEG',sdr_fps=30,hdr_fps=30),
    'dual-raw':dict(cameras=2,product='raw',label='双目 RAW 接收核验',sdr_fps=30,hdr_fps=None),
}
MODE_ROWS=(('color','彩色透传',0),('gray','灰度',1),('gaussian','高斯滤波',4),
           ('histogram','直方图均衡化',8),('lane','车道识别',48),('dehaze','去雾',2),('hdr','HDR',0))


def confirmed_processing_mask(metadata,*,source_epoch):
    """Private interpretation only after SharedStereoReceiver.accept succeeds.

    Legacy epoch-0 COLOR has no schema2 tag. Preserve the immutable SDK
    metadata, and never treat a missing later/HDR mask as disabled processing.
    """
    source=getattr(metadata,'source',None)
    if (type(source_epoch) is not int or source_epoch<0 or source is None or
            source.epoch!=source_epoch):
        raise ValueError('confirmed processing mask requires the actual verified SOURCE epoch')
    mask=metadata.schema2_processing_enables
    if mask is not None:
        if type(mask) is not int or not 0<=mask<=63:raise ValueError('invalid confirmed schema2 processing mask')
        return mask
    if (source_epoch==0 and type(metadata.processing_mode) is int and metadata.processing_mode==0 and
            type(metadata.record_flags) is int and not metadata.record_flags&1):return 0
    raise ValueError('missing schema2 processing mask outside confirmed legacy COLOR BOOT')


def frame_duration_ns(cameras,record_flags):
    if type(cameras) is not int or cameras not in (1,2) or type(record_flags) is not int or record_flags<0:
        raise ValueError('actual CAMERA_RAW topology and validated record flags required')
    # Bind to the accepted frame, not a requested mode with older epochs in flight.
    return 1_000_000_000//(30 if cameras==2 or record_flags&1 else 60)


def session_spec(name):
    if type(name) is not str or name not in SESSIONS:raise ValueError('explicit mono-jpeg/dual-jpeg/dual-raw cold session required')
    return dict(SESSIONS[name])


def modes(name):
    spec=session_spec(name)
    if spec['product']=='raw':return [dict(id='raw',label='RAW 接收核验',target_fps=30)]
    return [dict(id=key,label=label,enables=mask,target_fps=spec['hdr_fps'] if key=='hdr' else spec['sdr_fps'])
            for key,label,mask in MODE_ROWS if key!='lane' or spec['cameras']==1]


def configuration(session,mode):
    allowed={row['id']:row for row in modes(session)}
    if mode not in allowed or mode=='raw':raise ValueError('JPEG mode unsupported in this cold session')
    hdr=mode=='hdr'
    fields={k:v if hdr else 0 for k,v in HDR_POLICY.items()}
    return dict(schema=2,base=dict(mode='COLOR',quality=75,flags=0,min_quality=1,frame_budget=0,restart_mcus=0),
        extension=dict(schema=2,product_mode=2 if hdr else 0,processing_enables=allowed[mode]['enables'],
                       **fields,dehaze_lut_generation=0))


def validate_configuration(session,mode,document):
    if document!=configuration(session,mode):raise ValueError('complete fixed CAMERA_RAW mode/HDR recipe required')


def verify_integration(value):
    spec=session_spec(value.get('cold_session'))
    expected=dict(bit_sha256=BIT,source_commit=SOURCE,package_sha256=PACKAGE_SHA256)
    if (value.get('firmware_release')!=RELEASE_ID or value.get('firmware')!=expected or
            value.get('continuous') is not True or value.get('quality')!=75 or
            type(value.get('cameras')) is not int or value.get('cameras')!=spec['cameras'] or value.get('product')!=spec['product'] or
            value.get('initial_layout')!='cam0' or value.get('source_order_policy')!='strict' or
            value.get('hdr_policy')!=HDR_POLICY or value.get('mode_confirmation_s')!=30 or
            value.get('display_timing_policy')!='REALTIME_VISIBLE_SOURCE_V1' or
            value.get('runtime_role')!='CAMERA_RAW_SDK_OVERLAY_NOT_FIRMWARE_AUTHORITY'):
        raise ValueError('exact CAMERA_RAW identity, cold session and explicit policy required')
    if spec['product']=='jpeg' and value.get('recording',{}).get('retention')!=dict(mode='circular',low_water_bytes=2*1024**3,target_free_bytes=3*1024**3):
        raise ValueError('final HDMI circular recording required')
    if spec['product']=='raw' and value.get('recording') is not None:raise ValueError('RAW session is receive-only; ISP/display deferred by user')
    if 'jpeg_display_policy' in value:
        policy=value['jpeg_display_policy']
        if (spec['product']!='jpeg' or not isinstance(policy,dict) or policy!=JPEG_DISPLAY_POLICY or
                type(policy.get('threads_per_eye')) is not int):
            raise ValueError('explicit CAMERA_RAW JPEG source-interval/LINEAR policy required')
    return spec
