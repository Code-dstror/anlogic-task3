"""Same Receiver and native DMA pool across normal JPEG mono/dual sessions."""
from pathlib import Path
import time
try:
    from .camera_raw_owner import CameraOwner
    from .camera_raw_protocol import Router
    from .camera_session_rebuild import Rebuild, RebuiltColdSession
    from .camera_session_preview import SessionPreview
    from .camera_session_io import SessionControl, IDLE, HOST_DRAINED
    from .camera_session_control import REBUILD_SECONDS
    from .display_record_seal import durable_json
except ImportError:
    from camera_raw_owner import CameraOwner
    from camera_raw_protocol import Router
    from camera_session_rebuild import Rebuild, RebuiltColdSession
    from camera_session_preview import SessionPreview
    from camera_session_io import SessionControl, IDLE, HOST_DRAINED
    from camera_session_control import REBUILD_SECONDS
    from display_record_seal import durable_json


class SessionOwner(CameraOwner):
    def __init__(self,*args,session_control_factory=SessionControl,**kwargs):
        kwargs.setdefault('preview_factory',SessionPreview)
        super().__init__(*args,**kwargs)
        self.session_control = session_control_factory(self.receiver)
        self.session_control.evidence = self._session_evidence
        self.rebuild = None
        self.rebuild_count = 0

    def _session_evidence(self, name, value):
        directory = self.run_dir/'session-actions'
        directory.mkdir(exist_ok=True)
        path = directory/name
        if path.exists():
            raise RuntimeError('session action evidence already exists; no replay')
        durable_json(path,value)

    def _make_reader(self):
        if self.reader_factory is None:
            try:
                from .stereo_owned_record_reader import MetadataOwnedRecordReader
            except ImportError:
                from stereo_owned_record_reader import MetadataOwnedRecordReader
            factory=MetadataOwnedRecordReader
        else:
            factory=self.reader_factory
        return factory(self.receiver,self,maximum_batch=2,record_budget=None)

    def _poll(self,display):
        if self.rebuild and self.rebuild.stage in (
                'DRAINING_HOST','SEALING_RECORDING','WAITING_FRESH_BOOT'):
            display = False
        return super()._poll(display)

    def _stop_once(self):
        if self.rebuild and self.rebuild.stop_issued:
            self.stop_intent = True
            self.stop_returned = self.rebuild.stop_returned
            self._event('STOP_REUSES_SESSION_DRAIN',returned=self.stop_returned)
            return
        return super()._stop_once()

    def _control(self,preview):
        if self.rebuild is not None:
            if self.broker.check_timeout():
                raise TimeoutError('topology command deadline exceeded')
            if self.rebuild.tick():
                self.rebuild = None
                self.grace_deadline = 0
                self.preview.transition_until(0)
            return
        if self.broker.topology_queued():
            if self.command is not None or self.mode_pending is not None or self.pending_layout is not None:
                raise RuntimeError('old configuration/layout must settle before topology rebuild')
            request = self.broker.take()
            self.grace_deadline = self.clock()+REBUILD_SECONDS
            self.preview.transition_until(time.monotonic_ns()+REBUILD_SECONDS*1_000_000_000)
            self.rebuild = Rebuild(self,self.session_control,request,clock=self.clock)
            self.broker.rebuilding(request['request_id'],'RESTORING_SDR')
            return
        return super()._control(preview)

    def install_rebuilt_session(self,rebuild):
        if self.stop_event.is_set():
            raise RuntimeError('stop requested before new session selection')
        self.rebuild_count += 1
        directory = self.run_dir/'sessions'/f'{self.rebuild_count:06d}'
        directory.mkdir(parents=True,exist_ok=False)
        name = 'mono-jpeg' if rebuild.target==1 else 'dual-jpeg'
        config = dict(self.config,cold_session=name,cameras=rebuild.target)
        def admitted(caps):
            if self.stop_event.is_set():
                raise RuntimeError('stop requested during session admission')
            if self.storage_prepare is not None:
                proof = self.storage_prepare(caps)
            else:
                try:
                    from .display_recording import admit
                except ImportError:
                    from display_recording import admit
                proof = admit(config['recording'],boot=self.boot,require_space=False)
            durable_json(directory/'storage-ready.json',proof)
        owner = self
        class PrepareGuard:
            active = True
            def __getattr__(self, key):
                return getattr(owner.receiver,key)
            def read32(self, address):
                if self.active and owner.stop_event.is_set():
                    raise RuntimeError('stop requested during new-session selection')
                return owner.receiver.read32(address)
            def write32(self,address,value):
                with owner.broker.lock:
                    if self.active and owner.stop_event.is_set():
                        raise RuntimeError('stop requested before new-session MMIO')
                    return owner.receiver.write32(address,value)
        guarded = PrepareGuard()
        cold = RebuiltColdSession(guarded,session=name,on_admitted=admitted,
            evidence=lambda v:durable_json(directory/'cold-initial.json',v),
            session_control=self.session_control,expected_new_session=rebuild.new_session)
        receipt = cold.prepare()
        guarded.active = False
        if receipt['session'] != rebuild.new_session:
            raise RuntimeError('selected CFG session differs from kernel BOOT')
        durable_json(directory/'cold-preparation.json',receipt)
        self.config,self.cameras,self.cold,self.receipt = config,rebuild.target,cold,receipt
        self.profile='camera-raw-r2-seed25-session-v1-'+name
        self.router = Router(cold,directory)
        self.reader = self._make_reader()
        self.held.clear()  # All old copies were required empty before RESET.
        self.last_rx = [None,None]
        self.saved_first = [False,False]
        self.pending_layout = self.mode_pending = None
        self.layout_revision = 1
        self.preview = self.preview_factory(directory/'preview',config,boot=self.boot)
        self.preview.start()
        self.preview.transition_until(time.monotonic_ns()+30_000_000_000)
        with self.broker.lock:
            if self.stop_event.is_set():
                raise RuntimeError('stop requested before new START')
            # The old STOP cannot cover a new START with an uncertain outcome.
            rebuild.stop_issued = rebuild.stop_returned = False
            self.stop_intent = self.stop_returned = self.start_returned = False
            self._event('SESSION_START_CALL',session=receipt['session'],cameras=self.cameras)
            self.receiver.start()
            self.start_returned = True
            self._event('SESSION_START_RETURN',session=receipt['session'])
            self.state='RUNNING'

    def run(self):
        if self.state!='NEW':
            raise RuntimeError('one native owner lifetime required')
        self.state='PREPARING'
        preview_attempted=False
        last_publish=0
        try:
            startup = self.session_control.startup_snapshot()
            durable_json(self.run_dir/'session-startup.json',startup)
            if startup['state']['phase'] != IDLE or not startup['state']['flags'] & HOST_DRAINED:
                raise RuntimeError('initial IDLE and available drained session driver required; inspect session-startup.json')
            self.receipt=self.cold.prepare()
            durable_json(self.run_dir/'cold-preparation.json',self.receipt)
            self._event('COLD_SELECTION_ACK')
            self.router=Router(self.cold,self.run_dir)
            self.reader=self._make_reader()
            self.preview=self.preview_factory(self.run_dir/'preview',self.config,boot=self.boot)
            preview_attempted=True
            self.preview.start()
            with self.broker.lock:
                if self.stop_event.is_set():
                    raise RuntimeError('stop requested before initial START')
                self._event('START_CALL')
                self.start_intent=True
                self.started=self.clock()
                self.receiver.start()
                self.start_returned=True
                self._event('START_RETURN')
            self.state='RUNNING'
            while not self.stop_event.is_set() or self.command is not None or (
                    self.rebuild is not None and not self.rebuild.done.is_set()):
                self._poll(not self.stop_event.is_set())
                self.preview.check()
                self._control(self.preview.snapshot())
                now=self.clock()
                if self.command is not None and now>self.grace_deadline:
                    raise TimeoutError('configuration worker still in flight')
                if (not self.rebuild and now-self.started>5 and now>=self.grace_deadline
                        and any(self.last_rx[c] is None or now-self.last_rx[c]>3 for c in range(self.cameras))):
                    raise TimeoutError('active eye stopped delivering complete records')
                if now-last_publish>=1:
                    self._publish();last_publish=now
            self.state='DRAINING'
            self._stop_once();self._drain_host()
            self.state='DRAINED_RETAINED'
        except BaseException as error:
            self.failure=type(error).__name__+': '+str(error)[:512]
            self.state='FAULTED_RETAINED';self.stop_event.set()
            cfg_live=self.command is not None and not self.command['done'].is_set()
            rebuild_live=self.rebuild is not None and not self.rebuild.done.is_set()
            if self.start_intent and not self.stop_intent and not cfg_live and not rebuild_live:
                try:self._stop_once()
                except BaseException as e:self.evidence_error=str(e)[:512]
            if self.start_returned and self.stop_returned and self.reader is not None and self.reader.fault is None:
                try:self._drain_host()
                except BaseException as e:self.fault_drain_failure=str(e)[:512]
                finally:self.state='FAULTED_RETAINED'
        finally:
            if preview_attempted and self.preview is not None:
                self.final_preview=self.preview.close(timeout_s=15)
                if self.final_preview.get('failure') or not self.final_preview.get('worker_done'):
                    self.failure=self.failure or self.final_preview.get('failure') or 'display retirement pending'
                    self.state='FAULTED_RETAINED'
            self.stop_event.set()
            if self.evidence_error is not None:
                self.failure=self.failure or 'session stop evidence: '+self.evidence_error
                self.state='FAULTED_RETAINED'
            self.broker.stopped(self.failure)
            self._publish();self.events.close()
        return self.snapshot()

    def snapshot(self):
        value=super().snapshot()
        value.update(session_rebuild_count=self.rebuild_count,
            session_rebuild_stage=None if self.rebuild is None else self.rebuild.stage,
            old_cfg_session=None if self.rebuild is None else self.rebuild.old_session)
        return value
