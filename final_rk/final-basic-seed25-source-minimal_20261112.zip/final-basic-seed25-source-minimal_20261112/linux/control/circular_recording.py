"""Bounded maintenance for SD circular recording, outside the video worker."""
import importlib
import hashlib
import os
from pathlib import Path
import threading
import time
import urllib.error
import urllib.request


LOW_WATER = 2 * 1024**3
TARGET_FREE = 3 * 1024**3
POLICY = dict(mode='circular', low_water_bytes=LOW_WATER,
              target_free_bytes=TARGET_FREE)


def policy(config):
    value = config.get('retention')
    if value is None:
        return None
    if type(value) is not dict or value != POLICY:
        raise ValueError('fixed circular recording watermarks required')
    return dict(POLICY)


def require_replay_leases(config):
    """Do not reclaim while an old replay process serves unprotected readers."""
    expected = hashlib.sha256(str(Path(config['index']).absolute()).encode()).hexdigest()
    try:
        response = urllib.request.urlopen(
            urllib.request.Request('http://127.0.0.1:8765/', method='HEAD'), timeout=3)
    except urllib.error.HTTPError as error:
        # A busy but upgraded service still identifies its lease protocol.
        response = error
    with response:
        if (response.headers.get('X-Recording-Leases') != '1' or
                response.headers.get('X-Recording-Index') != expected):
            raise ValueError('matching replay reader protection must be active before circular cleanup')


def _check_mount(config, identity):
    value = Path(config['mount']).stat()
    if dict(dev=value.st_dev, ino=value.st_ino) != identity:
        raise OSError('recording SD mount changed after admission')


def _ensure_recordings_parent(config, identity):
    fd = os.open(config['mount'], os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        value = os.fstat(fd)
        if dict(dev=value.st_dev, ino=value.st_ino) != identity:
            raise OSError('recording SD mount changed before directory setup')
        _check_mount(config, identity)
        try:
            os.mkdir('recordings', mode=0o700, dir_fd=fd)
            os.fsync(fd)
        except FileExistsError:
            pass
        child = os.open('recordings', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
        try:
            if os.fstat(child).st_dev != value.st_dev:
                raise OSError('recordings parent is on another filesystem')
        finally:
            os.close(child)
        _check_mount(config, identity)
    finally:
        os.close(fd)


def prepare_space(config, *, boot, execute=False, verify_storage=True,
                  history_package='mono_record_history'):
    """Explicit pre-START cleanup; default checks do not delete recordings."""
    if policy(config) is None:
        raise ValueError('circular recording must be explicitly enabled')
    try:
        from .display_recording import admit
    except ImportError:
        from display_recording import admit
    admission = admit(config, boot=boot, verify_storage=verify_storage,
                      history_package=history_package, require_space=False)
    result = dict(status='CIRCULAR_SPACE_PLAN_NO_DELETE', policy=dict(POLICY),
                  admission=admission, needs_reclaim=admission['free_bytes'] < LOW_WATER,
                  executed=False, deleted=False)
    if not execute:
        return result
    if verify_storage:
        require_replay_leases(config)
        _ensure_recordings_parent(config, admission['storage_identity'])
    module = importlib.import_module(history_package + '.retention')
    with module.RetentionStore(config['index'], config['mount'], storage_admitted=verify_storage) as store:
        if verify_storage:
            _check_mount(config, admission['storage_identity'])
        before = store.snapshot()
        store.recover_pending()
        if store.free_bytes() < LOW_WATER:
            while True:
                batch = store.reclaim(target_free_bytes=TARGET_FREE, max_items=32)
                if store.free_bytes() >= TARGET_FREE:
                    break
                if not batch.get('deleted_clips'):
                    raise OSError('not enough unprotected sealed recordings to recover circular recording space')
        after = store.snapshot()
        deleted = after['deleted_clips'] - before['deleted_clips']
        result.update(status='CIRCULAR_SPACE_READY', executed=True, deleted=deleted > 0,
                      deleted_clips=deleted,
                      deleted_bytes=after['deleted_bytes'] - before['deleted_bytes'],
                      retention=after)
    result['admission'] = admit(config, boot=boot, verify_storage=verify_storage,
                                history_package=history_package)
    return result


class CircularReclaimer:
    """Own filesystem cleanup in one thread; cache status for the frame worker."""
    def __init__(self, config, *, history_package, storage_check, storage_admitted=False):
        self.config = config
        self.history_package = history_package
        self.storage_check = storage_check
        self.storage_admitted = storage_admitted
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.thread = None
        self.failure = None
        self.state = dict(POLICY, status='PREPARED', deleted_clips=0, deleted_bytes=0)

    def snapshot(self):
        with self.lock:
            return dict(self.state)

    def check(self):
        with self.lock:
            error = self.failure
        if error:
            raise RuntimeError('circular recording cleanup failed: ' + error)

    def start(self):
        if self.thread is not None:
            raise ValueError('one circular cleanup worker only')
        self.thread = threading.Thread(target=self._run, name='circular-recording-cleanup',
                                       daemon=True)
        self.thread.start()
        return self

    def _run(self):
        try:
            module = importlib.import_module(self.history_package + '.retention')
            self.storage_check()
            with module.RetentionStore(self.config['index'], self.config['mount'],
                                       storage_admitted=self.storage_admitted) as store:
                self.storage_check()
                store.recover_pending()
                draining = False
                while not self.stop_event.is_set():
                    self.storage_check()
                    free = store.free_bytes()
                    draining = draining or free < LOW_WATER
                    deleted = 0
                    if draining:
                        batch = store.reclaim(target_free_bytes=TARGET_FREE, max_items=8,
                                              stop_event=self.stop_event)
                        deleted = batch['deleted_clips']
                        free = store.free_bytes()
                        draining = free < TARGET_FREE
                    value = store.snapshot()
                    with self.lock:
                        self.state.update(value, mode='circular', status='RECLAIMING' if draining else 'READY',
                                          free_bytes=free)
                    # Cleanup never occupies the native/AU drain loop. Check
                    # cancellation between batches, and avoid a busy disk loop.
                    self.stop_event.wait(.05 if draining and deleted else .5)
        except BaseException as error:
            with self.lock:
                self.failure = str(error)
                self.state.update(status='FAULTED', error=str(error))
        finally:
            with self.lock:
                if self.failure is None:
                    self.state['status'] = 'STOPPED'

    def stop(self, timeout=2):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout)
        # An unresponsive filesystem operation retains its own directory FD;
        # it is never killed or redirected to another storage device.
        if self.thread is not None and self.thread.is_alive():
            with self.lock:
                self.state['status'] = 'STOP_PENDING_RETAINED'
        return self.snapshot()
