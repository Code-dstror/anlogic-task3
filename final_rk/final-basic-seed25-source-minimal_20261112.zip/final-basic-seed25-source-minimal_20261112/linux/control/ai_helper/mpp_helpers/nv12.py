"""Explicit full-range BT.601, 8-bit linear NV12 host views.

NV12 stores Y followed by interleaved U,V samples, one pair per 2x2 Y block.
Only ``BT601_FULL`` is accepted: OpenCV's usual NV12 conversion assumes a
different range and is deliberately not used here. The caller must keep input
storage immutable for the whole frame lifetime, including all buffer aliases.
Read-only NumPy flags alone do not establish exclusive ownership of storage.

Conversion uses Q16 coefficients, rounded by adding half a unit and flooring
(ties toward positive infinity), then clamps to [0,255]. Forward coefficient
rows are Y=(19595,38470,7471), U=(-11056,-21712,32768), and
V=(32768,-27440,-5328), with chroma offset 128. Chroma uses the centered 2x2
RGB box mean before quantization. Inverse coefficients are R/V=91881,
G/U=-22553, G/V=-46802, B/U=116130. Chroma reconstruction replicates each
pair across its 2x2 block. These conventions are deterministic, including at
clipped colors, and never infer a range or matrix from dimensions.
"""
from dataclasses import dataclass

import cv2
import numpy as np


BT601_FULL = "BT601_FULL"
MAX_BUFFER_BYTES = 64 * 1024 * 1024


def _geometry(width, height):
    if (type(width) is not int or type(height) is not int or
            width <= 0 or height <= 0 or width % 2 or height % 2 or
            width > 3840 or height > 2160):
        raise ValueError("NV12 requires even positive dimensions up to 3840x2160")


def _format(colorimetry, layout):
    if not isinstance(colorimetry, str) or colorimetry != BT601_FULL:
        raise ValueError("only explicit BT601_FULL colorimetry is supported")
    if not isinstance(layout, str) or layout != "linear":
        raise ValueError("only linear NV12 layout is supported")


@dataclass(frozen=True)
class NV12Frame:
    """Read-only active planes; row padding and vertical padding are excluded.

    ``y`` is (H,W) and ``uv`` is (H/2,W/2,2), with U before V. Positive
    independent row strides are allowed; samples within a row are contiguous.
    The frame retains the arrays without copying. Callers supplying views must
    prevent writes through every alias for the lifetime of the frame.
    """

    y: np.ndarray
    uv: np.ndarray
    colorimetry: str
    layout: str = "linear"

    def __post_init__(self):
        _format(self.colorimetry, self.layout)
        if not isinstance(self.y, np.ndarray) or not isinstance(self.uv, np.ndarray):
            raise ValueError("NV12 planes must be NumPy arrays")
        if self.y.ndim != 2:
            raise ValueError("Y plane must have shape (H,W)")
        height, width = self.y.shape
        _geometry(width, height)
        if self.uv.shape != (height // 2, width // 2, 2):
            raise ValueError("UV plane must have shape (H/2,W/2,2)")
        if self.y.dtype != np.uint8 or self.uv.dtype != np.uint8:
            raise ValueError("NV12 planes must have uint8 dtype")
        if (self.y.strides[1] != 1 or self.uv.strides[1:] != (2, 1) or
                self.y.strides[0] < width or self.uv.strides[0] < width):
            raise ValueError("NV12 requires contiguous row samples and positive row strides")
        span = ((height - 1) * self.y.strides[0] + width +
                (height // 2 - 1) * self.uv.strides[0] + width)
        if (max(self.y.strides[0], self.uv.strides[0]) > MAX_BUFFER_BYTES or
                span > MAX_BUFFER_BYTES):
            raise ValueError("NV12 plane storage footprint exceeds 64 MiB")
        if self.y.flags.writeable or self.uv.flags.writeable:
            raise ValueError("NV12 input planes must be read-only")

    @property
    def width(self):
        return self.y.shape[1]

    @property
    def height(self):
        return self.y.shape[0]


def validate(frame):
    """Revalidate a frame's current array metadata/flags and return the frame."""
    if not isinstance(frame, NV12Frame):
        raise ValueError("an NV12Frame is required")
    frame.__post_init__()
    return frame


def from_buffer(data, width, height, y_stride, uv_stride, uv_offset,
                colorimetry, layout="linear"):
    """View immutable linear storage without copying or reading its padding.

    Strides and offsets are bytes. ``uv_offset`` must follow the full strided
    Y plane and may include additional vertical padding (e.g. 1920*1088 for
    1920x1080). Both active planes must fit; trailing UV row padding need not
    be present. Buffer size is capped at 64 MiB. A read-only contiguous buffer
    is required; callers must also prevent mutation through any backing alias.
    All geometry/bounds checks precede construction of either NumPy view.
    """
    _format(colorimetry, layout)
    _geometry(width, height)
    if (type(y_stride) is not int or type(uv_stride) is not int or
            y_stride < width or uv_stride < width):
        raise ValueError("plane strides must be integer byte counts at least width")
    if max(y_stride, uv_stride) > MAX_BUFFER_BYTES:
        raise ValueError("NV12 row stride exceeds 64 MiB")
    if type(uv_offset) is not int or uv_offset < y_stride * height:
        raise ValueError("UV offset must follow the full strided Y plane")
    try:
        buffer = memoryview(data)
    except TypeError as exc:
        raise ValueError("a read-only contiguous buffer is required") from exc
    if not buffer.readonly or not buffer.c_contiguous:
        raise ValueError("a read-only contiguous buffer is required")
    if buffer.nbytes > MAX_BUFFER_BYTES:
        raise ValueError("NV12 buffer exceeds 64 MiB")
    end = uv_offset + (height // 2 - 1) * uv_stride + width
    if end > buffer.nbytes:
        raise ValueError("NV12 active planes exceed buffer bounds")
    buffer = buffer.cast("B")
    y = np.ndarray((height, width), np.uint8, buffer=buffer,
                   strides=(y_stride, 1))
    uv = np.ndarray((height // 2, width // 2, 2), np.uint8,
                    buffer=buffer, offset=uv_offset, strides=(uv_stride, 2, 1))
    return NV12Frame(y, uv, colorimetry, layout)


def _quantize(value, bits=16):
    return np.clip((value + (1 << (bits - 1))) >> bits, 0, 255).astype(np.uint8)


def to_rgb(frame):
    """Decode to a fresh RGB uint8 array using the documented full-range Q16 matrix."""
    # Revalidate mutable array metadata and flags before reading caller views.
    validate(frame)
    y = frame.y.astype(np.int32) << 16
    u = np.repeat(np.repeat(frame.uv[..., 0].astype(np.int32) - 128, 2, 0), 2, 1)
    v = np.repeat(np.repeat(frame.uv[..., 1].astype(np.int32) - 128, 2, 0), 2, 1)
    rgb = np.empty((frame.height, frame.width, 3), np.uint8)
    rgb[..., 0] = _quantize(y + 91881 * v)
    rgb[..., 1] = _quantize(y - 22553 * u - 46802 * v)
    rgb[..., 2] = _quantize(y + 116130 * u)
    return rgb


def from_rgb(rgb, *, colorimetry):
    """Encode RGB uint8 using a centered 2x2 chroma box before quantization.

    The result owns fresh Y/UV arrays, marked read-only; no input storage is
    retained. RGB input may be writable and need not be contiguous.
    """
    _format(colorimetry, "linear")
    if not isinstance(rgb, np.ndarray) or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError("RGB must have shape (H,W,3)")
    if rgb.dtype != np.uint8:
        raise ValueError("RGB must have uint8 dtype")
    height, width = rgb.shape[:2]
    _geometry(width, height)
    channels = rgb.astype(np.int32)
    r, g, b = (channels[..., i] for i in range(3))
    y = _quantize(19595 * r + 38470 * g + 7471 * b)
    # Sum first: averaging quantized YUV or uint8 RGB biases the chroma.
    blocks = (channels[0::2, 0::2] + channels[0::2, 1::2] +
              channels[1::2, 0::2] + channels[1::2, 1::2])
    r, g, b = (blocks[..., i] for i in range(3))
    uv = np.empty((height // 2, width // 2, 2), np.uint8)
    uv[..., 0] = _quantize(-11056 * r - 21712 * g + 32768 * b + (128 << 18), 18)
    uv[..., 1] = _quantize(32768 * r - 27440 * g - 5328 * b + (128 << 18), 18)
    y.flags.writeable = False
    uv.flags.writeable = False
    return NV12Frame(y, uv, colorimetry)


def resize(frame, width, height, interpolation=cv2.INTER_LINEAR):
    """Resize Y and two-channel UV independently; always return fresh storage.

    No RGB conversion occurs. Same-size requests also copy both active planes,
    so the returned frame never aliases caller input or its padding.
    """
    validate(frame)
    _geometry(width, height)
    y = cv2.resize(frame.y, (width, height), interpolation=interpolation)
    uv = cv2.resize(frame.uv, (width // 2, height // 2), interpolation=interpolation)
    # OpenCV allocates for resize without dst, including same-size requests.
    y.flags.writeable = False
    uv.flags.writeable = False
    return NV12Frame(y, uv, frame.colorimetry)
