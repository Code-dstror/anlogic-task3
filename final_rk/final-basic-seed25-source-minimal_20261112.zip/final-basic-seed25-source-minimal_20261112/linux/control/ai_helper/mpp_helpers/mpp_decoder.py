"""Private MPP JPEG owner returning immutable host NV12; no shared video imports.

Library loading/context allocation happen only when this factory is invoked.
A decode completes native sync/copy and task retirement before returning owned
bytes. The next decode cannot overwrite an earlier NV12Frame. No device reset,
software decoding fallback or automatic context reconstruction is provided.
"""
import ctypes as C
import math
from pathlib import Path
from threading import RLock,get_ident
import time

from .nv12 import BT601_FULL,from_buffer

MAX_JPEG=4*1024*1024
MAX_NV12=2048*1088*3//2


class MppError(RuntimeError):
    retained_decoder=None


class NativeResult(C.Structure):
    _fields_=[(name,C.c_uint32) for name in (
        'abi_version','width','height','hor_stride','ver_stride','format','errinfo',
        'discard','info_change','color_range','colorspace','color_primaries','color_trc')]+[
        ('buffer_size',C.c_uint64),('copied_bytes',C.c_uint64),('pts',C.c_int64)]+[
        (name,C.c_double) for name in ('input_copy_ms','mpp_decode_ms','output_copy_ms','total_ms')]


def validate_jpeg(data):
    """Validate bounded immutable baseline1080 JPEG header; MPP checks entropy."""
    if type(data) is not bytes or not 4<=len(data)<=MAX_JPEG or data[:2]!=b'\xff\xd8' or data[-2:]!=b'\xff\xd9':
        raise ValueError('bounded immutable complete JPEG required')
    offset=2
    while offset<len(data)-2:
        if data[offset]!=255:raise ValueError('invalid JPEG marker before scan')
        while offset<len(data) and data[offset]==255:offset+=1
        if offset>=len(data):break
        marker=data[offset];offset+=1
        if marker in (0,0xd8,0xd9) or 0xd0<=marker<=0xd7:raise ValueError('unexpected JPEG marker')
        if offset+2>len(data):break
        length=int.from_bytes(data[offset:offset+2],'big')
        if length<2 or offset+length>len(data):raise ValueError('invalid JPEG segment length')
        if marker in set(range(0xc0,0xd0))-{0xc4,0xc8,0xcc}:
            segment=data[offset:offset+length]
            if marker!=0xc0 or length!=17 or segment[2]!=8 or segment[7]!=3:
                raise ValueError('only8bit three-component baseline JPEG supported')
            if (int.from_bytes(segment[5:7],'big'),int.from_bytes(segment[3:5],'big'))!=(1920,1080):
                raise ValueError('private MPP dehaze requires1920x1080 JPEG')
            return
        if marker==0xda:break
        offset+=length
    raise ValueError('missing supported JPEG frame header')


def _message(error):
    try:return str(error)[:300]
    except BaseException:return type(error).__name__


class PrivateMppDecoder:
    def __init__(self,library,*,colorimetry,allow_unreported_color=False,timeout_ms=1000,_lib=None):
        if colorimetry!=BT601_FULL:raise ValueError('explicit BT601_FULL input contract required')
        if type(allow_unreported_color) is not bool:raise ValueError('allow_unreported_color must be bool')
        if type(timeout_ms) is not int or not 1<=timeout_ms<8000:raise ValueError('MPP timeout must be1..7999ms')
        self._lock=RLock();self._owner=get_ident();self._handle=C.c_void_p()
        self._active=self._closed=False;self._failure=self._cleanup_failure=None
        self._next_pts=1;self._completed=0;self._last=None
        self._failed_native=None
        self.colorimetry=colorimetry;self.allow_unreported_color=allow_unreported_color
        self._lib=_lib if _lib is not None else C.CDLL(str(Path(library).resolve(strict=True)))
        signatures={'result_size':([],C.c_uint32),'open':([C.POINTER(C.c_void_p),C.c_int],C.c_int),
                    'decode':([C.c_void_p,C.c_void_p,C.c_size_t,C.c_int64,C.c_void_p,C.c_size_t,C.POINTER(NativeResult)],C.c_int),
                    'close':([C.c_void_p],C.c_int),'error':([C.c_void_p],C.c_char_p)}
        for name,(arguments,result) in signatures.items():
            fn=getattr(self._lib,'dehaze_mpp_'+name);fn.argtypes=arguments;fn.restype=result
        if self._lib.dehaze_mpp_result_size()!=C.sizeof(NativeResult):raise MppError('private MPP result ABI size mismatch')
        self._output=C.create_string_buffer(MAX_NV12)
        ret=self._lib.dehaze_mpp_open(C.byref(self._handle),timeout_ms)
        if ret or not self._handle.value:
            error=MppError('private MPP open rc='+str(ret)+': '+self._native_error('context not created'))
            if self._handle.value:
                self._failure=error;self._cleanup_failure='partial open retained after native destroy failure'
                error.retained_decoder=self
            raise error

    def _thread(self):
        if self._owner!=get_ident():raise MppError('private MPP requires its owner thread')

    def _native_error(self,fallback):
        raw=self._lib.dehaze_mpp_error(self._handle)
        return raw.decode('utf-8','replace') if raw else fallback

    def _color(self,result):
        # These raw enum values are pinned to the fetched RK mpp_frame.h;
        # unknown metadata requires a separate explicit caller opt-in.
        if result.color_range not in (0,2) or result.colorspace not in (2,5,6):
            raise MppError('native color metadata conflicts with BT601_FULL')
        unreported=result.color_range==0 or result.colorspace==2
        if unreported and not self.allow_unreported_color:
            raise MppError('native color metadata unreported; explicit JPEG color contract opt-in required')
        return 'CALLER_EXPLICIT_JPEG_BT601_FULL_WITH_UNREPORTED_NATIVE' if unreported else 'NATIVE_REPORTED_BT601_FULL'

    def decode_to_nv12(self,jpeg):
        with self._lock:
            self._thread()
            if self._closed or not self._handle.value:raise MppError('private MPP is closed')
            if self._cleanup_failure is not None:raise MppError('private MPP cleanup failed; retained native handle cannot decode')
            if self._failure is not None:raise MppError('private MPP failed; no automatic retry or software fallback')
            if self._active:raise MppError('cannot reenter private MPP during a decode')
            self._active=True
            result=None;pts=None
            try:
                started=time.monotonic_ns();validate_jpeg(jpeg)
                if self._next_pts>=2**63:raise MppError('private PTS counter exhausted')
                pts=self._next_pts;result=NativeResult()
                ret=self._lib.dehaze_mpp_decode(self._handle,jpeg,len(jpeg),pts,self._output,MAX_NV12,C.byref(result))
                if ret:raise MppError(self._native_error('private MPP decode failed'))
                hs,vs=int(result.hor_stride),int(result.ver_stride)
                size=hs*vs*3//2
                if (result.abi_version!=1 or (result.width,result.height)!=(1920,1080) or
                    result.errinfo or result.discard or result.info_change or result.pts!=pts or
                    not 1920<=hs<=2048 or hs%2 or not 1080<=vs<=1088 or vs%2 or
                    result.copied_bytes!=size or size>MAX_NV12 or size>result.buffer_size):
                    raise MppError('private MPP result identity/geometry/bounds mismatch')
                authority=self._color(result)
                for name in ('input_copy_ms','mpp_decode_ms','output_copy_ms','total_ms'):
                    value=getattr(result,name)
                    if not math.isfinite(value) or value<0:raise MppError('invalid native timing metadata')
                copy_start=time.monotonic_ns();owned=C.string_at(self._output,size)
                copied=time.monotonic_ns()
                frame=from_buffer(owned,1920,1080,hs,hs,hs*vs,self.colorimetry)
                details={name:getattr(result,name) for name,_ in NativeResult._fields_}
                details.update(color_authority=authority,python_owned_copy_ms=(copied-copy_start)/1e6,
                               decode_to_owned_nv12_ms=(time.monotonic_ns()-started)/1e6,
                               zero_copy=False,execution='PRIVATE_MPP_HARDWARE')
                self._completed+=1;self._next_pts+=1;self._last=details
                return frame
            except BaseException as error:
                if result is not None:
                    self._failed_native=dict(expected_pts=pts,
                        **{name:getattr(result,name) for name,_ in NativeResult._fields_})
                self._failure=error
                raise
            finally:self._active=False

    def last_details(self):
        with self._lock:return None if self._last is None else dict(self._last)

    def status(self):
        with self._lock:
            return {'owner_thread':self._owner,'native_handle_retained':bool(self._handle.value),
                    'completed':self._completed,'failure':None if self._failure is None else _message(self._failure),
                    'cleanup_failure':self._cleanup_failure,'closed':self._closed,
                    'failed_native_result':None if self._failed_native is None else dict(self._failed_native),
                    'last_completed':None if self._last is None else dict(self._last)}

    def close(self):
        with self._lock:
            self._thread()
            if self._closed:return
            if self._active:raise MppError('cannot close private MPP during a decode')
            if self._cleanup_failure is not None:raise MppError('private MPP cleanup failed; native handle retained, no automatic retry')
            if self._handle.value:
                ret=self._lib.dehaze_mpp_close(self._handle)
                if ret:
                    self._cleanup_failure=self._native_error('private MPP destroy failed; retained storage')
                    raise MppError(self._cleanup_failure)
                self._handle=C.c_void_p()
            self._closed=True


def private_mpp_factory(library,*,colorimetry,allow_unreported_color=False,timeout_ms=1000):
    """Construct a lazy NEW-context factory without loading libraries/devices."""
    return lambda:PrivateMppDecoder(library,colorimetry=colorimetry,
                                   allow_unreported_color=allow_unreported_color,timeout_ms=timeout_ms)
