// Batched double-precision ByteTrack primitives. No model/association policy.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <vector>
#ifdef _WIN32
#define API extern "C" __declspec(dllexport)
#else
#define API extern "C"
#endif
using Matrix=double[64];
static void product(const double* a,const double* b,double* out,bool transpose_b=false){
 for(int i=0;i<8;i++)for(int j=0;j<8;j++){
  double x=0;for(int k=0;k<8;k++)x+=a[i*8+k]*b[transpose_b?j*8+k:k*8+j];out[i*8+j]=x;
 }
}
static void predict(double* m,double* c,bool tracked,double dt){
 if(!tracked)m[7]=0;
 Matrix f={},left={},cov={};double mean[8]={};
 for(int i=0;i<8;i++)f[i*8+i]=1;
 for(int i=0;i<4;i++)f[i*8+i+4]=dt;
 double p=(1./20)*m[3],v=(1./160)*m[3];double stddev[8]={p,p,1e-2,p,v,v,1e-5,v};
 for(int i=0;i<8;i++)for(int j=0;j<8;j++)mean[i]+=m[j]*f[i*8+j];
 product(f,c,left);product(left,f,cov,true);
 for(int i=0;i<8;i++)cov[i*8+i]+=stddev[i]*stddev[i]*dt;
 std::memcpy(m,mean,sizeof(mean));std::memcpy(c,cov,sizeof(cov));
}
static void warp(double* m,double* c,const double* h){
 const double p=std::abs(h[0]),q=std::abs(h[1]),r=std::abs(h[3]),s=std::abs(h[4]);
 const double a=m[2],height=m[3],d=r*a+s,n=p*a+q,k=p*s-q*r;
 if(a<=0||height<=0||d<=1e-8)throw std::runtime_error("Invalid state/motion for XYAH warp");
 const double derivative=k/(d*d);double mean[8];std::memcpy(mean,m,sizeof(mean));
 mean[0]=h[0]*m[0]+h[1]*m[1]+h[2];mean[1]=h[3]*m[0]+h[4]*m[1]+h[5];
 mean[2]=n/d;mean[3]=height*d;
 mean[4]=h[0]*m[4]+h[1]*m[5];mean[5]=h[3]*m[4]+h[4]*m[5];
 mean[6]=derivative*m[6];mean[7]=r*height*m[6]+d*m[7];
 Matrix j={},left={},cov={};
 j[0]=h[0];j[1]=h[1];j[8]=h[3];j[9]=h[4];j[18]=derivative;j[26]=height*r;j[27]=d;
 j[36]=h[0];j[37]=h[1];j[44]=h[3];j[45]=h[4];
 j[50]=-2*r*k/(d*d*d)*m[6];j[54]=derivative;
 j[58]=r*m[7];j[59]=r*m[6];j[62]=r*height;j[63]=d;
 product(j,c,left);product(left,j,cov,true);
 for(int i=0;i<8;i++)for(int z=0;z<8;z++)c[i*8+z]=(cov[i*8+z]+cov[z*8+i])*.5+(i==z?1e-10:0.);
 std::memcpy(m,mean,sizeof(mean));
}
API int y26_tracking_abi(){return 1;}
// pool rows predicted first; following unconfirmed rows only receive the warp.
API int y26_predict_warp(double* means,double* cov,const uint8_t* tracked,int count,int predicted,
 double dt,const double* motion,char* error,int cap){
 try{
  if(count<0||predicted<0||predicted>count||!std::isfinite(dt)||dt<=0)throw std::runtime_error("Invalid batch/step");
  if(count&&(!means||!cov||!tracked))throw std::runtime_error("Missing batch buffers");
  if(motion)for(int j=0;j<6;j++)if(!std::isfinite(motion[j]))throw std::runtime_error("Nonfinite motion");
  for(int i=0;i<count;i++){
   auto m=means+i*8;auto c=cov+i*64;
   if(i<predicted)predict(m,c,tracked[i]!=0,dt);
   if(motion)warp(m,c,motion);
  }
  return 0;
 }catch(const std::exception& e){if(error&&cap>0)std::snprintf(error,cap,"%s",e.what());return -1;}
}
static void box(const double* state,bool xyah,double* out){
 std::memcpy(out,state,4*sizeof(double));
 if(xyah){out[2]*=out[3];out[0]-=out[2]/2;out[1]-=out[3]/2;}
 out[2]+=out[0];out[3]+=out[1];
}
API void y26_track_boxes(const double* states,const uint8_t* xyah,int count,double width,double height,double* out){
 for(int i=0;i<count;i++){
  box(states+i*4,xyah[i]!=0,out+i*4);
  if(width>0&&height>0)for(int j=0;j<4;j++)out[i*4+j]=std::clamp(out[i*4+j],0.,j%2?height:width);
 }
}
// Same inclusive +1 IoU and score-fusion order as the existing NumPy path.
API void y26_iou_cost(const double* a,int n,const double* b,int m,const double* scores,double* out){
 for(int i=0;i<n;i++)for(int j=0;j<m;j++){
  const double* x=a+i*4;const double* y=b+j*4;
  const double iw=std::max(0.,std::min(x[2],y[2])-std::max(x[0],y[0])+1);
  const double ih=std::max(0.,std::min(x[3],y[3])-std::max(x[1],y[1])+1);
  const double inter=iw*ih;
  const double aa=std::max(x[2]-x[0]+1,0.)*std::max(x[3]-x[1]+1,0.);
  const double bb=std::max(y[2]-y[0]+1,0.)*std::max(y[3]-y[1]+1,0.);
  double cost=1-inter/std::max(aa+bb-inter,1e-12);
  if(scores)cost=1-(1-cost)*scores[j];out[i*m+j]=cost;
 }
}
struct CostScratch {std::vector<double> a,b;};
API void* y26_cost_open(){try{return new CostScratch;}catch(...){return nullptr;}}
API void y26_cost_close(void* p){delete static_cast<CostScratch*>(p);}
// One call: unpack states into boxes and compute/fuse costs. Output is caller-owned.
API int y26_state_cost(void* p,const double* a,const uint8_t* ak,int n,
 const double* b,const uint8_t* bk,int m,const double* scores,double* out){
 if(!p||n<0||m<0|| (n&&(!a||!ak)) || (m&&(!b||!bk)) || (n&&m&&!out))return -1;
 auto s=static_cast<CostScratch*>(p);s->a.resize(size_t(n)*4);s->b.resize(size_t(m)*4);
 y26_track_boxes(a,ak,n,0,0,s->a.data());y26_track_boxes(b,bk,m,0,0,s->b.data());
 y26_iou_cost(s->a.data(),n,s->b.data(),m,scores,out);return 0;
}

// Fixed H=[I4,0], identical observation noise and Cholesky correction.
// Work is confined to caller scratch; Python commits states only after success.
API int y26_correct_batch(double* means,double* cov,const double* tlwh,int count,char* error,int cap){
 try{
  if(count<0||(count&&(!means||!cov||!tlwh)))throw std::runtime_error("Invalid correction buffers");
  for(int n=0;n<count;n++){
   auto m=means+n*8;auto c=cov+n*64;auto box=tlwh+n*4;
   for(int i=0;i<8;i++)if(!std::isfinite(m[i]))throw std::runtime_error("Nonfinite correction mean");
   for(int i=0;i<64;i++)if(!std::isfinite(c[i]))throw std::runtime_error("Nonfinite correction covariance");
   for(int i=0;i<4;i++)if(!std::isfinite(box[i]))throw std::runtime_error("Nonfinite measurement");
   if(box[3]<=0)throw std::runtime_error("Invalid measurement height");
   double z[4]={box[0]+box[2]/2,box[1]+box[3]/2,box[2]/box[3],box[3]};
   double s[16],l[16]={},k[32],ks[32],next[64],next_m[8];
   double noise=(1./20)*m[3];double stddev[4]={noise,noise,1e-1,noise};
   for(int i=0;i<4;i++)for(int j=0;j<4;j++)s[i*4+j]=c[i*8+j]+(i==j?stddev[i]*stddev[i]:0.);
   for(int i=0;i<4;i++)for(int j=0;j<=i;j++){
    double v=s[i*4+j];for(int q=0;q<j;q++)v-=l[i*4+q]*l[j*4+q];
    if(i==j){if(!(v>0)||!std::isfinite(v))throw std::runtime_error("Correction covariance not positive definite");l[i*4+j]=std::sqrt(v);}
    else l[i*4+j]=v/l[j*4+j];
   }
   for(int i=0;i<8;i++){
    double y[4];
    for(int j=0;j<4;j++){double v=c[i*8+j];for(int q=0;q<j;q++)v-=l[j*4+q]*y[q];y[j]=v/l[j*4+j];}
    for(int j=3;j>=0;j--){double v=y[j];for(int q=j+1;q<4;q++)v-=l[q*4+j]*k[i*4+q];k[i*4+j]=v/l[j*4+j];}
    double correction=0;for(int j=0;j<4;j++)correction+=(z[j]-m[j])*k[i*4+j];next_m[i]=m[i]+correction;
    for(int j=0;j<4;j++){double v=0;for(int q=0;q<4;q++)v+=k[i*4+q]*s[q*4+j];ks[i*4+j]=v;}
   }
   for(int i=0;i<8;i++)for(int j=0;j<8;j++){double v=0;for(int q=0;q<4;q++)v+=ks[i*4+q]*k[j*4+q];next[i*8+j]=c[i*8+j]-v;}
   std::memcpy(m,next_m,sizeof(next_m));std::memcpy(c,next,sizeof(next));
  }
  return 0;
 }catch(const std::exception& e){if(error&&cap>0)std::snprintf(error,cap,"%s",e.what());return -1;}
}
