"""Opt-in exact AREA3 + BGR2GRAY candidate; no resampling policy change."""
import ctypes as C
import numpy as np

class NativeSourceGray:
    def __init__(self,library):
        self.lib=C.CDLL(str(library))
        self.lib.y26_source_gray3.argtypes=[C.c_void_p,C.c_void_p,C.c_int,C.c_int]
        self.lib.y26_source_gray3.restype=C.c_int
    def prepare(self,bgr,gray):
        if bgr.shape!=(1080,1920,3) or gray.shape!=(360,640) or bgr.dtype!=np.uint8 or gray.dtype!=np.uint8 or not bgr.flags.c_contiguous or not gray.flags.c_contiguous or not gray.flags.writeable:
            raise ValueError('AREA3 gray requires leased contiguous1080p BGR and writable640x360 output')
        if np.shares_memory(bgr,gray):raise ValueError('Input/output gray alias')
        rc=self.lib.y26_source_gray3(bgr.ctypes.data,gray.ctypes.data,1920,1080)
        if rc:raise RuntimeError('Exact source gray failed: '+str(rc))
