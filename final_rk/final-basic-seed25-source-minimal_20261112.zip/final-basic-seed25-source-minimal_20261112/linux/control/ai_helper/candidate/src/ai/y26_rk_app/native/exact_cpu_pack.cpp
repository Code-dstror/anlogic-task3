// Organisation-only candidate. Existing Kalman/IoU functions and LK/RANSAC are unchanged.
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <vector>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdint>
#include <stdexcept>
// Public CPython stable buffer ABI; no private object/NumPy structure access.
// The board has CPython3.11 but no development headers. PyDLL holds the GIL.
struct _object;using PyObject=_object;using Py_ssize_t=intptr_t;struct _ts;using PyThreadState=_ts;
struct Py_buffer {void*buf;PyObject*obj;Py_ssize_t len,itemsize;int readonly,ndim;char*format;Py_ssize_t*shape,*strides,*suboffsets;void*internal;};
static_assert(sizeof(void*)==8 && sizeof(Py_buffer)==80,"64bit public buffer ABI required");
extern "C" {
extern PyObject _Py_NoneStruct;
Py_ssize_t PySequence_Size(PyObject*);PyObject* PySequence_GetItem(PyObject*,Py_ssize_t);
PyObject* PyObject_GetAttrString(PyObject*,const char*);int PyObject_GetBuffer(PyObject*,Py_buffer*,int);
void PyBuffer_Release(Py_buffer*);void Py_DecRef(PyObject*);long PyLong_AsLong(PyObject*);
double PyFloat_AsDouble(PyObject*);PyObject* PyErr_Occurred();void PyErr_Clear();
PyThreadState* PyEval_SaveThread();void PyEval_RestoreThread(PyThreadState*);
}
struct Buffer {Py_buffer v{};bool acquired=false;~Buffer(){if(acquired)PyBuffer_Release(&v);}};
struct Object {PyObject*p=nullptr;explicit Object(PyObject*q):p(q){}~Object(){if(p)Py_DecRef(p);}};
static bool buffer(PyObject*p,Buffer&b,bool writable,int length){
 if(!p||PyObject_GetBuffer(p,&b.v,writable?0x1d:0x1c)!=0){PyErr_Clear();return false;}
 b.acquired=true;
 if(b.v.itemsize!=8||!b.v.format||std::strcmp(b.v.format,"d")||b.v.len<length*8)return false;
 if(b.v.ndim==1)return b.v.strides[0]==8;
 return b.v.ndim==2&&b.v.strides[1]==8&&b.v.strides[0]==b.v.shape[1]*8;
}
struct Pack {std::vector<double> means,covs,a,b,scores;std::vector<uint8_t> tracked,ak,bk;};
struct Unlocked {PyThreadState*p;Unlocked():p(PyEval_SaveThread()){}~Unlocked(){PyEval_RestoreThread(p);}};
extern "C" void* y26_pack_open(){try{return new Pack;}catch(...){return nullptr;}}
extern "C" void y26_pack_close(void*p){delete static_cast<Pack*>(p);}
using Predict=int(*)(double*,double*,const uint8_t*,int,int,double,const double*,char*,int);
extern "C" int y26_predict_objects(void*ctx,PyObject*tracks,int predicted,int tracked_state,double dt,const double*h,void*function,char*err,int cap){
 try{
  auto s=static_cast<Pack*>(ctx);int n=int(PySequence_Size(tracks));
  if(!s||n<0||predicted<0||predicted>n||!function)throw std::runtime_error("Invalid object prediction");
  s->means.resize(n*8);s->covs.resize(n*64);s->tracked.resize(n);
  std::vector<Buffer> means(n),covs(n);
  for(int i=0;i<n;i++){
   Object t(PySequence_GetItem(tracks,i));if(!t.p)throw std::runtime_error("Track access failed");
   Object m(PyObject_GetAttrString(t.p,"mean")),c(PyObject_GetAttrString(t.p,"covariance")),state(PyObject_GetAttrString(t.p,"state"));
   if(!state.p||!buffer(m.p,means[i],true,8)||!buffer(c.p,covs[i],true,64))return -2;
   s->tracked[i]=PyLong_AsLong(state.p)==tracked_state;
   if(PyErr_Occurred())throw std::runtime_error("Invalid track state");
   std::memcpy(s->means.data()+i*8,means[i].v.buf,64);std::memcpy(s->covs.data()+i*64,covs[i].v.buf,512);
  }
  // Exact existing kernel. Preserve all-or-nothing state commit on kernel failure.
  int rc;{Unlocked unlock;rc=reinterpret_cast<Predict>(function)(s->means.data(),s->covs.data(),s->tracked.data(),n,predicted,dt,h,err,cap);
   if(!rc)for(int i=0;i<n;i++){std::memcpy(means[i].v.buf,s->means.data()+i*8,64);std::memcpy(covs[i].v.buf,s->covs.data()+i*64,512);}
  }return rc;
 }catch(const std::exception&e){PyErr_Clear();if(err&&cap)std::snprintf(err,cap,"%s",e.what());return -1;}
}
static void states(PyObject*tracks,std::vector<double>&v,std::vector<uint8_t>&kind,std::vector<double>*scores){
 int n=int(PySequence_Size(tracks));if(n<0)throw std::runtime_error("Invalid track collection");v.resize(n*4);kind.resize(n);if(scores)scores->resize(n);
 for(int i=0;i<n;i++){
  Object t(PySequence_GetItem(tracks,i));if(!t.p)throw std::runtime_error("Track access failed");
  Object m(PyObject_GetAttrString(t.p,"mean"));if(!m.p)throw std::runtime_error("Missing mean");
  kind[i]=m.p!=&_Py_NoneStruct;
  Object fallback(kind[i]?nullptr:PyObject_GetAttrString(t.p,"_tlwh"));Buffer b;
  if(!buffer(kind[i]?m.p:fallback.p,b,false,4))throw std::runtime_error("Invalid packed track state");
  std::memcpy(v.data()+i*4,b.v.buf,32);
  if(scores){Object x(PyObject_GetAttrString(t.p,"score"));if(!x.p)throw std::runtime_error("Missing score");(*scores)[i]=PyFloat_AsDouble(x.p);if(PyErr_Occurred())throw std::runtime_error("Invalid score");}
 }
}
using Cost=int(*)(void*,const double*,const uint8_t*,int,const double*,const uint8_t*,int,const double*,double*);
extern "C" int y26_cost_objects(void*ctx,PyObject*a,PyObject*b,int fuse,void*cost_ctx,void*function,double*out,char*err,int cap){
 try{
  auto s=static_cast<Pack*>(ctx);if(!s||!function||!cost_ctx)throw std::runtime_error("Invalid cost context");
  states(a,s->a,s->ak,nullptr);states(b,s->b,s->bk,fuse?&s->scores:nullptr);
  int rc;{Unlocked unlock;rc=reinterpret_cast<Cost>(function)(cost_ctx,s->a.data(),s->ak.data(),int(s->ak.size()),s->b.data(),s->bk.data(),int(s->bk.size()),fuse?s->scores.data():nullptr,out);}return rc;
 }catch(const std::exception&e){PyErr_Clear();if(err&&cap)std::snprintf(err,cap,"%s",e.what());return -1;}
}
extern "C" int y26_gmc_mask(const double*boxes,int n,int w,int h,int source_w,int source_h,uint8_t*out){
 try{
  if(n<0||w<16||h<16||source_w<1||source_h<1||!out)return -1;
  cv::Mat mask(h,w,CV_8UC1,out);mask.setTo(0);mask(cv::Rect(5,5,w-10,h-10)).setTo(255);
  const double sx=double(w)/source_w,sy=double(h)/source_h;
  for(int i=0;i<n;i++){
   double a=boxes[i*4]*sx,b=boxes[i*4+1]*sy,c=boxes[i*4+2]*sx,d=boxes[i*4+3]*sy;
   if(!std::isfinite(a)||!std::isfinite(b)||!std::isfinite(c)||!std::isfinite(d))return -2;
   // Preserve original int/truncate, ceil, margins, ordering and OpenCV rectangle rasterization.
   cv::rectangle(mask,cv::Point(std::max(0,int(a)-3),std::max(0,int(b)-3)),cv::Point(std::min(w-1,int(std::ceil(c))+3),std::min(h-1,int(std::ceil(d))+3)),cv::Scalar(0),-1);
  }return 0;
 }catch(...){return -1;}
}
extern "C" int y26_gmc_indices(const float*a,const float*b,const float*back,const uint8_t*ok,const uint8_t*backok,const float*err,int n,const uint8_t*mask,int w,int h,int32_t*out){
 int count=0;
 for(int i=0;i<n;i++){
  const float x=b[2*i],y=b[2*i+1],bx=back[2*i],by=back[2*i+1];
  if(!ok[i]||!backok[i]||!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(bx)||!std::isfinite(by))continue;
  float dx=a[2*i]-bx,dy=a[2*i+1]-by,square=dx*dx+dy*dy;
  if(!(std::sqrt(square)<=1.5f)||!(err[i]<30.f)||!(x>=0&&x<w&&y>=0&&y<h))continue;
  int ix=std::min(w-1,std::max(0,int(x))),iy=std::min(h-1,std::max(0,int(y)));
  if(mask[iy*w+ix])out[count++]=i;
 }return count;
}
