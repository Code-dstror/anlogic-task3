"""Single-owner reusable exact two-stage TopK; returned rows are borrowed."""
import ctypes as C
from pathlib import Path
import numpy as np

class NativeTopK:
    def __init__(self,library):
        self.handle=None
        self.lib=C.CDLL(str(Path(library).resolve()));l=self.lib
        l.y26_topk_open.restype=C.c_void_p;l.y26_topk_close.argtypes=[C.c_void_p]
        l.y26_topk_run.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.c_int,C.c_void_p]
        l.y26_topk_run.restype=C.c_int
        self.rows=np.empty((8400,6),np.float32);self.handle=l.y26_topk_open()
        if not self.handle:raise RuntimeError('Native TopK initialization failed')
    def detections(self,boxes,scores,maximum=300,agnostic=False):
        half=boxes.dtype==np.float16 and scores.dtype==np.float16
        dtype=np.float16 if half else np.float32
        boxes=np.ascontiguousarray(boxes,dtype=dtype);scores=np.ascontiguousarray(scores,dtype=dtype)
        if boxes.shape!=(1,4,8400) or scores.shape!=(1,23,8400):raise ValueError('Unexpected dense output layout')
        if not isinstance(maximum,(int,np.integer)) or maximum<0:raise ValueError('Nonnegative integer max_det required')
        k=min(int(maximum),8400)
        if not self.handle:raise RuntimeError('Native TopK is closed')
        function=self.lib.y26_topk_run
        if half:
            if not hasattr(self.lib,'y26_topk_run16'):raise RuntimeError('FP16 TopK requires rebuilt library')
            function=self.lib.y26_topk_run16;function.argtypes=self.lib.y26_topk_run.argtypes;function.restype=C.c_int
        rc=function(self.handle,boxes.ctypes.data,scores.ctypes.data,k,int(bool(agnostic)),self.rows.ctypes.data)
        if rc==-2:raise ValueError('Nonfinite detection output')
        if rc!=k:raise RuntimeError('Native TopK failed: '+str(rc))
        return self.rows[:k]  # source_boxes immediately makes the owned copy.
    def close(self):
        if getattr(self,'handle',None):self.lib.y26_topk_close(self.handle);self.handle=None
    def __del__(self):self.close()
