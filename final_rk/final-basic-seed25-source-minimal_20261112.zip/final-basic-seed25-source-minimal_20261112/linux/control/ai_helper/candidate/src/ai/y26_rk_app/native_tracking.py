"""Opt-in batched native state/box primitives; SciPy assignment stays unchanged."""
import ctypes as C
import os
from pathlib import Path
import numpy as np

class NativeTracking:
    def __init__(self,library,packed_cost=None):
        self.cost_handle=None
        self.library=str(Path(library).resolve());self.lib=C.CDLL(self.library)
        l=self.lib;l.y26_tracking_abi.restype=C.c_int
        if l.y26_tracking_abi()!=1:raise RuntimeError('Unsupported tracking ABI')
        ptr=C.c_void_p
        l.y26_predict_warp.argtypes=[ptr,ptr,ptr,C.c_int,C.c_int,C.c_double,ptr,C.c_char_p,C.c_int]
        l.y26_predict_warp.restype=C.c_int
        l.y26_track_boxes.argtypes=[ptr,ptr,C.c_int,C.c_double,C.c_double,ptr];l.y26_track_boxes.restype=None
        l.y26_iou_cost.argtypes=[ptr,C.c_int,ptr,C.c_int,ptr,ptr];l.y26_iou_cost.restype=None
        self.pool={}
        self.batch_correction=os.environ.get('Y26_TRACKING_BATCH_CORRECTION')=='1'
        if self.batch_correction:
            if not hasattr(l,'y26_correct_batch'):raise RuntimeError('Rebuild tracking library for batch correction')
            l.y26_correct_batch.argtypes=[ptr,ptr,ptr,C.c_int,C.c_char_p,C.c_int]
            l.y26_correct_batch.restype=C.c_int
        self.packed_cost=os.environ.get('Y26_TRACKING_PACKED_COST')=='1' if packed_cost is None else bool(packed_cost)
        if self.packed_cost:
            if not hasattr(l,'y26_state_cost'):raise RuntimeError('Rebuild native tracking library for packed costs')
            l.y26_cost_open.restype=C.c_void_p;l.y26_cost_close.argtypes=[ptr]
            l.y26_state_cost.argtypes=[ptr,ptr,ptr,C.c_int,ptr,ptr,C.c_int,ptr,ptr];l.y26_state_cost.restype=C.c_int
            self.cost_handle=l.y26_cost_open()
            if not self.cost_handle:raise RuntimeError('Cost scratch allocation failed')
        self.object_pack=None
        if os.environ.get('Y26_NATIVE_OBJECT_PACK'):
            from native_exact_pack import ObjectPack
            self.object_pack=ObjectPack(os.environ['Y26_NATIVE_OBJECT_PACK'],self.lib)
    def buffers(self,name,n):
        # Grow geometrically; storage bounded by currently encountered track count.
        if name not in self.pool or self.pool[name][0].shape[0]<n:
            cap=max(16,1<<(max(1,n)-1).bit_length())
            self.pool[name]=(np.empty((cap,8),np.float64),np.empty((cap,8,8),np.float64),np.empty(cap,np.uint8))
        a,b,c=self.pool[name];return a[:n],b[:n],c[:n]
    def predict_warp(self,pool,unconfirmed,motion,dt):
        from bytetrack_cpu.basetrack import TrackState
        tracks=pool+(unconfirmed if motion is not None else [])
        if not tracks:return
        if self.object_pack and self.object_pack.predict(tracks,len(pool),int(TrackState.Tracked),dt,motion):return
        means,covs,tracked=self.buffers('state',len(tracks))
        for i,t in enumerate(tracks):means[i]=t.mean;covs[i]=t.covariance;tracked[i]=t.state==TrackState.Tracked
        h=None if motion is None else np.ascontiguousarray(motion,dtype=np.float64)
        if h is not None and h.shape!=(2,3):raise ValueError('Invalid warp shape')
        error=C.create_string_buffer(256)
        rc=self.lib.y26_predict_warp(means.ctypes.data,covs.ctypes.data,tracked.ctypes.data,len(tracks),len(pool),dt,
            None if h is None else h.ctypes.data,error,len(error))
        if rc:raise ValueError(error.value.decode())
        for i,t in enumerate(tracks):
            # Persistent track state must not point into reusable call scratch.
            if t.mean is None or not t.mean.flags.writeable:t.mean=means[i].copy()
            else:np.copyto(t.mean,means[i])
            if t.covariance is None or not t.covariance.flags.writeable:t.covariance=covs[i].copy()
            else:np.copyto(t.covariance,covs[i])
    def boxes(self,tracks,width=0,height=0):
        n=len(tracks)
        if not n:return np.empty((0,4),np.float64)
        state=np.empty((n,4),np.float64);kind=np.empty(n,np.uint8);out=np.empty_like(state)
        for i,t in enumerate(tracks):
            kind[i]=t.mean is not None;state[i]=t.mean[:4] if kind[i] else t._tlwh
        self.lib.y26_track_boxes(state.ctypes.data,kind.ctypes.data,n,width,height,out.ctypes.data)
        return out
    def cost(self,tracks,detections,fuse=False):
        n,m=len(tracks),len(detections);out=np.empty((n,m),np.float64)
        if not n or not m:return out
        if self.packed_cost:
            if self.object_pack and os.environ.get('Y26_OBJECT_COST_PACK')=='1':return self.object_pack.cost(tracks,detections,fuse,self.cost_handle,out)
            a,ak=self._states('cost_left',tracks);b,bk=self._states('cost_right',detections)
            scores=None
            if fuse:
                # Dedicated float64 score storage, not the uint8 prediction flags.
                if 'score_values' not in self.pool or len(self.pool['score_values'])<m:self.pool['score_values']=np.empty(max(16,1<<(m-1).bit_length()),np.float64)
                scores=self.pool['score_values'][:m]
                for i,d in enumerate(detections):scores[i]=d.score
            rc=self.lib.y26_state_cost(self.cost_handle,a.ctypes.data,ak.ctypes.data,n,b.ctypes.data,bk.ctypes.data,m,None if scores is None else scores.ctypes.data,out.ctypes.data)
            if rc:raise ValueError('Packed association cost failed')
            return out
        a=self.boxes(tracks);b=self.boxes(detections)
        scores=np.asarray([d.score for d in detections],dtype=np.float64) if fuse else None
        self.lib.y26_iou_cost(a.ctypes.data,n,b.ctypes.data,m,None if scores is None else scores.ctypes.data,out.ctypes.data)
        return out
    def _states(self,name,tracks):
        n=len(tracks)
        if name not in self.pool or len(self.pool[name][0])<n:
            cap=max(16,1<<(max(1,n)-1).bit_length());self.pool[name]=(np.empty((cap,4),np.float64),np.empty(cap,np.uint8))
        values,kinds=self.pool[name];values=values[:n];kinds=kinds[:n]
        for i,t in enumerate(tracks):
            kinds[i]=t.mean is not None;values[i]=t.mean[:4] if kinds[i] else t._tlwh
        return values,kinds
    def correct_matches(self,tracks,detections,matches):
        """One native call per association pass; independent result arrays per track."""
        if not self.batch_correction:return [None]*len(matches)
        n=len(matches)
        if not n:return []
        means,covs,_=self.buffers('correct_states',n)
        if 'correct_boxes' not in self.pool or len(self.pool['correct_boxes'])<n:
            self.pool['correct_boxes']=np.empty((max(16,1<<(n-1).bit_length()),4),np.float64)
        boxes=self.pool['correct_boxes'][:n]
        for i,(it,idet) in enumerate(matches):
            track=tracks[it];detection=detections[idet]
            means[i]=track.mean;covs[i]=track.covariance
            boxes[i]=detection._tlwh if detection.mean is None else detection.tlwh
        error=C.create_string_buffer(256)
        rc=self.lib.y26_correct_batch(means.ctypes.data,covs.ctypes.data,boxes.ctypes.data,n,error,len(error))
        if rc:raise ValueError(error.value.decode())
        return [(means[i].copy(),covs[i].copy()) for i in range(n)]
    def close(self):
        if getattr(self,'object_pack',None):self.object_pack.close()
        if getattr(self,'cost_handle',None):self.lib.y26_cost_close(self.cost_handle);self.cost_handle=None
    def __del__(self):self.close()
