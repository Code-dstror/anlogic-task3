"""Linux MPP/RGA integration boundary: no duplicate video decoder.

Linux sends a JSON descriptor per frame. V1 has three tensors, V2 has four; their
completion fences retired. The producer owns <=2 slots until ACK is returned.
Raw tensor paths may be shared-memory files (/dev/shm); stride is explicit.
"""
import json
import os
from pathlib import Path
import select
import sys
import threading
import time
import numpy as np

class Reader:
    def __init__(self,manifest,acks=None,timeout_s=10):
        self.file=sys.stdin.buffer if str(manifest)=='-' else open(manifest,'rb',buffering=0)
        self.buffer=b''
        self.acks=open(acks,'a',encoding='utf-8',buffering=1) if acks else None
        self.timeout=timeout_s;self.stop=threading.Event();self.mappings={};self.outstanding={};self.lock=threading.Lock();self.last={};self.schema=None;self.quarantined=None;self._close_guard=None;self.closed=False
    def _array(self,desc):
        if not desc.get('fence_complete'):raise ValueError('RGA completion fence has not retired')
        path=Path(desc['path']).resolve();shape=tuple(desc['shape']);strides=tuple(desc['strides_bytes']);offset=desc.get('offset_bytes',0)
        if (len(shape)!=3 or any(type(x) is not int or x<=0 for x in shape) or shape[2]!=3
                or len(strides)!=3 or any(type(x) is not int or x<=0 for x in strides)
                or strides[2]!=1 or strides[1]!=3 or strides[0]<shape[1]*3 or type(offset) is not int or offset<0):
            raise ValueError('Invalid uint8 HWC RGB/BGR shape/stride/offset')
        needed=(shape[0]-1)*strides[0]+(shape[1]-1)*3+3+offset
        key=str(path)
        if key not in self.mappings:
            if len(self.mappings)>=(8 if self.schema=='Y26_PREPARED_FRAME_V2' else 6):raise ValueError('Only two fixed prepared tensor slots may be mapped')
            actual=path.stat().st_size;backing=desc.get('backing_bytes',actual)
            if type(backing) is not int or not 0<needed<=backing<=actual:raise ValueError('Invalid prepared backing memory size')
            self.mappings[key]=np.memmap(path,mode='r',dtype=np.uint8,shape=(backing,))
        data=self.mappings[key]
        if 'backing_bytes' in desc and (type(desc['backing_bytes']) is not int or desc['backing_bytes']!=data.size):
            raise ValueError('Prepared mapping size changed within stream')
        if needed>data.size:raise ValueError('Tensor descriptor exceeds backing memory')
        return np.ndarray(shape,np.uint8,buffer=data,offset=offset,strides=strides)
    def read(self):
        deadline=time.monotonic()+self.timeout
        while b'\n' not in self.buffer:
            if self.stop.is_set():return None
            if sys.platform!='win32' and not select.select([self.file],[],[],.1)[0]:
                if time.monotonic()>deadline:raise TimeoutError('Linux prepared frame descriptor timed out')
                continue
            data=os.read(self.file.fileno(),65536)
            if not data:
                if self.buffer:raise ValueError('Truncated prepared frame descriptor')
                return None
            self.buffer+=data
            if len(self.buffer)>1048576:raise ValueError('Prepared descriptor exceeds bounded metadata size')
        line,self.buffer=self.buffer.split(b'\n',1)
        r=json.loads(line)
        schema=r.get('schema')
        if schema not in ('Y26_PREPARED_FRAME_V1','Y26_PREPARED_FRAME_V2'):raise ValueError('Prepared frame schema mismatch')
        if self.schema is not None and schema!=self.schema:raise ValueError('Cannot change prepared schema within one Reader')
        self.schema=schema
        if r['slot'] not in (0,1) or r['slot'] in self.outstanding:raise ValueError('Prepared slot overwritten before consumer ACK')
        if r['clock_domain'] not in ('CLOCK_MONOTONIC','RECORDED_PTS'):raise ValueError('Unsupported clock domain')
        if r.get('source_timestamp_kind') not in ('sensor_capture','linux_receive','replay_mapped_pts','recorded_pts'):raise ValueError('Explicit timestamp measurement boundary required')
        if not r.get('original_frame_key'):raise ValueError('Original frame identity required to count replay/unique frames')
        key=(r['session_id'],r['epoch'],r['camera_id']);seq=int(r['sequence']);pts=int(r['capture_timestamp_ns'])
        if key in self.last and (seq<=self.last[key][0] or pts<=self.last[key][1]):raise ValueError('Out-of-order source sequence/PTS')
        self.last[key]=(seq,pts)
        names=('source_bgr','detector_rgb','depth_rgb')
        if schema=='Y26_PREPARED_FRAME_V2':
            if r.get('shared_rgb_relation')!='BGR_CHANNEL_PERMUTATION':raise ValueError('Explicit shared RGB channel relationship required')
            names+=('source_rgb',)
        for name in names:
            if r[name]['frame_key']!=r['frame_key'] or r[name]['capture_timestamp_ns']!=pts:raise ValueError('Cross-frame tensor binding')
        if r['source_bgr']['color']!='BGR' or any(r[k]['color']!='RGB' for k in names if k!='source_bgr'):raise ValueError('Explicit source BGR/model RGB required')
        values={k:self._array(r[k]) for k in names}
        if schema=='Y26_PREPARED_FRAME_V2':
            if values['source_rgb'].shape!=values['source_bgr'].shape:raise ValueError('Shared RGB/source dimensions differ')
            # Source views must be packed so the exact full RGB digest is reusable.
            if not all(values[k].flags.c_contiguous for k in ('source_bgr','source_rgb')):raise ValueError('Shared source pixels must be packed')
        self.outstanding[r['slot']]=r
        return dict(descriptor=r,**values)
    def pixel_binding(self,frame):
        from frame_pixels import FramePixels
        r=frame['descriptor']
        if r['schema']=='Y26_PREPARED_FRAME_V1':return FramePixels(frame['source_bgr'],defer_hash=True)
        def valid():
            with self.lock:return self.outstanding.get(r['slot']) is r and not self.stop.is_set()
        return FramePixels._from_prepared_shared(frame['source_bgr'],frame['source_rgb'],valid)
    def release(self,slot):
        with self.lock:
            if self.quarantined is not None:raise RuntimeError('Native worker not retired; prepared leases quarantined')
            r=self.outstanding.get(slot)
            if r is not None:
                if self.acks:
                    self.acks.write(json.dumps(dict(schema='Y26_PREPARED_RELEASE_V1',slot=slot,frame_key=r['frame_key'],sequence=r['sequence']))+'\n')
                    self.acks.flush()
                del self.outstanding[slot]
    def guard_close(self,report):
        """Bind the owning pipeline's live retirement proof before starting it."""
        self._close_guard=report
    def quarantine(self,reason):
        with self.lock:
            if self.quarantined is None:self.quarantined=reason or 'Native retirement unknown'
            self.stop.set()
    def resume_cleanup(self):
        """Only a bound owner proven retired may clear a temporary quarantine."""
        with self.lock:
            if self.quarantined is None:return
            if self._close_guard is None or not self._close_guard()['safe_to_release']:
                raise RuntimeError('Cannot clear quarantine without native retirement proof')
            self.quarantined=None
    def close(self):
        self.stop.set()
        if self.quarantined is not None:raise RuntimeError('Cannot close/release quarantined native input mappings')
        if self.closed:return
        if self._close_guard is not None and not self._close_guard()['safe_to_release']:
            raise RuntimeError('Prepared input resources remain PENDING; no release ACK sent')
        for slot in list(self.outstanding):self.release(slot)
        if self.file is not sys.stdin.buffer:self.file.close()
        if self.acks:self.acks.close()
        self.mappings.clear();self.closed=True
