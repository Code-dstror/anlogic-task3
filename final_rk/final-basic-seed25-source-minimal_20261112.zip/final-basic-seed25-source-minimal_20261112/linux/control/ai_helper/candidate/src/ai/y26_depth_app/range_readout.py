"""Current raw range readout, with explicit target-ownership uncertainty.

Raw predictions remain in records for diagnosis. Ambiguous ownership must not
become a target's displayed range, position, size or temporal warning evidence.
This does not assert ownership when no flag was produced.
"""
import math

OWNERSHIP_UNKNOWN=frozenset(('UNKNOWN_POSSIBLE_FOREGROUND_OCCLUSION','UNKNOWN_TARGET_OVERLAP_AMBIGUOUS'))

def ownership_unknown(o):
    quality=o.get('distance_quality',o.get('quality'))
    evidence=o.get('distance_evidence',o.get('evidence')) or {}
    ownership=o.get('distance_ownership',o.get('ownership')) or {}
    return (quality in OWNERSHIP_UNKNOWN or evidence.get('status') in OWNERSHIP_UNKNOWN
            or str(ownership.get('status','')).startswith('UNKNOWN_'))

def current_range(o):
    if ownership_unknown(o):return None
    value=o.get('estimated_depth_m',o.get('distance'))
    return value if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0 else None
