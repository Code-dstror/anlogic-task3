import numpy as np
from collections import deque
import os
import os.path as osp
import copy

from .kalman_filter import KalmanFilter
from . import matching
from .basetrack import BaseTrack, TrackState
from .motion import warp_tracks
from cpu_profile import StageTimer

class STrack(BaseTrack):
    shared_kalman = KalmanFilter()
    def __init__(self, tlwh, score, detection_index=None):

        # wait activate
        self._tlwh = np.asarray(tlwh, dtype=float)
        self.kalman_filter = None
        self.mean, self.covariance = None, None
        self.is_activated = False

        self.score = score
        self.detection_index = detection_index
        self.tracklet_len = 0

    def predict(self):
        mean_state = self.mean.copy()
        if self.state != TrackState.Tracked:
            mean_state[7] = 0
        self.mean, self.covariance = self.kalman_filter.predict(mean_state, self.covariance)

    @staticmethod
    def multi_predict(stracks,dt=1.):
        if len(stracks) > 0:
            multi_mean = np.asarray([st.mean.copy() for st in stracks])
            multi_covariance = np.asarray([st.covariance for st in stracks])
            for i, st in enumerate(stracks):
                if st.state != TrackState.Tracked:
                    multi_mean[i][7] = 0
            multi_mean, multi_covariance = STrack.shared_kalman.multi_predict(multi_mean, multi_covariance,dt=dt)
            for i, (mean, cov) in enumerate(zip(multi_mean, multi_covariance)):
                stracks[i].mean = mean
                stracks[i].covariance = cov

    def activate(self, kalman_filter, frame_id):
        """Start a new tracklet"""
        self.kalman_filter = kalman_filter
        self.track_id = self.next_id()
        self.mean, self.covariance = self.kalman_filter.initiate(self.tlwh_to_xyah(self._tlwh))

        self.tracklet_len = 0
        self.state = TrackState.Tracked
        if frame_id == 1:
            self.is_activated = True
        # self.is_activated = True
        self.frame_id = frame_id
        self.start_frame = frame_id

    def re_activate(self, new_track, frame_id, new_id=False, correction=None):
        self.mean, self.covariance = correction if correction is not None else self.kalman_filter.update(
            self.mean, self.covariance, self.tlwh_to_xyah(new_track.tlwh)
        )
        self.tracklet_len = 0
        self.state = TrackState.Tracked
        self.is_activated = True
        self.frame_id = frame_id
        if new_id:
            self.track_id = self.next_id()
        self.score = new_track.score
        self.detection_index = new_track.detection_index

    def update(self, new_track, frame_id, correction=None):
        """
        Update a matched track
        :type new_track: STrack
        :type frame_id: int
        :type update_feature: bool
        :return:
        """
        self.frame_id = frame_id
        self.tracklet_len += 1

        if correction is None:
            new_tlwh = new_track.tlwh
            correction = self.kalman_filter.update(self.mean, self.covariance, self.tlwh_to_xyah(new_tlwh))
        self.mean, self.covariance = correction
        self.state = TrackState.Tracked
        self.is_activated = True

        self.score = new_track.score
        self.detection_index = new_track.detection_index

    @property
    # @jit(nopython=True)
    def tlwh(self):
        """Get current position in bounding box format `(top left x, top left y,
                width, height)`.
        """
        if self.mean is None:
            return self._tlwh.copy()
        ret = self.mean[:4].copy()
        ret[2] *= ret[3]
        ret[:2] -= ret[2:] / 2
        return ret

    @property
    # @jit(nopython=True)
    def tlbr(self):
        """Convert bounding box to format `(min x, min y, max x, max y)`, i.e.,
        `(top left, bottom right)`.
        """
        ret = self.tlwh.copy()
        ret[2:] += ret[:2]
        return ret

    @staticmethod
    # @jit(nopython=True)
    def tlwh_to_xyah(tlwh):
        """Convert bounding box to format `(center x, center y, aspect ratio,
        height)`, where the aspect ratio is `width / height`.
        """
        ret = np.asarray(tlwh).copy()
        ret[:2] += ret[2:] / 2
        ret[2] /= ret[3]
        return ret

    def to_xyah(self):
        return self.tlwh_to_xyah(self.tlwh)

    @staticmethod
    # @jit(nopython=True)
    def tlbr_to_tlwh(tlbr):
        ret = np.asarray(tlbr).copy()
        ret[2:] -= ret[:2]
        return ret

    @staticmethod
    # @jit(nopython=True)
    def tlwh_to_tlbr(tlwh):
        ret = np.asarray(tlwh).copy()
        ret[2:] += ret[:2]
        return ret

    def __repr__(self):
        return 'OT_{}_({}-{})'.format(self.track_id, self.start_frame, self.end_frame)


class BYTETracker(object):
    def __init__(self, args, frame_rate=30):
        self.tracked_stracks = []  # type: list[STrack]
        self.lost_stracks = []  # type: list[STrack]
        self.removed_stracks = []  # type: list[STrack]
        self.removed_ids = set()

        self.frame_id = 0
        self.args = args
        #self.det_thresh = args.track_thresh
        self.det_thresh = args.track_thresh + 0.1
        self.buffer_size = int(frame_rate / 30.0 * args.track_buffer)
        self.max_time_lost = self.buffer_size
        self.kalman_filter = KalmanFilter()
        self.native_backend=getattr(args,'native_backend',None)

    def association_cost(self,tracks,detections,fuse=False):
        if self.native_backend is not None:return self.native_backend.cost(tracks,detections,fuse)
        cost=matching.iou_distance(tracks,detections)
        return matching.fuse_score(cost,detections) if fuse else cost

    def correction_batch(self,tracks,detections,matches):
        if self.native_backend is not None and getattr(self.native_backend,'batch_correction',False):
            return self.native_backend.correct_matches(tracks,detections,matches)
        return [None]*len(matches)

    def update(self, output_results, img_info, img_size, camera_motion=None, source_indices=None, timings=None,
               prediction_dt=1.,recovery_allowed_ids=None):
        timer=StageTimer(timings)
        self.frame_id += 1
        activated_starcks = []
        refind_stracks = []
        lost_stracks = []
        removed_stracks = []

        if output_results.shape[1] == 5:
            scores = output_results[:, 4]
            bboxes = output_results[:, :4]
        else:
            output_results = output_results.cpu().numpy()
            scores = output_results[:, 4] * output_results[:, 5]
            bboxes = output_results[:, :4]  # x1y1x2y2
        img_h, img_w = img_info[0], img_info[1]
        scale = min(img_size[0] / float(img_h), img_size[1] / float(img_w))
        bboxes /= scale

        # Include the exact high threshold; otherwise it falls in neither pass.
        remain_inds = scores >= self.args.track_thresh
        inds_low = scores > 0.1
        inds_high = scores < self.args.track_thresh

        inds_second = np.logical_and(inds_low, inds_high)
        dets_second = bboxes[inds_second]
        dets = bboxes[remain_inds]
        scores_keep = scores[remain_inds]
        scores_second = scores[inds_second]
        source_indices=np.arange(len(scores)) if source_indices is None else np.asarray(source_indices)
        if source_indices.shape!=(len(scores),):raise ValueError('Source detection index length mismatch')
        indices_keep=source_indices[remain_inds];indices_second=source_indices[inds_second]

        if len(dets) > 0:
            '''Detections'''
            detections = [STrack(STrack.tlbr_to_tlwh(tlbr), s, int(index)) for
                          (tlbr, s,index) in zip(dets, scores_keep,indices_keep)]
        else:
            detections = []

        ''' Add newly detected tracklets to tracked_stracks'''
        unconfirmed = []
        tracked_stracks = []  # type: list[STrack]
        for track in self.tracked_stracks:
            if not track.is_activated:
                unconfirmed.append(track)
            else:
                tracked_stracks.append(track)

        ''' Step 2: First association, with high score detection boxes'''
        strack_pool = joint_stracks(tracked_stracks, self.lost_stracks)
        timer.mark('tracker_input_prepare')
        # Predict the current location with KF
        if self.native_backend is not None:
            self.native_backend.predict_warp(strack_pool,unconfirmed,camera_motion,prediction_dt)
        else:
            STrack.multi_predict(strack_pool,dt=prediction_dt)
            if camera_motion is not None:
                warp_tracks(strack_pool+unconfirmed,camera_motion)
        timer.mark('tracker_prediction_and_warp')
        association_timer=StageTimer(timings)
        dists = self.association_cost(strack_pool,detections,fuse=not self.args.mot20)
        if getattr(self.args,'gate_lost_high',False):
            dists=matching.gate_lost_high_cost(dists,strack_pool,detections,recovery_allowed_ids)
        association_timer.mark('tracker_high_cost_and_gate')
        matches, u_track, u_detection = matching.linear_assignment(dists, thresh=self.args.match_thresh)
        association_timer.mark('tracker_high_assignment')

        corrections=self.correction_batch(strack_pool,detections,matches)
        for (itracked, idet),correction in zip(matches,corrections):
            track = strack_pool[itracked]
            det = detections[idet]
            if track.state == TrackState.Tracked:
                track.update(detections[idet], self.frame_id,correction=correction)
                activated_starcks.append(track)
            else:
                track.re_activate(det, self.frame_id, new_id=False,correction=correction)
                refind_stracks.append(track)

        association_timer.mark('tracker_high_correction')
        ''' Step 3: Second association, with low score detection boxes'''
        # association the untrack to the low score detections
        if len(dets_second) > 0:
            '''Detections'''
            detections_second = [STrack(STrack.tlbr_to_tlwh(tlbr), s,int(index)) for
                          (tlbr, s,index) in zip(dets_second, scores_second,indices_second)]
        else:
            detections_second = []
        r_tracked_stracks = [strack_pool[i] for i in u_track if strack_pool[i].state == TrackState.Tracked]
        association_timer.mark('tracker_weak_input_prepare')
        dists = self.association_cost(r_tracked_stracks, detections_second)
        association_timer.mark('tracker_weak_cost')
        matches, u_track, u_detection_second = matching.linear_assignment(dists, thresh=0.5)
        association_timer.mark('tracker_weak_assignment')
        corrections=self.correction_batch(r_tracked_stracks,detections_second,matches)
        for (itracked, idet),correction in zip(matches,corrections):
            track = r_tracked_stracks[itracked]
            det = detections_second[idet]
            if track.state == TrackState.Tracked:
                track.update(det, self.frame_id,correction=correction)
                activated_starcks.append(track)
            else:
                track.re_activate(det, self.frame_id, new_id=False,correction=correction)
                refind_stracks.append(track)

        for it in u_track:
            track = r_tracked_stracks[it]
            if not track.state == TrackState.Lost:
                track.mark_lost()
                lost_stracks.append(track)

        association_timer.mark('tracker_weak_correction')
        if getattr(self.args,'recover_lost_low',False):
            recovery_timer=StageTimer(timings)
            # Active tracks get first choice of weak observations. Only unused
            # weak boxes may recover a lost ID; no weak track is initialized.
            lost_pool=[t for t in strack_pool if t.state==TrackState.Lost and
                       all(t is not newly_lost for newly_lost in lost_stracks)]
            unused_weak=[detections_second[i] for i in u_detection_second]
            if getattr(self.args,'lost_recovery_gate',False):
                lost_pool=[t for t in lost_pool if recovery_allowed_ids is not None and t.track_id in recovery_allowed_ids]
                weak_matches,_,_=matching.conservative_recovery(lost_pool,unused_weak,strack_pool+unconfirmed)
            else:
                weak_matches,_,_=matching.linear_assignment(matching.iou_distance(lost_pool,unused_weak),thresh=.5)
            corrections=self.correction_batch(lost_pool,unused_weak,weak_matches)
            for (it,idet),correction in zip(weak_matches,corrections):
                track=lost_pool[it]
                track.re_activate(unused_weak[idet],self.frame_id,new_id=False,correction=correction)
                refind_stracks.append(track)
            recovery_timer.mark('tracker_lost_recovery')

        '''Deal with unconfirmed tracks, usually tracks with only one beginning frame'''
        detections = [detections[i] for i in u_detection]
        association_timer.mark('tracker_recovery_and_unconfirmed_prepare')
        dists = self.association_cost(unconfirmed,detections,fuse=not self.args.mot20)
        association_timer.mark('tracker_unconfirmed_cost')
        matches, u_unconfirmed, u_detection = matching.linear_assignment(dists, thresh=0.7)
        association_timer.mark('tracker_unconfirmed_assignment')
        corrections=self.correction_batch(unconfirmed,detections,matches)
        for (itracked, idet),correction in zip(matches,corrections):
            unconfirmed[itracked].update(detections[idet], self.frame_id,correction=correction)
            activated_starcks.append(unconfirmed[itracked])
        for it in u_unconfirmed:
            track = unconfirmed[it]
            track.mark_removed()
            removed_stracks.append(track)

        association_timer.mark('tracker_unconfirmed_correction')
        timer.mark('tracker_association_and_correction')
        """ Step 4: Init new stracks"""
        for inew in u_detection:
            track = detections[inew]
            if track.score < self.det_thresh:
                continue
            track.activate(self.kalman_filter, self.frame_id)
            activated_starcks.append(track)
        """ Step 5: Update state"""
        for track in self.lost_stracks:
            if self.frame_id - track.end_frame > self.max_time_lost:
                track.mark_removed()
                removed_stracks.append(track)

        # print('Ramained match {} s'.format(t4-t3))

        self.tracked_stracks = [t for t in self.tracked_stracks if t.state == TrackState.Tracked]
        self.tracked_stracks = joint_stracks(self.tracked_stracks, activated_starcks)
        self.tracked_stracks = joint_stracks(self.tracked_stracks, refind_stracks)
        self.lost_stracks = sub_stracks(self.lost_stracks, self.tracked_stracks)
        self.lost_stracks.extend(lost_stracks)
        if getattr(self.args,'optimize_removed_cpu',False):
            # Same historical removal set and ordering as sub_stracks; avoid
            # scanning an ever-growing removed history on every frame.
            self.lost_stracks=[t for t in self.lost_stracks if t.track_id not in self.removed_ids]
        else:
            self.lost_stracks = sub_stracks(self.lost_stracks, self.removed_stracks)
        self.removed_stracks.extend(removed_stracks)
        self.removed_ids.update(t.track_id for t in removed_stracks)
        self.tracked_stracks, self.lost_stracks = remove_duplicate_stracks(self.tracked_stracks,self.lost_stracks,self.native_backend)
        # get scores of lost tracks
        output_stracks = [track for track in self.tracked_stracks if track.is_activated]
        timer.mark('tracker_lifecycle')

        return output_stracks


def joint_stracks(tlista, tlistb):
    exists = {}
    res = []
    for t in tlista:
        exists[t.track_id] = 1
        res.append(t)
    for t in tlistb:
        tid = t.track_id
        if not exists.get(tid, 0):
            exists[tid] = 1
            res.append(t)
    return res


def sub_stracks(tlista, tlistb):
    stracks = {}
    for t in tlista:
        stracks[t.track_id] = t
    for t in tlistb:
        tid = t.track_id
        if stracks.get(tid, 0):
            del stracks[tid]
    return list(stracks.values())


def remove_duplicate_stracks(stracksa, stracksb,native_backend=None):
    pdist = matching.iou_distance(stracksa,stracksb) if native_backend is None else native_backend.cost(stracksa,stracksb)
    pairs = np.where(pdist < 0.15)
    dupa, dupb = list(), list()
    for p, q in zip(*pairs):
        timep = stracksa[p].frame_id - stracksa[p].start_frame
        timeq = stracksb[q].frame_id - stracksb[q].start_frame
        if timep > timeq:
            dupb.append(q)
        else:
            dupa.append(p)
    resa = [t for i, t in enumerate(stracksa) if not i in dupa]
    resb = [t for i, t in enumerate(stracksb) if not i in dupb]
    return resa, resb
