// Existing GStreamer MPP decoder -> mapped NV12 -> RGA prepared views.
// No new MPP implementation, camera ownership, display or device setup here.
#include "prepared_rga.cpp"
#include <gst/gst.h>
#include <gst/app/gstappsink.h>
#include <gst/video/video.h>
#include <string>
struct Replay {GstElement* pipeline=nullptr;GstElement* sink=nullptr;void* prep=nullptr;int official=0,side=768;~Replay(){if(pipeline)gst_element_set_state(pipeline,GST_STATE_NULL);if(sink)gst_object_unref(sink);if(pipeline)gst_object_unref(pipeline);if(prep)y26_prep_close(prep);}};
extern "C" {
void* y26_replay_open(const char* path,int official,int side,char* error,int cap){
 auto p=new Replay;try{
  if(side!=512&&side!=576&&side!=640&&side!=768)throw std::runtime_error("depth size must be640/768");
  gst_init(nullptr,nullptr);p->official=official;p->side=side;p->prep=y26_prep_open();if(!p->prep)throw std::runtime_error("RGA allocation");
  gchar* escaped=g_strescape(path,nullptr);
  std::string command=std::string("filesrc location=\"")+escaped+"\" ! qtdemux ! h264parse ! mppvideodec ! video/x-raw,format=NV12 ! appsink name=frames sync=false drop=false max-buffers=2";
  g_free(escaped);GError* e=nullptr;p->pipeline=gst_parse_launch(command.c_str(),&e);
  if(e){std::string msg=e->message;g_error_free(e);throw std::runtime_error(msg);}
  if(!p->pipeline)throw std::runtime_error("GStreamer parse");p->sink=gst_bin_get_by_name(GST_BIN(p->pipeline),"frames");
  if(gst_element_set_state(p->pipeline,GST_STATE_PLAYING)==GST_STATE_CHANGE_FAILURE)throw std::runtime_error("MPP pipeline start failed");
  return p;
 }catch(const std::exception& e){if(error&&cap)snprintf(error,cap,"%s",e.what());delete p;return nullptr;}
}
// Input pixels stay mapped until synchronous RGA finishes. Returned pixels are
// caller-owned slot storage and remain valid until its ordered consumer releases.
int y26_replay_read_shared(void* handle,unsigned char* bgr,unsigned char* rgb,unsigned char* det,unsigned char* dep,
 uint64_t* pts,double* timing,int* metadata,char* error,int cap){
 auto p=static_cast<Replay*>(handle);GstSample* sample=nullptr;GstVideoFrame frame{};bool mapped=false;
 try{
  auto t=Clock::now();sample=gst_app_sink_try_pull_sample(GST_APP_SINK(p->sink),5*GST_SECOND);timing[0]=elapsed(t);
  if(!sample){if(gst_app_sink_is_eos(GST_APP_SINK(p->sink)))return 1;throw std::runtime_error("MPP sample timeout");}
  GstVideoInfo info;gst_video_info_init(&info);if(!gst_video_info_from_caps(&info,gst_sample_get_caps(sample)))throw std::runtime_error("NV12 caps missing");
  if(GST_VIDEO_INFO_WIDTH(&info)!=1920||GST_VIDEO_INFO_HEIGHT(&info)!=1080||GST_VIDEO_INFO_FORMAT(&info)!=GST_VIDEO_FORMAT_NV12)throw std::runtime_error("Unexpected decoded geometry/format");
  // Performance fixture explicitly converts the source's full range to limited
  // during its documented encode. Never interpret original full-range as limited.
  if(info.colorimetry.matrix!=GST_VIDEO_COLOR_MATRIX_BT709||info.colorimetry.range!=GST_VIDEO_COLOR_RANGE_16_235)throw std::runtime_error("Fixture requires negotiated BT709 limited-range");
  GstBuffer* buffer=gst_sample_get_buffer(sample);if(!GST_BUFFER_PTS_IS_VALID(buffer))throw std::runtime_error("Decoded frame lacks original PTS");
  *pts=GST_BUFFER_PTS(buffer);t=Clock::now();
  if(!gst_video_frame_map(&frame,&info,buffer,GST_MAP_READ))throw std::runtime_error("NV12 mapping failed");mapped=true;timing[1]=elapsed(t);
  int ys=GST_VIDEO_FRAME_PLANE_STRIDE(&frame,0),uvs=GST_VIDEO_FRAME_PLANE_STRIDE(&frame,1);
  metadata[0]=ys;metadata[1]=uvs;metadata[2]=info.colorimetry.matrix;metadata[3]=info.colorimetry.range;
  int rc=y26_prep_nv12_shared(p->prep,static_cast<const unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&frame,0)),static_cast<const unsigned char*>(GST_VIDEO_FRAME_PLANE_DATA(&frame,1)),ys,uvs,bgr,rgb,det,dep,p->official,2,p->side,timing+2,timing+6,metadata+4,error,cap);
  gst_video_frame_unmap(&frame);mapped=false;gst_sample_unref(sample);sample=nullptr;return rc;
 }catch(const std::exception& e){if(error&&cap)snprintf(error,cap,"%s",e.what());if(mapped)gst_video_frame_unmap(&frame);if(sample)gst_sample_unref(sample);return -1;}
}
int y26_replay_abi(){return 2;}
int y26_replay_read(void* handle,unsigned char* bgr,unsigned char* det,unsigned char* dep,
 uint64_t* pts,double* timing,int* metadata,char* error,int cap){
 // Old callers supply only six timing and four metadata entries.
 if(!handle)return -1;double tm[9]={};int meta[7]={};auto p=static_cast<Replay*>(handle);
 try{static_cast<Prep*>(p->prep)->rgb.resize(1920*1080*3);}catch(...){return -1;}
 int rc=y26_replay_read_shared(handle,bgr,static_cast<Prep*>(p->prep)->rgb.data(),det,dep,pts,tm,meta,error,cap);
 memcpy(timing,tm,6*sizeof(double));memcpy(metadata,meta,4*sizeof(int));return rc;
}
void y26_replay_close(void* handle){delete static_cast<Replay*>(handle);}
int y26_replay_rewind(void* handle){
 auto p=static_cast<Replay*>(handle);
 return gst_element_seek_simple(p->pipeline,GST_FORMAT_TIME,static_cast<GstSeekFlags>(GST_SEEK_FLAG_FLUSH|GST_SEEK_FLAG_KEY_UNIT),0)?0:-1;
}
}
