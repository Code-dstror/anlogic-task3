"""Single-owner, optional exact CPU LK pyramid cache; no tracking policy changes."""
import ctypes as C
from pathlib import Path
import numpy as np

class NativeFlow:
    def __init__(self,library):
        self.handle=None
        self.lib=C.CDLL(str(Path(library).resolve()));l=self.lib
        l.y26_flow_open.restype=C.c_void_p;l.y26_flow_close.argtypes=[C.c_void_p]
        l.y26_flow_run.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.c_int,
            C.c_void_p,C.c_int,C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.c_char_p,C.c_int]
        l.y26_flow_run.restype=C.c_int;self.handle=l.y26_flow_open();self.last_key=None;self.capacity=0
        if not self.handle:raise RuntimeError('Native GMC initialization failed')
    def flow(self,previous,current,points,previous_key,current_key):
        for gray in (previous,current):
            if gray.ndim!=2 or gray.dtype!=np.uint8 or not gray.flags.c_contiguous:raise ValueError('Expected packed gray')
        if previous.shape!=current.shape:raise ValueError('GMC gray geometry changed')
        points=np.ascontiguousarray(points,dtype=np.float32).reshape(-1,1,2);n=len(points)
        if n>self.capacity:
            self.capacity=max(512,n)
            self.arrays=(np.empty((self.capacity,1,2),np.float32),np.empty((self.capacity,1,2),np.float32),
                np.empty((self.capacity,1),np.uint8),np.empty((self.capacity,1),np.uint8),np.empty((self.capacity,1),np.float32))
        f,b,ok,bok,err=[a[:n] for a in self.arrays];message=C.create_string_buffer(512)
        rc=self.lib.y26_flow_run(self.handle,previous.ctypes.data,current.ctypes.data,current.shape[1],current.shape[0],
            points.ctypes.data,n,f.ctypes.data,b.ctypes.data,ok.ctypes.data,bok.ctypes.data,err.ctypes.data,
            int(self.last_key==previous_key),message,len(message))
        if rc:raise RuntimeError(message.value.decode())
        self.last_key=current_key;return f,ok,err,b,bok
    def close(self):
        if getattr(self,'handle',None):self.lib.y26_flow_close(self.handle);self.handle=None
    def __del__(self):self.close()
