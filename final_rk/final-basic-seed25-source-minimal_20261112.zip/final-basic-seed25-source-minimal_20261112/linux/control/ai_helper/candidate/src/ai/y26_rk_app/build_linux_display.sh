#!/bin/sh
# The vendor worker queues/drops the base video and is not our KMS integration.
echo 'BLOCKED: legacy display candidate is not qualified for the live video path.' >&2
echo 'Use the AI-private native/kms_ai_boundary candidate and complete the documented video-owner review first.' >&2
exit 2
