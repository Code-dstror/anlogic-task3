"""Retain prepared leases until real native retirement, with r2 compatibility.

Resource CLOSED is separate from application success. PENDING owners remain
strongly held and must be retried on the same pipeline consumer thread.
"""
import json
from pathlib import Path

# Strong references survive a failed main()/close call. No ACK, forced model
# destruction or mmap teardown is permitted while the worker/native owner lives.
# Retry close_runtime on the same consumer thread after the operation retires.
_PENDING_SHUTDOWNS={}

def close_runtime(source,stream,player,*,primary_error=None,prior_cleanup_errors=(),audit_path=None):
    if getattr(source,'_close_guard',None) is None:source.guard_close(stream.shutdown_report)
    entry=getattr(stream,'_runtime_shutdown_entry',None)
    if entry is None:
        entry=dict(source=source,stream=stream,player=player,
            first_error=None if primary_error is None else repr(primary_error),cleanup_errors=[],
            source_closed=False,player_closed=False,attempts=0)
        stream._runtime_shutdown_entry=entry
    _PENDING_SHUTDOWNS[id(stream)]=entry
    entry['attempts']+=1;source.stop.set()
    entry['cleanup_errors'].extend(prior_cleanup_errors)
    def record(stage,exc):
        if entry['first_error'] is None:entry['first_error']=repr(exc)
        entry['cleanup_errors'].append(dict(stage=stage,error=repr(exc),attempt=entry['attempts']))
    close_error=None
    try:stream.close()
    except BaseException as exc:close_error=exc
    pipeline=stream.shutdown_report()
    if entry['first_error'] is None:
        entry['first_error']=pipeline['worker_error'] or next(iter(pipeline['cleanup_errors']),None)
    if close_error is not None:record('pipeline.close',close_error)
    if not pipeline['safe_to_release']:
        try:source.quarantine(entry['first_error'] or 'Native retirement unknown')
        except BaseException as exc:record('source.quarantine',exc)
    if pipeline['safe_to_release'] and not entry['source_closed']:
        try:
            source.resume_cleanup()
            source.close();entry['source_closed']=True
        except BaseException as exc:record('source.close',exc)
    if not entry['player_closed']:
        try:player.close();entry['player_closed']=True
        except BaseException as exc:record('player.close',exc)
    closed=pipeline['safe_to_release'] and entry['source_closed'] and entry['player_closed']
    report=dict(state='CLOSED' if closed else 'PENDING',first_error=entry['first_error'],
        cleanup_errors=list(entry['cleanup_errors']),pipeline=pipeline,
        source_closed=entry['source_closed'],player_closed=entry['player_closed'],attempts=entry['attempts'],
        outstanding_slots=sorted(source.outstanding),mapped_backings=len(source.mappings),
        prepared_memory_quarantined=source.quarantined is not None)
    if audit_path is not None:
        try:Path(audit_path).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        except BaseException as exc:
            record('shutdown.audit',exc)
            report.update(first_error=entry['first_error'],cleanup_errors=list(entry['cleanup_errors']))
    if closed:_PENDING_SHUTDOWNS.pop(id(stream),None)
    return report


def close_prepared_pipeline(stream,source,player):
    """Keep the r2 public helper; real pipelines use auditable owner reports.

    Legacy stream adapters without shutdown_report retain r2's raise-on-error
    contract and quarantine. They cannot supply proof to unquarantine a Reader.
    """
    if hasattr(stream,'shutdown_report'):
        report=close_runtime(source,stream,player)
        if report['state']!='CLOSED' or report['first_error'] is not None:
            raise RuntimeError('Prepared pipeline '+report['state']+': '+str(report['first_error']))
        return report
    source.stop.set()
    entry=_PENDING_SHUTDOWNS.setdefault(id(stream),dict(source=source,stream=stream,player=player,cleanup_errors=[]))
    try:
        stream.close()
    except BaseException as error:
        entry.setdefault('first_error',repr(error))
        try:source.quarantine(str(error))
        except BaseException as cleanup:entry['cleanup_errors'].append(dict(stage='source.quarantine',error=repr(cleanup)))
        try:player.close()
        except BaseException as cleanup:entry['cleanup_errors'].append(dict(stage='player.close',error=repr(cleanup)))
        raise
    try:
        source.close()
    except BaseException as error:
        entry.setdefault('first_error',repr(error))
        try:player.close()
        except BaseException as cleanup:entry['cleanup_errors'].append(dict(stage='player.close',error=repr(cleanup)))
        raise
    try:player.close()
    except BaseException as error:
        entry.setdefault('first_error',repr(error));raise
    _PENDING_SHUTDOWNS.pop(id(stream),None)
