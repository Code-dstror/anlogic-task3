// Exact YOLO26 O2O two-stage selection. Total tie order matches NumPy stable
// argsort: score descending, original position ascending. No NMS/thresholds.
#include <algorithm>
#include <numeric>
#include <vector>
#include <cmath>
#include <new>
#include <cstdint>
#include <cstring>
#include <functional>
#ifdef _WIN32
#define API __declspec(dllexport)
#else
#define API
#endif
#if defined(Y26_TOPK_NEON) && defined(__ARM_NEON)
#include <arm_neon.h>
#endif
struct TopK {
 std::vector<int> anchors,flat;
 std::vector<float> maxima;
 std::vector<uint64_t> keys;
 TopK():anchors(8400),maxima(8400){flat.reserve(8400*23);}
};
#ifdef Y26_TOPK_KEYS
static uint64_t rank_key(float value,uint32_t index){
 uint32_t bits;std::memcpy(&bits,&value,sizeof(bits));
 if((bits&0x7fffffffu)==0)bits=0; // +0 and -0 compare equal in the reference.
 uint32_t ordered=(bits&0x80000000u)?~bits:(bits^0x80000000u);
 return (uint64_t(ordered)<<32)|uint64_t(~index);
}
#endif
template<class Iterator,class Compare>
static void select(Iterator first,Iterator middle,Iterator last,Compare compare){
#ifdef Y26_TOPK_NTH
 if(middle!=last)std::nth_element(first,middle,last,compare);
 std::sort(first,middle,compare);
#else
 std::partial_sort(first,middle,last,compare);
#endif
}
extern "C" {
API void* y26_topk_open(){try{return new TopK;}catch(...){return nullptr;}}
API void y26_topk_close(void* handle){delete static_cast<TopK*>(handle);}
API int y26_topk_run(void* handle,const float* boxes,const float* scores,int maximum,int agnostic,float* output){
 if(!handle||!boxes||!scores||!output||maximum<0||maximum>8400)return -1;
 auto s=static_cast<TopK*>(handle);
#if defined(Y26_TOPK_NEON) && defined(__ARM_NEON)
 // The same finite rejection and per-anchor maxima, four anchors per load.
 // Only maxima used for ranking are calculated; emitted score bits are copied
 // unchanged from scores, including signed zeros. No FP16 approximation.
 const uint32x4_t exponent=vdupq_n_u32(0x7f800000u);uint32x4_t invalid=vdupq_n_u32(0);
 for(int i=0;i<4*8400;i+=4){
  uint32x4_t bits=vreinterpretq_u32_f32(vld1q_f32(boxes+i));
  invalid=vorrq_u32(invalid,vceqq_u32(vandq_u32(bits,exponent),exponent));
 }
 for(int c=0;c<23;c++)for(int a=0;a<8400;a+=4){
  float32x4_t value=vld1q_f32(scores+c*8400+a);uint32x4_t bits=vreinterpretq_u32_f32(value);
  invalid=vorrq_u32(invalid,vceqq_u32(vandq_u32(bits,exponent),exponent));
  vst1q_f32(s->maxima.data()+a,c==0?value:vmaxq_f32(vld1q_f32(s->maxima.data()+a),value));
 }
 if(vmaxvq_u32(invalid))return -2;
#else
 for(int i=0;i<4*8400;i++)if(!std::isfinite(boxes[i]))return -2;
 for(int c=0;c<23;c++)for(int a=0;a<8400;a++){
  float value=scores[c*8400+a];if(!std::isfinite(value))return -2;
  if(c==0||value>s->maxima[a])s->maxima[a]=value;
 }
#endif
#ifdef Y26_TOPK_KEYS
 s->keys.resize(8400);
 for(int i=0;i<8400;i++)s->keys[i]=rank_key(s->maxima[i],uint32_t(i));
 select(s->keys.begin(),s->keys.begin()+maximum,s->keys.end(),std::greater<uint64_t>());
 for(int i=0;i<maximum;i++)s->anchors[i]=int(~uint32_t(s->keys[i]));
#else
 std::iota(s->anchors.begin(),s->anchors.end(),0);
 select(s->anchors.begin(),s->anchors.begin()+maximum,s->anchors.end(),[&](int a,int b){
  float x=s->maxima[a],y=s->maxima[b];return x>y||(x==y&&a<b);
 });
#endif
 if(agnostic){
  for(int i=0;i<maximum;i++){
   int anchor=s->anchors[i],cls=0;float value=scores[anchor];
   for(int c=1;c<23;c++)if(scores[c*8400+anchor]>value){value=scores[c*8400+anchor];cls=c;}
   for(int j=0;j<4;j++)output[i*6+j]=boxes[j*8400+anchor];
   output[i*6+4]=value;output[i*6+5]=static_cast<float>(cls);
  }
 }else{
  s->flat.resize(maximum*23);
  auto score=[&](int i){return scores[(i%23)*8400+s->anchors[i/23]];};
#ifdef Y26_TOPK_KEYS
  s->keys.resize(maximum*23);
  for(int i=0;i<maximum*23;i++)s->keys[i]=rank_key(score(i),uint32_t(i));
  select(s->keys.begin(),s->keys.begin()+maximum,s->keys.end(),std::greater<uint64_t>());
  for(int i=0;i<maximum;i++)s->flat[i]=int(~uint32_t(s->keys[i]));
#else
  std::iota(s->flat.begin(),s->flat.end(),0);
  select(s->flat.begin(),s->flat.begin()+maximum,s->flat.end(),[&](int a,int b){
   float x=score(a),y=score(b);return x>y||(x==y&&a<b);
  });
#endif
  for(int i=0;i<maximum;i++){
   int index=s->flat[i],anchor=s->anchors[index/23],cls=index%23;
   for(int j=0;j<4;j++)output[i*6+j]=boxes[j*8400+anchor];
   output[i*6+4]=scores[cls*8400+anchor];output[i*6+5]=static_cast<float>(cls);
  }
 }
 return maximum;
}
}

// Portable IEEE binary16 reader. No full 23x8400 float expansion is allocated.
static float half_value(uint16_t h){
 uint32_t sign=uint32_t(h&0x8000u)<<16,e=(h>>10)&31u,m=h&1023u,bits;
 if(e==0){
  if(!m)bits=sign;
  else {int shift=0;while(!(m&1024u)){m<<=1;shift++;}bits=sign|(uint32_t(113-shift)<<23)|((m&1023u)<<13);}
 }else if(e==31)bits=sign|0x7f800000u|(m<<13);
 else bits=sign|((e+112u)<<23)|(m<<13);
 float f;std::memcpy(&f,&bits,4);return f;
}
extern "C" API int y26_topk_run16(void* handle,const uint16_t* boxes,const uint16_t* scores,int maximum,int agnostic,float* output){
 if(!handle||!boxes||!scores||!output||maximum<0||maximum>8400)return -1;
 auto s=static_cast<TopK*>(handle);
 for(int i=0;i<4*8400;i++)if((boxes[i]&0x7c00u)==0x7c00u)return -2;
 for(int c=0;c<23;c++)for(int a=0;a<8400;a++){
  uint16_t h=scores[c*8400+a];if((h&0x7c00u)==0x7c00u)return -2;
  float v=half_value(h);if(c==0||v>s->maxima[a])s->maxima[a]=v;
 }
 std::iota(s->anchors.begin(),s->anchors.end(),0);
 select(s->anchors.begin(),s->anchors.begin()+maximum,s->anchors.end(),[&](int a,int b){
  float x=s->maxima[a],y=s->maxima[b];return x>y||(x==y&&a<b);
 });
 if(agnostic){
  for(int i=0;i<maximum;i++){
   int a=s->anchors[i],cls=0;float v=half_value(scores[a]);
   for(int c=1;c<23;c++){float x=half_value(scores[c*8400+a]);if(x>v){v=x;cls=c;}}
   for(int j=0;j<4;j++)output[i*6+j]=half_value(boxes[j*8400+a]);
   output[i*6+4]=v;output[i*6+5]=float(cls);
  }
 }else{
  s->flat.resize(maximum*23);std::iota(s->flat.begin(),s->flat.end(),0);
  auto score=[&](int i){return half_value(scores[(i%23)*8400+s->anchors[i/23]]);};
  select(s->flat.begin(),s->flat.begin()+maximum,s->flat.end(),[&](int a,int b){
   float x=score(a),y=score(b);return x>y||(x==y&&a<b);
  });
  for(int i=0;i<maximum;i++){
   int k=s->flat[i],a=s->anchors[k/23],cls=k%23;
   for(int j=0;j<4;j++)output[i*6+j]=half_value(boxes[j*8400+a]);
   output[i*6+4]=half_value(scores[cls*8400+a]);output[i*6+5]=float(cls);
  }
 }
 return maximum;
}
