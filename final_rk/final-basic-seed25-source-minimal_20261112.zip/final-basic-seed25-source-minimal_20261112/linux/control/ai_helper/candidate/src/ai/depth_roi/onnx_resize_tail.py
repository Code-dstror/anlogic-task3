"""Optional ONNX Resize-tail preparation; not an RKNN support/accuracy claim.

Run only for a depth output that does not already include its resize. Keeps the
same align_corners intermediate stage; do not append a second 768x768 resize to
an already resized export. RKNN compilation and tensor-byte costs remain to test.
"""
import argparse
from pathlib import Path

def main():
    import onnx
    import numpy as np
    from onnx import helper,numpy_helper
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--depth-output',required=True);p.add_argument('--height',type=int,default=768)
    p.add_argument('--width',type=int,default=768);a=p.parse_args()
    if a.output.exists():raise FileExistsError(a.output)
    model=onnx.load(a.input)
    if min(x.version for x in model.opset_import if x.domain=='')<11:raise ValueError('Resize needs opset >=11')
    out=next(o for o in model.graph.output if o.name==a.depth_output)
    dims=[d.dim_value for d in out.type.tensor_type.shape.dim]
    if len(dims)!=4 or dims[0:2]!=[1,1] or min(dims)<1:raise ValueError('Require static [1,1,H,W] scalar depth')
    if dims[2:]==[a.height,a.width]:raise ValueError('Depth output already resized; do not duplicate')
    if min(a.height,a.width)<1:raise ValueError('Positive dimensions required')
    prefix='roi_depth_resize_tail'
    names={v.name for v in model.graph.initializer}|{n for op in model.graph.node for n in list(op.input)+list(op.output)}
    if any(n.startswith(prefix) for n in names):raise ValueError('Tail names already present')
    sizes=prefix+'_sizes';new=prefix+'_output'
    model.graph.initializer.append(numpy_helper.from_array(np.array([1,1,a.height,a.width],np.int64),sizes))
    model.graph.node.append(helper.make_node('Resize',[a.depth_output,'','',sizes],[new],name=prefix,
                                            mode='linear',coordinate_transformation_mode='align_corners'))
    out.name=new;out.type.tensor_type.shape.dim[2].dim_value=a.height;out.type.tensor_type.shape.dim[3].dim_value=a.width
    onnx.checker.check_model(model);onnx.save(model,a.output)
    print('ONNX_TAIL_WRITTEN; RKNN and board NOT_RUN; original model unchanged')

if __name__=='__main__':main()
