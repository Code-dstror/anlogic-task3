"""Explicit depth geometry selected by route: official letterbox / LC64 stretch.

The depth sampler follows raw->full model input->content crop->source with its
established align-corners convention. Camera K follows RGB pixel-centre resize.
"""
import cv2
import numpy as np

PROFILES={'IG00':dict(size=768,resize='stretch'),'IG01':dict(size=640,resize='stretch'),
          'IG02':dict(size=768,resize='letterbox'),'IG03':dict(size=640,resize='letterbox')}

def geometry(width,height,size,resize):
    if resize not in ('stretch','letterbox') or size not in (512,576,640,768):raise ValueError('Unknown depth geometry')
    if resize=='stretch':nw=nh=size;left=top=0
    else:
        nw,nh=round(width*size/max(width,height)),round(height*size/max(width,height))
        left,top=(size-nw)//2,(size-nh)//2
    return dict(width=width,height=height,size=size,resize=resize,content_width=nw,content_height=nh,
        left=left,top=top,sx=nw/width,sy=nh/height,pad_value=114,
        content_box=None if resize=='stretch' else [left,top,nw,nh],
        depth_mapping='raw->model_input align_corners; content crop->source align_corners',
        input_geometry='RGB OpenCV linear pixel-centre resize; pad114')

class DepthPreprocessor:
    def __init__(self,size=768,resize='stretch',reuse=True):
        self.size=size;self.resize=resize;self.reuse=reuse;self.source=None;self.output=None;self.resized=None;self.source_shape=None
    def prepare(self,bgr,*,source_rgb=None):
        h,w=bgr.shape[:2];g=geometry(w,h,self.size,self.resize);nw,nh=g['content_width'],g['content_height']
        if not self.reuse or self.output is None or self.source_shape!=bgr.shape:
            self.source_shape=bgr.shape;self.source=None;self.output=np.empty((self.size,self.size,3),np.uint8)
            self.resized=np.empty((nh,nw,3),np.uint8)
        if source_rgb is None:
            if self.source is None:self.source=np.empty_like(bgr)
            cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB,dst=self.source);rgb=self.source
        else:
            if (source_rgb.shape!=bgr.shape or source_rgb.dtype!=np.uint8
                or not source_rgb.flags.c_contiguous or source_rgb.flags.writeable):
                raise ValueError('Shared depth source must be source-sized, contiguous read-only RGB uint8')
            rgb=source_rgb
        if self.resize=='stretch':cv2.resize(rgb,(self.size,self.size),dst=self.output,interpolation=cv2.INTER_LINEAR)
        else:
            cv2.resize(rgb,(nw,nh),dst=self.resized,interpolation=cv2.INTER_LINEAR)
            self.output.fill(114);self.output[g['top']:g['top']+nh,g['left']:g['left']+nw]=self.resized
        return self.output,g
