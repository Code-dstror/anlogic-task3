"""Same-image classical lane candidates. Experimental; no FPGA/GT substitution."""
from dataclasses import dataclass
from hashlib import sha256
import json
import cv2
import numpy as np

from warning_contracts import RegionContact

PARAMS=dict(width=640,roi_top=.48,roi_bottom=.94,edge_low=50,edge_high=140,
            hough_threshold=22,min_length=28,max_gap=24,inlier_pixels=9,
            minimum_vertical_support=.15,retention_fraction=.012)


@dataclass(frozen=True)
class LaneCandidate:
    frame_key: str
    quality: str
    rows: tuple
    segments: tuple
    diagnostics: dict


def _fit(segments,width,height):
    if len(segments)<2:return None
    points=np.array([(x,y) for s in segments for x,y in ((s[0],s[1]),(s[2],s[3]))],float)
    best=None
    for x1,y1,x2,y2 in segments:
        if abs(y2-y1)<1:continue
        slope=(x2-x1)/(y2-y1);intercept=x1-slope*y1
        errors=np.abs(points[:,0]-(slope*points[:,1]+intercept))
        mask=errors<=PARAMS['inlier_pixels']
        rank=(int(mask.sum()),float(np.ptp(points[mask,1])) if mask.any() else 0)
        if best is None or rank>best[0]:best=(rank,mask)
    if best is None or best[0][0]<4:return None
    selected=points[best[1]]
    if np.ptp(selected[:,1])<height*PARAMS['minimum_vertical_support']:return None
    matrix=np.column_stack((selected[:,1],np.ones(len(selected))))
    slope,intercept=np.linalg.lstsq(matrix,selected[:,0],rcond=None)[0]
    residual=np.abs(selected[:,0]-(slope*selected[:,1]+intercept))
    if np.percentile(residual,90)>PARAMS['inlier_pixels']:return None
    return dict(slope=float(slope),intercept=float(intercept),y0=float(selected[:,1].min()),
                y1=float(selected[:,1].max()),inlier_points=len(selected),residual_p90=float(np.percentile(residual,90)))


def estimate(rgb,frame,*,excluded_mask=None,near_y=None):
    if (not isinstance(rgb,np.ndarray) or rgb.dtype!=np.uint8 or rgb.shape!=(frame.height,frame.width,3)
            or sha256(rgb.tobytes()).hexdigest()!=frame.source_rgb_sha256):
        raise ValueError('software lane requires the exact current source RGB')
    w=PARAMS['width'];h=round(frame.height*w/frame.width)
    image=cv2.resize(rgb,(w,h),interpolation=cv2.INTER_AREA)
    gray=cv2.cvtColor(image,cv2.COLOR_RGB2GRAY)
    hsv=cv2.cvtColor(image,cv2.COLOR_RGB2HSV)
    white=(hsv[:,:,1]<85)&(hsv[:,:,2]>150)
    yellow=(hsv[:,:,0]>=12)&(hsv[:,:,0]<=42)&(hsv[:,:,1]>65)&(hsv[:,:,2]>90)
    colors=cv2.dilate((white|yellow).astype(np.uint8),np.ones((5,5),np.uint8))
    edges=cv2.Canny(cv2.GaussianBlur(gray,(5,5),0),PARAMS['edge_low'],PARAMS['edge_high'])
    road=np.zeros((h,w),np.uint8)
    roi=np.array([[.43*w,.48*h],[.57*w,.48*h],[.98*w,.94*h],[.02*w,.94*h]],np.int32)
    cv2.fillConvexPoly(road,roi,255)
    edges=cv2.bitwise_and(edges,edges,mask=(road*(colors>0)).astype(np.uint8))
    if excluded_mask is not None:
        if excluded_mask.dtype!=np.bool_ or excluded_mask.shape!=(frame.height,frame.width):
            raise ValueError('Source-view boolean ego mask required')
        small=cv2.resize(excluded_mask.astype(np.uint8),(w,h),interpolation=cv2.INTER_NEAREST)
        edges[small>0]=0
    if near_y is not None:
        if not .48<float(near_y)<=1:raise ValueError('Invalid reviewed near boundary')
        edges[int(h*near_y):]=0
    lines=cv2.HoughLinesP(edges,1,np.pi/180,threshold=PARAMS['hough_threshold'],
                          minLineLength=PARAMS['min_length'],maxLineGap=PARAMS['max_gap'])
    groups={'left':[],'right':[]};kept=[]
    for x1,y1,x2,y2 in ([] if lines is None else lines[:,0]):
        if abs(int(y2)-int(y1))<12:continue
        a=(int(x2)-int(x1))/(int(y2)-int(y1));xm=(x1+x2)/2
        side='left' if -.0>a>=-1.6 and xm<w*.58 else 'right' if 0<a<=1.6 and xm>w*.42 else None
        if side:
            line=tuple(map(int,(x1,y1,x2,y2)));groups[side].append(line);kept.append((*line,side))
    fits={name:_fit(values,w,h) for name,values in groups.items()}
    diag=dict(source='RK_SOFTWARE_RGB_CANNY_HOUGH_EXPERIMENT',fpga_lane_used=False,ground_truth_used=False,
              parameters=PARAMS,fits=fits,model_confidence=None,ego_lane_identity='UNVERIFIED')
    diag.update(ego_exclusion_applied=excluded_mask is not None,reviewed_near_y=near_y,
                full_road_area_segmentation=False)
    scale=frame.width/w
    segments=tuple(dict(x1=s[0]*scale,y1=s[1]*scale,x2=s[2]*scale,y2=s[3]*scale,side=s[4]) for s in kept)
    def unknown(reason):return LaneCandidate(frame.key,reason,(),segments,diag)
    if any(v is None for v in fits.values()):return unknown('UNKNOWN_MISSING_OR_SHORT_LANE_SIDES')
    l,r=fits['left'],fits['right']
    y0=max(l['y0'],r['y0']);y1=min(l['y1'],r['y1'])
    if y1-y0<h*.12:return unknown('UNKNOWN_INSUFFICIENT_SHARED_Y_SUPPORT')
    ys=np.linspace(y0,y1,12)
    left=l['slope']*ys+l['intercept'];right=r['slope']*ys+r['intercept']
    if (np.any(left<0) or np.any(right>=w) or np.any(right-left<w*.08) or np.any(right-left>w*.85)
            or np.any((left+right)/2<w*.22) or np.any((left+right)/2>w*.78)):
        return unknown('UNKNOWN_AMBIGUOUS_LANE_GEOMETRY')
    rows=tuple(dict(y=float(y*scale),left=float(a*scale),right=float(b*scale)) for y,a,b in zip(ys,left,right))
    return LaneCandidate(frame.key,'CANDIDATE_SOFTWARE_LANE_UNVERIFIED',rows,segments,diag)


class SoftwareLaneRegion:
    def __init__(self,candidate):
        self.candidate=candidate
        self.evidence_source=candidate.diagnostics.get('source','RK_SOFTWARE_LANE')
        self.region_id='software-lane:'+sha256(json.dumps([PARAMS,self.evidence_source],sort_keys=True).encode()).hexdigest()[:16]

    def evaluate(self,frame,target):
        target.validate(frame);c=self.candidate
        if frame.key!=c.frame_key:raise ValueError('cross-frame lane region rejected')
        def unknown(reason):return RegionContact(target,None,None,self.region_id,self.evidence_source,reason)
        if c.quality not in ('CANDIDATE_SOFTWARE_LANE_UNVERIFIED','CANDIDATE_YOLOP_ROAD_LANE_UNVERIFIED'):
            return unknown(c.quality if c.quality.startswith('UNKNOWN') else 'UNKNOWN_UNSUPPORTED_LANE_QUALITY')
        if len(c.rows)<2:return unknown('UNKNOWN_INSUFFICIENT_LANE_ROWS')
        values=np.array([[r['y'],r['left'],r['right']] for r in c.rows],dtype=float)
        if (not np.isfinite(values).all() or np.any(np.diff(values[:,0])<=0)
                or np.any(values[:,0]<0) or np.any(values[:,0]>=frame.height)
                or np.any(values[:,1]<0) or np.any(values[:,2]>frame.width)
                or np.any(values[:,1]>=values[:,2])):
            return unknown('UNKNOWN_INVALID_LANE_GEOMETRY')
        x=(target.bbox_source_xyxy[0]+target.bbox_source_xyxy[2])/2;y=target.bbox_source_xyxy[3]
        if y>=frame.height-1 or not c.rows[0]['y']<=y<=c.rows[-1]['y']:
            return unknown('UNKNOWN_OUTSIDE_SUPPORTED_LANE_ROWS')
        left=float(np.interp(y,[r['y'] for r in c.rows],[r['left'] for r in c.rows]))
        right=float(np.interp(y,[r['y'] for r in c.rows],[r['right'] for r in c.rows]))
        margin=frame.width*PARAMS['retention_fraction']
        return RegionContact(target,left<=x<=right,max(0,left-margin)<=x<=min(frame.width,right+margin),
                             self.region_id,self.evidence_source,c.quality)
