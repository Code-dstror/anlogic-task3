"""Elapsed-time region events; no model, tracker, image library, or board API.

Time is provided by the caller with an explicit clock domain. Media PTS replay
does not measure live processing latency or qualify production tickets.
"""
from dataclasses import asdict,dataclass
from hashlib import sha256
import json
import math


@dataclass(frozen=True)
class TimePolicy:
    enter_ms: float = 150
    exit_ms: float = 250
    missing_ms: float = 350
    max_frame_gap_ms: float = 250
    max_measurement_age_ms: float = 250
    min_enter_observations: int = 2
    min_exit_observations: int = 2
    observation_confidence: float = .25
    scope: str = 'OFFLINE_EXPERIMENT_NOT_APPROVED_WARNING_THRESHOLDS'

    def __post_init__(self):
        if self.scope!='OFFLINE_EXPERIMENT_NOT_APPROVED_WARNING_THRESHOLDS': raise ValueError('Experimental scope required')
        for key in ('enter_ms','exit_ms','missing_ms','max_frame_gap_ms','max_measurement_age_ms'):
            v=getattr(self,key)
            if type(v) not in (int,float) or not math.isfinite(v) or v<=0: raise ValueError('Positive finite duration required')
        for key in ('min_enter_observations','min_exit_observations'):
            if type(getattr(self,key)) is not int or getattr(self,key)<2: raise ValueError('At least two fresh observations required')
        if type(self.observation_confidence) not in (int,float) or not math.isfinite(self.observation_confidence) or not 0<=self.observation_confidence<=1:
            raise ValueError('Invalid confidence threshold')


class TemporalWarning:
    def __init__(self,policy: TimePolicy):
        self.policy=policy
        self.policy_sha256=sha256(json.dumps(asdict(policy),sort_keys=True).encode()).hexdigest()
        self.states={}; self.context=None; self.last=None; self.region_id=None; self.counter=0

    def _event(self,stamp,tid,state,action,reason):
        f=stamp.identity
        return dict(event_id=state['event_id'],track_id=tid,class_id=state['class_id'],
                    action=action,reason=reason,frame_key=f.key,sequence=f.sequence,
                    timestamp_ns=stamp.timestamp_ns,clock_domain=stamp.clock_domain,
                    policy_sha256=self.policy_sha256,warning_kind='REGION_ONLY',
                    distance_m=None,collision_risk='UNKNOWN')

    def _reset(self,stamp,reason):
        out=[self._event(stamp,k,s,'ENDED_UNKNOWN',reason) for k,s in self.states.items() if s['event_id']]
        self.states.clear(); return out

    def update(self,stamp,contacts,*,region_id):
        f=stamp.identity
        ids=set()
        if not region_id: raise ValueError('Region provider identity required')
        for c in contacts:
            c.validate(f)
            if c.region_id!=region_id or c.target.track_id in ids: raise ValueError('Duplicate target or mixed region providers')
            ids.add(c.target.track_id)
        context=(f.context,stamp.clock_domain)
        if self.last and context==self.context and (f.sequence<=self.last.identity.sequence or stamp.timestamp_ns<=self.last.timestamp_ns):
            raise ValueError('Duplicate/out-of-order source frame or timestamp')
        events=[]
        if self.last and context!=self.context: events+=self._reset(stamp,'CONTEXT_OR_CLOCK_CHANGED')
        elif self.last and region_id!=self.region_id: events+=self._reset(stamp,'REGION_PROVIDER_CHANGED')
        elif self.last and (stamp.timestamp_ns-self.last.timestamp_ns)/1e6>self.policy.max_frame_gap_ms:
            events+=self._reset(stamp,'SOURCE_TIME_GAP')
        self.context=context; self.last=stamp; self.region_id=region_id
        stale=stamp.age_ms>self.policy.max_measurement_age_ms
        present=set(); objects=[]
        now=stamp.observed_at_ns if stale else stamp.timestamp_ns
        for c in ([] if stale else contacts):
            o=c.target
            if o.confidence<self.policy.observation_confidence: continue
            tid=o.track_id; present.add(tid)
            s=self.states.get(tid)
            if s and s['class_id']!=o.class_id:
                if s['event_id']: events.append(self._event(stamp,tid,s,'ENDED_UNKNOWN','TRACK_CLASS_CHANGED'))
                del self.states[tid]; s=None
            if s is None:
                s=dict(class_id=o.class_id,event_id=None,enter_since=None,exit_since=None,
                       enter_count=0,exit_count=0,last_valid_ns=now,last_observed_ns=now)
                self.states[tid]=s
            s['last_observed_ns']=now
            known=c.inside_entry is not None
            if not known:
                s.update(enter_since=None,exit_since=None,enter_count=0,exit_count=0)
                if s['event_id'] and (now-s['last_valid_ns'])/1e6>=self.policy.missing_ms:
                    events.append(self._event(stamp,tid,s,'ENDED_UNKNOWN','REGION_EVIDENCE_UNAVAILABLE'))
                    s['event_id']=None
                status='UNKNOWN'
            else:
                s['last_valid_ns']=now
                if s['event_id']:
                    s['enter_since']=None; s['enter_count']=0
                    if c.inside_retention:
                        s['exit_since']=None; s['exit_count']=0; status='ACTIVE'
                    else:
                        if s['exit_since'] is None: s['exit_since']=now
                        s['exit_count']+=1; status='CLEAR_PENDING'
                        if (now-s['exit_since'])/1e6>=self.policy.exit_ms and s['exit_count']>=self.policy.min_exit_observations:
                            events.append(self._event(stamp,tid,s,'CLEARED','OBSERVED_OUTSIDE_RETENTION_REGION'))
                            s.update(event_id=None,exit_since=None,exit_count=0); status='CLEARED'
                else:
                    if c.inside_entry:
                        if s['enter_since'] is None: s['enter_since']=now
                        s['enter_count']+=1; status='CANDIDATE'
                        if (now-s['enter_since'])/1e6>=self.policy.enter_ms and s['enter_count']>=self.policy.min_enter_observations:
                            self.counter+=1
                            s['event_id']=f'{f.session}:{f.epoch}:region:{self.counter}'
                            events.append(self._event(stamp,tid,s,'ACTIVATED','ELAPSED_TIME_AND_FRESH_OBSERVATIONS'))
                            s.update(enter_since=None,enter_count=0); status='ACTIVE'
                    else:
                        s.update(enter_since=None,enter_count=0); status='INACTIVE'
            objects.append({**asdict(o),'inside_entry':c.inside_entry,'inside_retention':c.inside_retention,
                'region_source':c.evidence_source,'region_quality':c.quality,'warning_state':status,
                'danger_level':'UNKNOWN' if not known else 'REGION_WARNING' if s['event_id'] else 'PENDING' if status=='CANDIDATE' else 'OUTSIDE_REGION',
                'event_id':s['event_id'],'entry_observations':s['enter_count'],
                'entry_elapsed_ms':0 if s['enter_since'] is None else (now-s['enter_since'])/1e6,
                'exit_elapsed_ms':0 if s['exit_since'] is None else (now-s['exit_since'])/1e6,
                'distance':{'status':'UNAVAILABLE','meters':None,'source':'NONE'},'collision_risk':'UNKNOWN'})
        missing=[]
        for tid,s in list(self.states.items()):
            if tid in present: continue
            s.update(enter_since=None,exit_since=None,enter_count=0,exit_count=0)
            duration=(now-s['last_valid_ns'])/1e6
            if s['event_id']:
                missing.append(dict(track_id=tid,event_id=s['event_id'],bbox_source_xyxy=None,
                                    danger_level='UNKNOWN',missing_ms=duration))
            if duration>=self.policy.missing_ms:
                if s['event_id']: events.append(self._event(stamp,tid,s,'ENDED_UNKNOWN','OBSERVATION_LOST_OR_EXPIRED'))
                del self.states[tid]
        return dict(schema='TIME_REGION_WARNING_V1',frame=asdict(f),frame_key=f.key,
            timestamp_ns=stamp.timestamp_ns,clock_domain=stamp.clock_domain,time_source=stamp.time_source,
            measurement_age_ms=stamp.age_ms,region_id=region_id,policy_sha256=self.policy_sha256,
            objects=objects,missing_observations=missing,event_transitions=events,
            open_event_count=sum(bool(s['event_id']) for s in self.states.values()),
            dropped_reason='MEASUREMENT_EXPIRED' if stale else None,
            warning_kind='REGION_ONLY',distance_enabled=False,collision_risk='UNKNOWN',
            production_real='NOT_VERIFIED',hdmi='NOT_RUN')

    def finish(self):
        return self._reset(self.last,'OFFLINE_STREAM_END') if self.last else []
