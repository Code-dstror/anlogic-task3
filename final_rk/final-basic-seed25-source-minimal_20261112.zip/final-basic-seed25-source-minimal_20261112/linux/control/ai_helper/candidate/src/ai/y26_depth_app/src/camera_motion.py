"""Prediction-only sparse background motion, inspired by BoT-SORT GMC.

Original local implementation: masked corners, forward/backward LK, RANSAC
similarity, explicit source-frame lineage and conservative validity checks.
This is image motion, not calibrated vehicle ego-motion or a lane provider.
"""
from dataclasses import dataclass
from hashlib import sha256
import math
import os
import cv2
import numpy as np
from frame_pixels import FramePixels
from cpu_profile import StageTimer


@dataclass(frozen=True)
class MotionEvidence:
    frame_key: str
    previous_frame_key: str | None
    timestamp_ns: int
    previous_timestamp_ns: int | None
    clock_domain: str
    status: str
    matrix: tuple | None
    diagnostics: dict


class CameraMotion:
    def __init__(self, width=640, maximum_gap_ms=250, minimum_inliers=20, maximum_corners=400,
                 feature_policy='adaptive',reuse_buffers=False,native_library=None):
        self.width=width;self.gap_ms=maximum_gap_ms;self.minimum_inliers=minimum_inliers
        if maximum_corners<minimum_inliers:raise ValueError('Too few GMC features')
        self.maximum_corners=maximum_corners
        if feature_policy!='adaptive':raise ValueError('Only adaptive GMC is supported by this application')
        self.feature_policy=feature_policy
        self.feature_age=0;self.feature_timestamp_ns=None
        self.last=None;self.gray=None;self.points=None
        self.reuse_buffers=bool(reuse_buffers);self.buffers=None;self.buffer_index=0
        self.native_flow=None
        if native_library:
            from native_gmc import NativeFlow
            self.native_flow=NativeFlow(native_library)
        self.native_pack=None
        if os.environ.get('Y26_GMC_EXACT_PACK'):
            from native_exact_pack import GmcPack
            self.native_pack=GmcPack(os.environ['Y26_GMC_EXACT_PACK'])

    def reset(self):
        self.last=None;self.gray=None;self.points=None
        self.feature_age=0;self.feature_timestamp_ns=None

    def update(self,stamp,bgr,boxes,*,pixel_binding=None,timings=None):
        timer=StageTimer(timings)
        f=stamp.identity
        if bgr.dtype!=np.uint8 or bgr.shape!=(f.height,f.width,3):
            raise ValueError('GMC requires current source uint8 BGR image')
        if pixel_binding is not None:
            if not isinstance(pixel_binding,FramePixels) or not pixel_binding.matches(bgr,f):
                raise ValueError('GMC read-only source binding differs')
        elif sha256(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB).tobytes()).hexdigest()!=f.source_rgb_sha256:
            raise ValueError('GMC source pixels do not match current frame')
        previous=self.last
        same=previous is not None and f.context==previous.identity.context and stamp.clock_domain==previous.clock_domain
        if same and (f.sequence<=previous.identity.sequence or stamp.timestamp_ns<=previous.timestamp_ns):
            raise ValueError('GMC refuses duplicate/out-of-order frames')
        dt=None if previous is None else (stamp.timestamp_ns-previous.timestamp_ns)/1e6
        reset=not same or dt>self.gap_ms or stamp.age_ms>self.gap_ms
        timer.mark('gmc_binding_and_context')
        w=min(self.width,f.width);h=round(f.height*w/f.width)
        prepared_gray=pixel_binding.gmc_gray(w,h) if pixel_binding is not None else None
        if self.reuse_buffers:
            if self.buffers is None or self.buffers[0].shape!=(h,w,3):
                self.buffers=(np.empty((h,w,3),np.uint8),[np.empty((h,w),np.uint8) for _ in range(2)],np.empty((h,w),np.uint8))
                self.buffer_index=0
            small,grays,mask=self.buffers
            gray=grays[self.buffer_index];self.buffer_index=1-self.buffer_index
            # Preserve resize-then-gray order, interpolation and exact pixels.
            if prepared_gray is None:
                cv2.resize(bgr,(w,h),dst=small,interpolation=cv2.INTER_AREA)
                cv2.cvtColor(small,cv2.COLOR_BGR2GRAY,dst=gray)
            else:np.copyto(gray,prepared_gray)  # Owned history must survive source-slot reuse.
        else:
            if prepared_gray is None:
                small=cv2.resize(bgr,(w,h),interpolation=cv2.INTER_AREA)
                gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
            else:gray=prepared_gray.copy()
            mask=np.empty((h,w),np.uint8)
        timer.mark('gmc_resize_gray')
        if self.native_pack:self.native_pack.mask(boxes,w,h,f.width,f.height,mask)
        else:
            mask.fill(0);mask[5:h-5,5:w-5]=255
            scale=np.array([w/f.width,h/f.height,w/f.width,h/f.height])
            for box in boxes:
                a,b,c,d=np.asarray(box,float)*scale
                if not np.isfinite([a,b,c,d]).all():raise ValueError('Nonfinite GMC exclusion box')
                cv2.rectangle(mask,(max(0,int(a)-3),max(0,int(b)-3)),
                              (min(w-1,int(math.ceil(c))+3),min(h-1,int(math.ceil(d))+3)),0,-1)
        timer.mark('gmc_mask')
        next_points=None;survivors=None
        timer.mark('gmc_features')
        diagnostics=dict(working_resolution=[w,h],features=0 if next_points is None else len(next_points),
                         full_resolution=[f.width,f.height],quality_is_probability=False)
        status='UNKNOWN_GMC_INITIAL_OR_CONTEXT_GAP';matrix=None
        if not reset and self.points is not None and len(self.points)>=self.minimum_inliers:
            lk=dict(winSize=(21,21),maxLevel=3,
                    criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
            if self.native_flow:
                forward,ok,error,backward,back_ok=self.native_flow.flow(self.gray,gray,self.points,previous.identity.key,f.key)
            else:forward,ok,error=cv2.calcOpticalFlowPyrLK(self.gray,gray,self.points,None,**lk)
            if not self.native_flow and forward is not None:
                backward,back_ok,_=cv2.calcOpticalFlowPyrLK(gray,self.gray,forward,None,**lk)
            elif not self.native_flow:backward=back_ok=None
            timer.mark('gmc_flow_bidirectional')
            status='UNKNOWN_GMC_INSUFFICIENT_CORRESPONDENCES'
            if backward is not None:
                a=self.points.reshape(-1,2);b=forward.reshape(-1,2)
                if self.native_pack:
                    indices=self.native_pack.indices(self.points,forward,backward,ok,back_ok,error,mask)
                else:
                    finite=np.isfinite(b).all(1)&np.isfinite(backward.reshape(-1,2)).all(1)
                    valid=(ok.ravel()>0)&(back_ok.ravel()>0)&finite
                    valid&=np.linalg.norm(a-backward.reshape(-1,2),axis=1)<=1.5
                    valid&=(error.ravel()<30)&(b[:,0]>=0)&(b[:,0]<w)&(b[:,1]>=0)&(b[:,1]<h)
                    indices=np.flatnonzero(valid)
                    indices=indices[mask[np.clip(b[indices,1].astype(int),0,h-1),np.clip(b[indices,0].astype(int),0,w-1)]>0]
                a=a[indices];b=b[indices];diagnostics['correspondences']=len(a)
                timer.mark('gmc_correspondence_filter')
                if len(a)>=self.minimum_inliers:
                    affine,inliers=cv2.estimateAffinePartial2D(a,b,method=cv2.RANSAC,ransacReprojThreshold=2.,
                        maxIters=2000,confidence=.99,refineIters=10)
                    timer.mark('gmc_ransac')
                    if affine is not None and inliers is not None and np.isfinite(affine).all():
                        keep=inliers.ravel()>0;n=int(keep.sum());ratio=n/len(a)
                        residual=np.linalg.norm(a@affine[:,:2].T+affine[:,2]-b,axis=1)
                        spread=np.ptp(a[keep],axis=0) if n else np.zeros(2)
                        scale_factor=float(np.hypot(affine[0,0],affine[1,0]))
                        angle=math.degrees(math.atan2(affine[1,0],affine[0,0]))
                        median=float(np.median(residual[keep])) if n else 1e9
                        diagnostics.update(inliers=n,inlier_ratio=ratio,median_residual_px=median,
                            scale=scale_factor,rotation_deg=angle,background_spread=spread.tolist())
                        valid=(n>=self.minimum_inliers and ratio>=.5 and median<=1.5
                            and spread[0]>=w*.2 and spread[1]>=h*.15
                            and .9<=scale_factor<=1.1 and abs(angle)<=5
                            and abs(affine[0,2])<=w*.15 and abs(affine[1,2])<=h*.15)
                        status='VALID_BACKGROUND_SIMILARITY' if valid else 'UNKNOWN_GMC_QUALITY_REJECTED'
                        if valid:
                            # Reuse only current-frame background RANSAC inliers,
                            # never failed flow points or foreground-masked points.
                            survivors=np.ascontiguousarray(b[keep],dtype=np.float32).reshape(-1,1,2)
                            # S^-1 H S, including rounded height resize geometry.
                            sx,sy=w/f.width,h/f.height
                            full=np.diag([1/sx,1/sy])@affine[:,:2]@np.diag([sx,sy])
                            translation=np.diag([1/sx,1/sy])@affine[:,2]
                            matrix=tuple(tuple(float(x) for x in row) for row in np.column_stack([full,translation]))
        elif not reset:
            status='UNKNOWN_GMC_INSUFFICIENT_FEATURES'
        timer.mark('gmc_quality_before_features')
        age_ms=(stamp.timestamp_ns-self.feature_timestamp_ns)/1e6 if self.feature_timestamp_ns is not None else float('inf')
        spread=np.ptp(survivors.reshape(-1,2),axis=0) if survivors is not None and len(survivors) else np.zeros(2)
        refresh=(reset or survivors is None or len(survivors)<max(self.minimum_inliers,int(self.maximum_corners*.6))
                 or spread[0]<w*.4 or spread[1]<h*.3 or self.feature_age>=4 or age_ms>=250)
        if refresh:
            next_points=cv2.goodFeaturesToTrack(gray,maxCorners=self.maximum_corners,qualityLevel=.015,minDistance=8,
                                              mask=mask,blockSize=7)
            self.feature_age=0;self.feature_timestamp_ns=stamp.timestamp_ns
        else:
            next_points=survivors;self.feature_age+=1
        diagnostics.update(feature_policy='adaptive',features_refreshed=bool(refresh),feature_age=self.feature_age,
                           features=0 if next_points is None else len(next_points))
        timer.mark('gmc_features')
        self.last=stamp;self.gray=gray;self.points=next_points
        timer.mark('gmc_quality_and_state')
        return MotionEvidence(f.key,None if previous is None else previous.identity.key,
            stamp.timestamp_ns,None if previous is None else previous.timestamp_ns,stamp.clock_domain,
            status,matrix,diagnostics)
