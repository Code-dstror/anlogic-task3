"""One diagnostic display contract; proximity and camera-plane TTC stay distinct.

This does not change thresholds, region membership or speech scheduling.
CLEAR describes an evaluated diagnostic condition, never certified road safety.
"""
SEVERITY={'CLEAR':0,'ATTENTION':1,'DANGER':2}
CONTRACT='PROXIMITY_TTC_LEVELS_V2'


def resolve(proximity,motion,group,*,unified=True,vehicle_voice_policy='ttc_only'):
    if vehicle_voice_policy not in ('ttc_only','confirmed_distance_or_ttc'):
        raise ValueError('Unknown vehicle voice policy')
    p=proximity or dict(level='EXCLUDED',reason='SELF_EXCLUDED',voice_eligible=False)
    level=p['level'];reason=p['reason'];vehicle=group=='vehicle'
    confirmed=bool(vehicle and level not in ('UNKNOWN','EXCLUDED') and motion.get('risk_confirmed')
                   and motion.get('risk_candidate_level') in ('ATTENTION','DANGER'))
    if not vehicle:
        ttc='NOT_APPLICABLE';ttc_reason='VEHICLE_TTC_ONLY'
    elif confirmed:
        ttc=motion['risk_candidate_level'];ttc_reason='CONFIRMED_CAMERA_PLANE_TTC_DIAGNOSTIC'
    elif level in ('UNKNOWN','EXCLUDED'):
        ttc='UNKNOWN';ttc_reason=reason
    elif motion.get('risk_candidate_level') in ('ATTENTION','DANGER'):
        ttc='UNKNOWN';ttc_reason='TTC_ENTRY_CONFIRMING'
    elif (motion.get('reason')=='CURRENT_UNVERIFIED_DEPTH_WINDOW'
          and motion.get('state') in ('APPROACHING','NEAR_CONSTANT_RANGE','RECEDING')):
        ttc='CLEAR';ttc_reason='NO_CURRENT_LONGITUDINAL_TTC_CANDIDATE'
    else:
        ttc='UNKNOWN';ttc_reason=motion.get('reason','NO_VALID_CURRENT_OBSERVATION')
    display=level;display_reason=reason;kind='PROXIMITY_DIAGNOSTIC'
    if unified and level not in ('UNKNOWN','EXCLUDED'):
        if confirmed and SEVERITY[ttc]>=SEVERITY[level]:
            display=ttc;display_reason=ttc_reason;kind='CAMERA_PLANE_TTC_DIAGNOSTIC'
        elif level=='CLEAR' and vehicle and ttc=='UNKNOWN':
            # A missing/unconfirmed closing trend cannot announce hazard release.
            display='UNKNOWN';display_reason=ttc_reason;kind='CAMERA_PLANE_TTC_DIAGNOSTIC'
    proximity_voice=bool(p.get('voice_eligible') and level in ('ATTENTION','DANGER'))
    voice=(confirmed or proximity_voice if vehicle_voice_policy=='confirmed_distance_or_ttc' else confirmed) if vehicle else bool(p.get('voice_eligible'))
    basis=display if voice and vehicle and vehicle_voice_policy=='confirmed_distance_or_ttc' and unified else ttc if vehicle and voice else level if voice else 'UNKNOWN'
    basis_kind=('NONE' if not voice else
        ('CAMERA_PLANE_TTC_DIAGNOSTIC' if confirmed and (vehicle_voice_policy=='ttc_only' or not proximity_voice or (unified and kind=='CAMERA_PLANE_TTC_DIAGNOSTIC')) else 'PROXIMITY_DIAGNOSTIC'))
    return dict(warning_contract=CONTRACT,proximity_level=level,proximity_reason=reason,
        ttc_level=ttc,ttc_confirmed=confirmed,ttc_reason=ttc_reason,
        display_level=display,display_reason=display_reason,display_kind=kind,
        level=display,reason=display_reason,voice_eligible=voice,
        voice_basis_level=basis,voice_basis_kind=basis_kind,collision_risk_validated=False)
