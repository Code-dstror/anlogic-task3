#include "kms_ai_boundary.h"
#include <cstring>
#include <memory>

namespace {
struct Pending { bool active=false; y26_kms_frame frame{}; y26_ticket ticket{}; };
struct Boundary {
 void* gate=nullptr;
 uint64_t run=0,last_offer=0,last_present=0;
 bool offered=false,presented=false,bound=false,disabled=false,stopping=false;
 y26_source context{};
 Pending slots[2];
};
bool supported(const y26_kms_frame& f){
 return f.width==1920 && f.height==1080 && f.layout==1 && f.color==1 && f.received;
}
bool context_equal(const y26_source& a,const y26_source& b){
 return a.session==b.session && a.epoch==b.epoch && a.camera==b.camera &&
        a.kind==b.kind && a.format==b.format && a.role==b.role;
}
bool exact(const y26_kms_frame& a,const y26_kms_frame& b){
 // Packed private struct: no uninitialized padding participates in identity.
 return !std::memcmp(&a,&b,sizeof(a));
}
void retire(Boundary* b,Pending& p){
 if(p.active){y26_gate_retire(b->gate,&p.ticket);p.active=false;}
}
void fault(Boundary* b){
 b->disabled=true;
 for(auto& p:b->slots)retire(b,p);
}
}
extern "C" void* y26_kms_open(const char* directory,uint64_t run){
 if(!run)return nullptr;
 std::unique_ptr<Boundary> b(new Boundary);
 b->gate=y26_gate_open(directory);if(!b->gate)return nullptr;
 b->run=run;return b.release();
}
extern "C" int y26_kms_offer(void* ptr,const y26_kms_frame* f,
 const unsigned char* y,const unsigned char* uv,int ys,int us){
 auto b=static_cast<Boundary*>(ptr);
 if(!b||!f||b->disabled||b->stopping)return 0;
 if(f->run!=b->run || !f->token || (b->offered && f->token<=b->last_offer) ||
    (b->presented && f->token<=b->last_present) ||
    (b->bound && !context_equal(f->source,b->context))){fault(b);return 0;}
 b->offered=true;b->last_offer=f->token;
 if(!supported(*f))return 0;
 if(!b->bound){b->context=f->source;b->bound=true;}
 y26_ticket ticket{};double copy_ms=0;
 int rc=y26_gate_submit(b->gate,y,uv,ys,us,f->token,f->received,&f->source,&ticket,&copy_ms);
 if(rc<0){fault(b);return 0;}
 if(!rc)return 0;
 auto& p=b->slots[ticket.slot];
 // A slot cannot be reused until its exact completion and retirement.
 p.active=true;p.frame=*f;p.ticket=ticket;return 1;
}
extern "C" int y26_kms_select(void* ptr,const y26_kms_frame* f,y26_box* boxes,int cap,int* count){
 if(count)*count=0;
 auto b=static_cast<Boundary*>(ptr);
 if(!b||!f||!boxes||!count||cap<300)return 0;
 if(b->disabled||b->stopping)return 0;
 if(f->run!=b->run || !f->token || (b->presented && f->token<=b->last_present) ||
    (b->bound && !context_equal(f->source,b->context))){fault(b);return 0;}
 b->presented=true;b->last_present=f->token;
 int selected=0;
 for(auto& p:b->slots){
  if(!p.active || p.frame.token>f->token)continue;
  if(p.frame.token<f->token){retire(b,p);continue;}
  if(!exact(p.frame,*f)){fault(b);*count=0;return 0;}
  int rc=y26_gate_take(b->gate,&p.ticket,boxes,cap,count);
  if(rc==1){p.active=false;selected=1;}
  else {retire(b,p);*count=0;if(rc==-1){fault(b);return 0;}}
 }
 return selected;
}
extern "C" int y26_kms_disabled(void* ptr){
 auto b=static_cast<Boundary*>(ptr);return !b||b->disabled;
}
extern "C" int y26_kms_begin_drain(void* ptr){
 auto b=static_cast<Boundary*>(ptr);if(!b)return 1;
 b->stopping=true;
 for(auto& p:b->slots)retire(b,p);
 return y26_gate_begin_drain(b->gate);
}
extern "C" int y26_kms_try_close(void* ptr){
 auto b=static_cast<Boundary*>(ptr);if(!b)return 1;
 b->stopping=true;
 for(auto& p:b->slots)retire(b,p);
 if(!y26_gate_try_close(b->gate))return 0;
 delete b;return 1;
}
