"""Shared current-frame evidence for YOLO26n23 + official Depth / LC64 routes.

No vendor training imports, no GT, no network access, no board API.
"""
import copy
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'src'))
import cv2
import numpy as np
from camera_motion import CameraMotion
from road_application import RoadApplication
from region_warning import FrameIdentity
from warning_contracts import TimedFrame
from software_lane import LaneCandidate
from frame_pixels import FramePixels
from cpu_profile import StageTimer


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def ms(start):
    return (time.perf_counter()-start)*1000


def describe(values):
    a=np.asarray(values,float)
    return dict(mean=float(a.mean()),p50=float(np.median(a)),p95=float(np.percentile(a,95)),
                p99=float(np.percentile(a,99)),maximum=float(a.max()),n=len(a))


def weak_tracking_candidates(rows, config, g):
    """Weak current boxes continue IDs only; never generate depth or warning evidence."""
    candidates=[]
    threshold=config['tracker']['threshold']
    for row in rows[(rows[:,4]>.1)&(rows[:,4]<threshold)]:
        cid=int(row[5])
        if cid!=row[5] or not 0<=cid<len(config['model']['names']):continue
        box=row[:4].astype(float).copy()
        box[[0,2]]=(box[[0,2]]-g['left'])/g['sx']
        box[[1,3]]=(box[[1,3]]-g['top'])/g['sy']
        box=np.clip(box,[0,0,0,0],[g['width'],g['height'],g['width'],g['height']])
        if box[0]>=box[2] or box[1]>=box[3]:continue
        candidates.append(dict(class_id=cid,confidence=float(row[4]),xyxy=box.tolist(),tracking_only=True))
    return candidates




class Evidence:
    def __init__(self,config,model='Y26D',scene=None):
        config=copy.deepcopy(config)
        config['tracker']['frame_rate']=config.get('scene_fps',{}).get(scene,config['tracker']['frame_rate'])
        source_view=config.get('source_views',{}).get(scene)
        if source_view:
            config['camera'].update(width=source_view['width'],height=source_view['height'],view_id=source_view['view_id'])
            # A new camera must never inherit PandaSet's depth scale/geometry.
            config['depth_validity'].update(scale=None,calibration_geometry=None)
        config['depth_validity']['source_name']=model+'_NATIVE_UNQUALIFIED'
        self.config=config
        self.model=model
        self.app=RoadApplication(config,config['model'],config['camera'],active_variants=['ego_lane'])
        self.motion=CameraMotion(width=int(config.get('cpu_runtime',{}).get('gmc_width',640)),
            maximum_corners=int(config.get('cpu_runtime',{}).get('gmc_corners',400)),
            feature_policy=config.get('cpu_runtime',{}).get('gmc_feature_policy','adaptive'),
            reuse_buffers=config.get('cpu_runtime',{}).get('gmc_reuse_buffers',False),
            native_library=config.get('cpu_runtime',{}).get('gmc_native_library'),
            maximum_gap_ms=config['tracker']['max_gap_ms'])
        self.profile_cpu=config.get('cpu_runtime',{}).get('profile_stages',False)

    def process(self,row,bgr,objects,*,tracking_candidates=None,pixel_binding=None,observed_at_ns=None):
        c=self.config['camera']
        profile={} if self.profile_cpu else None
        detail_timer=StageTimer(profile)
        begin=time.perf_counter()
        if pixel_binding is not None:
            if not isinstance(pixel_binding,FramePixels) or pixel_binding.bgr is not bgr:
                raise ValueError('Application pixel binding differs from this source frame')
            binding=pixel_binding
        else:binding=FramePixels(bgr,hash_buffer=self.config.get('cpu_runtime',{}).get('hash_buffer',True))
        identity=FrameIdentity(self.model+'-unified-'+row['scene'],0,'front_camera',row['source_frame'],
            c['width'],c['height'],binding.rgb_sha256,c['view_id'])
        ns=int(row['capture_timestamp_ns']) if 'capture_timestamp_ns' in row else round(row['capture_timestamp_s']*1e9)
        if observed_at_ns is not None and row.get('clock_domain')!='CLOCK_MONOTONIC':
            raise ValueError('Live age requires explicit same-domain CLOCK_MONOTONIC capture timestamp')
        stamp=TimedFrame(identity,ns,row.get('clock_domain','PANDASET_CAPTURE_TIME'),ns if observed_at_ns is None else int(observed_at_ns),
            'OFFLINE_RECORDED_TIME' if observed_at_ns is None else 'LINUX_CAPTURE_AND_CONSUMER_CLOCK_MONOTONIC')
        binding_ms=ms(begin)
        detail_timer.mark('identity_detail')
        start=time.perf_counter();motion=self.motion.update(stamp,binding.bgr,[o['xyxy'] for o in objects],pixel_binding=binding,timings=profile);gmc=ms(start)
        self.last_motion=motion
        detail_timer.mark('gmc_total_detail')
        start=time.perf_counter()
        lane=LaneCandidate(identity.key,'UNKNOWN_NO_AUTOMATIC_LANE',(),(),dict(source='MISSING'))
        application=self.app.process(stamp,objects,lane,tracking_candidates=tracking_candidates,camera_motion=motion,timings=profile)
        result=application['variants']['ego_lane']
        self.last_result=result
        rules=ms(start)
        detail_timer.mark('tracking_rules_detail')
        assert not result['eligible_voice_groups']
        linked={o['source_detection_index']:o for o in result['objects'] if o.get('source_detection_index') is not None}
        ownership=application.get('depth_ownership')
        for i,o in enumerate(objects):
            if ownership is not None and i<len(ownership):o['distance_ownership']=ownership[i]
            item=linked.get(i)
            o.update(track_id=None if item is None else item['track_id'],frame_key=identity.key,
                distance_quality='TRACK_PENDING' if item is None else item['distance']['status'],
                distance_evidence=None if item is None else item['distance'],warning='UNKNOWN')
        return dict(frame_pixel_binding=binding_ms,GMC=gmc,tracking_depth_rules_total=rules,**(profile or {}))


def overlay(bgr,objects):
    view=cv2.resize(bgr,(960,540))
    for o in objects:
        a,b,c,d=np.rint(np.array(o['xyxy'])*.5).astype(int)
        cv2.rectangle(view,(a,b),(c,d),(90,210,230),1)
    return view

