"""Frozen detection and camera-Z metrics, shared by ORT and board predictions."""
import numpy as np

def iou(a,b):
    a=np.asarray(a,float).reshape(-1,4);b=np.asarray(b,float).reshape(-1,4)
    inter=np.maximum(np.minimum(a[:,None,2:],b[None,:,2:])-np.maximum(a[:,None,:2],b[None,:,:2]),0).prod(2)
    return inter/np.maximum((a[:,2:]-a[:,:2]).prod(1)[:,None]+(b[:,2:]-b[:,:2]).prod(1)[None,:]-inter,1e-9)

def matches(pred,truth,threshold=.5):
    """Score-ordered best unclaimed same-class GT, matching frozen validator."""
    if not len(pred) or not len(truth):return []
    overlap=iou(np.asarray(pred)[:,:4],np.asarray(truth)[:,:4]);same=np.asarray(pred)[:,5,None]==np.asarray(truth)[None,:,4]
    used_t=set();out=[]
    for p in np.argsort(-np.asarray(pred)[:,4],kind='stable'):
        values=overlap[p].copy();values[~same[p]]=0
        if used_t:values[list(used_t)]=0
        t=int(values.argmax())
        if values[t]>=threshold:out.append((int(p),t));used_t.add(t)
    return out

def ap(recall,precision):
    r=np.r_[0.,recall,1.];p=np.r_[1.,precision,0.];p=np.maximum.accumulate(p[::-1])[::-1]
    x=np.linspace(0,1,101);y=np.interp(x,r,p)
    return float(np.trapezoid(y,x) if hasattr(np,'trapezoid') else np.trapz(y,x))

def detection_metrics(frames,classes=23,operating_conf=.25):
    thresholds=np.arange(.5,.96,.05);conf=[];labels=[];tp=[];n_gt=np.zeros(classes,int);tp_op=np.zeros(classes,int);fp_op=np.zeros(classes,int)
    for f in frames:
        pred=np.asarray(f['predictions'],float).reshape(-1,6);gt=np.asarray(f['truth'],float).reshape(-1,5)
        if len(gt):n_gt+=np.bincount(gt[:,4].astype(int),minlength=classes)
        correct=np.zeros((len(pred),len(thresholds)),bool)
        for j,threshold in enumerate(thresholds):
            for p,t in matches(pred,gt,float(threshold)):correct[p,j]=True
        active=pred[:,4]>=operating_conf;operating=pred[active]
        matched=matches(operating,gt,.5);hits={p for p,t in matched}
        for i,r in enumerate(operating):(tp_op if i in hits else fp_op)[int(r[5])]+=1
        conf.extend(pred[:,4]);labels.extend(pred[:,5].astype(int));tp.extend(correct)
    conf=np.asarray(conf);labels=np.asarray(labels,int);tp=np.asarray(tp,bool).reshape(-1,10);per_class=[]
    for c in range(classes):
        order=np.flatnonzero(labels==c);order=order[np.argsort(-conf[order],kind='stable')]
        selected=tp[order];cum=selected.cumsum(0);rec=cum/max(1,n_gt[c]);precision=cum/np.maximum(np.arange(1,len(order)+1)[:,None],1)
        aps=[ap(rec[:,j],precision[:,j]) if len(order) else 0. for j in range(10)] if n_gt[c] else None
        per_class.append(dict(class_id=c,GT=int(n_gt[c]),TP=int(tp_op[c]),FP=int(fp_op[c]),FN=int(n_gt[c]-tp_op[c]),
            precision=float(tp_op[c]/max(1,tp_op[c]+fp_op[c])),recall=float(tp_op[c]/n_gt[c]) if n_gt[c] else None,
            AP50=aps[0] if aps is not None else None,AP50_95=float(np.mean(aps)) if aps is not None else None))
    valid=[r for r in per_class if r['GT']];hits=int(tp_op.sum());false=int(fp_op.sum());total=int(n_gt.sum())
    return dict(images=len(frames),GT=total,precision=float(hits/max(1,hits+false)),recall=float(hits/total) if total else None,
        mAP50=float(np.mean([r['AP50'] for r in valid])) if valid else None,mAP50_95=float(np.mean([r['AP50_95'] for r in valid])) if valid else None,
        macro_precision_present_classes=float(np.mean([r['precision'] for r in valid])) if valid else None,
        macro_recall_present_classes=float(np.mean([r['recall'] for r in valid])) if valid else None,
        operating_conf=operating_conf,AP_conf_floor=.001,max_det=300,NMS=False,per_class=per_class,
        protocol='23class; score-ordered best-unclaimed same-class GT, 101point interpolated trapezoid AP; absent-GT classes excluded from mAP. P/R fixedconf.25; not native best-F1 P/R.')

def distance_metrics(rows):
    def score(items):
        valid=[r for r in items if r['prediction_m'] is not None and np.isfinite(r['prediction_m']) and r['prediction_m']>0]
        e=np.array([abs(r['prediction_m']-r['truth_m']) for r in valid]);z=np.array([r['truth_m'] for r in valid])
        return dict(observations=len(items),valid=len(valid),coverage=len(valid)/len(items) if items else None,
            MAE_m=float(e.mean()) if len(e) else None,RMSE_m=float(np.sqrt(np.mean(e**2))) if len(e) else None,
            AbsRel=float(np.mean(e/z)) if len(e) else None,P95_error_m=float(np.percentile(e,95)) if len(e) else None,worst_error_m=float(e.max()) if len(e) else None)
    unique={}
    for r in rows:unique.setdefault((r['scene'],r['uuid']),r)
    out=dict(all_observations=score(rows),independent_first=score(list(unique.values())),distance_definition='owned visible surface camera-forward Z; not 3D center/radial range/bumper clearance',bins={})
    for lo,hi in [(0,5),(5,10),(10,20),(20,40),(40,80),(80,float('inf'))]:
        items=[r for r in rows if lo<r['truth_m']<=hi];seen={}
        for r in items:seen.setdefault((r['scene'],r['uuid']),r)
        out['bins'][str(lo)+'_'+str(hi)]=dict(all_observations=score(items),independent_first=score(list(seen.values())))
    for dimension in ('group','camera','dataset'):
        out[dimension]={v:score([r for r in rows if r.get(dimension)==v]) for v in sorted({r.get(dimension,'unknown') for r in rows})}
    return out
