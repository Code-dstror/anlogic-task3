"""Recorded1080p: existing MPP/GStreamer -> RGA -> FP RKNN -> full CPU app.

Recorded PTS and replay epochs are explicit. Every admitted frame executes both
models; no inference-cache replay or display-only FPS. No physical HDMI claim.
"""
import argparse,collections,ctypes as ct,json,sys,time,wave,os
from pathlib import Path
import numpy as np
import cv2
extra=os.environ.get('Y26_SCIPY_PATH')
if extra and extra not in sys.path:sys.path.append(extra)  # NumPy/OpenCV already selected from the system.
HERE=Path(__file__).resolve().parent;HOST=HERE.parent/'y26_depth_app'
sys.path[:0]=[str(HOST),str(HOST/'src'),str(HERE)]
from networks import Networks
from ordered_pipeline import OrderedPipeline,Packet,FrameKey
from runtime import Evidence,describe
from task_pipeline import DiagnosticTasks
from demo_routes import apply_route
from model_preprocessing import geometry as det_geometry
from depth_preprocessing import geometry as dep_geometry
from range_readout import current_range
from voice_scheduler import VoiceScheduler,AlertSnapshot
from replay_pixels import ReplayPixels
from cpu_profile import configure_timing,clock_snapshot,record_interval,TIMING_NOTES,thread_placement
from result_adapter import build_result
from sudden_near import merged_voice_groups

def read(p):return json.loads(p.read_text(encoding='utf-8'))

def profiled_frames(stream,enabled):
    while True:
        before=clock_snapshot() if enabled else None
        try:lease=next(stream)
        except StopIteration:return
        if before is not None:
            # Includes waiting for publication; separate from ready-queue residence.
            record_interval(lease.packet.value['stages'],'consumer_stream_next_block',before)
        yield lease

class RecordedVoice:
    def __init__(self):
        self.scheduler=VoiceScheduler();self.end=None;self.duration={}
        root=Path(os.environ.get('Y26_VOICE_ROOT',str(HOST/'assets/audio')))
        voices=read(root/'manifest.json')['voices']
        for key,item in voices.items():
            with wave.open(str(root/item['file']),'rb') as w:self.duration[key]=round(w.getnframes()/w.getframerate()*1e9)
        self.scheduler.available_voice_keys=set(self.duration)
    def process(self,context,key,groups,now):
        begin=len(self.scheduler.events)
        if self.end is not None and now>=self.end:self.scheduler.complete(self.scheduler.current['request_id'],now);self.end=None
        self.scheduler.observe(AlertSnapshot((context,),key,now,tuple(groups)),now)
        request=self.scheduler.poll(now)
        if request:self.end=now+self.duration[request['group']]
        return dict(request=request,events=self.scheduler.events[begin:],physical_audio=False,clock='recorded PTS and WAV duration, not ALSA output')

class NativeReplay:
    def __init__(self,args):
        self.lib=ct.CDLL(str(args.replay_library));l=self.lib
        l.y26_replay_open.argtypes=[ct.c_char_p,ct.c_int,ct.c_int,ct.c_char_p,ct.c_int];l.y26_replay_open.restype=ct.c_void_p
        # Fail explicitly on a stale library: never silently return to CPU RGB.
        if not hasattr(l,'y26_replay_abi'):raise RuntimeError('Rebuild MPP replay library: shared-RGB ABI2 required')
        l.y26_replay_abi.restype=ct.c_int
        if l.y26_replay_abi()!=2:raise RuntimeError('Unsupported MPP replay ABI')
        l.y26_replay_read_shared.argtypes=[ct.c_void_p,ct.c_void_p,ct.c_void_p,ct.c_void_p,ct.c_void_p,ct.POINTER(ct.c_uint64),ct.POINTER(ct.c_double),ct.POINTER(ct.c_int),ct.c_char_p,ct.c_int];l.y26_replay_read_shared.restype=ct.c_int
        l.y26_replay_close.argtypes=[ct.c_void_p];self.handle=None;self.args=args;self.open()
        l.y26_replay_rewind.argtypes=[ct.c_void_p];l.y26_replay_rewind.restype=ct.c_int
    def open(self):
        error=ct.create_string_buffer(1024);self.handle=self.lib.y26_replay_open(str(self.args.video).encode(),int(self.args.route=='official'),self.args.depth_size,error,len(error))
        if not self.handle:raise RuntimeError(error.value.decode())
    def read(self,slot):
        pts=ct.c_uint64();tm=(ct.c_double*9)();meta=(ct.c_int*7)();error=ct.create_string_buffer(1024)
        slot.begin();clocks=clock_snapshot() if self.args.clock_detail else None
        try:
            rc=self.lib.y26_replay_read_shared(self.handle,slot.bgr.ctypes.data,slot.rgb.ctypes.data,slot.det.ctypes.data,slot.depth.ctypes.data,ct.byref(pts),tm,meta,error,len(error))
            if rc<0:raise RuntimeError(error.value.decode())
            prep_ms=0.
            if rc==0:
                started=time.perf_counter();slot.publish();prep_ms=(time.perf_counter()-started)*1000
            else:slot.close()
        except BaseException:slot.close();raise
        timings=dict(zip(['MPP_decode_wait','MPP_map','NV12_repack','RGA_CSC_source_BGR','RGA_RGB_resize','pad114','rga_bgr_to_rgb','rga_detector_resize','rga_depth_resize_or_copy'],map(float,tm)))
        timings['source_publish_hash_GMC_prepare']=prep_ms
        if os.environ.get('Y26_RGB_SWAP_NATIVE')=='1':
            timings['native_BGR_to_RGB']=timings.pop('rga_bgr_to_rgb')
        if clocks is not None:record_interval(timings,'native_decode_prepare',clocks)
        metadata=dict(y_stride=meta[0],uv_stride=meta[1],matrix=meta[2],range=meta[3],direct_mapped_NV12=bool(meta[4]),shared_640_resize=bool(meta[5]),explicit_copy_bytes=meta[6],replay_ABI=2)
        return rc,pts.value,timings,metadata
    def close(self):
        if self.handle:self.lib.y26_replay_close(self.handle);self.handle=None

class Producer:
    def __init__(self,args,config):
        configure_timing(args.clock_detail)
        self.args=args;self.config=config;self.pool={};self.epoch=0;self.sequence=0;self.last_pts=None
        self.net=Networks(args.detector,args.depth,args.route,args.library,args.roi_library,config,input_mode='bound-fp16',depth_size=args.depth_size,execution=args.execution,core_mask=3)
        try:self.net.warmup(20);self.reader=NativeReplay(args)
        except BaseException:self.net.close();raise
    def read(self,slot):
        begin=time.monotonic_ns()
        if slot not in self.pool:self.pool[slot]=ReplayPixels(self.args.depth_size,
            eager_gmc=os.environ.get('Y26_REPLAY_EAGER_GMC')=='1',gmc_width=self.config['cpu_runtime'].get('gmc_width',640))
        pixels=self.pool[slot];bgr,det,dep=pixels.bgr,pixels.det,pixels.depth
        rc,pts,tm,meta=self.reader.read(pixels)
        if rc==1:
            if self.reader.lib.y26_replay_rewind(self.reader.handle):self.reader.close();self.reader.open()
            self.epoch+=1;self.sequence=0;self.last_pts=None
            rc,pts,tm,meta=self.reader.read(pixels)
            if rc:raise RuntimeError('Empty replay after EOS')
        if self.last_pts is not None and pts<=self.last_pts:raise RuntimeError('Duplicate/nonmonotonic decoded PTS')
        self.last_pts=pts;sequence=self.sequence;self.sequence+=1
        dg=det_geometry(1920,1080);zg=dep_geometry(1920,1080,self.args.depth_size,'letterbox' if self.args.route=='official' else 'stretch')
        objects,weak,nt=self.net.infer_prepared(det,dep,1920,1080,dg,zg);tm.update(nt)
        context=('MPP_RECORDED_VIDEO',self.epoch,'front');key=FrameKey(context,sequence,int(pts))
        return Packet(key,dict(bgr=bgr,pixel_slot=pixels,pixel_binding=pixels.binding,objects=objects,weak=weak,stages=tm,admitted_ns=begin,ready_ns=time.monotonic_ns(),metadata=meta))
    def close(self):self.reader.close();self.net.close()

def draw(bgr,objects,config,tasks,dst):
    np.copyto(dst,bgr)
    order={key:i+1 for i,key in enumerate(tasks.get('pedestrian_priority',[]))}
    for o in objects:
        if not o.get('display_visible',True):continue
        x1,y1,x2,y2=np.rint(o['xyxy']).astype(int);level=o.get('display_level',o.get('level'))
        color=(50,70,255) if level=='DANGER' else (0,210,255) if level=='ATTENTION' else (180,210,200)
        cv2.rectangle(dst,(x1,y1),(x2,y2),color,2);z=current_range(o);key=o.get('id','')
        text=o['application_group']+' '+key+(' Est.collision ~%.1fm'%z if z else ' ?')
        if key in order:text+=' P'+str(order[key])
        if level:text+=' '+str(level)
        cv2.putText(dst,text,(max(0,x1),max(25,y1-5)),cv2.FONT_HERSHEY_SIMPLEX,.6,color,1,cv2.LINE_AA)
    for i,alert in enumerate(tasks.get('fast_near',{}).get('alerts',[])[:3]):
        text='NEAR TARGET ESTIMATE - TREND UNKNOWN' if alert['kind']=='FAST_NEAR_DIAGNOSTIC' else 'TARGET AHEAD - DEPTH UNCONFIRMED'
        cv2.putText(dst,text,(30,38+i*32),cv2.FONT_HERSHEY_SIMPLEX,.65,(30,210,255),2,cv2.LINE_AA)

def main():
    p=argparse.ArgumentParser();p.add_argument('--video',type=Path,required=True);p.add_argument('--detector',type=Path,required=True);p.add_argument('--depth',type=Path,required=True)
    p.add_argument('--library',type=Path,required=True);p.add_argument('--replay-library',type=Path,required=True);p.add_argument('--roi-library',type=Path,required=True)
    p.add_argument('--route',choices=['official','lc64'],required=True);p.add_argument('--depth-size',type=int,choices=[512,576,640,768],default=768)
    p.add_argument('--execution',choices=['serial','parallel_split'],default='serial');p.add_argument('--opencv-threads',type=int,choices=[1,4,8],default=8)
    p.add_argument('--pipeline',choices=['ordered','staged'],default='ordered');p.add_argument('--full-log',action='store_true')
    p.add_argument('--slots',type=int,choices=[2,3],default=2)
    p.add_argument('--clock-detail',action='store_true',help='Detailed CPU/scheduler clocks; separate diagnostic results from wall-only FPS')
    p.add_argument('--tracking-library',type=Path,help='Explicit native batch ABI1; SciPy assignment policy unchanged')
    p.add_argument('--gmc-buffer-mode',choices=['legacy','reuse'],default='reuse')
    p.add_argument('--fast-near',choices=['off','diagnostic'],default='diagnostic')
    p.add_argument('--gmc-library',type=Path,help='Optional CPU LK pyramid reuse; original LK remains default')
    p.add_argument('--cpu-affinity',choices=['all','big'],default='all',help='Apply before creating any native/OpenCV/network workers')
    p.add_argument('--seconds',type=float,default=300);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    if a.pipeline=='ordered' and a.slots!=2:p.error('Existing ordered adapter supports two slots only')
    a.output.mkdir(parents=True,exist_ok=False)
    if a.cpu_affinity=='big':
        if not hasattr(os,'sched_setaffinity') or not {4,5,6,7}.issubset(os.sched_getaffinity(0)):raise RuntimeError('RK3576 big-core set4-7 unavailable')
        os.sched_setaffinity(0,{4,5,6,7})
        # Imports may already have created BLAS/OpenCV helpers. Bind existing
        # threads too; newly created workers inherit the creator's affinity.
        for task in Path('/proc/self/task').glob('[0-9]*'):
            try:os.sched_setaffinity(int(task.name),{4,5,6,7})
            except ProcessLookupError:pass
    configure_timing(a.clock_detail);cv2.setNumThreads(a.opencv_threads);cv2.setRNGSeed(0)
    config=apply_route(read(HOST/'config.json'),'official' if a.route=='official' else 'lc64')
    config['cpu_runtime']['profile_stages']=True;config['depth_input_geometry']={'size':a.depth_size,'resize':'letterbox' if a.route=='official' else 'stretch'}
    config['cpu_runtime']['clock_detail']=a.clock_detail
    config['cpu_runtime']['gmc_reuse_buffers']=a.gmc_buffer_mode=='reuse'
    if a.gmc_library:config['cpu_runtime']['gmc_native_library']=str(a.gmc_library.resolve())
    config['fast_near']=dict(enabled=a.fast_near=='diagnostic',distance_m=5.)
    if a.tracking_library:config['tracker']['native_library']=str(a.tracking_library.resolve())
    owners=[]
    def factory():
        q=Producer(a,config);owners.append(q);return q
    if a.pipeline=='staged':
        from staged_replay import StagedReplay
        stream=StagedReplay(a,config)
    else:stream=OrderedPipeline(factory,capacity=2,shutdown_timeout_s=20)
    state=tasks=voice=None;context=None
    stages=collections.defaultdict(list);latencies=[];count=0;first=None;last=None;unique=set();epochs=set();error=None;status='FAILED';view=np.empty((1080,1920,3),np.uint8);placement=[];transfer_counts=collections.Counter()
    try:
        with stream,(a.output/'frames.jsonl').open('w',encoding='utf-8',buffering=1) as log:
            for lease in profiled_frames(stream,a.clock_detail):
                with lease as packet,packet.value['pixel_slot']:
                    q=packet.value;consumer=time.monotonic_ns();first=first or q['admitted_ns'];scene=':'.join(map(str,packet.key.context))
                    if scene!=context:
                        cfg=json.loads(json.dumps(config));cfg['source_views'][scene]=dict(width=1920,height=1080,view_id='PIE-front-recorded')
                        cfg['scene_fps']={scene:30};state=Evidence(cfg,'Y26D',scene=scene);tasks=DiagnosticTasks(cfg,'Y26D',{});voice=RecordedVoice();context=scene
                    row=dict(index=count,scene=scene,source_frame=packet.key.sequence,capture_timestamp_ns=packet.key.timestamp_ns,capture_timestamp_s=packet.key.timestamp_ns/1e9,clock_domain='RECORDED_PTS',source_timestamp_kind='recorded_pts')
                    clocks=clock_snapshot() if a.clock_detail else None
                    t=time.perf_counter();binding=q['pixel_binding'];tm=dict(q['stages'],source_binding_prepare=(time.perf_counter()-t)*1000)
                    objects=q['objects'];part=clock_snapshot() if a.clock_detail else None
                    tm.update(state.process(row,binding.bgr,objects,tracking_candidates=q['weak'],pixel_binding=binding))
                    if part is not None:record_interval(tm,'state_process',part)
                    key=state.last_motion.frame_key
                    part=clock_snapshot() if a.clock_detail else None
                    t=time.perf_counter();result=tasks.process(row,1920,1080,objects,key,scene,packet.key.timestamp_ns/1e6,0.);tm['geometry_TTC_priority']=(time.perf_counter()-t)*1000
                    if part is not None:record_interval(tm,'geometry_detail',part)
                    voice_groups=merged_voice_groups(result['eligible_groups'],result.get('fast_near',{}))
                    t=time.perf_counter();decision=voice.process(scene,key,voice_groups,packet.key.timestamp_ns);tasks.fast.acknowledge_voice(decision,result.get('fast_near'));tm['voice_decision']=(time.perf_counter()-t)*1000
                    if 'fast_near_ms' in result:tm['fast_near_ms']=result['fast_near_ms']
                    t=time.perf_counter();draw(binding.bgr,objects,config,result,view);tm['overlay1080p']=(time.perf_counter()-t)*1000
                    finish=time.monotonic_ns();latency=(finish-q['admitted_ns'])/1e6;latencies.append(latency);last=finish
                    tasks.fast.note_overlay_ready(result.get('fast_near'),finish)
                    tm['ready_queue_wait']=(consumer-q['ready_ns'])/1e6;tm['CPU_consumer']=(finish-consumer)/1e6
                    if clocks is not None:record_interval(tm,'consumer_profiled',clocks)
                    if not placement:placement=thread_placement()
                    transfer_counts['frames_direct_NV12' if q['metadata']['direct_mapped_NV12'] else 'frames_repacked_NV12']+=1
                    transfer_counts['frames_shared_640_resize']+=int(q['metadata']['shared_640_resize'])
                    transfer_counts['explicit_native_copy_bytes']+=q['metadata']['explicit_copy_bytes']
                    adapter_start=time.perf_counter()
                    external=dict(session_id=str(packet.key.context[0]),epoch=packet.key.context[1],camera_id=packet.key.context[2],
                        sequence=packet.key.sequence,frame_key=key,clock_domain='RECORDED_PTS',source_timestamp_kind='recorded_pts',capture_timestamp_ns=packet.key.timestamp_ns)
                    outward=build_result(external,result['task_packet'],decision,1920,1080,display_eligible=True,expected_application_frame_key=key)
                    tm['result_adapter']=(time.perf_counter()-adapter_start)*1000
                    t=time.perf_counter()
                    stored=objects if a.full_log else [{k:o.get(k) for k in ['class_id','application_group','confidence','xyxy','track_id','id','estimated_depth_m','distance_quality','display_visible','display_level','display_kind']} for o in objects]
                    record=dict(source=row,epoch=packet.key.context[1],source_rgb_sha256=binding.rgb_sha256,objects=stored,voice=decision,
                        pixel_transport=q['metadata'],stages_ms={k:v for k,v in tm.items() if not k.endswith('.scheduler_slices')},
                        stage_counts={k:v for k,v in tm.items() if k.endswith('.scheduler_slices')},file_to_overlay_ms=latency)
                    record['linux_result']=outward
                    if packet.key.context[1]==0:
                        record['gmc_evidence']=dict(status=state.last_motion.status,matrix=state.last_motion.matrix,diagnostics=state.last_motion.diagnostics)
                    if a.full_log:record['task_packet']=result['task_packet']
                    log.write(json.dumps(record,ensure_ascii=False,allow_nan=False)+'\n');tm['log_write']=(time.perf_counter()-t)*1000
                    for k,v in tm.items():
                        if v is not None:stages[k].append(float(v))
                    count+=1;unique.add(packet.key.sequence);epochs.add(packet.key.context[1])
                    if count>=60000:raise RuntimeError('Bounded timing capacity reached')
                if (time.monotonic_ns()-first)/1e9>=a.seconds:break
        status='COMPLETED_RECORDED_MPP_RGA_NPU_CPU_OVERLAY_NOT_HDMI_QUALIFIED'
    except BaseException as e:error=repr(e);raise
    finally:
        elapsed=(last-first)/1e9 if first and last else None
        summary=dict(status=status,error=error,frames=count,elapsed_s=elapsed,complete_processing_fps=count/elapsed if elapsed else None,unique_source_frames=len(unique),replayed_processing_frames=count-len(unique),epochs=len(epochs),latency_ms=describe(latencies) if latencies else None,over300ms=sum(v>=300 for v in latencies),stage_ms={k:describe(v) for k,v in stages.items()},OpenCV_threads=cv2.getNumThreads(),depth_size=a.depth_size,route=a.route,execution=a.execution,pipeline=a.pipeline,source_backpressure_ms=stream.slot_wait_ms,NPU=True,MPP=True,RGA=True,source_resolution=[1920,1080],overlay_resolution=[1920,1080],pipeline_slots=a.slots,CPU_affinity=sorted(os.sched_getaffinity(0)),RGA_import_cache=os.environ.get("Y26_RGA_IMPORT_CACHE")=="1",warmups_excluded=20,input_policy='unpaced file saturation, all decoded frames admitted; no cached inference',scope='fixed recorded-video derivative; actual MPP NV12/RGA/FP networks/C++exactROI/GMC/tracking/quality/rules/TTC/priority/voice decision/1080 memory overlay/JSON; excludes sensor, physical display, real ALSA and video encoding',video=str(a.video),GT='NOT_AVAILABLE_FOR_DEMO_VIDEO',calibration=False)
        summary.update(shared_RGB=True,replay_ABI=2,RGA_import_cache=os.environ.get('Y26_RGA_IMPORT_CACHE')=='1',
            optimization_flags={key:os.environ.get(key)=='1' for key in ('Y26_RGA_STRIDE_DIRECT','Y26_RGB_SWAP_NATIVE','Y26_REPLAY_EAGER_GMC')},
            linux_result_schema='AI_LINUX_RESULT_V1',
            fast_near=a.fast_near,fast_audio_policy='Normal scheduler; no preemption, no gap exemption, once per fast event; normal persistent alerts unchanged',
            tracking_library=str(a.tracking_library.resolve()) if a.tracking_library else None,gmc_buffer_mode=a.gmc_buffer_mode,
            RGA_import_cache_note='Optional bounded imports for caller-owned RGB/input arrays only; no caching transient MPP map handles, no zero-copy claim',
            clock_detail=a.clock_detail,timing_definitions=TIMING_NOTES if a.clock_detail else None,
            thread_placement_after_first_frame=placement,transfer_counts=dict(transfer_counts),
            timing_mode='diagnostic CPU/scheduler clocks' if a.clock_detail else 'wall-only throughput',
            queue_profile=getattr(stream,'queue_profile',{}),
            stage_counts={k:v for k,v in summary['stage_ms'].items() if k.endswith('.scheduler_slices')})
        summary['stage_ms']={k:v for k,v in summary['stage_ms'].items() if not k.endswith('.scheduler_slices')}
        (a.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        if count:cv2.imwrite(str(a.output/'last_preview.jpg'),view)
if __name__=='__main__':main()
