"""Current-observation quality gate; estimates are never certified metric range.

No GT, manual ROI or detector confidence-to-risk conversion is used here.
Temporal thresholds are explicit development settings, not collision thresholds.
"""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class DepthPolicy:
    minimum_valid_fraction: float = .8
    maximum_relative_iqr: float = .35
    maximum_age_ms: float = 250
    maximum_gap_ms: float = 250
    jump_absolute_m: float = 2.
    jump_relative: float = .25
    jump_rate_m_s: float = 30.
    recovery_observations: int = 2
    recovery_relative: float = .15
    scale: float | None = None
    calibration_geometry: str | None = None
    source_name: str = 'YOLO26n-Depth_PRETRAINED'

    def __post_init__(self):
        numeric=(self.minimum_valid_fraction,self.maximum_relative_iqr,self.maximum_age_ms,
                 self.maximum_gap_ms,self.jump_absolute_m,self.jump_relative,
                 self.jump_rate_m_s,self.recovery_relative)
        if (any(not math.isfinite(x) or x<=0 for x in numeric)
                or self.minimum_valid_fraction>1 or self.recovery_observations<2
                or (self.scale is not None and (not math.isfinite(self.scale) or self.scale<=0))
                or ((self.scale is None)!=(self.calibration_geometry is None))):
            raise ValueError('Invalid experimental depth policy or unbound calibration')


def iou(a,b):
    inter=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    return inter/max(1e-9,(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter)


class DepthValidity:
    def __init__(self,policy=None):
        self.policy=policy or DepthPolicy()
        self.context=None
        self.history={}

    def reset(self):
        self.context=None
        self.history={}

    def evaluate(self,stamp,target,evidence,*,camera_motion=None):
        frame=stamp.identity
        target.validate(frame)
        context=tuple(frame.context)+(stamp.clock_domain,)
        if context!=self.context:
            self.history={};self.context=context
        self.history={key:value for key,value in self.history.items()
                      if 0<=(stamp.timestamp_ns-value['time_ns'])/1e6<=self.policy.maximum_gap_ms}
        raw=None if evidence is None else evidence.get('estimated_depth_m')
        result=dict(status='UNKNOWN_NO_CURRENT_DEPTH_ASSOCIATION',meters=None,
                    model_estimate_m=None,calibrated_estimate_m=None,usable_for_relative_depth=False,
                    frame_key=frame.key,collision_risk='UNKNOWN',
                    source=self.policy.source_name,quality_is_probability=False)
        def unknown(reason,reset=True):
            result['status']=reason
            if reset:self.history.pop(target.track_id,None)
            return result
        if stamp.age_ms>self.policy.maximum_age_ms:
            return unknown('UNKNOWN_STALE_DEPTH')
        if evidence is None:
            return unknown('UNKNOWN_NO_CURRENT_DEPTH_ASSOCIATION')
        if evidence.get('frame_key',frame.key)!=frame.key:
            return unknown('UNKNOWN_DEPTH_FRAME_MISMATCH')
        if raw is None or not isinstance(raw,(int,float)) or not math.isfinite(raw) or raw<=0:
            return unknown('UNKNOWN_INVALID_DEPTH')
        raw=float(raw);result['model_estimate_m']=raw
        result.update(evidence_bbox=evidence.get('xyxy'),patch_xyxy=evidence.get('patch_xyxy'),
                      depth_iqr_m=evidence.get('depth_iqr_m'),valid_fraction=evidence.get('valid_fraction'))
        value=raw
        if self.policy.scale is not None:
            if frame.geometry!=self.policy.calibration_geometry:
                return unknown('UNKNOWN_CALIBRATION_GEOMETRY_MISMATCH')
            value=raw*self.policy.scale
            result['calibrated_estimate_m']=value
            result['scale']=self.policy.scale
        kind=evidence.get('distance_kind','DENSE_DEPTH_PATCH')
        result['distance_kind']=kind
        if kind=='OBJECT_REGRESSION':
            # A scalar regression has no pixel distribution or patch-valid fraction.
            # Keep its current RAW value, but do not manufacture dense-patch quality
            # or promote repeated/confident predictions to a qualified measurement.
            return unknown('UNKNOWN_OBJECT_DISTANCE_UNVALIDATED')
        if kind!='DENSE_DEPTH_PATCH':
            return unknown('UNKNOWN_DISTANCE_KIND_UNSUPPORTED')
        fraction=evidence.get('valid_fraction')
        spread=evidence.get('depth_iqr_m')
        # Old caches may omit quality fields; do not invent a good measurement.
        if fraction is None or spread is None:
            return unknown('UNKNOWN_DEPTH_QUALITY_MISSING')
        if not math.isfinite(fraction) or fraction<self.policy.minimum_valid_fraction or fraction>1:
            return unknown('UNKNOWN_LOW_VALID_DEPTH_FRACTION')
        if not math.isfinite(spread) or spread<0 or spread/raw>self.policy.maximum_relative_iqr:
            return unknown('UNKNOWN_MIXED_DEPTH_PATCH')
        if evidence.get('ego_candidate_unreviewed'):
            return unknown('UNKNOWN_UNREVIEWED_SELF_CANDIDATE')
        if evidence.get('possible_foreground_occlusion'):
            return unknown('UNKNOWN_POSSIBLE_FOREGROUND_OCCLUSION')
        if evidence.get('ambiguous_target_patch'):
            result['overlapping_detection_indices']=evidence.get('overlapping_detection_indices',[])
            return unknown('UNKNOWN_TARGET_OVERLAP_AMBIGUOUS')
        box=target.bbox_source_xyxy
        previous=self.history.get(target.track_id)
        comparison_box=None if previous is None else previous['box']
        result['motion_geometry_compensated']=False
        if camera_motion is not None and camera_motion.status=='VALID_BACKGROUND_SIMILARITY':
            if (camera_motion.frame_key!=frame.key or camera_motion.timestamp_ns!=stamp.timestamp_ns
                    or camera_motion.clock_domain!=stamp.clock_domain):
                return unknown('UNKNOWN_DEPTH_FRAME_MISMATCH')
            if (previous is not None and previous.get('frame_key')==camera_motion.previous_frame_key
                    and previous['time_ns']==camera_motion.previous_timestamp_ns):
                H=camera_motion.matrix
                a,b,c,d=previous['box']
                corners=[(H[0][0]*x+H[0][1]*y+H[0][2],H[1][0]*x+H[1][1]*y+H[1][2])
                         for x,y in [(a,b),(c,b),(a,d),(c,d)]]
                comparison_box=(min(p[0] for p in corners),min(p[1] for p in corners),
                                max(p[0] for p in corners),max(p[1] for p in corners))
                result['motion_geometry_compensated']=True
        truncated=box[0]<=1 or box[1]<=1 or box[2]>=frame.width-1 or box[3]>=frame.height-1
        if truncated:
            patch=evidence.get('patch_xyxy')
            supported=(previous is not None and not previous['pending'] and patch is not None
                and patch[0]>=8 and patch[1]>=8 and patch[2]<=frame.width-8 and patch[3]<=frame.height-8
                and patch[2]-patch[0]>=12 and patch[3]-patch[1]>=12 and iou(box,comparison_box)>=.2
                and (box[2]-box[0])*(box[3]-box[1])>=.5*(comparison_box[2]-comparison_box[0])*(comparison_box[3]-comparison_box[1]))
            if not supported:return unknown('UNKNOWN_TRUNCATED_TARGET')
            result['visible_surface_only']=True
        if previous is None:
            self.history[target.track_id]=dict(time_ns=stamp.timestamp_ns,value=value,box=box,
                class_id=target.class_id,pending=True,confirmations=1,frame_key=frame.key)
            return unknown('UNKNOWN_DEPTH_WARMUP',False)
        if previous is not None:
            dt=(stamp.timestamp_ns-previous['time_ns'])/1e9
            if dt<=0:
                return unknown('UNKNOWN_NONMONOTONIC_DEPTH_OBSERVATION')
            limit=max(self.policy.jump_absolute_m,self.policy.jump_relative*previous['value'],
                      self.policy.jump_rate_m_s*dt)
            identity_suspect=(previous['class_id']!=target.class_id or
                              (iou(box,comparison_box)<.1 and dt<=self.policy.maximum_gap_ms/1000))
            jumping=abs(value-previous['value'])>limit
            if identity_suspect or jumping or previous['pending']:
                coherent=abs(value-previous['value'])<=max(self.policy.jump_absolute_m,
                                                         self.policy.recovery_relative*previous['value'])
                confirmations=previous['confirmations']+1 if previous['pending'] and coherent and not identity_suspect else 1
                pending=confirmations<self.policy.recovery_observations
                self.history[target.track_id]=dict(time_ns=stamp.timestamp_ns,value=value,box=box,
                    class_id=target.class_id,pending=pending,confirmations=confirmations,frame_key=frame.key)
                if pending:
                    return unknown('UNKNOWN_POSSIBLE_ID_SWITCH' if identity_suspect else 'UNKNOWN_DEPTH_JUMP',False)
        self.history[target.track_id]=dict(time_ns=stamp.timestamp_ns,value=value,box=box,
                                         class_id=target.class_id,pending=False,confirmations=0,frame_key=frame.key)
        result['usable_for_relative_depth']=True
        result['status']='CURRENT_VISIBLE_SURFACE_ESTIMATE_TRUNCATED' if truncated else (
            'CURRENT_ESTIMATE_EXPERIMENTAL_SCALE_UNVERIFIED' if self.policy.scale is not None else 'MODEL_DEFAULT_SCALE_UNVERIFIED')
        return result
