"""Versioned, same-source application display wire; never render bare detections."""
import math
import struct
from result_adapter import distance_view

VERSION = 2
SOURCE_FIELDS = ('session', 'epoch', 'sequence', 'camera', 'kind', 'format', 'role')
REQUEST = struct.Struct('<IIQQQ7I')
REPLY = struct.Struct('<IIQQII7I')
BOX = struct.Struct('<4fif6ifq')
GROUPS = {'pedestrian': 0, 'vehicle': 1, 'two_wheeler': 2, 'obstacle': 3}
LEVELS = {'UNKNOWN': -1, 'CLEAR': 0, 'ATTENTION': 1, 'DANGER': 2,
          'NOT_APPLICABLE': -2, 'EXCLUDED': -3}
DISTANCE_KNOWN, DIAGNOSTIC_VALID, TTC_CONFIRMED = 1, 2, 4


def finite_positive(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value > 0)


def display_reply(req, row, now_ns):
    version, slot, token, received, _, *source = req
    if version != VERSION:
        raise ValueError('display protocol version mismatch')
    desc = row['source']
    expected = dict(zip(SOURCE_FIELDS, source))
    if (desc.get('source') != expected or desc.get('association_token') != token
            or desc.get('received_monotonic_ns') != received):
        raise ValueError('cross-source display result')
    stale = now_ns < received or now_ns - received >= 250_000_000
    eligible = row.get('display_eligible') is True and not stale
    payload = []
    if eligible:
        packet = row.get('task_packet')
        if not isinstance(packet, dict) or packet.get('schema') != 'AI_TASKS_DIAGNOSTIC_V1':
            raise ValueError('application packet required; raw detections cannot bypass policy')
        raw = {o.get('id'): o for o in row.get('objects', [])}
        for o in packet['objects']:
            if o.get('display_visible') is not True:
                continue
            original = raw.get(o['id'], {})
            if original.get('self_excluded') is True:
                continue
            xy = o['xyxy']
            if (len(xy) != 4 or any(not math.isfinite(float(v)) for v in xy)
                    or xy[2] <= xy[0] or xy[3] <= xy[1]):
                raise ValueError('invalid display rectangle')
            group = GROUPS[o['group']]
            distance, _, _ = distance_view(o)
            known = distance is not None
            flags = DISTANCE_KNOWN if known else 0
            if o.get('diagnostic_eligible') is True:
                flags |= DIAGNOSTIC_VALID
            motion = o.get('motion_diagnostic') or {}
            ttc = motion.get('ttc_camera_plane_estimate_s')
            if o.get('ttc_confirmed') is True and finite_positive(ttc):
                flags |= TTC_CONFIRMED
            else:
                ttc = -1.0
            priority = o.get('pedestrian_priority') if group == 0 else None
            priority = int(priority) if isinstance(priority, int) and priority > 0 else 0
            track = original.get('track_id')
            track = int(track) if isinstance(track, int) and not isinstance(track, bool) else -1
            payload.append(BOX.pack(*xy, int(o['class_id']), float(distance) if known else -1.,
                                    group, LEVELS[o.get('display_level', 'UNKNOWN')],
                                    LEVELS[o.get('proximity_level', 'UNKNOWN')],
                                    LEVELS[o.get('ttc_level', 'UNKNOWN')], priority, flags,
                                    float(ttc), track))
            if len(payload) >= 300:
                break
    return (REPLY.pack(VERSION, slot, token, received, len(payload), int(not eligible), *source)
            + b''.join(payload))


def empty_reply(req):
    return REPLY.pack(VERSION, req[1], req[2], req[3], 0, 1, *req[5:])
