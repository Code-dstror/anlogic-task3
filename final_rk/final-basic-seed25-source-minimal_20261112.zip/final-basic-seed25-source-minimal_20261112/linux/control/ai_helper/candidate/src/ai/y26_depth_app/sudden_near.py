"""First-current-observation diagnostic, independent of longitudinal TTC.

No stable track is required. Manual ROI, monocular metres and spatial event
association remain unvalidated. Unknown ego geometry never implies a clear mask.
"""
from hashlib import sha256
import math
import numpy as np
from deployment.policy import inside

GROUPS=('pedestrian','vehicle','two_wheeler','obstacle')
def number(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

class SuddenNear:
    def __init__(self,config):
        self.config=config;self.enabled=config.get('enabled',False)
        if not number(config.get('distance_m',5.)) or config.get('distance_m',5.)<=0:raise ValueError('Invalid fast diagnostic distance')
        self.context=None;self.states={};self.previous=[];self.previous_ns=None;self.serial=0;self.last_ns=None
    def _match(self,box,group,records):
        selected=[r for r in records if r['group']==group]
        if not selected:return None
        a=np.asarray([r['box'] for r in selected],float);b=np.asarray(box,float)
        inter=np.maximum(np.minimum(a[:,2:],b[2:])-np.maximum(a[:,:2],b[:2]),0).prod(1)
        area=np.maximum(a[:,2:]-a[:,:2],0).prod(1);bb=max(0,(b[2]-b[0])*(b[3]-b[1]))
        scores=inter/np.maximum(area+bb-inter,1e-9);i=int(np.argmax(scores))
        return selected[i] if scores[i]>=.3 else None
    def _quality(self,o,width,height):
        z=o.get('estimated_depth_m');ownership=o.get('distance_ownership') or {}
        if o.get('identity_conflict') or o.get('jump'):return 'IDENTITY_OR_DEPTH_JUMP'
        if ownership.get('frame_key')!=o.get('frame_key') or not ownership.get('status'):return 'CURRENT_OWNERSHIP_CHECK_MISSING'
        if str(ownership.get('status','')).startswith('UNKNOWN_'):return 'BACKGROUND_OR_OWNERSHIP_UNKNOWN'
        if ownership.get('status')!='NO_CURRENT_COMPETITION_FLAG' or o.get('possible_foreground_occlusion'):
            return 'CURRENT_OWNERSHIP_UNCONFIRMED'
        if o.get('distance_quality') in ('UNKNOWN_POSSIBLE_FOREGROUND_OCCLUSION','UNKNOWN_TARGET_OVERLAP_AMBIGUOUS'):
            return 'BACKGROUND_OR_OWNERSHIP_UNKNOWN'
        patch=o.get('patch_xyxy');box=o['xyxy']
        if not isinstance(patch,(list,tuple)) or len(patch)!=4 or any(type(x) is not int for x in patch):return 'PATCH_SUPPORT_MISSING'
        a,b,c,d=patch
        if not (0<=a<c<=width and 0<=b<d<=height):return 'PATCH_OUTSIDE_IMAGE'
        if not (box[0]-1<=a<c<=box[2]+1 and box[1]-1<=b<d<=box[3]+1):return 'PATCH_TARGET_MISMATCH'
        if box[0]<=2 or box[1]<=2 or box[2]>=width-2 or box[3]>=height-2:return 'TRUNCATED_TARGET_UNREVIEWED'
        count=(c-a)*(d-b)
        if count<32 or o.get('sampled_pixels')!=count or o.get('region_pixels')!=count or o.get('statistics_approximate') is not False:
            return 'PATCH_SUPPORT_INSUFFICIENT'
        fraction=o.get('valid_fraction');spread=o.get('depth_iqr_m')
        if not number(fraction) or fraction<self.config.get('minimum_valid_fraction',.8):return 'LOW_VALID_DEPTH_SUPPORT'
        if not number(spread) or spread<0 or spread/max(z,1e-9)>self.config.get('maximum_relative_iqr',.35):return 'DEPTH_DISPERSION_HIGH'
        if str(o.get('depth_state','')).startswith('UNKNOWN_'):return 'RAW_DEPTH_INVALID'
        return None
    def step(self,objects,key,source_ns,now_ns,context,width,height,roi,*,ego_confirmed):
        if type(source_ns) is not int or type(now_ns) is not int or source_ns<0 or now_ns<source_ns:raise ValueError('Fast diagnostic clock invalid')
        if context!=self.context:self.context=context;self.states={};self.previous=[];self.previous_ns=None;self.serial=0;self.last_ns=None
        if self.last_ns is not None and source_ns<=self.last_ns:raise ValueError('Fast diagnostic source reordered')
        self.last_ns=source_ns
        result=dict(schema='FAST_NEAR_DIAGNOSTIC_V1',frame_key=key,alerts=[],events=[],voice_groups=[],
            scope='MANUAL_ROI_DIAGNOSTIC_NOT_CONFIRMED_DRIVING_PATH',metric_validated=False,collision_risk_validated=False,
            requires_TTC_history=False,TTC_wait_bypassed=False,ordinary_TTC_unchanged=True,ego_geometry_confirmed=ego_confirmed,
            audio_policy='NORMAL_NONPREEMPTIVE_ONE_SECOND_GAP',status='DISABLED')
        for state in self.states.values():state['current_voice_eligible']=False
        if not self.enabled:return result
        if now_ns-source_ns>=250_000_000:result['status']='UNKNOWN_STALE_OBSERVATION';return result
        if not ego_confirmed:result['status']='UNKNOWN_SELF_GEOMETRY';self.previous=[];return result
        result['status']='DIAGNOSTIC_CURRENT'
        if self.previous_ns is None or source_ns-self.previous_ns>250_000_000:self.previous=[]
        for eid,s in list(self.states.items()):
            s['current_voice_eligible']=False
            if source_ns-s['last_seen_ns']>1_500_000_000:
                result['events'].append(dict(action='ENDED_UNKNOWN',event_id=eid,reason='NO_CURRENT_OBSERVATION',frame_key=key))
                del self.states[eid]
        current=[];claimed=set()
        for o in sorted(objects,key=lambda o:o.get('confidence',0),reverse=True):
            group=o.get('application_group');box=o.get('xyxy')
            if (group not in GROUPS or o.get('self_excluded') is not False or o.get('frame_key')!=key
                    or not number(o.get('confidence')) or o['confidence']<self.config.get('detector_threshold',.25)
                    or not isinstance(box,(list,tuple)) or len(box)!=4 or not all(number(x) for x in box)
                    or not (0<=box[0]<box[2]<=width and 0<=box[1]<box[3]<=height)):continue
            in_roi=inside(box,width,height,roi);z=o.get('estimated_depth_m')
            current.append(dict(group=group,box=list(box),in_roi=in_roi))
            state=self._match(box,group,list(self.states.values()))
            if state and state['event_id'] in claimed:continue  # Same-frame duplicate, no extra event.
            if state:
                state.update(box=list(box),last_seen_ns=source_ns);claimed.add(state['event_id'])
            near=number(z) and 0<z<=self.config.get('distance_m',5.) and in_roi
            quality=self._quality(o,width,height) if near else 'NOT_CURRENT_NEAR'
            if state is None:
                previous=self._match(box,group,self.previous)
                if not near or (previous is not None and previous['in_roi']):continue
                if len(self.states)>=64:result['status']='UNKNOWN_EVENT_CAPACITY';continue
                self.serial+=1;eid='fast-'+sha256(str(context).encode()).hexdigest()[:12]+'-'+str(self.serial)
                state=dict(event_id=eid,group=group,box=list(box),last_seen_ns=source_ns,first_observed_ns=source_ns,
                    first_valid_observation_ns=None,first_visual_request_ns=now_ns,audio_spoken=False,
                    first_memory_overlay_ready_monotonic_ns=None,
                    playback_request_ns=None,exit_since_ns=None,current_voice_eligible=False)
                self.states[eid]=state;claimed.add(eid)
                result['events'].append(dict(action='FAST_TARGET_DIAGNOSTIC_ACTIVATED',event_id=eid,frame_key=key,source_timestamp_ns=source_ns))
            if not near:
                # Only a current, observed exit clears an event; absence is UNKNOWN.
                clear=not in_roi or (number(z) and z>self.config.get('distance_m',5.)+2 and self._quality(o,width,height) is None)
                if clear:
                    if state['exit_since_ns'] is None:state['exit_since_ns']=source_ns
                    if source_ns-state['exit_since_ns']>=1_000_000_000:
                        result['events'].append(dict(action='CLEARED',event_id=state['event_id'],reason='CONTINUOUS_VALID_EXIT',frame_key=key))
                        del self.states[state['event_id']]
                else:state['exit_since_ns']=None
                continue
            state['exit_since_ns']=None;trusted=quality is None
            if trusted and state['first_valid_observation_ns'] is None:state['first_valid_observation_ns']=source_ns
            state['current_voice_eligible']=trusted and not state['audio_spoken']
            result['alerts'].append(dict(event_id=state['event_id'],target_id=o['id'],group=group,xyxy=list(box),frame_key=key,
                kind='FAST_NEAR_DIAGNOSTIC' if trusted else 'CURRENT_TARGET_DEPTH_UNKNOWN',
                text='前方估计近距目标，请注意；接近趋势待确认（未标定）' if trusted else '前方目标，请注意；距离待确认',
                distance_m=None,distance_basis='UNVALIDATED_CAMERA_FORWARD_ESTIMATE',depth_support_status='CURRENT_PATCH_SUPPORTED_UNCALIBRATED' if trusted else quality,
                ttc_status='UNKNOWN_FAST_BRANCH',collision_risk_validated=False,region_source='MANUAL_DIAGNOSTIC_ROI',
                first_observed_ns=state['first_observed_ns'],first_valid_observation_ns=state['first_valid_observation_ns'],
                first_visual_request_ns=state['first_visual_request_ns'],physical_visual_start_ns=None,physical_audio_start_ns=None,
                playback_request_ns=state['playback_request_ns'],audio_pending=state['current_voice_eligible'],
                first_memory_overlay_ready_monotonic_ns=state['first_memory_overlay_ready_monotonic_ns'],
                event_identity_source='CLASS_SPATIAL_DIAGNOSTIC_NOT_MOT_GROUND_TRUTH',
                voice_eligible=state['current_voice_eligible'],clock_domain='source/decision clocks supplied by application'))
        self.previous=current;self.previous_ns=source_ns
        result['voice_groups']=[g for g in GROUPS if any(s['group']==g and s['current_voice_eligible'] for s in self.states.values())]
        result['TTC_wait_bypassed']=bool(result['alerts'])
        return result
    def note_overlay_ready(self,frame_result,monotonic_ns):
        if frame_result is None:return
        for alert in frame_result.get('alerts',[]):
            state=self.states.get(alert['event_id'])
            if state is not None:
                if state['first_memory_overlay_ready_monotonic_ns'] is None:state['first_memory_overlay_ready_monotonic_ns']=monotonic_ns
                alert['first_memory_overlay_ready_monotonic_ns']=state['first_memory_overlay_ready_monotonic_ns']
    def acknowledge_voice(self,voice,frame_result=None):
        for e in voice.get('events',[]):
            if e.get('action')!='PLAY_START':continue
            groups=e.get('groups') or [e.get('group')]
            for s in self.states.values():
                if s['group'] in groups and s['current_voice_eligible']:
                    s['audio_spoken']=True;s['playback_request_ns']=e.get('started_ns');s['current_voice_eligible']=False
                    if frame_result is not None:
                        for alert in frame_result.get('alerts',[]):
                            if alert['event_id']==s['event_id']:
                                alert.update(playback_request_ns=s['playback_request_ns'],voice_request_id=e.get('request_id'),audio_pending=False)

def merged_voice_groups(normal,fast):
    return [g for g in GROUPS if g in normal or g in fast.get('voice_groups',[])]
