// CPU-mapped MPP NV12 planes -> reusable RGA RGB views. No decoder/device setup.
#include <cstddef>
#include <cstdint>
#include <im2d.h>
#include <chrono>
#include <cstring>
#include <cstdio>
#include <vector>
#include <stdexcept>
#include <cstdlib>
#include <unordered_map>
#if defined(__ARM_NEON)
#include <arm_neon.h>
#endif
using Clock=std::chrono::steady_clock;
static double elapsed(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
struct Prep {
 std::vector<unsigned char> nv12,rgb;
 std::unordered_map<uintptr_t,std::pair<rga_buffer_handle_t,size_t>> handles;
 Prep():nv12(1920*1080*3/2) {}
 ~Prep(){for(auto &v:handles)releasebuffer_handle(v.second.first);}
};
static void check(IM_STATUS x){if(x!=IM_STATUS_SUCCESS)throw std::runtime_error(imStrError(x));}
static bool option(const char* name){const char* v=std::getenv(name);return v&&std::strcmp(v,"1")==0;}
static rga_buffer_t owned_buffer(Prep* p,unsigned char* data,int w,int h,int format){
 if(!option("Y26_RGA_IMPORT_CACHE"))return wrapbuffer_virtualaddr(data,w,h,format);
 uintptr_t key=reinterpret_cast<uintptr_t>(data);size_t bytes=size_t(w)*h*3;
 auto item=p->handles.find(key);
 if(item==p->handles.end()){
  if(p->handles.size()>=64)throw std::runtime_error("RGA owned buffer cache capacity");
  auto handle=importbuffer_virtualaddr(data,bytes);
  if(!handle)throw std::runtime_error("RGA import caller-owned buffer failed");
  item=p->handles.emplace(key,std::make_pair(handle,bytes)).first;
 }
 if(item->second.second!=bytes)throw std::runtime_error("RGA reused pointer geometry changed");
 return wrapbuffer_handle(item->second.first,w,h,format);
}
static void swap_rgb(const unsigned char* src,unsigned char* dst,size_t pixels){
 size_t i=0;
#if defined(__ARM_NEON)
 for(;i+16<=pixels;i+=16){uint8x16x3_t a=vld3q_u8(src+3*i);uint8x16_t b=a.val[0];a.val[0]=a.val[2];a.val[2]=b;vst3q_u8(dst+3*i,a);}
#endif
 for(;i<pixels;i++){dst[3*i]=src[3*i+2];dst[3*i+1]=src[3*i+1];dst[3*i+2]=src[3*i];}
}
extern "C" {
void* y26_prep_open(){try{return new Prep;}catch(...){return nullptr;}}
void y26_prep_close(void* p){delete static_cast<Prep*>(p);}
// Caller must retire MPP/RGA fences and establish CPU coherency before access.
// Outputs are caller-owned packed arrays. RGA synchronous=1; costs explicit.
// detail[0:3]: BGR->RGB, detector resize, depth resize/copy (children of tm[2]).
// facts[0:3]: direct mapped NV12 (possibly strided), shared resize, explicit copied bytes.
int y26_prep_nv12_shared(void* handle,const unsigned char* y,const unsigned char* uv,int ys,int uvs,
 unsigned char* bgr,unsigned char* shared_rgb,unsigned char* det,unsigned char* dep,int official,int color,int depth_size,
 double* tm,double* detail,int* facts,char* error,int cap){
 try {
  if(!handle||!y||!uv||!bgr||!shared_rgb||!det||!dep||!tm||!detail||!facts||ys<1920||uvs<1920||(depth_size!=512&&depth_size!=576&&depth_size!=640&&depth_size!=768))throw std::runtime_error("invalid mapped planes/stride/output");
  auto p=static_cast<Prep*>(handle);auto t=Clock::now();
  const bool packed=ys==1920&&uvs==1920&&reinterpret_cast<uintptr_t>(uv)==reinterpret_cast<uintptr_t>(y)+1920*1080;
  const uintptr_t yp=reinterpret_cast<uintptr_t>(y),up=reinterpret_cast<uintptr_t>(uv);
  const uintptr_t offset=up>=yp?up-yp:0;
  const bool strided=option("Y26_RGA_STRIDE_DIRECT")&&ys==uvs&&offset>0
      &&offset%static_cast<unsigned>(ys)==0&&offset/static_cast<unsigned>(ys)>=1080
      &&offset/static_cast<unsigned>(ys)<=1088&&ys%16==0;
  const bool direct=packed||strided;
  int input_stride=strided?ys:1920,input_height_stride=strided?int(offset/ys):1080;
  const unsigned char* input=y;facts[0]=direct;facts[1]=official&&depth_size==640;facts[2]=0;
  if(!direct){
   for(int row=0;row<1080;row++)memcpy(p->nv12.data()+row*1920,y+(size_t)row*ys,1920);
   for(int row=0;row<540;row++)memcpy(p->nv12.data()+1920*1080+row*1920,uv+(size_t)row*uvs,1920);
   input=p->nv12.data();facts[2]=1920*1080*3/2;
  }
  tm[0]=elapsed(t);t=Clock::now();
  auto src=wrapbuffer_virtualaddr(const_cast<unsigned char*>(input),1920,1080,RK_FORMAT_YCbCr_420_SP,input_stride,input_height_stride);
  // librga1.10 requires each job to use either handles on both sides or
  // addresses on both sides. MPP's short-lived mapping stays address-based.
  auto full=wrapbuffer_virtualaddr(bgr,1920,1080,RK_FORMAT_BGR_888);
  if(color==1){
   src.color_space_mode=IM_YUV_BT709_FULL_RANGE;full.color_space_mode=IM_RGB_FULL;
   check(improcess(src,full,{}, {}, {}, {},-1,nullptr,nullptr,IM_SYNC));
  }else if(color==0 || color==2 || color==3){
   int mode=color==0?IM_YUV_TO_RGB_BT601_FULL:(color==2?IM_YUV_TO_RGB_BT709_LIMIT:IM_YUV_TO_RGB_BT601_LIMIT);
   check(imcvtcolor(src,full,RK_FORMAT_YCbCr_420_SP,RK_FORMAT_BGR_888,mode,1));
  }else throw std::runtime_error("unknown explicit color profile");
  tm[1]=elapsed(t);
  // Fill only borders. RGA writes directly into the owned input content area.
  t=Clock::now();int dh=official?depth_size*9/16:depth_size,top=(depth_size-dh)/2;
  memset(det,114,140*640*3);memset(det+500*640*3,114,140*640*3);
  if(top){memset(dep,114,top*depth_size*3);memset(dep+(top+dh)*depth_size*3,114,(depth_size-top-dh)*depth_size*3);}
  tm[3]=elapsed(t);t=Clock::now();auto one=t;
  auto rgb=owned_buffer(p,shared_rgb,1920,1080,RK_FORMAT_RGB_888);
  if(option("Y26_RGB_SWAP_NATIVE")){swap_rgb(bgr,shared_rgb,1920*1080);facts[2]+=1920*1080*3;}
  else {
   auto swap_source=owned_buffer(p,bgr,1920,1080,RK_FORMAT_BGR_888);
   check(imcvtcolor(swap_source,rgb,RK_FORMAT_BGR_888,RK_FORMAT_RGB_888,0,1));
  }
  detail[0]=elapsed(one);one=Clock::now();
  auto small=owned_buffer(p,det+140*640*3,640,360,RK_FORMAT_RGB_888);
  check(imresize(rgb,small,0,0,INTER_LINEAR,1));
  detail[1]=elapsed(one);one=Clock::now();
  if(facts[1]){memcpy(dep+top*depth_size*3,det+140*640*3,640*360*3);facts[2]+=640*360*3;}
  else {
   auto depth=owned_buffer(p,dep+top*depth_size*3,depth_size,dh,RK_FORMAT_RGB_888);
   check(imresize(rgb,depth,0,0,INTER_LINEAR,1));
  }
  detail[2]=elapsed(one);tm[2]=elapsed(t);return 0;
 }catch(const std::exception &e){if(error&&cap>0)snprintf(error,cap,"%s",e.what());return -1;}
}
// Legacy ABI preserved; the shared-RGB application requires replay ABI2.
int y26_prep_nv12_color(void* handle,const unsigned char* y,const unsigned char* uv,int ys,int uvs,
 unsigned char* bgr,unsigned char* det,unsigned char* dep,int official,int color,int depth_size,double* tm,char* error,int cap){
 if(!handle)return -1;double detail[3];int facts[3];auto p=static_cast<Prep*>(handle);
 try{p->rgb.resize(1920*1080*3);}catch(...){return -1;}
 return y26_prep_nv12_shared(handle,y,uv,ys,uvs,bgr,p->rgb.data(),det,dep,official,color,depth_size,tm,detail,facts,error,cap);
}
int y26_prep_nv12(void* handle,const unsigned char* y,const unsigned char* uv,int ys,int uvs,
 unsigned char* bgr,unsigned char* det,unsigned char* dep,int official,double* tm,char* error,int cap){
 return y26_prep_nv12_color(handle,y,uv,ys,uvs,bgr,det,dep,official,0,768,tm,error,cap);
}
}
