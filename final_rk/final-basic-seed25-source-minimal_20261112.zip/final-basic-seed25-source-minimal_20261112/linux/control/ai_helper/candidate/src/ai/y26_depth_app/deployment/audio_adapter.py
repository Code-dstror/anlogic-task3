"""RK local ALSA playback adapter around the existing offline VoiceScheduler."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import wave


def discover_alsa_devices():
    """Read-only enumeration. The caller must select one actual device string."""
    result = subprocess.run(["aplay", "-L"], capture_output=True, text=True, check=True)
    return [line for line in result.stdout.splitlines() if line and not line[0].isspace()]


class AlsaVoiceAdapter:
    def __init__(self, *, demo_root, voices_dir, device, popen=None):
        if not device or type(device) is not str:
            raise ValueError("select an ALSA device at runtime")
        sys.path.insert(0, str(Path(demo_root).resolve() / "src"))
        from voice_scheduler import VoiceScheduler
        self.scheduler = VoiceScheduler(freshness_ms=250, gap_ms=1000)
        self.voices = Path(voices_dir).resolve()
        manifest = json.loads((self.voices / "manifest.json").read_text(encoding="utf-8"))
        self.files = {}
        for group, item in manifest["voices"].items():
            path = self.voices / item["file"]
            if path.parent != self.voices or hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
                raise ValueError("voice hash/path mismatch")
            with wave.open(str(path), "rb") as wav:
                if (wav.getframerate(), wav.getnchannels(), wav.getsampwidth()) != (48000, 1, 2):
                    raise ValueError("voice must be 48k mono PCM16")
            self.files[group] = path
        self.scheduler = VoiceScheduler(freshness_ms=250, gap_ms=1000, available_voice_keys=self.files)
        self.device = device
        self.popen = subprocess.Popen if popen is None else popen
        self.process = None
        self.request = None
        self.events = []

    def observe(self, snapshot, now_ns):
        self.scheduler.observe(snapshot, now_ns)
        return self.poll(now_ns)

    def poll(self, now_ns):
        if self.process is not None:
            code = self.process.poll()
            if code is not None:
                self.scheduler.complete(self.request["request_id"], now_ns, success=code == 0)
                self.events.append({"event": "ACTUAL_PROCESS_END", "request_id": self.request["request_id"],
                                    "monotonic_ns": now_ns, "exit_code": code})
                self.process = None
                self.request = None
        if self.process is None:
            request = self.scheduler.poll(now_ns)
            if request is not None:
                command = ["aplay", "-q", "-D", self.device, str(self.files[request["group"]])]
                try:
                    # The player is polled without a pipe reader. Avoid a full
                    # stderr pipe blocking completion and the 1-second gap.
                    self.process = self.popen(command, stdout=subprocess.DEVNULL,
                                              stderr=subprocess.DEVNULL)
                except Exception:
                    self.scheduler.complete(request["request_id"], now_ns, success=False)
                    raise
                self.request = request
                self.events.append({"event": "PLAY_REQUEST", "request_id": request["request_id"],
                                    "group": request["group"], "monotonic_ns": now_ns})
                return request
        return None

    def invalidate(self, now_ns):
        self.scheduler.invalidate(now_ns)

    def state(self, now_ns):
        state = self.scheduler.state(now_ns)
        state["device"] = self.device
        state["physical_audio"] = "NOT_TESTED_BY_VM"
        return state
