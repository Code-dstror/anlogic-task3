// Context and host I/O storage are reused. inputs_set still copies/converts:
// this is NOT advertised as DMA zero-copy. Build against the installed RKNN SDK.
#include <rknn_api.h>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iterator>
#include <vector>
#include <cstdint>
#include <cstdlib>

struct Bridge {rknn_context ctx=0;rknn_input_output_num num{};std::vector<rknn_tensor_attr> attr;std::vector<std::vector<float>> data;std::vector<std::vector<uint16_t>> data16;bool host_fp16=false;std::vector<rknn_output> outputs;~Bridge(){if(ctx)rknn_destroy(ctx);}};
static void prepare_outputs(Bridge* b){
 for(unsigned i=0;i<b->num.n_output;i++){
  auto &o=b->outputs[i];o.index=i;o.want_float=b->host_fp16?0:1;o.is_prealloc=1;
  o.buf=b->host_fp16?static_cast<void*>(b->data16[i].data()):static_cast<void*>(b->data[i].data());
  o.size=b->attr[i].n_elems*(b->host_fp16?sizeof(uint16_t):sizeof(float));
 }
}
struct Times {double inputs_ms,run_ms,outputs_ms,hardware_run_ms;};
#ifdef Y26_CUSTOM_DEPTH_GPU
extern int y26_register_depth_gpu(rknn_context context);
#endif
static double ms(std::chrono::steady_clock::time_point t){return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t).count();}
extern "C" {
void* y26_open_flags(const char* path,unsigned flags){
 auto b=new Bridge;try {std::ifstream f(path,std::ios::binary);std::vector<char> model((std::istreambuf_iterator<char>(f)),{});
 if(model.empty()||rknn_init(&b->ctx,model.data(),model.size(),flags,nullptr)!=0){delete b;return nullptr;}
#ifdef Y26_CUSTOM_DEPTH_GPU
 if(y26_register_depth_gpu(b->ctx)){delete b;return nullptr;}
#endif
 if(rknn_query(b->ctx,RKNN_QUERY_IN_OUT_NUM,&b->num,sizeof(b->num))||b->num.n_input!=1){delete b;return nullptr;}
 b->attr.resize(b->num.n_output);b->data.resize(b->num.n_output);b->data16.resize(b->num.n_output);b->outputs.resize(b->num.n_output);
 // Logical outputs_get layout only. This is NOT padded native I/O binding.
 const char* fp16=std::getenv("Y26_LOGICAL_FP16_OUTPUT");b->host_fp16=fp16&&std::strcmp(fp16,"1")==0;
 for(unsigned i=0;i<b->num.n_output;i++){
  b->attr[i].index=i;if(rknn_query(b->ctx,RKNN_QUERY_OUTPUT_ATTR,&b->attr[i],sizeof(rknn_tensor_attr))){delete b;return nullptr;}
  if(b->host_fp16){
   if(b->attr[i].type!=RKNN_TENSOR_FLOAT16 || b->attr[i].size!=b->attr[i].n_elems*2){delete b;return nullptr;}
   b->data16[i].resize(b->attr[i].n_elems);
  }else b->data[i].resize(b->attr[i].n_elems);
 }prepare_outputs(b);return b;} catch(...){delete b;return nullptr;}
}
void* y26_open(const char* path){return y26_open_flags(path,0);}
int y26_core_mask(void* h,unsigned mask){return rknn_set_core_mask(static_cast<Bridge*>(h)->ctx,static_cast<rknn_core_mask>(mask));}
int y26_perf_detail(void* h,char* buffer,int cap){
 rknn_perf_detail perf{};int rc=rknn_query(static_cast<Bridge*>(h)->ctx,RKNN_QUERY_PERF_DETAIL,&perf,sizeof perf);
 if(rc)return rc;if(!perf.perf_data||perf.data_len>16*1024*1024)return -1002;
 if(cap>0){if(static_cast<uint64_t>(cap)<=perf.data_len)return -1003;memcpy(buffer,perf.perf_data,perf.data_len);buffer[perf.data_len]=0;}
 return static_cast<int>(perf.data_len);
}
int y26_output_count(void* h){return static_cast<Bridge*>(h)->num.n_output;}
int y26_output_info(void* h,int i,int* dims,int* rank,int* format,int* type,float* scale,int* zp){
 auto b=static_cast<Bridge*>(h);if(i<0||i>=(int)b->attr.size())return -1;auto a=b->attr[i];*rank=a.n_dims;*format=a.fmt;*type=a.type;*scale=a.scale;*zp=a.zp;
 for(unsigned j=0;j<a.n_dims;j++)dims[j]=a.dims[j];return a.n_elems;
}
const float* y26_output_data(void* h,int i){auto b=static_cast<Bridge*>(h);return i>=0&&i<(int)b->data.size()?b->data[i].data():nullptr;}
int y26_host_output_type(void* h){return static_cast<Bridge*>(h)->host_fp16?16:32;}
const uint16_t* y26_output_data16(void* h,int i){auto b=static_cast<Bridge*>(h);return i>=0&&i<(int)b->data16.size()?b->data16[i].data():nullptr;}
int y26_input_info(void* h,int native,int* dims,int* rank,int* format,int* type,int* size,int* stride){
 auto b=static_cast<Bridge*>(h);rknn_tensor_attr a{};a.index=0;
 if(rknn_query(b->ctx,native?RKNN_QUERY_NATIVE_INPUT_ATTR:RKNN_QUERY_INPUT_ATTR,&a,sizeof(a)))return -1;
 *rank=a.n_dims;*format=a.fmt;*type=a.type;*size=a.size_with_stride;*stride=a.w_stride;for(unsigned j=0;j<a.n_dims;j++)dims[j]=a.dims[j];return 0;
}
int y26_run(void* h,const unsigned char* rgb,unsigned bytes,Times* times){
 auto b=static_cast<Bridge*>(h);rknn_input in{};in.index=0;in.buf=const_cast<unsigned char*>(rgb);in.size=bytes;in.type=RKNN_TENSOR_UINT8;in.fmt=RKNN_TENSOR_NHWC;in.pass_through=0;
 auto t=std::chrono::steady_clock::now();int ret=rknn_inputs_set(b->ctx,1,&in);times->inputs_ms=ms(t);if(ret)return ret;
 t=std::chrono::steady_clock::now();ret=rknn_run(b->ctx,nullptr);times->run_ms=ms(t);if(ret)return ret;
 prepare_outputs(b);
 t=std::chrono::steady_clock::now();ret=rknn_outputs_get(b->ctx,b->num.n_output,b->outputs.data(),nullptr);times->outputs_ms=ms(t);if(ret)return ret;
 rknn_perf_run perf{};times->hardware_run_ms=rknn_query(b->ctx,RKNN_QUERY_PERF_RUN,&perf,sizeof(perf))? -1.:perf.run_duration/1000.;
 return rknn_outputs_release(b->ctx,b->num.n_output,b->outputs.data());
}
int y26_versions(void* h,char* buffer,int size){rknn_sdk_version v{};auto b=static_cast<Bridge*>(h);int r=rknn_query(b->ctx,RKNN_QUERY_SDK_VERSION,&v,sizeof(v));if(!r)std::snprintf(buffer,size,"api=%s driver=%s",v.api_version,v.drv_version);return r;}
int y26_tensor_metadata(void* h,int output,int native,int index,char* name,int cap,unsigned* dims,unsigned* values){
 auto b=static_cast<Bridge*>(h);rknn_tensor_attr a{};a.index=index;
 rknn_query_cmd cmd=output?(native?RKNN_QUERY_NATIVE_OUTPUT_ATTR:RKNN_QUERY_OUTPUT_ATTR):(native?RKNN_QUERY_NATIVE_INPUT_ATTR:RKNN_QUERY_INPUT_ATTR);
 int rc=rknn_query(b->ctx,cmd,&a,sizeof a);if(rc)return rc;
 std::snprintf(name,cap,"%s",a.name);for(unsigned i=0;i<a.n_dims;i++)dims[i]=a.dims[i];
 unsigned v[]={a.n_dims,a.n_elems,a.size,(unsigned)a.fmt,(unsigned)a.type,(unsigned)a.qnt_type,a.w_stride,a.size_with_stride};
 memcpy(values,v,sizeof v);return 0;
}
void y26_close(void* h){delete static_cast<Bridge*>(h);}
}
