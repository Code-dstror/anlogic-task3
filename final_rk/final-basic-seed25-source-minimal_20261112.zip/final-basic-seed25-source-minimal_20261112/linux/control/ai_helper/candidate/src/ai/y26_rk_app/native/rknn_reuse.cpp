// Optional native FP16 input binding. Original bridge and baseline stay intact.
// Only accepts queried contiguous NHWC FP16. No guessed stride or normalization.
#include "rknn_bridge.cpp"
#include <cstdint>
#include <cstdlib>
#include <cstring>
#if defined(__ARM_NEON)
#include <arm_neon.h>
#endif
struct ReuseInput {
 Bridge* base; rknn_tensor_mem* mem=nullptr; rknn_tensor_attr attr{};
 uint16_t lut[256];
 ~ReuseInput(){if(mem)rknn_destroy_mem(base->ctx,mem);}
};
extern "C" {
void* y26_reuse_open(void* handle){
 auto r=new ReuseInput; r->base=static_cast<Bridge*>(handle);
 if(rknn_query(r->base->ctx,RKNN_QUERY_NATIVE_INPUT_ATTR,&r->attr,sizeof(r->attr)) ||
    r->attr.type!=RKNN_TENSOR_FLOAT16 || r->attr.fmt!=RKNN_TENSOR_NHWC ||
    r->attr.n_dims!=4 || r->attr.dims[0]!=1 || r->attr.dims[3]!=3 ||
    r->attr.w_stride!=r->attr.dims[2] || r->attr.size_with_stride!=r->attr.n_elems*2){delete r;return nullptr;}
 for(int i=0;i<256;i++){__fp16 value=static_cast<__fp16>(static_cast<float>(i)/255.0f);memcpy(&r->lut[i],&value,2);}
 r->mem=rknn_create_mem(r->base->ctx,r->attr.size_with_stride);
 if(!r->mem){delete r;return nullptr;}
 r->attr.pass_through=1;
 if(rknn_set_io_mem(r->base->ctx,r->mem,&r->attr)){delete r;return nullptr;}
 return r;
}
int y26_reuse_run(void* handle,const unsigned char* rgb,unsigned bytes,Times* times){
 auto r=static_cast<ReuseInput*>(handle);auto b=r->base;
 if(bytes!=r->attr.n_elems)return -1001;
 auto t=std::chrono::steady_clock::now();auto dst=static_cast<uint16_t*>(r->mem->virt_addr);
 // Normalization is included in inputs_ms on EVERY iteration, not precomputed gold.
 unsigned i=0;
#if defined(__ARM_NEON)
 const char* vector=std::getenv("Y26_FP16_VECTOR_STORE");
 if(vector&&std::strcmp(vector,"1")==0){
  // Exact existing LUT bits, packed 128-bit writes rather than 8 scalar stores.
  for(;i+8<=bytes;i+=8){uint16x8_t v={r->lut[rgb[i]],r->lut[rgb[i+1]],r->lut[rgb[i+2]],r->lut[rgb[i+3]],
      r->lut[rgb[i+4]],r->lut[rgb[i+5]],r->lut[rgb[i+6]],r->lut[rgb[i+7]]};vst1q_u16(dst+i,v);}
 }
#endif
 for(;i<bytes;i++)dst[i]=r->lut[rgb[i]];
 times->inputs_ms=ms(t);
 t=std::chrono::steady_clock::now();int ret=rknn_run(b->ctx,nullptr);times->run_ms=ms(t);if(ret)return ret;
 prepare_outputs(b);
 t=std::chrono::steady_clock::now();ret=rknn_outputs_get(b->ctx,b->num.n_output,b->outputs.data(),nullptr);times->outputs_ms=ms(t);if(ret)return ret;
 rknn_perf_run perf{};times->hardware_run_ms=rknn_query(b->ctx,RKNN_QUERY_PERF_RUN,&perf,sizeof(perf))?-1.:perf.run_duration/1000.;
 return rknn_outputs_release(b->ctx,b->num.n_output,b->outputs.data());
}
void y26_reuse_close(void* handle){delete static_cast<ReuseInput*>(handle);}
}
