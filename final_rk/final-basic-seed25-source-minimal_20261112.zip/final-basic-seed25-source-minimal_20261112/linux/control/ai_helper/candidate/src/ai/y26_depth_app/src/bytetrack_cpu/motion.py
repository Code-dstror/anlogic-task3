"""Warp XYAH states and covariance; do not copy BoT-SORT's XYWH Jacobian.

Positions are the axis-aligned envelope under the accepted image similarity.
Velocities use its local derivative; covariance uses the full analytic Jacobian.
"""
import numpy as np


def warp_state(mean,covariance,matrix):
    m=np.asarray(mean,float);H=np.asarray(matrix,float)
    if H.shape!=(2,3) or not np.isfinite(H).all() or m[2]<=0 or m[3]<=0:
        raise ValueError('Invalid motion/state')
    R=H[:,:2];p,q=abs(R[0]);r,s=abs(R[1]);a,h=m[2:4]
    D=r*a+s;N=p*a+q;K=p*s-q*r
    if D<=1e-8:raise ValueError('Degenerate camera motion')
    derivative=K/D**2
    out=m.copy();out[:2]=R@m[:2]+H[:,2];out[2]=N/D;out[3]=h*D
    out[4:6]=R@m[4:6];out[6]=derivative*m[6];out[7]=r*h*m[6]+D*m[7]
    J=np.zeros((8,8));J[:2,:2]=R;J[2,2]=derivative;J[3,2]=h*r;J[3,3]=D
    J[4:6,4:6]=R;J[6,2]=-2*r*K/D**3*m[6];J[6,6]=derivative
    J[7,2]=r*m[7];J[7,3]=r*m[6];J[7,6]=r*h;J[7,7]=D
    P=J@covariance@J.T;P=(P+P.T)*.5+np.eye(8)*1e-10
    return out,P


def warp_tracks(tracks,matrix):
    for track in tracks:
        if track.mean is not None:
            track.mean,track.covariance=warp_state(track.mean,track.covariance,matrix)
