/* Two retained original GstBuffers maximum (active + queued).
 * Streaming probe never waits for AI. One worker chains frames in source order.
 * Queue overflow drops NEW input explicitly; it never paints an old result onto
 * a newer frame. This is bounded decoupling, not a claim of zero-copy or60fps. */
#include "linux_gate.h"
#include <time.h>
static void *y26_gate_handle;
struct y26_owned {GstBuffer* buffer;GstVideoInfo info;struct r5_lane_item lane;struct y26_ticket ticket;int submitted;double copy_ms;};
static struct y26_owned y26_queue[2];
static unsigned y26_head,y26_tail,y26_queued,y26_owned_count;
static pthread_mutex_t y26_queue_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t y26_queue_changed=PTHREAD_COND_INITIALIZER;
static _Atomic int y26_cancelled;
static _Atomic uint64_t y26_overflow,y26_expired;
static GstMiniObject* (*y26_ref)(GstMiniObject*);
static GstFlowReturn (*y26_chain)(GstPad*,GstBuffer*);
static GstPad *y26_peer;
static GstPad* (*y26_get_peer)(GstPad*);
static gulong (*y26_add_probe)(GstPad*,GstPadProbeType,GstPadProbeCallback,gpointer,GDestroyNotify);
static void y26_drop_owned(struct y26_owned* q){
 if(q->submitted)y26_gate_retire(y26_gate_handle,&q->ticket);
 r5_lane_unref((GstMiniObject*)q->buffer);
 pthread_mutex_lock(&y26_queue_lock);y26_owned_count--;pthread_mutex_unlock(&y26_queue_lock);
}
static int y26_render(struct y26_owned* q,const struct y26_box* boxes,int count){
 if(!count&&!q->lane.mask)return 1;
 GstBuffer* writable=(GstBuffer*)r5_lane_writable((GstMiniObject*)q->buffer);
 if(!writable){q->buffer=NULL;return 0;}
 q->buffer=writable;GstVideoFrame f;
 if(!r5_lane_map(&f,&q->info,writable,GST_MAP_WRITE))return 0;
 unsigned char *y=GST_VIDEO_FRAME_PLANE_DATA(&f,0),*uv=GST_VIDEO_FRAME_PLANE_DATA(&f,1);
 int ys=GST_VIDEO_FRAME_PLANE_STRIDE(&f,0),us=GST_VIDEO_FRAME_PLANE_STRIDE(&f,1);
 if(!y||!uv||ys<1920||us<1920){r5_lane_unmap(&f);return 0;}
 struct r5_lane_surface surface={y,uv,ys,us};
 if(q->lane.mask)r5_lane_draw(&surface,&q->lane);
 if(count)y26_draw_nv12(y,uv,ys,us,boxes,count);
 r5_lane_unmap(&f);return 1;
}
static void *y26_display_worker(void* unused){
 (void)unused;
 for(;;){
  struct y26_owned q={0};
  pthread_mutex_lock(&y26_queue_lock);
  while(!y26_queued&&!atomic_load(&y26_cancelled)&&!r5_lane_error()){
   struct timespec t;clock_gettime(CLOCK_REALTIME,&t);t.tv_nsec+=20000000;
   if(t.tv_nsec>=1000000000){t.tv_sec++;t.tv_nsec-=1000000000;}
   pthread_cond_timedwait(&y26_queue_changed,&y26_queue_lock,&t);
  }
  if(!y26_queued){pthread_mutex_unlock(&y26_queue_lock);break;}
  q=y26_queue[y26_head];y26_head=(y26_head+1)%2;y26_queued--;
  pthread_mutex_unlock(&y26_queue_lock);
  if(atomic_load(&y26_cancelled)||r5_lane_error()){y26_drop_owned(&q);continue;}
  struct y26_box boxes[300];int count=0,status=1;
  if(q.submitted){
   do{
    status=y26_gate_take(y26_gate_handle,&q.ticket,boxes,300,&count);
    if(status||atomic_load(&y26_cancelled)||r5_lane_error())break;
    struct timespec pause={0,1000000};nanosleep(&pause,NULL);
   }while(1);
  }
  if(status<0||atomic_load(&y26_cancelled)||r5_lane_error()){
   if(status==-1)r5_lane_fail();
   if(status==-2)atomic_fetch_add(&y26_expired,1);
   y26_drop_owned(&q);continue; /* no expired original/AI view is presented */
  }
  uint64_t now=now_ns();
  if(now<q.lane.received_ns||now-q.lane.received_ns>=250000000){atomic_fetch_add(&y26_expired,1);y26_drop_owned(&q);continue;}
  if(!y26_render(&q,boxes,count)){if(q.buffer)r5_lane_unref((GstMiniObject*)q.buffer);pthread_mutex_lock(&y26_queue_lock);y26_owned_count--;pthread_mutex_unlock(&y26_queue_lock);r5_lane_fail();continue;}
  now=now_ns();
  if(atomic_load(&y26_cancelled)||now<q.lane.received_ns||now-q.lane.received_ns>=250000000){y26_drop_owned(&q);continue;}
  /* Sink-pad chain consumes exactly our retained ref; no source-probe recursion. */
  GstFlowReturn flow=y26_chain(y26_peer,q.buffer);q.buffer=NULL;
  pthread_mutex_lock(&y26_queue_lock);y26_owned_count--;pthread_mutex_unlock(&y26_queue_lock);
  char line[224];snprintf(line,sizeof line,"Y26_ASYNC token=%llu seq=%u submitted=%d boxes=%d age_ms=%.3f copy_ms=%.6f queue_drops=%llu expired=%llu\n",
   (unsigned long long)q.lane.pts,q.lane.sequence,q.submitted,count,(now-q.lane.received_ns)/1e6,q.copy_ms,
   (unsigned long long)atomic_load(&y26_overflow),(unsigned long long)atomic_load(&y26_expired));emit(line);
  if(flow!=GST_FLOW_OK){r5_lane_fail();atomic_store(&y26_cancelled,1);}
 }
 /* Retain gate/peer resources with the existing Linux owner. No forced unmap. */
 return NULL;
}
static GstPadProbeReturn y26_events(GstPad* pad,GstPadProbeInfo* info,void* unused){
 (void)pad;(void)unused;GstEvent* e=GST_PAD_PROBE_INFO_EVENT(info);
 if(e&&(GST_EVENT_TYPE(e)==GST_EVENT_EOS||GST_EVENT_TYPE(e)==GST_EVENT_FLUSH_START||GST_EVENT_TYPE(e)==GST_EVENT_FLUSH_STOP)){
  atomic_store(&y26_cancelled,1);pthread_cond_broadcast(&y26_queue_changed);
 }
 return GST_PAD_PROBE_OK;
}
static int y26_enqueue(void* pad,GstBuffer* buffer,const struct r5_lane_item* item){
 pthread_mutex_lock(&y26_queue_lock);
 if(atomic_load(&y26_cancelled)){pthread_mutex_unlock(&y26_queue_lock);return -1;}
 if(y26_owned_count>=2){atomic_fetch_add(&y26_overflow,1);pthread_mutex_unlock(&y26_queue_lock);return 0;}
 y26_owned_count++;pthread_mutex_unlock(&y26_queue_lock);
 struct y26_owned q={0};q.lane=*item;
 GstCaps* caps=r5_lane_caps(pad);int valid=caps&&r5_lane_info(&q.info,caps);if(caps)r5_lane_unref((GstMiniObject*)caps);
 if(!valid||GST_VIDEO_INFO_FORMAT(&q.info)!=GST_VIDEO_FORMAT_NV12||GST_VIDEO_INFO_WIDTH(&q.info)!=1920||GST_VIDEO_INFO_HEIGHT(&q.info)!=1080||q.info.colorimetry.range!=GST_VIDEO_COLOR_RANGE_0_255||q.info.colorimetry.matrix!=GST_VIDEO_COLOR_MATRIX_BT601)goto failed;
 GstVideoFrame f;
 if(!r5_lane_map(&f,&q.info,buffer,GST_MAP_READ))goto failed;
 struct y26_source source={item->session,item->epoch,item->sequence,item->camera,item->kind,item->format,item->role};
 q.submitted=y26_gate_submit(y26_gate_handle,GST_VIDEO_FRAME_PLANE_DATA(&f,0),GST_VIDEO_FRAME_PLANE_DATA(&f,1),GST_VIDEO_FRAME_PLANE_STRIDE(&f,0),GST_VIDEO_FRAME_PLANE_STRIDE(&f,1),item->pts,item->received_ns,&source,&q.ticket,&q.copy_ms);
 r5_lane_unmap(&f);
 if(q.submitted<0)goto failed;
 q.buffer=(GstBuffer*)y26_ref((GstMiniObject*)buffer);
 pthread_mutex_lock(&y26_queue_lock);y26_queue[y26_tail]=q;y26_tail=(y26_tail+1)%2;y26_queued++;pthread_cond_signal(&y26_queue_changed);pthread_mutex_unlock(&y26_queue_lock);
 return 1;
failed:
 pthread_mutex_lock(&y26_queue_lock);y26_owned_count--;pthread_mutex_unlock(&y26_queue_lock);return -1;
}
static int y26_async_start(GstPad* pad){
 y26_peer=y26_get_peer(pad);if(!y26_peer)return 0;
 if(!y26_add_probe(pad,GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM,y26_events,NULL,NULL))return 0;
 pthread_t thread;return !pthread_create(&thread,NULL,y26_display_worker,NULL)&&!pthread_detach(thread);
}
