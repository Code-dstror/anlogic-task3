"""Lightweight post-tracking task assembly shared by CPU/RK candidate and cached diagnostic replay."""
import time
from camera_geometry import attach_geometry, task_packet
from deployment.policy import Engine, inside, finite
from collision_motion import Motion
from warning_levels import resolve, CONTRACT
from range_readout import ownership_unknown,current_range
from sudden_near import SuddenNear


class DiagnosticTasks:
    def __init__(self, config, model, camera_profiles=None):
        self.config, self.model = config, model
        self.profiles = camera_profiles or {}
        self.context, self.history, self.index, self.last_levels = None, {}, 0, {}
        self.motion = Motion(config.get('collision_diagnostic', {}))
        self.engine = Engine(dict(scope='SIMULATION', thresholds=config['distance_thresholds'],
            confirm_ms=200, release_ms=1000, hysteresis_m=2, freshness_ms=250))
        fast=dict(config.get('fast_near',{}));fast.setdefault('detector_threshold',config.get('detector_threshold',.25))
        for name in ('minimum_valid_fraction','maximum_relative_iqr'):
            if name in config.get('depth_validity',{}):fast.setdefault(name,config['depth_validity'][name])
        self.fast=SuddenNear(fast)

    def process(self, row, width, height, objects, key, context, now_ms, age_ms):
        if context != self.context:
            self.context, self.history, self.index, self.last_levels = context, {}, 0, {}
        profile = self.profiles.get(row['scene'])
        attach_geometry(objects, profile, width, height, self.config['camera'])
        # Display mask only. Keep outside observations for tracking and valid release.
        retention = self.config['camera']['raw_manual_region']['retention']
        for o in objects:
            o['inside_display_retention'] = inside(o['xyxy'], width, height, retention)
            o['display_visible'] = o['display_visible'] and o['inside_display_retention']
        policy_objects = []
        for i, o in enumerate(objects):
            tracked = o['track_id'] is not None
            oid = 'T'+str(o['track_id']) if tracked else 'D'+str(row['source_frame'])+'-'+str(i)
            z, cid = o['estimated_depth_m'], o['class_id']
            o['demo_bumper_clearance_m']=None
            o['distance_display_assumption']='CAMERA_FORWARD_Z_ESTIMATE_NOT_BUMPER_CLEARANCE'
            if self.config.get('distance_demo_assumptions',{}).get('prediction_as_bumper_clearance'):
                o['demo_bumper_clearance_m']=current_range(o)
                o['distance_display_assumption']='RAW_Z_USED_AS_BUMPER_CLEARANCE_FOR_DEMO_NOT_GEOMETRIC_CONVERSION'
            previous = self.history.get(oid)
            adjacent = previous is not None and previous['index'] == self.index-1 and previous['class_id'] == cid
            jump = bool(tracked and adjacent and finite(z) and finite(previous['z']) and abs(z-previous['z']) > max(3, .2*previous['z']))
            consistent = finite(z) and z > 0 and tracked and not jump
            if self.model == 'E2':
                consistent = consistent and self.config['diagnostic_scalar']['minimum_distance_m'] <= z <= self.config['diagnostic_scalar']['maximum_distance_m']
                streak = (previous['streak']+1 if adjacent else 1) if consistent else 0
                eligible = streak >= self.config['diagnostic_scalar']['minimum_consecutive']
            else:
                streak = 0
                eligible = consistent and (o['distance_quality'].startswith('CURRENT_') or (self.config['diagnostic_scalar'].get('allow_default_scale_diagnostic',False) and o['distance_quality']=='MODEL_DEFAULT_SCALE_UNVERIFIED'))
            eligible = eligible and age_ms <= 250 and not ownership_unknown(o) and not o.get('identity_conflict',False)
            if tracked:
                self.history[oid] = dict(index=self.index, class_id=cid, z=z, streak=streak)
            o.update(id=oid, tracked=tracked, jump=jump, diagnostic_eligible=eligible,
                metric_distance_status='UNVERIFIED', collision_distance_m=None, ttc_s=None)
            policy_objects.append(dict(id=oid, group=o['application_group'], frame_key=key, distance_frame_key=key,
                observed=True, identity_valid=tracked, distance_m=current_range(o), distance_state='VALID' if eligible else 'UNKNOWN',
                self=o['self_excluded'], region_source='SIMULATED_UNCONFIRMED_ROI',
                region='INSIDE' if inside(o['xyxy'], width, height, self.config['diagnostic_roi']['polygon']) else 'OUTSIDE'))
        self.history = {k:v for k,v in self.history.items() if v['index'] >= self.index-1}
        result = self.engine.process(dict(key=key, context=context, observed_ms=now_ms-age_ms, objects=policy_objects), now_ms)
        by_id = {o['id']: o for o in result['objects']}
        motion_inputs = [dict(id=o['id'], class_id=o['class_id'], group=o['application_group'],
            tracked=o['tracked'], diagnostic_eligible=o['diagnostic_eligible'] and not o['self_excluded'],
            distance=current_range(o), jump=o['jump'],identity_conflict=o.get('identity_conflict',False),
            edge=o['xyxy'][0]<=2 or o['xyxy'][1]<=2 or o['xyxy'][2]>=width-2 or o['xyxy'][3]>=height-2,
            in_roi=inside(o['xyxy'],width,height,self.config['diagnostic_roi']['polygon'])) for o in objects]
        motions = self.motion.step(motion_inputs, row['capture_timestamp_s']*1000, context)
        result['proximity_ranked'] = [dict(p) for p in result['ranked']]
        result['ranked'] = []
        unified=self.config.get('warning_presentation',{}).get('unified_levels',True)
        for o in objects:
            o['motion_diagnostic'] = motions[o['id']]
            p=by_id.get(o['id'])
            presentation=resolve(p,motions[o['id']],o['application_group'],unified=unified,
                vehicle_voice_policy=self.config.get('warning_presentation',{}).get('vehicle_voice_policy','ttc_only'))
            o.update(presentation)
            if p:
                p.update(presentation)
                if p['voice_eligible']:
                    ranked=dict(p,warning_kind=p['display_kind'])
                    if not unified and o['application_group']=='vehicle':
                        ranked.update(level=p['ttc_level'],warning_kind='CAMERA_PLANE_TTC_DIAGNOSTIC')
                    result['ranked'].append(ranked)
        result['warning_contract']=CONTRACT
        severity={'DANGER':2,'ATTENTION':1,'CLEAR':0,'UNKNOWN':0}
        result['ranked'].sort(key=lambda p:(-severity[p['level']],p['group']!='pedestrian',p['distance_m'],p['id']))
        result['eligible_groups']=[g for g in ('pedestrian','vehicle','two_wheeler','obstacle') if any(p['group']==g for p in result['ranked'])]
        result['pedestrian_priority']=[p['id'] for p in result['ranked'] if p['group']=='pedestrian']
        events, current = [], {}
        for o in objects:
            p = by_id.get(o['id'], dict(level='EXCLUDED', reason='SELF_EXCLUDED', voice_eligible=False))
            o.update(level=p['level'], reason=p['reason'], voice_eligible=p['voice_eligible'])
            current[o['id']] = o['level']
            before = self.last_levels.get(o['id'])
            if before != o['level']:
                events.append(dict(action='DIAGNOSTIC_STATE_CHANGE', id=o['id'], previous=before,
                    current=o['level'], reason=o['reason'], frame_key=key, observed_ms=now_ms-age_ms))
        for oid, level in self.last_levels.items():
            if oid not in current and level not in ('CLEAR', 'UNKNOWN', 'EXCLUDED'):
                events.append(dict(action='DIAGNOSTIC_STATE_CHANGE', id=oid, previous=level,
                    current='UNKNOWN', reason='NOT_OBSERVED', frame_key=key, observed_ms=now_ms-age_ms))
                current[oid] = 'UNKNOWN'
        self.last_levels = current
        result['task_packet'] = task_packet(objects, result, key,
            dict(scene=row['scene'], source_frame=row['source_frame'], capture_timestamp_s=row['capture_timestamp_s']), profile)
        result['task_packet']['events'] = events
        if self.fast.enabled:
            start=time.perf_counter();camera=self.config['camera']
            ego_confirmed=bool(profile and camera.get('ego_profile_id')==profile.get('id')
                and (profile.get('width'),profile.get('height'))==(width,height)
                and ((camera.get('ego_mask_enabled') is True
                      and camera.get('ego_polygon_confirmed') is True and len(camera.get('ego_polygon',[]))>=3)
                     or camera.get('ego_no_visible_self_confirmed') is True))
            source_ns=int(row['capture_timestamp_ns']) if 'capture_timestamp_ns' in row else round(row['capture_timestamp_s']*1e9)
            fast_now=time.monotonic_ns() if row.get('clock_domain')=='CLOCK_MONOTONIC' else source_ns+max(0,round(age_ms*1e6))
            fast=self.fast.step(objects,key,source_ns,fast_now,context,width,height,
                self.config['diagnostic_roi']['polygon'],ego_confirmed=ego_confirmed)
            fast['clock_domain']=row.get('clock_domain','RECORDED_PTS')
            fast['source_timestamp_kind']=row.get('source_timestamp_kind','recorded_pts')
            for alert in fast['alerts']:
                alert['clock_domain']=fast['clock_domain'];alert['source_timestamp_kind']=fast['source_timestamp_kind']
            result['fast_near']=fast;result['task_packet']['fast_near']=fast
            result['fast_near_ms']=(time.perf_counter()-start)*1000
        self.index += 1
        return result
