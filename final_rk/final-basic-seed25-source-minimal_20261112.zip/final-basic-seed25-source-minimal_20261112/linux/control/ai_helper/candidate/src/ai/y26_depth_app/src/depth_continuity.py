"""Display continuity is separate from current-observation validity and risk."""
import math


class DepthContinuity:
    def __init__(self,time_constant_ms=150.,prediction_limit_ms=200.):
        self.tau=time_constant_ms/1000
        self.limit=prediction_limit_ms
        self.history={};self.context=None

    def reset(self):
        self.history={};self.context=None

    def context_for(self,stamp):
        return tuple(stamp.identity.context)+(stamp.clock_domain,)

    def missing(self,stamp,track_id):
        result=dict(status='UNKNOWN_NO_CURRENT_DEPTH_ASSOCIATION',meters=None,model_estimate_m=None,
                    calibrated_estimate_m=None,usable_for_relative_depth=False)
        return self._display(stamp,track_id,result)

    def update(self,stamp,target,quality):
        if self.context_for(stamp)!=self.context:
            self.reset();self.context=self.context_for(stamp)
        self.history={tid:h for tid,h in self.history.items()
                      if 0<=(stamp.timestamp_ns-h['time_ns'])/1e6<=max(250.,self.limit)}
        previous=self.history.get(target.track_id)
        if quality.get('usable_for_relative_depth'):
            value=quality.get('calibrated_estimate_m')
            if value is None:value=quality['model_estimate_m']
            filtered=float(value);velocity=0.
            if previous and previous['class_id']==target.class_id:
                dt=(stamp.timestamp_ns-previous['time_ns'])/1e9
                if 0<dt<=.25:
                    alpha=1-math.exp(-dt/self.tau)
                    filtered=alpha*value+(1-alpha)*previous['filtered']
                    velocity=max(-30.,min(30.,(filtered-previous['filtered'])/dt))
            self.history[target.track_id]=dict(time_ns=stamp.timestamp_ns,filtered=filtered,velocity=velocity,
                class_id=target.class_id,source_frame_key=stamp.identity.key)
            quality=dict(quality,smoothed_estimate_m=filtered,
                display=dict(status='SMOOTHED_CURRENT_ESTIMATE',estimate_m=filtered,age_ms=0.,
                    uses_current_depth=True,source_frame_key=stamp.identity.key,not_for_collision=True))
            return quality
        # A suspected identity/scale/frame error must not inherit an old target's display.
        if quality['status'] in ('UNKNOWN_POSSIBLE_ID_SWITCH','UNKNOWN_DEPTH_FRAME_MISMATCH',
                                 'UNKNOWN_TARGET_OVERLAP_AMBIGUOUS',
                                 'UNKNOWN_POSSIBLE_FOREGROUND_OCCLUSION',
                                 'UNKNOWN_CALIBRATION_GEOMETRY_MISMATCH','UNKNOWN_DEPTH_JUMP',
                                 'UNKNOWN_STALE_DEPTH','UNKNOWN_NONMONOTONIC_DEPTH_OBSERVATION'):
            self.history.pop(target.track_id,None)
        return self._display(stamp,target.track_id,quality)

    def _display(self,stamp,track_id,quality):
        result=dict(quality)
        previous=self.history.get(track_id) if self.context_for(stamp)==self.context else None
        age=None if previous is None else (stamp.timestamp_ns-previous['time_ns'])/1e6
        if previous is not None and 0<=age<=self.limit:
            result['display']=dict(status='PREDICTED_DISPLAY_ONLY',
                estimate_m=max(.01,previous['filtered']+previous['velocity']*age/1000),age_ms=age,
                uses_current_depth=False,source_frame_key=previous['source_frame_key'],not_for_collision=True)
        else:
            result['display']=dict(status='UNKNOWN',estimate_m=None,age_ms=age,uses_current_depth=False,not_for_collision=True)
            self.history.pop(track_id,None)
        result['smoothed_estimate_m']=None
        return result
