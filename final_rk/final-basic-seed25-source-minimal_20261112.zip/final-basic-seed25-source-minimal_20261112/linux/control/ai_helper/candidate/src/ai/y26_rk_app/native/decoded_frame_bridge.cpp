#include "decoded_frame_bridge.h"
#include <cstring>
#include <memory>

namespace {
uint32_t u32(const unsigned char* p){
 return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);
}
uint64_t u64(const unsigned char* p){return u32(p)|(uint64_t(u32(p+4))<<32);}
struct Item {bool used=false;uint64_t pts=0;y26_kms_frame frame{};};
struct Video {
 void* kms=nullptr;uint64_t run=0,last_token=0,last_pts=0;
 uint32_t generation=0,cohort_length=0,last_sequence=0;char cohort[64]{};
 uint64_t last_received=0;
 bool registered=false,bound=false,disabled=false,stopping=false;
 y26_source context{};Item items[64];uint64_t counters[5]{};
};
bool context_equal(const y26_source& a,const y26_source& b){
 return a.session==b.session && a.epoch==b.epoch && a.camera==b.camera &&
  a.kind==b.kind && a.format==b.format && a.role==b.role;
}
void clear(Video* v){for(auto& i:v->items)i.used=false;v->counters[4]=0;}
int fault(Video* v){
 ++v->counters[3];v->disabled=true;clear(v);
 y26_kms_begin_drain(v->kms);return 0;
}
bool mapped(const y26_nv12_view* a){
 if(!a || !a->y || !a->uv || a->width!=1920 || a->height!=1080 ||
    a->layout!=1 || a->color!=1 || a->cpu_read_ready!=1 || a->original_pixels!=1 ||
    a->y_stride<1920 || a->uv_stride<1920)return false;
 return a->y_bytes>=uint64_t(a->y_stride)*1079+1920 &&
        a->uv_bytes>=uint64_t(a->uv_stride)*539+1920;
}
}
extern "C" void* y26_video_open(const char* directory,uint64_t run,const char* cohort,uint32_t n,uint32_t generation){
 if(!run || !cohort || !n || n>64)return nullptr;
 for(uint32_t i=0;i<n;++i)if(cohort[i]<33 || cohort[i]>126)return nullptr;
 std::unique_ptr<Video> v(new Video);
 v->kms=y26_kms_open(directory,run);if(!v->kms)return nullptr;
 v->run=run;v->cohort_length=n;std::memcpy(v->cohort,cohort,n);v->generation=generation;
 return v.release();
}
extern "C" int y26_video_register(void* ptr,const unsigned char* p,size_t n){
 auto v=static_cast<Video*>(ptr);if(!v || v->disabled || v->stopping)return 0;
 if(!p || n!=156 || std::memcmp(p,"Y26META1",8) || u32(p+8)!=1 || u32(p+12)!=156)return fault(v);
 uint64_t run=u64(p+16),token=u64(p+24),pts=u64(p+32),received=u64(p+40);
 uint32_t generation=u32(p+48),w=u32(p+52),h=u32(p+56),cn=u32(p+88);
 // JPEG generation belongs to each recycled FPGA slot. Match the initial
 // owned frame on open, then allow later generations in the SAME stream.
 // Per-frame token/PTS/SOURCE/time still bind exact decode and result identity.
 if(run!=v->run || !token || !received || pts==UINT64_MAX || !generation ||
    (!v->registered && generation!=v->generation) ||
    w!=1920 || h!=1080 || cn!=v->cohort_length || std::memcmp(p+92,v->cohort,cn))return fault(v);
 for(uint32_t i=cn;i<64;++i)if(p[92+i])return fault(v);
 if(v->registered && (token<=v->last_token || pts<=v->last_pts))return fault(v);
 y26_source source{u32(p+60),u32(p+64),u32(p+68),u32(p+72),u32(p+76),u32(p+80),u32(p+84)};
 if(v->bound && (!context_equal(source,v->context) || source.sequence<=v->last_sequence || received<=v->last_received))return fault(v);
 if(!v->bound){v->context=source;v->bound=true;}
 v->last_sequence=source.sequence;v->last_received=received;
 v->registered=true;v->last_token=token;v->last_pts=pts;
 Item* entry=nullptr;
 for(auto& i:v->items)if(!i.used){entry=&i;break;}
 if(!entry){
  entry=&v->items[0];for(auto& i:v->items)if(i.pts<entry->pts)entry=&i;
  ++v->counters[0];
 }else ++v->counters[4];
 entry->used=true;entry->pts=pts;
 entry->frame={run,token,received,source,w,h,0,0};return 1;
}
extern "C" int y26_video_decoded(void* ptr,uint64_t pts,const y26_nv12_view* view,y26_kms_frame* out){
 auto v=static_cast<Video*>(ptr);if(!v || !out || v->disabled || v->stopping)return 0;
 Item* entry=nullptr;for(auto& i:v->items)if(i.used && i.pts==pts){entry=&i;break;}
 if(!entry){++v->counters[1];return 0;}
 *out=entry->frame;entry->used=false;--v->counters[4];
 // Missing/unsupported real caps never get replaced by expected caps.
 if(!mapped(view)){++v->counters[2];return 1;}
 out->layout=view->layout;out->color=view->color;
 return y26_kms_offer(v->kms,out,view->y,view->uv,view->y_stride,view->uv_stride)?2:1;
}
extern "C" int y26_video_select(void* ptr,const y26_kms_frame* frame,y26_box* boxes,int cap,int* count){
 if(count)*count=0;
 auto v=static_cast<Video*>(ptr);if(!v || v->disabled || v->stopping)return 0;
 return y26_kms_select(v->kms,frame,boxes,cap,count);
}
extern "C" void y26_video_stats(void* ptr,uint64_t counters[5]){
 auto v=static_cast<Video*>(ptr);if(v && counters)std::memcpy(counters,v->counters,sizeof(v->counters));
}
extern "C" int y26_video_begin_drain(void* ptr){
 auto v=static_cast<Video*>(ptr);if(!v)return 1;
 v->stopping=true;clear(v);return y26_kms_begin_drain(v->kms);
}
extern "C" int y26_video_try_close(void* ptr){
 auto v=static_cast<Video*>(ptr);if(!v)return 1;
 v->stopping=true;clear(v);
 if(!y26_kms_try_close(v->kms))return 0;
 delete v;return 1;
}
