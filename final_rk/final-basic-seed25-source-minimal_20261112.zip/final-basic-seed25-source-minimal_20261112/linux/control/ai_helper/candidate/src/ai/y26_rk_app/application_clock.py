"""One source/decision clock boundary; never subtract frame age twice."""

def decision_time(source_ns,now_ns=None):
    if type(source_ns) is not int or source_ns<0:raise ValueError('Invalid source timestamp')
    if now_ns is None:return source_ns/1e6,0.
    if type(now_ns) is not int or now_ns<source_ns:raise ValueError('Decision clock precedes source')
    return now_ns/1e6,(now_ns-source_ns)/1e6
