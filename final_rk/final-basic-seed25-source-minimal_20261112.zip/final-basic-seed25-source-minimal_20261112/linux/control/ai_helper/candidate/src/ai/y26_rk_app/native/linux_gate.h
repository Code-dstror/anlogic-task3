#ifndef Y26_LINUX_GATE_H
#define Y26_LINUX_GATE_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#pragma pack(push,1)
struct y26_source {uint32_t session,epoch,sequence,camera,kind,format,role;};
/* Wire V2: raw23 class retained; group/levels/priority come from application. */
struct y26_box {float x1,y1,x2,y2;int32_t cls;float distance;int32_t group,level,proximity,ttc_level,priority,flags;float ttc_s;int64_t track_id;};
struct y26_ticket {uint32_t slot;uint64_t token,received;struct y26_source source;};
#pragma pack(pop)
void* y26_gate_open(const char* directory);
/* Stop submissions and send ordered SHUT_WR; replies can still arrive.
 * 1 sealed, 0 lock busy/retry, -1 transport fault (retain uncertain slots). */
int y26_gate_begin_drain(void*);
/* Only after all callers stopped. Returns 0 while any slot is still in use;
 * do not discard the handle or unlink/reuse bridge files in that case.
 * Automatically seals submission with SHUT_WR on the first attempt. */
int y26_gate_try_close(void*);
void y26_gate_close(void*); /* compatibility: retains pending handle */
/* No waiting for inference in submit/take. Expired AI slots remain quarantined
 * until their exact completion arrives. Gst display refs belong to caller. */
int y26_gate_submit(void*,const unsigned char*,const unsigned char*,int,int,uint64_t,uint64_t,const struct y26_source*,struct y26_ticket*,double*);
/* 1=ready,0=pending,-2=retired/expired,-1=fatal; count0 means a real empty result. */
int y26_gate_take(void*,const struct y26_ticket*,struct y26_box*,int,int*);
void y26_gate_retire(void*,const struct y26_ticket*);
void y26_draw_nv12(unsigned char*,unsigned char*,int,int,const struct y26_box*,int);
#ifdef __cplusplus
}
#endif
#endif
