// Exact LK parameters; reuse each image pyramid/derivative across both directions.
#include <opencv2/video/tracking.hpp>
#include <opencv2/core.hpp>
#include <vector>
#include <cstring>
#include <cstdio>
#include <stdexcept>
struct Flow {std::vector<cv::Mat> previous,current;int width=0,height=0;};
extern "C" {
void* y26_flow_open(){try{return new Flow;}catch(...){return nullptr;}}
void y26_flow_close(void* p){delete static_cast<Flow*>(p);}
int y26_flow_run(void* handle,const unsigned char* before,const unsigned char* now,int w,int h,
 const float* points,int n,float* forward,float* backward,unsigned char* ok,unsigned char* backok,float* error,
 int reuse,char* message,int cap){
 try{
  if(!handle||!before||!now||w<32||h<32||n<1||n>10000)throw std::runtime_error("Invalid LK buffers/shape");
  auto p=static_cast<Flow*>(handle);cv::Mat a(h,w,CV_8UC1,const_cast<unsigned char*>(before)),b(h,w,CV_8UC1,const_cast<unsigned char*>(now));
  if(reuse&&p->width==w&&p->height==h&&!p->current.empty())p->previous.swap(p->current);
  else cv::buildOpticalFlowPyramid(a,p->previous,cv::Size(21,21),3,true,cv::BORDER_REFLECT_101,cv::BORDER_CONSTANT,false);
  cv::buildOpticalFlowPyramid(b,p->current,cv::Size(21,21),3,true,cv::BORDER_REFLECT_101,cv::BORDER_CONSTANT,false);
  // tryReuseInputImage=false: cached pyramids own pixels after source-slot reuse.
  cv::Mat input(n,1,CV_32FC2,const_cast<float*>(points)),f(n,1,CV_32FC2,forward),back(n,1,CV_32FC2,backward);
  cv::Mat status(n,1,CV_8U,ok),reverse_status(n,1,CV_8U,backok),err(n,1,CV_32F,error);
  auto criteria=cv::TermCriteria(cv::TermCriteria::COUNT|cv::TermCriteria::EPS,30,.01);
  cv::calcOpticalFlowPyrLK(p->previous,p->current,input,f,status,err,cv::Size(21,21),3,criteria,0,1e-4);
  cv::calcOpticalFlowPyrLK(p->current,p->previous,f,back,reverse_status,cv::noArray(),cv::Size(21,21),3,criteria,0,1e-4);
  p->width=w;p->height=h;return 0;
 }catch(const std::exception& e){if(message&&cap)snprintf(message,cap,"%s",e.what());return -1;}
}
}
