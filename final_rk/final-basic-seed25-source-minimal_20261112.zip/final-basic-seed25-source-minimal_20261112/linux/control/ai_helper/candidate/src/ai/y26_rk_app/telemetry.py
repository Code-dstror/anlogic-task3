"""Read-only board telemetry. Missing/unreadable values stay null."""
import argparse,json,time,resource
from pathlib import Path

def value(path):
 try:return Path(path).read_text().strip()
 except OSError:return None

def sample(pid):
 root=Path('/sys');status=value(f'/proc/{pid}/status')
 fields={}
 if status:
  for line in status.splitlines():
   if line.startswith(('VmRSS:','VmHWM:')):k,v=line.split(':',1);fields[k]=int(v.split()[0])*1024
 return dict(monotonic_ns=time.monotonic_ns(),cpu_stat=value('/proc/stat'),memory_info=value('/proc/meminfo'),process=fields,
  thermal={str(p):value(p) for p in root.glob('class/thermal/thermal_zone*/temp')},
  devfreq={str(p):dict(cur_freq=value(p/'cur_freq'),load=value(p/'load')) for p in root.glob('class/devfreq/*')},
  cpu_freq={str(p):value(p) for p in root.glob('devices/system/cpu/cpufreq/policy*/scaling_cur_freq')},
  NPU_utilization=value('/sys/kernel/debug/rknpu/load'),FPGA_resources=None,FPGA_compression_ratio=None,physical_HDMI_latency=None,physical_acoustic_latency=None)

def main():
 p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--duration',type=float,default=300);a=p.parse_args();start=time.monotonic()
 with a.output.open('x') as f:
  while time.monotonic()-start<a.duration:f.write(json.dumps(sample(a.pid))+'\n');f.flush();time.sleep(1)
if __name__=='__main__':main()
