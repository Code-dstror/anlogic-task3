"""Single-player category coalescing. Explicit clocks and completion callbacks."""
from dataclasses import dataclass
from hashlib import sha256
import json

GROUPS=('pedestrian','vehicle','two_wheeler','obstacle')
COMBINATIONS={'pedestrian_vehicle':('pedestrian','vehicle'),'pedestrian_two_wheeler':('pedestrian','two_wheeler'),
              'pedestrian_obstacle':('pedestrian','obstacle'),'vehicle_obstacle':('vehicle','obstacle')}


@dataclass(frozen=True)
class AlertSnapshot:
    context: tuple
    frame_key: str
    observation_ns: int
    eligible_groups: tuple

    def validate(self,now_ns):
        if (not isinstance(self.context,tuple) or not self.context or not isinstance(self.frame_key,str)
                or not self.frame_key or type(now_ns) is not int or type(self.observation_ns) is not int
                or not 0<=self.observation_ns<=now_ns or not isinstance(self.eligible_groups,tuple)
                or len(set(self.eligible_groups))!=len(self.eligible_groups)
                or any(g not in GROUPS for g in self.eligible_groups)):
            raise ValueError('invalid fresh alert snapshot or clock')


class VoiceScheduler:
    """Caller serializes access; no thread, playback or wall-clock assumptions.

    pending is a single current choice, rebuilt from fresh application state.
    A started phrase may finish when evidence is later unknown or clears.
    """
    def __init__(self,*,freshness_ms=250,gap_ms=1000,available_voice_keys=GROUPS):
        if freshness_ms!=250 or gap_ms!=1000:
            raise ValueError('approved freshness/gap contract required')
        self.fresh_ns=250000000;self.gap_ns=1000000000
        self.context=None;self.snapshot=None;self.current=None;self.pending=None
        self.last_spoken={};self.last_end_ns=None;self.last_clock=-1;self.serial=0
        self.events=[]
        self.available_voice_keys=set(available_voice_keys)

    def _clock(self,now):
        if type(now) is not int or now<0 or now<self.last_clock:
            raise ValueError('monotonic playback clock required')
        self.last_clock=now

    def _choose(self,now):
        snap=self.snapshot
        if snap is None or now-snap.observation_ns>self.fresh_ns:return None
        groups=snap.eligible_groups
        if not groups:return None
        # First unseen group wins; pedestrian has first preference. After all
        # eligible groups have spoken, least recently started wins fairly.
        order=sorted(groups,key=lambda g:(self.last_spoken.get(g,-1),GROUPS.index(g)))
        first=order[0]
        pairs=[(key,members) for key,members in COMBINATIONS.items()
               if key in self.available_voice_keys and first in members and all(g in groups for g in members)]
        if pairs:return min(pairs,key=lambda p:order.index(next(g for g in p[1] if g!=first)))[0]
        return first

    def observe(self,snapshot,now_ns):
        snapshot.validate(now_ns)
        if (self.snapshot and snapshot.context==self.context
                and snapshot.observation_ns<=self.snapshot.observation_ns):
            raise ValueError('duplicate or reordered alert observation')
        self._clock(now_ns)
        if snapshot.context!=self.context:
            self.context=snapshot.context;self.last_spoken={};self.pending=None
            self.events.append(dict(action='CONTEXT_RESET',at_ns=now_ns,current_may_finish=self.current is not None))
        self.snapshot=snapshot
        self.pending=self._choose(now_ns)

    def poll(self,now_ns):
        self._clock(now_ns)
        self.pending=self._choose(now_ns)
        if (self.current is not None or self.pending is None
                or self.last_end_ns is not None and now_ns<self.last_end_ns+self.gap_ns):return None
        self.serial+=1;group=self.pending;self.pending=None
        snap=self.snapshot
        request=dict(request_id='voice-'+str(self.serial),group=group,file=group+'.wav',
                     started_ns=now_ns,frame_key=snap.frame_key,observation_ns=snap.observation_ns,
                     context_id=sha256(json.dumps(self.context,sort_keys=True).encode()).hexdigest())
        request['groups']=COMBINATIONS.get(group,(group,))
        self.current=request
        for member in request['groups']:self.last_spoken[member]=now_ns
        self.events.append(dict(action='PLAY_START',**request))
        return dict(request)

    def complete(self,request_id,actual_end_ns,*,success=True):
        # Validate before mutating; an old callback cannot release a new player.
        if self.current is None or self.current['request_id']!=request_id:
            raise ValueError('playback completion token differs')
        if type(actual_end_ns) is not int or actual_end_ns<max(self.current['started_ns'],self.last_clock):
            raise ValueError('invalid actual playback end clock')
        self._clock(actual_end_ns)
        self.events.append(dict(action='PLAY_END' if success else 'PLAY_FAILED',
                                request_id=request_id,group=self.current['group'],at_ns=actual_end_ns))
        self.last_end_ns=actual_end_ns;self.current=None
        self.pending=self._choose(actual_end_ns)

    def invalidate(self,now_ns,reason='NO_NEW_OBSERVATION'):
        self._clock(now_ns);self.snapshot=None;self.pending=None
        self.events.append(dict(action='PENDING_INVALIDATED',at_ns=now_ns,reason=reason))

    def state(self,now_ns):
        if type(now_ns) is not int or now_ns<self.last_clock:raise ValueError('state clock went backwards')
        return dict(playing=None if self.current is None else dict(self.current),
                    pending=self._choose(now_ns),max_pending=1,max_playing=1,
                    next_earliest_ns=None if self.last_end_ns is None else self.last_end_ns+self.gap_ns,
                    actual_device_playback='NOT_MEASURED_BY_SCHEDULER')
