"""Same-frame possible foreground conflict of an actual depth query patch.

This is a conservative diagnostic qualification, not segmentation or calibrated
occlusion GT. Never replaces a value or changes detection/tracker indices.
Only high current detections and their raw patch statistics are examined.
"""
import numpy as np


def annotate_foreground(detections,groups,frame_key,policy,*,minimum_coverage=.7,duplicate_iou=.85,minimum_confidence=.25):
    if not 0<minimum_coverage<=1 or not 0<=duplicate_iou<1:
        raise ValueError('Invalid depth ownership geometry settings')
    out=[dict(o) for o in detections]
    if not out:return out
    b=np.asarray([o['xyxy'] for o in out],dtype=float)
    p=np.asarray([o.get('patch_xyxy') or [0,0,0,0] for o in out],dtype=float)
    area=np.maximum(b[:,2:]-b[:,:2],0).prod(axis=1)
    inter=np.maximum(np.minimum(b[:,None,2:],b[None,:,2:])-np.maximum(b[:,None,:2],b[None,:,:2]),0).prod(axis=2)
    iou=inter/np.maximum(area[:,None]+area[None,:]-inter,1e-9)
    patch_area=np.maximum(p[:,2:]-p[:,:2],0).prod(axis=1)
    overlap=np.maximum(np.minimum(p[:,None,2:],b[None,:,2:])-np.maximum(p[:,None,:2],b[None,:,:2]),0).prod(axis=2)
    coverage=overlap/np.maximum(patch_area[:,None],1e-9)
    group=[groups.get(str(o['class_id'])) for o in out]
    confident=np.asarray([o['confidence']>=minimum_confidence for o in out],bool)
    cross=np.asarray([[a is not None and c is not None and a!=c for c in group] for a in group],bool)
    z=np.asarray([o.get('estimated_depth_m',np.nan) for o in out],float)
    iqr=np.asarray([o.get('depth_iqr_m',np.nan) for o in out],float)
    fraction=np.asarray([o.get('valid_fraction',0.) for o in out],float)
    usable=(np.isfinite(z)&(z>0)&np.isfinite(iqr)&(iqr>=0)
            &(iqr/np.maximum(z,1e-9)<=policy.maximum_relative_iqr)
            &(fraction>=policy.minimum_valid_fraction))
    possible=(cross&confident[:,None]&confident[None,:]&(iou<=duplicate_iou)&(coverage>=minimum_coverage)
              &(b[None,:,3]>=b[:,None,3])&usable[:,None]&usable[None,:]&(z[None,:]<=z[:,None]))
    for i,o in enumerate(out):
        rivals=np.flatnonzero(possible[i]).tolist()
        o['possible_foreground_occlusion']=bool(rivals)
        o['distance_ownership']=dict(status='UNKNOWN_COMPETING_CURRENT_SURFACES' if rivals else 'NO_CURRENT_COMPETITION_FLAG',
            frame_key=frame_key,possible_foreground_indices=rivals,patch_coverage=[float(coverage[i,j]) for j in rivals],
            index_space='RAW_CURRENT_HIGH_DETECTIONS',calibrated=False,
            source='CURRENT_PATCH_COVERAGE_FOOTPOINT_AND_RAW_DEPTH_SUPPORT')
    return out
