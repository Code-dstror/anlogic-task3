"""Prediction-only overlap ambiguity of the actual depth sampling patch.

Inspired by detection/track intersection-over-area occlusion checks. This is
neither instance segmentation nor ground-truth identity/occlusion labeling.
"""
def annotate_overlap(detections,groups,minimum_coverage=.7):
    if not 0<minimum_coverage<=1:raise ValueError('Invalid patch coverage threshold')
    result=[dict(d) for d in detections]
    for i,d in enumerate(result):
        d['ambiguous_target_patch']=False;d['overlapping_detection_indices']=[]
        patch=d.get('patch_xyxy');group=groups.get(str(d['class_id']))
        if patch is None or group is None:continue
        a,b,c,e=patch;area=max(0,c-a)*max(0,e-b)
        if area<=0:continue
        for j,other in enumerate(result):
            if i==j or other['confidence']<.25 or groups.get(str(other['class_id']))!=group:continue
            x,y,z,w=other['xyxy']
            coverage=max(0,min(c,z)-max(a,x))*max(0,min(e,w)-max(b,y))/area
            if coverage>=minimum_coverage:
                d['ambiguous_target_patch']=True;d['overlapping_detection_indices'].append(j)
    return result
