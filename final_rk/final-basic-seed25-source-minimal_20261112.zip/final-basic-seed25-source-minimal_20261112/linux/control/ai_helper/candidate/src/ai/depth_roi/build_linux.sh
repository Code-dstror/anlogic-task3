#!/usr/bin/env bash
set -eu
cd -- "$(dirname -- "$0")"
mkdir -p build
"${CXX:-c++}" -std=c++17 -O3 -fPIC -shared -ffp-contract=off -fno-fast-math \
  native/roi_depth.cpp -o build/libroi_depth.so
printf '%s\n' 'Built for the current compiler target. Performance/ARM64 numerical acceptance still require that target device.'
