#ifndef Y26_KMS_AI_BOUNDARY_H
#define Y26_KMS_AI_BOUNDARY_H
#include "linux_gate.h"
#ifdef __cplusplus
extern "C" {
#endif
/* AI-private in-process candidate, NOT the FPGA or current video wire ABI.
 * One video owner thread calls all APIs. The adapter retains no video refs.
 * token is a positive unique increasing decoded-frame ID within this run, not time.
 * received is original host CLOCK_MONOTONIC receive time; never reset on offer.
 * layout=1: mapped linear NV12; color=1: verified BT.601 full range.
 * Unknown caps use 0 and bypass AI. Mapping/sync remain the video's responsibility.
 */
#pragma pack(push,1)
struct y26_kms_frame {
 uint64_t run,token,received;
 struct y26_source source;
 uint32_t width,height,layout,color;
};
#pragma pack(pop)
void* y26_kms_open(const char* directory,uint64_t run);
/* 1 submitted; 0 bypass. No inference wait. Synchronous NV12 copy still costs CPU.
 * Call on decoded original pixels BEFORE any existing overlay is drawn. */
int y26_kms_offer(void*,const struct y26_kms_frame*,const unsigned char* y,
                  const unsigned char* uv,int y_stride,int uv_stride);
/* Call once in presentation order, immediately before presenting this frame.
 * 1 exact ready result (count may be 0); 0 plain video. Never a video STOP signal.
 * Never waits for pending AI. An unready sample is retired, not reused next frame.
 * cap must be >=300. This API selects boxes; it does NOT draw or commit KMS.
 */
int y26_kms_select(void*,const struct y26_kms_frame*,struct y26_box*,int cap,int* count);
int y26_kms_disabled(void*);
/* Stop offer/display eligibility and half-close the request direction.
 * Keep the bridge/runner alive to drain exact completions. 1/0/-1 as gate. */
int y26_kms_begin_drain(void*);
/* Stop callers first. 0 means pending/unknown native ownership: retain handle,
 * directory, mappings and consumer; retry only after actual completion.
 * 1 destroys the object; caller must clear its pointer. */
int y26_kms_try_close(void*);
#ifdef __cplusplus
}
#endif
#endif
