"""Frame-bound offline image-region warnings. No metric collision assessment."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import cached_property
from hashlib import sha256
import json
import math


@dataclass(frozen=True)
class FrameIdentity:
    session: str
    epoch: int
    camera: str
    sequence: int
    width: int
    height: int
    source_rgb_sha256: str
    geometry: str = 'DECODED_IMAGE'

    def __post_init__(self):
        if (any(type(x) is not int or x < 0 for x in (self.sequence, self.epoch))
                or any(type(x) is not int or x <= 0 for x in (self.width, self.height))
                or any(not isinstance(x, str) or not x for x in (self.session, self.camera, self.geometry))
                or len(self.source_rgb_sha256) != 64
                or any(c not in '0123456789abcdef' for c in self.source_rgb_sha256)):
            raise ValueError('invalid frame identity')

    @cached_property
    def key(self):
        return sha256(json.dumps(asdict(self), sort_keys=True).encode()).hexdigest()

    @property
    def context(self):
        return (self.session, self.epoch, self.camera, self.width, self.height, self.geometry)


def inside(point, polygon):
    """Ray casting; the polygon boundary is included."""
    x, y = point
    result = False
    for a, b in zip(polygon, polygon[1:] + polygon[:1]):
        ax, ay = a
        bx, by = b
        cross = (x-ax)*(by-ay) - (y-ay)*(bx-ax)
        if abs(cross) < 1e-10 and min(ax,bx)-1e-10 <= x <= max(ax,bx)+1e-10 and min(ay,by)-1e-10 <= y <= max(ay,by)+1e-10:
            return True
        if (ay > y) != (by > y) and x < (bx-ax)*(y-ay)/(by-ay)+ax:
            result = not result
    return result


def validate_config(config):
    if config.get('scope') != 'OFFLINE_EXPERIMENT_NOT_APPROVED_WARNING_THRESHOLDS':
        raise ValueError('experimental scope must be explicit')
    for key in ('enter_frames', 'exit_frames', 'missing_frames'):
        if type(config.get(key)) is not int or config[key] < 1:
            raise ValueError('frame thresholds must be positive integers')
    if not isinstance(config.get('rule_id'), str) or not config['rule_id']:
        raise ValueError('rule identity required')
    if config.get('entry_point') != 'BBOX_BOTTOM_CENTER':
        raise ValueError('only bbox bottom-center membership is implemented')
    score = config.get('observation_confidence')
    if type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 1:
        raise ValueError('invalid observation threshold')
    for key in ('entry_polygon', 'retention_polygon'):
        polygon = config.get(key)
        if (not isinstance(polygon, list) or len(polygon) < 3
                or any(not isinstance(p, list) or len(p) != 2 for p in polygon)
                or any(type(v) not in (int,float) or not math.isfinite(v) or not 0 <= v <= 1 for p in polygon for v in p)):
            raise ValueError('invalid normalized polygon')
        # These demo polygons must be nondegenerate and convex. This also
        # excludes self-crossing input and makes containment unambiguous.
        turns = []
        for i, a in enumerate(polygon):
            b, c = polygon[(i+1)%len(polygon)], polygon[(i+2)%len(polygon)]
            turns.append((b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]))
        if not (all(t > 1e-10 for t in turns) or all(t < -1e-10 for t in turns)):
            raise ValueError('polygon must be strictly convex')
    if not all(inside(p,config['retention_polygon']) for p in config['entry_polygon']):
        raise ValueError('retention polygon must contain entry polygon')


class RegionWarning:
    def __init__(self, config):
        validate_config(config)
        self.config = json.loads(json.dumps(config, allow_nan=False))
        self.config_sha256 = sha256(json.dumps(self.config,sort_keys=True).encode()).hexdigest()
        self.context = None
        self.last_sequence = None
        self.states = {}
        self.counter = 0

    def _transition(self, frame, tid, state, action, reason):
        return {'event_id': state['event_id'], 'action': action, 'reason': reason,
                'track_id': tid, 'class_id': state['class_id'], 'frame_key': frame.key,
                'sequence': frame.sequence, 'rule_id': self.config['rule_id'],
                'config_sha256': self.config_sha256, 'warning_kind': 'REGION_ONLY',
                'collision_risk': 'UNKNOWN', 'distance_m': None}

    def reset(self, frame, reason):
        events = [self._transition(frame, tid, state, 'ENDED_UNKNOWN', reason)
                  for tid,state in self.states.items() if state['event_id']]
        self.states.clear()
        return events

    def update(self, frame, observations):
        # Validate everything before changing state. A stale/misbound result
        # cannot advance confirmation or paint a box on another source frame.
        seen = set()
        for obj in observations:
            box, score = obj['bbox_source_xyxy'], obj['confidence']
            if (obj.get('frame_key') != frame.key
                    or type(obj.get('track_id')) is not int or obj['track_id'] < 0
                    or obj['track_id'] in seen or type(obj.get('class_id')) is not int
                    or not 0 <= obj['class_id'] < 23
                    or type(score) not in (int,float) or not math.isfinite(score) or not 0 <= score <= 1
                    or len(box) != 4 or any(type(v) not in (int,float) or not math.isfinite(v) for v in box)
                    or not 0 <= box[0] < box[2] <= frame.width or not 0 <= box[1] < box[3] <= frame.height
                    or obj.get('observation_state') != 'OBSERVED_FILTERED'):
                raise ValueError('invalid or misbound current-frame observation')
            seen.add(obj['track_id'])
        same_context = frame.context == self.context
        if same_context and self.last_sequence is not None and frame.sequence <= self.last_sequence:
            raise ValueError('duplicate or out-of-order frame')
        events = []
        if not same_context:
            events.extend(self.reset(frame,'CONTEXT_CHANGED'))
        elif self.last_sequence is not None and frame.sequence != self.last_sequence+1:
            events.extend(self.reset(frame,'FRAME_SEQUENCE_GAP'))
        self.context, self.last_sequence = frame.context, frame.sequence
        objects, eligible = [], set()
        for obj in observations:
            tid = obj['track_id']
            if obj['confidence'] < self.config['observation_confidence']:
                continue
            eligible.add(tid)
            state = self.states.get(tid)
            if state is not None and state['class_id'] != obj['class_id']:
                if state['event_id']:
                    events.append(self._transition(frame,tid,state,'ENDED_UNKNOWN','TRACK_CLASS_CHANGED'))
                state = None
            if state is None:
                state = {'class_id':obj['class_id'], 'enter':0,'exit':0,'missing':0,'event_id':None}
                self.states[tid] = state
            state['missing'] = 0
            box = obj['bbox_source_xyxy']
            point = [(box[0]+box[2])/(2*frame.width),box[3]/frame.height]
            entry = inside(point,self.config['entry_polygon'])
            retain = inside(point,self.config['retention_polygon'])
            if state['event_id']:
                state['exit'] = 0 if retain else state['exit']+1
                if state['exit'] >= self.config['exit_frames']:
                    events.append(self._transition(frame,tid,state,'CLEARED','OBSERVED_OUTSIDE_RETENTION_REGION'))
                    state.update(event_id=None,enter=0,exit=0)
                    status = 'CLEARED'
                else:
                    status = 'ACTIVE' if retain else 'CLEAR_PENDING'
            else:
                state['enter'] = state['enter']+1 if entry else 0
                if state['enter'] >= self.config['enter_frames']:
                    self.counter += 1
                    state['event_id'] = f'{frame.session}:{frame.epoch}:region:{self.counter}'
                    events.append(self._transition(frame,tid,state,'ACTIVATED','CONSECUTIVE_OBSERVED_REGION_ENTRY'))
                    status = 'ACTIVE'
                else:
                    status = 'CANDIDATE' if entry else 'INACTIVE'
            level = ('REGION_WARNING' if state['event_id'] else
                     'PENDING' if status=='CANDIDATE' else 'OUTSIDE_REGION')
            objects.append({**obj,'region_point_normalized':point,'inside_entry':entry,
                            'inside_retention':retain,'warning_state':status,'danger_level':level,
                            'danger_basis':'IMAGE_REGION_ONLY','collision_risk':'UNKNOWN',
                            'distance':{'status':'UNAVAILABLE','meters':None},
                            'enter_streak':state['enter'],'exit_streak':state['exit'],
                            'event_id':state['event_id']})
        missing = []
        for tid, state in list(self.states.items()):
            if tid in eligible:
                continue
            state['missing'] += 1
            state['enter'] = 0
            state['exit'] = 0  # Missing observations cannot confirm an exit.
            if state['event_id']:
                missing.append({'track_id':tid,'event_id':state['event_id'],
                                'warning_state':'OBSERVATION_MISSING','danger_level':'UNKNOWN',
                                'missing_frames':state['missing'],'bbox_source_xyxy':None})
            if state['missing'] >= self.config['missing_frames']:
                if state['event_id']:
                    events.append(self._transition(frame,tid,state,'ENDED_UNKNOWN','OBSERVATION_LOST'))
                del self.states[tid]
        return {'schema':'OFFLINE_REGION_WARNING_V1','frame':asdict(frame),'frame_key':frame.key,
                'rule_id':self.config['rule_id'],'config_sha256':self.config_sha256,
                'warning_kind':'REGION_ONLY','collision_risk':'UNKNOWN',
                'objects':objects,'missing_observations':missing,'event_transitions':events,
                'active_event_count':sum(bool(s['event_id']) for s in self.states.values()),
                'metric_warning_enabled':False,'production_real':'NOT_VERIFIED','hdmi':'NOT_RUN'}

    def finish(self, frame):
        return self.reset(frame,'OFFLINE_STREAM_END')
