"""Robust source-time closing trends; unverified camera-plane TTC, not bumper TTC."""
import math
import statistics

class Motion:
    def __init__(self, options=None):
        self.options=dict(window_ms=1200,minimum_span_ms=600,minimum_observations=4,maximum_gap_ms=250,
            noise_floor_m=.15,closing_min_mps=.5,stable_limit_mps=1,ttc_attention_s=3,ttc_danger_s=1.5,confirm_ms=200,
            history_mode='source_time_window',retain_missing_history=False,ttc_distance_mode='raw_current')
        self.options.update(options or {});self.context=None;self.states={}
        if self.options['history_mode'] not in ('source_time_window','legacy_last16'):
            raise ValueError('Unknown motion history mode')
        if not 190 <= self.options['minimum_span_ms'] <= self.options['window_ms']:
            raise ValueError('Motion window must cover the minimum source-time span')
        if not 2 <= self.options['minimum_observations'] <= 16:
            raise ValueError('Motion fit supports 2 to 16 actual observations')
        if self.options['ttc_distance_mode'] not in ('raw_current','fitted_current'):
            raise ValueError('Unknown TTC distance mode')

    def _fit_points(self,points):
        """Keep established low-rate fits; recover source-time support at 30/60Hz.

        Raw history is bounded separately from the 16-point slope calculation.
        Every selected pair is an actual past observation, never interpolation.
        """
        recent=points[-16:]
        if (self.options['history_mode']=='legacy_last16' or len(points)<=16
                or recent[-1][0]-recent[0][0]>=self.options['minimum_span_ms']):
            return recent
        selected=[];index=0;start,end=points[0][0],points[-1][0]
        for i in range(16):
            target=start+(end-start)*i/15
            while index+1<len(points) and abs(points[index+1][0]-target)<abs(points[index][0]-target):
                index+=1
            if not selected or points[index] != selected[-1]:selected.append(points[index])
        return selected

    def step(self,objects,time,context):
        if context!=self.context:self.states={};self.context=context
        c=self.options;out={};seen=set()
        for o in objects:
            oid=o['id'];seen.add(oid)
            result=dict(state='UNKNOWN',reason='NO_VALID_CURRENT_OBSERVATION',closing_speed_estimate_mps=None,
                slope_support_band_mps=None,ttc_camera_plane_estimate_s=None,ttc_s=None,bumper_clearance_m=None,
                metric_validated=False,risk_candidate_level='UNKNOWN',risk_confirmed=False,confirmed_stopped=False,
                path_source='MANUAL_DIAGNOSTIC_ROI',assumption='CONSTANT_CLOSING_SPEED_TO_CAMERA_PLANE_ONLY')
            out[oid]=result;z=o.get('distance')
            if (not o.get('tracked') or not o.get('diagnostic_eligible') or o.get('jump') or o.get('edge')
                    or not isinstance(z,(int,float)) or not math.isfinite(z) or z<=0):
                self.states.pop(oid,None);continue
            s=self.states.get(oid)
            resumed=bool(s and s.get('missing'))
            # The ordinary adjacent-frame check cannot see across an absent frame.
            # Reuse only continuous current distances; never insert a predicted point.
            recovery_jump=bool(resumed and abs(z-s['points'][-1][1])>max(3,.2*s['points'][-1][1]))
            if recovery_jump or o.get('identity_conflict'):
                s=None;resumed=False
                result['history_reset_reason']='RECOVERY_DISTANCE_DISCONTINUITY' if recovery_jump else 'IDENTITY_CONFLICT'
            if s is None or s['cid']!=o['class_id'] or time<=s['time'] or time-s['time']>c['maximum_gap_ms']:
                s=dict(cid=o['class_id'],group=o['group'],points=[],hazard=None,since=None)
                resumed=False
            if resumed:result['history_resumed']=True;result['history_gap_ms']=time-s['time']
            s['missing']=False
            s['time']=time;s['points'].append((time,z))
            limit=16 if c['history_mode']=='legacy_last16' else 128
            s['points']=[p for p in s['points'] if time-p[0]<=c['window_ms']][-limit:];self.states[oid]=s
            points=self._fit_points(s['points']);span=(time-points[0][0])/1000;result['reason']='INSUFFICIENT_CONTINUOUS_HISTORY'
            if len(points)<c['minimum_observations'] or span*1000<c['minimum_span_ms']:continue
            start=points[0][0]
            slopes=[(b[1]-a[1])/((b[0]-a[0])/1000) for i,a in enumerate(points) for b in points[i+1:] if (b[0]-a[0])/1000>=.19]
            slope=statistics.median(slopes);intercept=statistics.median(z-slope*(t-start)/1000 for t,z in points)
            residuals=[z-(intercept+slope*(t-start)/1000) for t,z in points];center=statistics.median(residuals)
            noise=max(c['noise_floor_m'],1.4826*statistics.median(abs(r-center) for r in residuals));half=2*noise/span;closing=-slope
            fitted_z=intercept+slope*span
            result.update(closing_speed_estimate_mps=closing,slope_support_band_mps=[closing-half,closing+half],
                band_definition='HEURISTIC_RESIDUAL_BAND_NOT_CALIBRATED_CONFIDENCE_INTERVAL',reason='CURRENT_UNVERIFIED_DEPTH_WINDOW')
            result['state']=('APPROACHING' if closing-half>c['closing_min_mps'] else 'RECEDING' if closing+half < -c['closing_min_mps']
                else 'NEAR_CONSTANT_RANGE' if abs(closing)+half<=c['stable_limit_mps'] else 'UNKNOWN')
            hazard=None
            if result['state']=='APPROACHING' and o['group']=='vehicle':
                numerator=fitted_z if c['ttc_distance_mode']=='fitted_current' else z
                if not math.isfinite(numerator) or numerator<=0:
                    result.update(state='UNKNOWN',reason='INVALID_TTC_FITTED_DISTANCE');s.update(hazard=None,since=None);continue
                ttc=numerator/closing;result['ttc_camera_plane_estimate_s']=ttc
                if c['ttc_distance_mode']=='fitted_current':
                    result.update(ttc_distance_basis='FITTED_CURRENT_DIAGNOSTIC_NOT_MEASURED_RANGE',
                        ttc_distance_estimate_m=fitted_z,ttc_raw_camera_plane_estimate_s=z/closing)
                if o.get('in_roi') and ttc<=c['ttc_attention_s']:hazard='DANGER' if ttc<=c['ttc_danger_s'] else 'ATTENTION'
            if hazard!=s['hazard']:s.update(hazard=hazard,since=time if hazard else None)
            if hazard:result.update(risk_candidate_level=hazard,risk_confirmed=time-s['since']>=c['confirm_ms'])
        retained={}
        for key,value in self.states.items():
            if key in seen:retained[key]=value
            elif (c['retain_missing_history'] and value.get('group')=='vehicle'
                  and 0<=time-value['time']<=c['maximum_gap_ms']):
                # No output/current distance/confirmation while absent. Timestamp and
                # real history remain untouched; the confirmation starts again on return.
                value.update(missing=True,hazard=None,since=None);retained[key]=value
        self.states=retained
        return out
