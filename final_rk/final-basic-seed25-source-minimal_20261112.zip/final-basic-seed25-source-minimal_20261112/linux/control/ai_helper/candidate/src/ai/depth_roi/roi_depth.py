"""Two-stage align-corners ROI sampling, without a dense resized depth image.

numpy_exact/native_exact retain all original ROI pixels and intermediate FP32
rounding. Approximate grid sampling was discarded by user request.
An instance belongs to one worker and one fixed image geometry.
"""
import ctypes as ct
from pathlib import Path

import numpy as np


def axis_map(n_in, n_out, start=0, end=None):
    if min(n_in, n_out) < 1:
        raise ValueError('Positive dimensions required')
    end=n_in-1 if end is None else end
    pos = np.linspace(start, end, n_out, dtype=np.float32)
    lo = pos.astype(np.int32)
    # Keep the original NumPy float32-minus-int32 promotion to float64.
    return lo, np.minimum(lo+1, n_in-1), pos-lo


def region(box, shape):
    if len(box) != 4 or not np.isfinite(box).all():
        raise ValueError('Finite xyxy required')
    x1,y1,x2,y2 = map(float,box)
    if x2 <= x1 or y2 <= y1:
        return (0,0,0,0)
    cx,cy = (x1+x2)/2,(y1+y2)/2
    rx,ry = max(1,(x2-x1)*.15),max(1,(y2-y1)*.15)
    return (min(shape[1],max(0,int(cx-rx))), min(shape[0],max(0,int(cy-ry))),
            max(0,min(shape[1],int(np.ceil(cx+rx)))), max(0,min(shape[0],int(np.ceil(cy+ry)))))


def bilinear(depth, xs, ys, xmap, ymap):
    x0,xn,dx = (a[xs] for a in xmap)
    y0,yn,dy = (a[ys] for a in ymap)
    a = depth[y0[:,None],x0[None,:]]*(1-dx)+depth[y0[:,None],xn[None,:]]*dx
    b = depth[yn[:,None],x0[None,:]]*(1-dx)+depth[yn[:,None],xn[None,:]]*dx
    return (a*(1-dy[:,None])+b*dy[:,None]).astype(np.float32)


def result(patch, bounds, approximate):
    valid = patch[np.isfinite(patch)&(patch>0)]
    out = dict(estimated_depth_m=None, depth_state='UNKNOWN_INVALID_PATCH', valid_fraction=0.,
               patch_xyxy=list(bounds), depth_iqr_m=None, sampled_pixels=int(patch.size),
               region_pixels=max(0,bounds[2]-bounds[0])*max(0,bounds[3]-bounds[1]),
               statistics_approximate=bool(approximate))
    if valid.size:
        out.update(estimated_depth_m=float(np.median(valid)),
                   depth_state='MODEL_DEFAULT_SCALE_UNVERIFIED',
                   valid_fraction=float(valid.size/patch.size),
                   depth_iqr_m=float(np.percentile(valid,75)-np.percentile(valid,25)))
    return out


class NativeResult(ct.Structure):
    _fields_ = [('median',ct.c_double),('fraction',ct.c_double),('iqr',ct.c_double),
                ('bounds',ct.c_int32*4),('sampled',ct.c_int32),('region',ct.c_int32),
                ('valid',ct.c_int32),('approximate',ct.c_int32)]


class RoiDepthSampler:
    def __init__(self, raw_shape, source_shape, intermediate_shape=(768,768),
                 mode='numpy_exact', library=None, content_box=None):
        if mode not in ('numpy_exact','native_exact'):
            raise ValueError('Unknown sampler mode')
        self.raw_shape=tuple(map(int,raw_shape));self.source_shape=tuple(map(int,source_shape))
        self.intermediate_shape=tuple(map(int,intermediate_shape));self.mode=mode
        if any(d<1 or d>8192 for s in (self.raw_shape,self.source_shape,self.intermediate_shape) for d in s):
            raise ValueError('Dimensions must be in 1..8192')
        self.x1=axis_map(self.raw_shape[1],self.intermediate_shape[1])
        self.y1=axis_map(self.raw_shape[0],self.intermediate_shape[0])
        self.x2=axis_map(self.intermediate_shape[1],self.source_shape[1])
        self.y2=axis_map(self.intermediate_shape[0],self.source_shape[0])
        self.content_box=content_box
        if content_box is not None:
            left,top,width,height=map(int,content_box)
            if left<0 or top<0 or width<1 or height<1 or left+width>self.intermediate_shape[1] or top+height>self.intermediate_shape[0]:
                raise ValueError('Content crop outside model input')
            self.x2=axis_map(self.intermediate_shape[1],self.source_shape[1],left,left+width-1)
            self.y2=axis_map(self.intermediate_shape[0],self.source_shape[0],top,top+height-1)
        self.handle=None
        if mode.startswith('native'):
            path=Path(library) if library else Path(__file__).parent/'build'/('roi_depth.dll' if __import__('os').name=='nt' else 'libroi_depth.so')
            self.lib=ct.CDLL(str(path.resolve()))
            self.lib.ds_create.argtypes=[ct.c_int]*7;self.lib.ds_create.restype=ct.c_void_p
            self.lib.ds_destroy.argtypes=[ct.c_void_p]
            self.lib.ds_process.argtypes=[ct.c_void_p,ct.POINTER(ct.c_float),ct.c_int,
                                          ct.POINTER(ct.c_double),ct.c_int,ct.POINTER(NativeResult)]
            self.lib.ds_process.restype=ct.c_int
            self.handle=self.lib.ds_create(*self.raw_shape,*self.intermediate_shape,*self.source_shape,4096)
            if not self.handle:raise RuntimeError('Native sampler allocation failed')
            if content_box is not None:
                self.lib.ds_set_content.argtypes=[ct.c_void_p,ct.c_int,ct.c_int,ct.c_int,ct.c_int]
                self.lib.ds_set_content.restype=ct.c_int
                if self.lib.ds_set_content(self.handle,*map(int,content_box)):raise RuntimeError('Invalid native content crop')

    def close(self):
        if getattr(self,'handle',None):
            self.lib.ds_destroy(self.handle);self.handle=None

    def __del__(self):
        self.close()

    def sample(self, raw, boxes):
        raw=np.asarray(raw,dtype=np.float32)
        if raw.shape != self.raw_shape:raise ValueError('Depth geometry changed; create matching sampler')
        if len(boxes)>4096:raise ValueError('Too many boxes')
        if self.mode.startswith('native'):
            if not self.handle:raise RuntimeError('Sampler is closed')
            raw=np.ascontiguousarray(raw)
            boxes=np.ascontiguousarray(boxes,dtype=np.float64).reshape(-1,4)
            if not np.isfinite(boxes).all():raise ValueError('Nonfinite box')
            buf=(NativeResult*len(boxes))()
            code=self.lib.ds_process(self.handle,raw.ctypes.data_as(ct.POINTER(ct.c_float)),raw.shape[1],
                                     boxes.ctypes.data_as(ct.POINTER(ct.c_double)),len(boxes),buf)
            if code:raise RuntimeError('Native sampler error '+str(code))
            return [dict(estimated_depth_m=r.median if r.valid else None,
                         depth_state='MODEL_DEFAULT_SCALE_UNVERIFIED' if r.valid else 'UNKNOWN_INVALID_PATCH',
                         valid_fraction=r.fraction,depth_iqr_m=r.iqr if r.valid else None,
                         patch_xyxy=list(r.bounds),sampled_pixels=r.sampled,region_pixels=r.region,
                         statistics_approximate=bool(r.approximate)) for r in buf]
        outputs=[]
        for box in boxes:
            bounds=region(box,self.source_shape);xa,ya,xb,yb=bounds
            xs=np.arange(xa,max(xa,xb),dtype=np.int32);ys=np.arange(ya,max(ya,yb),dtype=np.int32)
            if not len(xs) or not len(ys):
                outputs.append(result(np.empty(0,np.float32),bounds,False));continue
            # Reconstruct only intermediate cells used by the final sample grid.
            ux=np.unique(np.concatenate((self.x2[0][xs],self.x2[1][xs])))
            uy=np.unique(np.concatenate((self.y2[0][ys],self.y2[1][ys])))
            mid=raw[np.ix_(uy,ux)].copy() if self.raw_shape==self.intermediate_shape else bilinear(raw,ux,uy,self.x1,self.y1)
            xm=(np.searchsorted(ux,self.x2[0][xs]),np.searchsorted(ux,self.x2[1][xs]),self.x2[2][xs])
            ym=(np.searchsorted(uy,self.y2[0][ys]),np.searchsorted(uy,self.y2[1][ys]),self.y2[2][ys])
            patch=bilinear(mid,np.arange(len(xs)),np.arange(len(ys)),xm,ym)
            outputs.append(result(patch,bounds,len(xs)*len(ys)<max(0,xb-xa)*max(0,yb-ya)))
        return outputs
