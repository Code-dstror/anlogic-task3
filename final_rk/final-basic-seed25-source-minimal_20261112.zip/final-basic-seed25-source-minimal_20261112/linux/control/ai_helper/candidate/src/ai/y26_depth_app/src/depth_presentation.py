"""Preserve current detection estimates without promoting them to measurements."""
import math

def detection_estimate(stamp,evidence,policy):
    value=evidence.get('estimated_depth_m')
    valid=isinstance(value,(int,float)) and math.isfinite(value) and value>0
    current=evidence.get('frame_key',stamp.identity.key)==stamp.identity.key and stamp.age_ms<=policy.maximum_age_ms
    raw=float(value) if valid and current else None
    bound=policy.scale is not None and stamp.identity.geometry==policy.calibration_geometry
    return dict(model_estimate_m=raw,calibrated_estimate_m=raw*policy.scale if raw is not None and bound else None,
        status='RAW_UNVERIFIED_TRACK_PENDING' if raw is not None else 'UNKNOWN_INVALID_OR_STALE_DEPTH',
        frame_key=stamp.identity.key,meters=None,usable_for_relative_depth=False,collision_risk='UNKNOWN',source=policy.source_name,
        patch_xyxy=evidence.get('patch_xyxy'),depth_iqr_m=evidence.get('depth_iqr_m'),
        valid_fraction=evidence.get('valid_fraction'),calibration_geometry=policy.calibration_geometry if bound else None)

def visible_depth(distance):
    """Prefer a current estimate to old display prediction; label its evidence level."""
    display=distance.get('display',{})
    current=display.get('estimate_m')
    if current is not None and display.get('status')!='PREDICTED_DISPLAY_ONLY':
        return current,'CURRENT_ESTIMATE'
    raw=distance.get('calibrated_estimate_m')
    if raw is None:raw=distance.get('model_estimate_m')
    if raw is not None:return raw,'RAW_UNVERIFIED'
    if current is not None:return current,'PREDICTED_DISPLAY_ONLY'
    return None,'UNKNOWN'
