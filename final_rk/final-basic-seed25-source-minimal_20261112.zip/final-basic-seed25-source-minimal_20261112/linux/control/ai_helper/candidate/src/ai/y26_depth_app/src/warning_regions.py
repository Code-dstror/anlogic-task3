"""Region adapters; camera geometry and model output remain outside event rules."""
from hashlib import sha256
import json

from region_warning import inside,validate_config
from warning_contracts import RegionContact


class PolygonRegion:
    def __init__(self,entry,retention,*,label='MANUAL_IMAGE_REGION_EXPERIMENT'):
        config=dict(scope='OFFLINE_EXPERIMENT_NOT_APPROVED_WARNING_THRESHOLDS',
                    rule_id='polygon-validator',entry_point='BBOX_BOTTOM_CENTER',
                    observation_confidence=0,enter_frames=1,exit_frames=1,missing_frames=1,
                    entry_polygon=entry,retention_polygon=retention)
        validate_config(config)
        self.entry=json.loads(json.dumps(entry)); self.retention=json.loads(json.dumps(retention))
        self.label=label
        self.region_id='polygon:'+sha256(json.dumps([entry,retention,label],sort_keys=True).encode()).hexdigest()[:16]

    def evaluate(self,frame,target):
        target.validate(frame)
        b=target.bbox_source_xyxy
        if b[3]>=frame.height-1:
            return RegionContact(target,None,None,self.region_id,self.label,'BOTTOM_TRUNCATED_UNKNOWN')
        p=[(b[0]+b[2])/(2*frame.width),b[3]/frame.height]
        return RegionContact(target,inside(p,self.entry),inside(p,self.retention),self.region_id,self.label,'MANUAL_DEMO')


class CorridorRegion:
    def __init__(self,corridor,*,provider_id,evidence_source):
        self.corridor=corridor; self.region_id=provider_id; self.evidence_source=evidence_source

    def evaluate(self,frame,target):
        from lane_corridor import contact
        target.validate(frame)
        r=contact(frame,self.corridor,target.bbox_source_xyxy,observation_frame_key=target.frame_key)
        entry=None if r['entry_fraction'] is None else r['entry_fraction']>0
        retain=None if r['retention_fraction'] is None else r['retention_fraction']>0
        return RegionContact(target,entry,retain,self.region_id,self.evidence_source,self.corridor.quality)
