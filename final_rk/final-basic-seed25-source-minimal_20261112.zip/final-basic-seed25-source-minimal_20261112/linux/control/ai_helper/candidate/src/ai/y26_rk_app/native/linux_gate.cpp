#include "linux_gate.h"
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
#include <chrono>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <string>
#include <memory>
#include <mutex>
static uint64_t ns(){return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
#pragma pack(push,1)
struct Request {uint32_t version,slot;uint64_t token,received,published;y26_source source;};
struct Reply {uint32_t version,slot;uint64_t token,received;uint32_t count,disposition;y26_source source;};
#pragma pack(pop)
static_assert(sizeof(Request)==60,"request ABI");
static_assert(sizeof(Reply)==60,"reply ABI");
static_assert(sizeof(y26_box)==60,"box ABI");
struct Slot {bool busy=false,done=false,retired=false;uint32_t count=0,disposition=0;y26_ticket ticket{};y26_box boxes[300];};
struct Gate {
 int sock=-1;unsigned char* maps[2]={};Slot slots[2];std::mutex lock;
 std::string ready;bool failed=false,draining=false;uint64_t next=0,interval=1000000000/30;
 ~Gate(){if(sock>=0)close(sock);for(auto p:maps)if(p)munmap(p,1920*1080*3/2);}
};
static bool same(const y26_ticket& a,const y26_ticket& b){return a.slot==b.slot&&a.token==b.token&&a.received==b.received&&!memcmp(&a.source,&b.source,sizeof a.source);}
static bool valid_box(const y26_box& b){
 if(!std::isfinite(b.x1)||!std::isfinite(b.y1)||!std::isfinite(b.x2)||!std::isfinite(b.y2)||b.x2<=b.x1||b.y2<=b.y1||b.x1<0||b.y1<0||b.x2>1920||b.y2>1080)return false;
 if(b.cls<0||b.cls>=23||b.group<0||b.group>3||b.level < -3||b.level>2||b.proximity < -3||b.proximity>2||b.ttc_level < -3||b.ttc_level>2)return false;
 if(b.flags<0||(b.flags&~7)||b.priority<0||b.track_id < -1)return false;
 if((b.flags&1)&&(!std::isfinite(b.distance)||b.distance<=0))return false;
 if((b.flags&4)&&(!std::isfinite(b.ttc_s)||b.ttc_s<=0))return false;
 return true;
}
/* Called under lock. Never blocks, and never frees a still-in-use slot. */
static void drain(Gate* g){
 unsigned char buf[sizeof(Reply)+300*sizeof(y26_box)];
 for(unsigned batch=0;batch<2 && !g->failed;batch++){
  int n=recv(g->sock,buf,sizeof buf,MSG_DONTWAIT|MSG_TRUNC);
  if(n<0){if(errno==EINTR)continue;if(errno==EAGAIN||errno==EWOULDBLOCK)return;g->failed=true;return;}
  if(n<(int)sizeof(Reply)){g->failed=true;return;}
  Reply r;memcpy(&r,buf,sizeof r);
  if(r.version!=2||r.slot>1||r.count>300||r.disposition>1||(r.disposition && r.count)||n!=(int)(sizeof r+r.count*sizeof(y26_box))){g->failed=true;return;}
  Slot& s=g->slots[r.slot];y26_ticket t{r.slot,r.token,r.received,r.source};
  if(!s.busy||s.done||!same(s.ticket,t)){g->failed=true;return;}
  memcpy(s.boxes,buf+sizeof r,r.count*sizeof(y26_box));
  for(unsigned i=0;i<r.count;i++)if(!valid_box(s.boxes[i])){g->failed=true;return;}
  s.count=r.count;s.disposition=r.disposition;s.done=true;
  if(s.retired){s.busy=false;s.done=false;}
 }
}
extern "C" void* y26_gate_open(const char* directory){
 if(!directory)return nullptr;
 std::unique_ptr<Gate> g(new Gate);std::string root(directory);sockaddr_un a{};a.sun_family=AF_UNIX;
 std::string sock=root+"/bridge.sock";if(sock.size()>=sizeof(a.sun_path))return nullptr;strcpy(a.sun_path,sock.c_str());
 g->sock=socket(AF_UNIX,SOCK_SEQPACKET|SOCK_CLOEXEC|SOCK_NONBLOCK,0);if(g->sock<0||connect(g->sock,(sockaddr*)&a,sizeof a))return nullptr;
 for(int i=0;i<2;i++){
  int fd=open((root+"/"+std::to_string(i)+"_nv12.bin").c_str(),O_RDWR|O_CLOEXEC);struct stat st{};
  if(fd<0)return nullptr;
  if(fstat(fd,&st)||st.st_size!=1920*1080*3/2){close(fd);return nullptr;}
  void* m=mmap(nullptr,st.st_size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);close(fd);
  if(m==MAP_FAILED)return nullptr;
  g->maps[i]=(unsigned char*)m;
 }
 const char* fps=getenv("Y26_INPUT_FPS");if(fps){int n=atoi(fps);if(n!=10&&n!=15&&n!=20&&n!=30)return nullptr;g->interval=1000000000/n;}
 g->ready=root+"/native_ready.signal";return g.release();
}
static int seal(Gate* g){
 if(g->draining)return g->failed?-1:1;
 g->draining=true;
 // Ordered EOF after all submitted requests; retain the read/reply direction.
 if(shutdown(g->sock,SHUT_WR)){g->failed=true;return -1;}
 return g->failed?-1:1;
}
extern "C" int y26_gate_begin_drain(void* p){
 auto g=static_cast<Gate*>(p);if(!g)return 1;
 std::unique_lock<std::mutex> guard(g->lock,std::try_to_lock);
 if(!guard.owns_lock())return 0;
 return seal(g);
}
extern "C" int y26_gate_try_close(void* p){
 auto g=static_cast<Gate*>(p);if(!g)return 1;
 // Caller has stopped all gate clients. A failed/unknown completion is retained.
 {std::unique_lock<std::mutex> guard(g->lock,std::try_to_lock);if(!guard.owns_lock())return 0;
  seal(g);drain(g);for(const auto& s:g->slots)if(s.busy)return 0;}
 delete g;return 1;
}
extern "C" void y26_gate_close(void* p){(void)y26_gate_try_close(p);}
extern "C" int y26_gate_submit(void* p,const unsigned char* y,const unsigned char* uv,int ys,int us,uint64_t token,uint64_t received,const y26_source* source,y26_ticket* out,double* copy_ms){
 auto g=static_cast<Gate*>(p);if(!g||!y||!uv||!source||!out||!copy_ms||ys<1920||us<1920)return -1;
 std::unique_lock<std::mutex> guard(g->lock,std::try_to_lock);if(!guard.owns_lock())return 0;drain(g);if(g->failed)return -1;if(g->draining)return 0;
 *copy_ms=0;if(access(g->ready.c_str(),F_OK))return 0;
 uint64_t begin=ns();if(!received||begin<received||begin-received>=250000000||begin<g->next)return 0;
 int slot=!g->slots[0].busy?0:!g->slots[1].busy?1:-1;if(slot<0)return 0;
 auto dest=g->maps[slot];
 for(int row=0;row<1080;row++)memcpy(dest+row*1920,y+(size_t)row*ys,1920);
 for(int row=0;row<540;row++)memcpy(dest+1920*1080+row*1920,uv+(size_t)row*us,1920);
 uint64_t copied=ns();*copy_ms=(copied-begin)/1e6;if(copied<received||copied-received>=250000000)return 0;Request req{2,(uint32_t)slot,token,received,copied,*source};
 if(send(g->sock,&req,sizeof req,MSG_DONTWAIT|MSG_NOSIGNAL)!=(int)sizeof req){g->failed=true;return -1;}
 Slot& s=g->slots[slot];s.busy=true;s.done=false;s.retired=false;s.ticket={(uint32_t)slot,token,received,*source};*out=s.ticket;
 if(!g->next||begin-g->next>g->interval)g->next=begin+g->interval;else g->next+=g->interval;
 return 1;
}
extern "C" void y26_gate_retire(void* p,const y26_ticket* t){
 auto g=static_cast<Gate*>(p);if(!g||!t||t->slot>1)return;
 std::lock_guard<std::mutex> guard(g->lock);drain(g);Slot& s=g->slots[t->slot];
 if(s.busy&&same(s.ticket,*t)){s.retired=true;if(s.done){s.busy=false;s.done=false;}}
}
extern "C" int y26_gate_take(void* p,const y26_ticket* t,y26_box* boxes,int cap,int* count){
 auto g=static_cast<Gate*>(p);if(!g||!t||!boxes||!count||cap<300||t->slot>1)return -1;
 std::lock_guard<std::mutex> guard(g->lock);drain(g);*count=0;if(g->failed)return -1;
 Slot& s=g->slots[t->slot];if(!s.busy||!same(s.ticket,*t))return -1;
 uint64_t now=ns();if(now<t->received||now-t->received>=250000000){s.retired=true;if(s.done){s.busy=false;s.done=false;}return -2;}
 if(!s.done)return 0;
 if(s.disposition){s.busy=false;s.done=false;return -2;}
 memcpy(boxes,s.boxes,s.count*sizeof(y26_box));*count=(int)s.count;s.busy=false;s.done=false;return 1;
}
static const unsigned char font[][7]={
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},{30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},{14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},{14,17,17,15,1,1,14},
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},{30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},{14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},{7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},{17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},{30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},{15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},{17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},{17,17,10,4,4,4,4},{31,1,2,4,8,16,31}};
static void pixel(unsigned char*y,unsigned char*uv,int ys,int us,int x,int yy,int level){
 if(x<0||x>=1920||yy<0||yy>=1080)return;
 unsigned char Y=150,U=128,V=128;
 if(level==2){Y=76;U=85;V=255;}else if(level==1){Y=226;U=0;V=149;}else if(level==0){Y=179;U=171;V=0;}
 y[(size_t)yy*ys+x]=Y;size_t j=(size_t)(yy/2)*us+(x&~1);uv[j]=U;uv[j+1]=V;
}
static void text(unsigned char*y,unsigned char*uv,int ys,int us,int x,int yy,const char*s,int level){
 for(;*s;s++,x+=12)for(int row=0;row<7;row++){
  int c=*s;unsigned bits=c>='0'&&c<='9'?font[c-'0'][row]:c>='A'&&c<='Z'?font[10+c-'A'][row]:c=='-'?(row==3?31:0):c=='.'?(row==6?4:0):c=='~'?(row==3?10:0):0;
  for(int col=0;col<5;col++)if(bits&(1u<<(4-col)))for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++)pixel(y,uv,ys,us,x+2*col+dx,yy+2*row+dy,level);
 }
}
static const char* level_name(int l){return l==2?"DANGER":l==1?"ATTENTION":l==0?"CLEAR":"UNKNOWN";}
extern "C" void y26_draw_nv12(unsigned char*y,unsigned char*uv,int ys,int us,const y26_box*b,int n){
 if(!y||!uv||!b||ys<1920||us<1920||n<0||n>300)return;
 const char* names[]={"PERSON","VEHICLE","TWO-WHEEL","OBSTACLE"};
 for(int i=0;i<n;i++){
  if(!valid_box(b[i]))continue;
  int x=std::max(0,std::min(1919,(int)b[i].x1)),xx=std::max(0,std::min(1919,(int)b[i].x2));
  int a=std::max(0,std::min(1079,(int)b[i].y1)),z=std::max(0,std::min(1079,(int)b[i].y2));
  for(int t=0;t<2;t++){for(int j=x;j<=xx;j++){pixel(y,uv,ys,us,j,a+t,b[i].level);pixel(y,uv,ys,us,j,z-t,b[i].level);}for(int j=a;j<=z;j++){pixel(y,uv,ys,us,x+t,j,b[i].level);pixel(y,uv,ys,us,xx-t,j,b[i].level);}}
  char label[112],range[32],priority[24]={},motion[40];
  if(b[i].flags&1)snprintf(range,sizeof range,"~%.1fM",b[i].distance);else snprintf(range,sizeof range,"--M");
  if(b[i].group==0&&b[i].priority)snprintf(priority,sizeof priority," P%d",b[i].priority);
  snprintf(label,sizeof label,"%s%s %s %s",names[b[i].group],priority,level_name(b[i].level),range);
  if(b[i].flags&4)snprintf(motion,sizeof motion,"TTC~%.1fS",b[i].ttc_s);else snprintf(motion,sizeof motion,"TTC %s",b[i].ttc_level==-2?"NA":"UNKNOWN");
  int tx=std::min(x,1920-12*(int)strlen(label)),ty=std::max(0,a-32);tx=std::max(0,tx);
  text(y,uv,ys,us,tx,ty,label,b[i].level);snprintf(label,sizeof label,"NEAR %s %s",level_name(b[i].proximity),motion);text(y,uv,ys,us,tx,ty+16,label,b[i].level);
 }
}
