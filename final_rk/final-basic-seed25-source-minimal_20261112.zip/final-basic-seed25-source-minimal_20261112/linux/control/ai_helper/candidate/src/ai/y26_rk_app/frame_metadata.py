"""AI-private sideband candidate. Does not replace any FPGA/video feed ABI.

Bind before the display queue: snapshot is the native owner's successfully
released immutable record. parse_record is the SAME validated parser as video.
No receive timestamp is created here, and no board/device is opened.
"""
from dataclasses import dataclass
import struct

MAGIC = b'Y26META1'
VERSION = 1
HEADER = struct.Struct('<8sII4Q11I64s')
SOURCE_FIELDS = ('session', 'epoch', 'sequence', 'camera', 'kind', 'format', 'role')
assert HEADER.size == 156


def integer(name, value, bits, minimum=0):
    if type(value) is not int or not minimum <= value < 2**bits:
        raise ValueError(f'{name}: explicit uint{bits} required')
    return value


@dataclass(frozen=True)
class FrameMetadata:
    run: int
    token: int
    pts: int
    received: int
    jpeg_generation: int
    width: int
    height: int
    source: tuple
    receiver_cohort: str

    def pack(self):
        for name in ('run', 'token', 'received'):
            integer(name, getattr(self, name), 64, 1)
        integer('pts', self.pts, 64)
        if self.pts == 2**64-1:
            raise ValueError('unknown Gst PTS cannot associate a decoded frame')
        integer('jpeg_generation', self.jpeg_generation, 32)
        if (self.width, self.height) != (1920, 1080):
            raise ValueError('only explicit native 1080p is supported')
        if type(self.source) is not tuple or len(self.source) != 7:
            raise ValueError('all seven SOURCE fields required')
        for name, value in zip(SOURCE_FIELDS, self.source):
            integer(name, value, 32)
        cohort = self.receiver_cohort.encode('ascii')
        if not 1 <= len(cohort) <= 64 or any(not 33 <= c <= 126 for c in cohort):
            raise ValueError('explicit 1..64-byte printable receiver cohort required')
        return HEADER.pack(MAGIC, VERSION, HEADER.size, self.run, self.token,
                           self.pts, self.received, self.jpeg_generation,
                           self.width, self.height, *self.source, len(cohort), cohort)


def bind_owned(snapshot, *, parse_record, run, receiver_cohort, token, pts, source_role):
    """Return immutable (metadata, JPEG) from one owned AJPG record.

    source_role must be supplied from the reviewed ingress context. Older
    SourceMetadata has no role field; do not guess it from camera/kind/format.
    The caller must preserve this pair through existing drop/queue decisions.
    No call to this function proves a native RELEASE: that is the owner's API.
    """
    if type(snapshot.wire) is not bytes:
        raise TypeError('only immutable owned record bytes accepted')
    record = parse_record(snapshot.wire, expected_version=3)
    source = record.metadata.source
    if source is None or source.sequence != record.sequence:
        raise ValueError('same-record SOURCE required')
    integer('source_role', source_role, 32)
    if hasattr(source, 'role') and source.role != source_role:
        raise ValueError('SOURCE role contradicts ingress role')
    fields = tuple(getattr(source, name) for name in SOURCE_FIELDS[:-1]) + (source_role,)
    if type(record.jpeg) is not bytes or not 4 <= len(record.jpeg) <= 4194304:
        raise ValueError('bounded immutable JPEG payload required')
    meta = FrameMetadata(run, token, pts, snapshot.received_monotonic_ns,
                         record.metadata.jpeg_generation, record.width, record.height,
                         fields, receiver_cohort)
    return meta.pack(), record.jpeg
