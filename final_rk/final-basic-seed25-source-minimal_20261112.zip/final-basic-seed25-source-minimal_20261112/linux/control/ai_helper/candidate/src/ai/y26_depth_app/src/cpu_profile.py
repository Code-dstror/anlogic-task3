"""Opt-in accumulated CPU stage times; disabled profiles do not read the clock."""
import os
from contextvars import ContextVar
from time import perf_counter,perf_counter_ns,thread_time_ns,process_time_ns

_detail=ContextVar('y26_cpu_clock_detail',default=False)

def configure_timing(enabled):
    """Per-thread opt-in; normal host runs keep the original cheap wall clock."""
    _detail.set(bool(enabled))

def thread_placement():
    """One inventory, not per-frame filesystem scanning. Linux only."""
    from pathlib import Path
    rows=[]
    if os.name!='posix':return rows
    for task in Path('/proc/self/task').glob('[0-9]*'):
        try:
            status=dict(line.split(':',1) for line in (task/'status').read_text().splitlines() if ':' in line)
            tid=int(task.name)
            rows.append(dict(tid=tid,name=status.get('Name','').strip(),
                allowed_cpus=status.get('Cpus_allowed_list','').strip(),
                affinity=sorted(os.sched_getaffinity(tid)),nice=os.getpriority(os.PRIO_PROCESS,tid)))
        except (OSError,ValueError):pass
    return rows

def clock_snapshot():
    # /proc/thread-self refers to this native Linux thread, not just main PID.
    # Missing proc counters are null, never fabricated as zero wait.
    cpu=thread_time_ns();process=process_time_ns();run=wait=slices=None
    if os.name=='posix':
        try:
            with open('/proc/thread-self/schedstat','r') as f:
                run,wait,slices=map(int,f.read().split()[:3])
        except (OSError,ValueError):pass
    return (perf_counter_ns(),cpu,process,run,wait,slices)

def record_interval(timings,name,before,after=None):
    after=clock_snapshot() if after is None else after
    wall=(after[0]-before[0])/1e6;cpu=(after[1]-before[1])/1e6
    values={name:wall,name+'.thread_cpu_ms':cpu,
            name+'.non_cpu_wall_ms':max(0.,wall-cpu),
            name+'.process_cpu_ms':(after[2]-before[2])/1e6}
    if before[4] is not None and after[4] is not None:
        values[name+'.runqueue_wait_ms']=(after[4]-before[4])/1e6
        values[name+'.scheduler_slices']=after[5]-before[5]
    for k,v in values.items():timings[k]=timings.get(k,0.)+v
    return after

TIMING_NOTES={
    'thread_cpu_ms':'calling thread only; excludes OpenCV/TBB/native worker CPU',
    'process_cpu_ms':'whole process including concurrent decoder, network and OpenCV threads; overlapping, not additive',
    'non_cpu_wall_ms':'wall minus calling-thread CPU; NOT pure waiting; includes work delegated to other threads/devices',
    'runqueue_wait_ms':'calling-thread Linux schedstat runnable-but-not-scheduled time, if available; not lock/IO wait',
    'scheduler_slices':'calling-thread schedstat time-slice delta, count not milliseconds',
    'RGA':'synchronous API wall time includes submission, hardware execution and synchronization',
}


class StageTimer:
    def __init__(self, timings=None):
        self.timings = timings
        self.detailed=timings is not None and _detail.get()
        self.snapshot=clock_snapshot() if self.detailed else None
        self.started = perf_counter() if timings is not None else None

    def mark(self, name):
        if self.timings is not None:
            if self.detailed:
                self.snapshot=record_interval(self.timings,name,self.snapshot)
                return
            now = perf_counter()
            self.timings[name] = self.timings.get(name, 0.) + (now-self.started)*1000
            self.started = now
