"""Shared E input contract; hardware starts at Linux's existing decoded NV12.

No JPEG/MPP decoder belongs here. Already prepared RGB goes straight to inference.
"""
import time
import cv2
import numpy as np

PROFILE_ID='E_RGB640_PAD114_ROUND_V1'
SIZE=640

def geometry(width,height):
    if type(width) is not int or type(height) is not int or width<=0 or height<=0:
        raise ValueError('Positive integer source dimensions required')
    nw,nh=round(width*SIZE/max(width,height)),round(height*SIZE/max(width,height))
    if min(nw,nh)<1:raise ValueError('Input aspect ratio produces an empty resized image')
    return dict(width=width,height=height,sx=nw/width,sy=nh/height,left=(SIZE-nw)//2,top=(SIZE-nh)//2,size=SIZE)

def resized_size(g):return round(g['width']*g['sx']),round(g['height']*g['sy'])

def validate_rgb(rgb):
    if not isinstance(rgb,np.ndarray) or rgb.shape!=(1,SIZE,SIZE,3) or rgb.dtype!=np.uint8 or not rgb.flags.c_contiguous:
        raise ValueError('Expected prepared RGB uint8 NHWC [1,640,640,3]; no normalized float/BGR input')

class PreparedInput:
    def __init__(self,rgb,g,*,source,frame_key=None,release=None,timings=None):
        validate_rgb(rgb)
        self._rgb=rgb;self.geometry=dict(g);self.source=source;self.frame_key=frame_key
        self.profile_id=PROFILE_ID;self.normalized=False;self._release=release;self.closed=False
        self.timings={} if timings is None else dict(timings)
    @property
    def rgb(self):
        if self.closed:raise RuntimeError('Prepared input lease expired')
        return self._rgb
    def validate(self):
        if self.profile_id!=PROFILE_ID or self.normalized:raise ValueError('Wrong profile or double normalization')
        validate_rgb(self.rgb)
    def close(self):
        if not self.closed:
            self.closed=True
            if self._release:self._release()
    def __enter__(self):self.validate();return self
    def __exit__(self,*args):self.close()

def onnx_tensor(prepared,output=None):
    """CPU/ONNX normalizes once. RKNN receives original uint8 with configured std255."""
    if isinstance(prepared,PreparedInput):prepared.validate();rgb=prepared.rgb
    else:rgb=prepared;validate_rgb(rgb)
    if output is None:output=np.empty((1,3,SIZE,SIZE),np.float32)
    if output.shape!=(1,3,SIZE,SIZE) or output.dtype!=np.float32 or not output.flags.c_contiguous:
        raise ValueError('Invalid reusable ONNX output buffer')
    np.copyto(output,rgb.transpose(0,3,1,2),casting='unsafe');np.divide(output,255,out=output)
    return output

class CpuPreprocessor:
    def __init__(self):self._rgb=np.empty((1,SIZE,SIZE,3),np.uint8);self._held=False
    def prepare(self,image,*,pixel_format='BGR',frame_key=None):
        if isinstance(image,PreparedInput):raise ValueError('Already prepared; feed directly to backend')
        if self._held:raise RuntimeError('Release previous input before buffer reuse')
        if pixel_format not in ('BGR','RGB'):raise ValueError('Declare BGR or RGB explicitly')
        if not isinstance(image,np.ndarray) or image.dtype!=np.uint8 or image.ndim!=3 or image.shape[2]!=3:
            raise ValueError('Expected source HWC uint8 image')
        start=time.perf_counter_ns();h,w=image.shape[:2];g=geometry(w,h);nw,nh=resized_size(g)
        resized=cv2.resize(image,(nw,nh),interpolation=cv2.INTER_LINEAR);self._rgb.fill(114)
        self._rgb[0,g['top']:g['top']+nh,g['left']:g['left']+nw]=resized[:,:,::-1] if pixel_format=='BGR' else resized
        self._held=True
        def release():self._held=False
        return PreparedInput(self._rgb,g,source='CPU_'+pixel_format,frame_key=frame_key,release=release,
            timings={'shared_preprocess':(time.perf_counter_ns()-start)/1e6})

def prepare_bgr_owned(bgr):
    """Legacy wrapper: owned RGB array without persistent processor reuse."""
    processor=CpuPreprocessor()
    with processor.prepare(bgr,pixel_format='BGR') as prepared:return prepared.rgb,dict(prepared.geometry)
