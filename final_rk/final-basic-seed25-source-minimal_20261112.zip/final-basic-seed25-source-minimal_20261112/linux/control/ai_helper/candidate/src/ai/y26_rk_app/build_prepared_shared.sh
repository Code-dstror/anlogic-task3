#!/usr/bin/env bash
# Real-time prepared V2 needs RGA only; no duplicate MPP decoder or GST headers.
set -euo pipefail
src_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
out_dir="${1:?pass a new candidate board_libs directory}"
mkdir -p -- "$out_dir"
dest="$out_dir/liby26_prepared_rgb2.so"
temp="$dest.building.$$"
trap 'rm -f -- "$temp"' EXIT
g++ -O3 -std=c++17 -fPIC -shared -ffp-contract=off -fno-fast-math \
  -I/usr/include/rga "$src_dir/native/prepared_rga.cpp" -o "$temp" -lrga
mv -f -- "$temp" "$dest"
printf 'Built prepared shared-RGB candidate: %s\nNo test or decoder started.\n' "$dest"
