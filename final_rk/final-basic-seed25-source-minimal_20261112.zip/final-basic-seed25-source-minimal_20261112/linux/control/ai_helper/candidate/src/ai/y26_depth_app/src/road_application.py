"""Two detector label spaces, same-frame depth association and three event routes."""
import numpy as np
from scipy.optimize import linear_sum_assignment
from tracking_adapter import TrackingAdapter
from temporal_warning import TemporalWarning, TimePolicy
from warning_regions import PolygonRegion
from software_lane import SoftwareLaneRegion
from ego_region import EgoGeometry, ExcludedRegion, SemanticRegion
from voice_scheduler import AlertSnapshot, GROUPS
from depth_validity import DepthValidity, DepthPolicy
from depth_continuity import DepthContinuity
from target_ambiguity import annotate_overlap
from cpu_profile import StageTimer
from depth_ownership import annotate_foreground


def associate_depth(targets, observations, observation_indices=None):
    """One-to-one current-frame association; never carry a lost track's old range."""
    pairs={}
    if observation_indices is not None:
        used=set()
        for target in targets:
            index=observation_indices.get(target.track_id)
            # Weak tracker-only candidates are after the high-score observations.
            if index is None:continue
            if type(index) is not int or index<0:
                raise ValueError('Invalid or duplicate current observation index')
            if index>=len(observations):continue
            if index in used:raise ValueError('Duplicate current observation index')
            observation=observations[index]
            if observation['class_id']!=target.class_id:
                raise ValueError('Tracker observation index class mismatch')
            pairs[target.track_id]=observation;used.add(index)
        return pairs
    for cid in {t.class_id for t in targets}:
        ts=[t for t in targets if t.class_id==cid]
        ds=[d for d in observations if d['class_id']==cid]
        if not ds:continue
        a=np.array([t.bbox_source_xyxy for t in ts]);b=np.array([d['xyxy'] for d in ds])
        inter=np.maximum(np.minimum(a[:,None,2:],b[None,:,2:])-np.maximum(a[:,None,:2],b[None,:,:2]),0).prod(2)
        union=(a[:,2:]-a[:,:2]).prod(1)[:,None]+(b[:,2:]-b[:,:2]).prod(1)[None,:]-inter
        iou=inter/np.maximum(union,1e-9)
        ti,di=linear_sum_assignment(1-iou)
        for t,d in zip(ti,di):
            if iou[t,d]>=.3:pairs[ts[t].track_id]=ds[d]
    return pairs


class RoadApplication:
    def __init__(self, config, model, camera, *, active_variants=None):
        self.model=model; self.groups=model['groups']
        self.depth_motion_compensation=config.get('depth_motion_compensation',False)
        self.target_overlap_guard=config.get('target_overlap_guard',False)
        self.foreground_depth_guard=dict(config.get('foreground_depth_guard',{}))
        self.ego=EgoGeometry(camera,config['ego_rule'])
        self.raw_tracker=TrackingAdapter(len(model['names']),**config['tracker'])
        self.ego_tracker=TrackingAdapter(len(model['names']),**config['tracker'])
        variants=list(config['variants'] if active_variants is None else active_variants)
        if not variants or len(set(variants))!=len(variants) or any(v not in config['variants'] for v in variants):
            raise ValueError('Select explicitly configured application variants')
        self.raw_enabled='raw_manual' in variants
        self.ego_enabled=any(v in variants for v in ('ego_manual','ego_lane'))
        self.engines={v:TemporalWarning(TimePolicy(**config['policy'])) for v in variants}
        self.manual=PolygonRegion(**{k:camera['raw_manual_region'][k] for k in ('entry','retention','label')})
        self.depth_gates={name:DepthValidity(DepthPolicy(**config.get('depth_validity',{})))
                          for name in ('raw_manual','ego_manual')}
        self.depth_displays={name:DepthContinuity(**config.get('depth_continuity',{}))
                             for name in ('raw_manual','ego_manual')}

    def process(self, stamp, raw, lane, *, tracking_candidates=None,camera_motion=None,timings=None):
        timer=StageTimer(timings)
        if lane.frame_key!=stamp.identity.key:raise ValueError('Lane evidence is from another frame')
        # Auxiliary weak boxes may continue an existing ID, but cannot supply
        # current depth evidence, initialize warnings or become displayed detections.
        tracking_candidates=[] if tracking_candidates is None else tracking_candidates
        if any(not .1<d['confidence']<self.raw_tracker.threshold for d in tracking_candidates):
            raise ValueError('Auxiliary tracker candidates must be strictly low confidence')
        if stamp.age_ms>250:
            raw=[];tracking_candidates=[];camera_motion=None
            self.raw_tracker.reset();self.ego_tracker.reset()
            for gate in self.depth_gates.values():gate.reset()
            for display in self.depth_displays.values():display.reset()
        if self.target_overlap_guard:raw=annotate_overlap(raw,self.groups)
        ownership=None
        if self.foreground_depth_guard.get('enabled',False):
            raw=annotate_foreground(raw,self.groups,stamp.identity.key,self.depth_gates['ego_manual'].policy,
                minimum_coverage=self.foreground_depth_guard.get('minimum_patch_coverage',.7),
                duplicate_iou=self.foreground_depth_guard.get('duplicate_iou',.85),minimum_confidence=self.raw_tracker.threshold)
            ownership=[o['distance_ownership'] for o in raw]
            timer.mark('application_depth_ownership')
        kept,excluded=self.ego.split(stamp.identity,raw,self.model['car_class_id'])
        weak_kept,_=self.ego.split(stamp.identity,tracking_candidates,self.model['car_class_id'])
        timer.mark('application_input_and_ego')
        def adapter(objects):
            return [dict(frame_key=stamp.identity.key,class_id=d['class_id'],confidence=d['confidence'],
                         bbox_source_xyxy=d['xyxy']) for d in objects]
        # Diagnostic routes have independent tracker and temporal state. A
        # deployment explicitly selecting ego_lane need not update raw_manual.
        # Default remains all configured routes for historical experiments.
        raw_targets=(self.raw_tracker.update(stamp,adapter(raw+tracking_candidates),camera_motion=camera_motion,timings=timings)
                     if self.raw_enabled else [])
        ego_targets=(self.ego_tracker.update(stamp,adapter(kept+weak_kept),camera_motion=camera_motion,timings=timings)
                     if self.ego_enabled else [])
        timer.mark('application_tracking_total')
        associations={'raw_manual':associate_depth(raw_targets,raw,
                          getattr(self.raw_tracker,'current_observation_indices',None)),
                      'ego_manual':associate_depth(ego_targets,kept,
                          getattr(self.ego_tracker,'current_observation_indices',None))}
        associations['ego_lane']=associations['ego_manual']
        timer.mark('application_current_depth_binding')
        current_depth={}
        for route,targets in [('raw_manual',raw_targets),('ego_manual',ego_targets)]:
            if (route=='raw_manual' and not self.raw_enabled) or (route=='ego_manual' and not self.ego_enabled):
                current_depth[route]={}
                continue
            current_depth[route]={target.track_id:self.depth_displays[route].update(stamp,target,
                self.depth_gates[route].evaluate(stamp,target,associations[route].get(target.track_id),
                    camera_motion=camera_motion if self.depth_motion_compensation else None)) for target in targets}
        current_depth['ego_lane']=current_depth['ego_manual']
        timer.mark('application_depth_temporal')
        providers={'raw_manual':SemanticRegion(self.manual,self.groups),
                   'ego_manual':ExcludedRegion(self.manual,self.ego,self.groups),
                   'ego_lane':ExcludedRegion(SoftwareLaneRegion(lane),self.ego,self.groups)}
        results={}
        for variant,engine in self.engines.items():
            provider=providers[variant]
            targets=raw_targets if variant=='raw_manual' else ego_targets
            result=engine.update(stamp,[provider.evaluate(stamp.identity,t) for t in targets],region_id=provider.region_id)
            eligible=set()
            for obj in result['objects']:
                tracker=self.raw_tracker if variant=='raw_manual' else self.ego_tracker
                indices=getattr(tracker,'current_observation_indices',None)
                if indices is not None:obj['source_detection_index']=indices.get(obj['track_id'])
                obj['class_name']=self.model['names'][obj['class_id']]
                group=self.groups.get(str(obj['class_id']));obj['application_group']=group
                display_route='raw_manual' if variant=='raw_manual' else 'ego_manual'
                obj['distance']=dict(current_depth[variant][obj['track_id']] if obj['track_id'] in current_depth[variant]
                    else self.depth_displays[display_route].missing(stamp,obj['track_id']))
                if group and obj['warning_state']=='ACTIVE' and obj['inside_retention'] is True:
                    eligible.add(group)
            result['distance_enabled']=False
            result['depth_estimates_attached']=True
            used={id(d) for d in associations[variant].values()}
            # Keep raw confirmed-threshold detections visible while the tracker
            # is initializing. They are an overlay, not region observations.
            from depth_presentation import detection_estimate
            result['unconfirmed_detections']=[dict(class_id=d['class_id'],
                class_name=self.model['names'][d['class_id']],confidence=d['confidence'],
                bbox_source_xyxy=d['xyxy'],frame_key=stamp.identity.key,
                display_status='DETECTED_TRACK_PENDING',depth_status='UNVERIFIED',meters=None,
                distance=detection_estimate(stamp,d,self.depth_gates[
                    'raw_manual' if variant=='raw_manual' else 'ego_manual'].policy))
                for d in (raw if variant=='raw_manual' else kept)
                if id(d) not in used and d['confidence']>=engine.policy.observation_confidence]
            result['eligible_voice_groups']=[g for g in GROUPS if g in eligible]
            result['voice_snapshot']=AlertSnapshot(tuple(stamp.identity.context)+(stamp.clock_domain,provider.region_id),
                                                 stamp.identity.key,stamp.timestamp_ns,tuple(result['eligible_voice_groups']))
            result['lane_provider']=lane.diagnostics['source'] if variant=='ego_lane' else 'MANUAL_DEBUG'
            results[variant]=result
        timer.mark('application_region_rules_and_presentation')
        return dict(variants=results,excluded_self=excluded,kept_detections=kept,
                    depth_ownership=ownership,
                    raw_detection_count=len(raw),primary='ego_lane',manual_fallback=False,
                    fpga_lane_used=False,collision_risk='UNKNOWN',
                    camera_motion_status='NOT_USED' if camera_motion is None else camera_motion.status)

    def finish(self):
        return {v:e.finish() for v,e in self.engines.items()}
