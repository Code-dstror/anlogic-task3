#!/usr/bin/env bash
# Compile only; no board test or model launch. Uses existing ARM64 compiler.
set -euo pipefail
src_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
out_dir="${1:?pass a new candidate board_libs directory}"
mkdir -p -- "$out_dir"
dest="$out_dir/liby26_tracking_batch_v1.so"
g++ -O3 -std=c++17 -fPIC -shared -ffp-contract=off -fno-fast-math \
  "$src_dir/native/tracking_batch.cpp" -o "$dest"
printf 'Built tracking ABI1 candidate: %s\nNo test started.\n' "$dest"
