#ifndef Y26_DECODED_FRAME_BRIDGE_H
#define Y26_DECODED_FRAME_BRIDGE_H
#include "kms_ai_boundary.h"
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Private review candidate: sideband=156 little-endian bytes, not a video wire
 * change. All calls belong to the same serialized video owner. No Gst refs,
 * JPEG bytes or pixel mappings are retained here; metadata capacity is 64.
 * Fresh directory/connection + run/cohort/SOURCE epoch for each context.
 * jpeg_generation below matches only the first registered owned frame; FPGA
 * JPEG slot generations vary per frame and do not create a new AI session.
 */
void* y26_video_open(const char* directory,uint64_t run,const char* cohort,
                     uint32_t cohort_length,uint32_t jpeg_generation);
/* Call with exactly the sideband paired with the JPEG being pushed to the
 * existing decoder under that same PTS. 1 registered; 0 AI bypass.
 * Full table evicts oldest METADATA only: an eventual miss is plain video. */
int y26_video_register(void*,const unsigned char* sideband,size_t length);
struct y26_nv12_view {
 const unsigned char *y,*uv;
 uint64_t y_bytes,uv_bytes;
 int y_stride,uv_stride;
 uint32_t width,height,layout,color,cpu_read_ready,original_pixels;
};
/* After real decode/map+sync, BEFORE any lane/AI drawing. Match by actual PTS.
 * 2 AI submitted; 1 metadata bound but AI skipped; 0 no usable association.
 * out is only valid for rc>0; caller can attach it to that exact GstBuffer.
 * layout=1 linear NV12; color=1 proven BT.601 full; the two readiness flags
 * are explicit caller attestations, not a substitute for DMA sync/fences.
 */
int y26_video_decoded(void*,uint64_t pts,const struct y26_nv12_view*,struct y26_kms_frame* out);
/* On the SAME frame immediately before presentation; 1 exact result,0 plain.
 * Does not draw, call Gst/KMS, wait for inference, or return video STOP. */
int y26_video_select(void*,const struct y26_kms_frame*,struct y26_box*,int cap,int* count);
/* Diagnostic counts: [0] metadata evictions, [1] decode misses, [2] rejected
 * mapped views, [3] metadata faults, [4] live metadata entries. */
void y26_video_stats(void*,uint64_t counters[5]);
int y26_video_begin_drain(void*);
int y26_video_try_close(void*);
#ifdef __cplusplus
}
#endif
#endif
