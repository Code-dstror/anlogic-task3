#pragma once
#include <stdint.h>
#ifdef _WIN32
#define DS_API __declspec(dllexport)
#else
#define DS_API __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
extern "C" {
#endif
typedef struct {
    double median, fraction, iqr;
    int32_t bounds[4], sampled, region, valid, approximate;
} ds_result;
/* Fixed H,W for raw depth, intermediate resize and original source geometry.
   All original ROI pixels are evaluated; no approximate sampling mode.
   Context scratch space is reused. One context per worker, not thread safe. */
DS_API void *ds_create(int rh,int rw,int mh,int mw,int sh,int sw,int max_boxes);
DS_API void ds_destroy(void *context);
/* Optional content crop within the intermediate model input (letterbox only).
   Set once before processing. Default is the full intermediate image. */
DS_API int ds_set_content(void *context,int left,int top,int width,int height);
/* depth: already decoded scalar metric/model depth, float32, row stride in
   float elements. boxes: source-pixel xyxy, double[box_count*4]. Caller owns
   buffers until return. Does not dequantize/transpose RKNN tensors or resize RGB. */
DS_API int ds_process(void *context,const float *depth,int row_stride,
                      const double *boxes,int box_count,ds_result *out);
#ifdef __cplusplus
}
#endif
