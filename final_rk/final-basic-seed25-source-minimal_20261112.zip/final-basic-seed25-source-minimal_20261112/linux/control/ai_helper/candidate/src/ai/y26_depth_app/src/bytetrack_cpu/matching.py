"""Offline NumPy/SciPy association adapter for pinned MIT ByteTrack.

Uses upstream cython_bbox's inclusive-box IoU convention. Assignment uses a
dummy-augmented Hungarian problem; ties are not claimed LAPJV-identical.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment


def iou_distance(tracks, detections):
    if not tracks or not detections:
        return np.empty((len(tracks), len(detections)), dtype=float)
    a = np.asarray([t.tlbr for t in tracks], dtype=float)
    b = np.asarray([t.tlbr for t in detections], dtype=float)
    tl = np.maximum(a[:, None, :2], b[None, :, :2])
    br = np.minimum(a[:, None, 2:], b[None, :, 2:])
    inter = np.maximum(br - tl + 1, 0).prod(axis=2)
    area_a = np.maximum(a[:, 2:] - a[:, :2] + 1, 0).prod(axis=1)
    area_b = np.maximum(b[:, 2:] - b[:, :2] + 1, 0).prod(axis=1)
    return 1 - inter / np.maximum(area_a[:, None] + area_b[None, :] - inter, 1e-12)


def fuse_score(cost, detections):
    return 1 - (1 - cost) * np.asarray([d.score for d in detections])[None, :]


def conservative_recovery(tracks,detections,competitors,minimum_margin=.15):
    """Same-class unused weak boxes, with unique IoU and KF position support.

    Experimental development gates, not identity probability or calibrated CI.
    Active tracks already got first choice before this separate recovery pass.
    """
    cost=iou_distance(tracks,detections)
    if not cost.size:return linear_assignment(cost,.5)
    overlap=1-cost
    all_ids={t.track_id for t in tracks}
    others=[t for t in competitors if t.track_id not in all_ids]
    competing=1-iou_distance(others,detections)
    measurements=np.asarray([d.to_xyah() for d in detections])
    allowed=np.zeros_like(cost,dtype=bool)
    for i,track in enumerate(tracks):
        distance=track.kalman_filter.gating_distance(track.mean,track.covariance,measurements,only_position=True)
        for j in range(len(detections)):
            row_other=np.delete(overlap[i],j).max(initial=0.)
            col_other=np.delete(overlap[:,j],i).max(initial=0.)
            rival=competing[:,j].max(initial=0.)
            allowed[i,j]=(overlap[i,j]>=.5 and overlap[i,j]-max(row_other,col_other,rival)>=minimum_margin
                          and distance[j]<=5.9915)
    return linear_assignment(np.where(allowed,cost,1e6),.5)


def gate_lost_high_cost(cost,pool,detections,eligible_ids,minimum_margin=.15):
    """Gate lost rows of the original high-score cost; active rows stay unchanged."""
    from .basetrack import TrackState
    result=cost.copy()
    if not result.size:return result
    overlap=1-iou_distance(pool,detections)
    measurements=np.asarray([d.to_xyah() for d in detections])
    for i,t in enumerate(pool):
        if t.state!=TrackState.Lost:continue
        if eligible_ids is None or t.track_id not in eligible_ids:
            result[i,:]=1e6;continue
        distance=t.kalman_filter.gating_distance(t.mean,t.covariance,measurements,only_position=True)
        for j in range(len(detections)):
            rival=max(np.delete(overlap[i],j).max(initial=0.),np.delete(overlap[:,j],i).max(initial=0.))
            if overlap[i,j]<.3 or overlap[i,j]-rival<minimum_margin or distance[j]>5.9915:
                result[i,j]=1e6
    return result


def linear_assignment(cost, thresh):
    n, m = cost.shape
    if not n or not m:
        return np.empty((0, 2), dtype=int), tuple(range(n)), tuple(range(m))
    extended = np.full((n + m, n + m), thresh / 2, dtype=float)
    extended[:n, :m] = np.where(cost <= thresh, cost, 1e6)
    extended[n:, m:] = 0
    a, b = linear_sum_assignment(extended)
    matches = [(i, j) for i, j in zip(a, b) if i < n and j < m and cost[i, j] <= thresh]
    used_a, used_b = {i for i, _ in matches}, {j for _, j in matches}
    return (np.asarray(matches, dtype=int).reshape(-1, 2),
            tuple(i for i in range(n) if i not in used_a), tuple(j for j in range(m) if j not in used_b))
