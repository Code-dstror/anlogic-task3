"""RK-native prepared-frame -> ordered NPU/CPU application pipeline.

Linux supplies already decoded/source and already prepared model tensors; no
MPP/NV12 decoder is implemented again. Results/ACK are streamed, never an
unbounded per-frame list. HDMI consumption remains in the Linux display owner.
"""
import argparse
import collections
import json
import os
from pathlib import Path
import sys
import time
import numpy as np
import cv2
extra=os.environ.get('Y26_SCIPY_PATH')
if extra and extra not in sys.path:sys.path.append(extra)
HERE=Path(__file__).resolve().parent;HOST=HERE.parent/'y26_depth_app'
sys.path[:0]=[str(HERE),str(HOST),str(HOST/'src')]
from prepared_frames import Reader
from networks import Networks
from ordered_pipeline import OrderedPipeline,Packet,FrameKey
from runtime import Evidence
from task_pipeline import DiagnosticTasks
from frame_pixels import FramePixels
from alsa_voice import Player
from demo_routes import apply_route,routes
from cpu_profile import configure_timing,StageTimer,TIMING_NOTES,thread_placement
from result_adapter import build_result
from shutdown import close_prepared_pipeline,close_runtime,_PENDING_SHUTDOWNS
from application_clock import decision_time
from sudden_near import merged_voice_groups

def read(p):return json.loads(p.read_text(encoding='utf-8'))

class Producer:
    def __init__(self,source,args,config):
        configure_timing(args.clock_detail)
        self.source=source;self.args=args;self.pool={}
        self.net=None
        try:
            self.net=Networks(args.detector,args.depth,'official' if args.route=='official' else 'lc64',args.library,args.roi_library,config,
                input_mode=args.input_mode,depth_size=args.depth_size,execution=args.execution,core_mask=3)
            self._ready(args)
        except BaseException as exc:
            if self.net is None:
                # Networks' partial construction cannot be proven retired here.
                exc.y26_resources_pending=True
            else:
                try:self.close()
                except BaseException as cleanup:
                    exc.y26_resources_pending=True
                    exc.y26_cleanup_errors=[cleanup]
                    if hasattr(exc,'add_note'):exc.add_note('Producer startup cleanup failed: '+repr(cleanup))
            if getattr(exc,'y26_resources_pending',False):exc.y26_resource_owner=self
            raise
    def _ready(self,args):
        self.metadata=dict(detector=self.net.det.attributes,depth=self.net.depth.attributes,detector_input=self.net.det.input_attributes,
            depth_input=self.net.depth.input_attributes,versions=[self.net.det.versions,self.net.depth.versions],
            tensor_metadata=dict(detector=self.net.det.tensor_metadata,depth=self.net.depth.tensor_metadata))
        self.net.warmup(20)
        (args.output/'native_ready.json').write_text(json.dumps(dict(status='NPU_CONTEXTS_READY',warmup_inferences_per_model=20,metadata=self.metadata),indent=2),encoding='utf-8')
    def read(self,slot):
        waiting=time.monotonic_ns();frame=self.source.read();begin=time.monotonic_ns()
        if frame is None:return None
        desc=frame['descriptor'];rgb={};packed=0
        for name in ('detector_rgb','depth_rgb'):
            v=frame[name]
            if not v.flags.c_contiguous:
                key=(slot,name)
                if key not in self.pool:self.pool[key]=np.empty(v.shape,np.uint8)
                np.copyto(self.pool[key],v);v=self.pool[key];packed+=v.nbytes
            rgb[name]=v
        h,w=frame['source_bgr'].shape[:2]
        objects,weak,timing=self.net.infer_prepared(rgb['detector_rgb'],rgb['depth_rgb'],w,h,desc['detector_geometry'],desc['depth_geometry'])
        timing['prepared_receive_wait_ms']=(begin-waiting)/1e6
        value=dict(frame=frame,objects=objects,weak=weak,timing=timing,admitted_ns=begin,ready_ns=time.monotonic_ns(),strided_pack_bytes=packed)
        key=FrameKey((desc['session_id'],desc['epoch'],desc['camera_id'],desc['clock_domain']),int(desc['sequence']),int(desc['capture_timestamp_ns']))
        return Packet(key,value)
    def close(self):
        # A failed detector/postprocess can leave a depth future running. A
        # barrier on each existing one-worker pool retires every submitted call
        # before Networks.close touches samplers/model handles. This can block;
        # the consumer timeout retains this Producer and its prepared inputs.
        for name in ('det_pool','depth_pool'):
            pool=getattr(self.net,name,None)
            if pool is not None:pool.submit(lambda: None).result()
        self.net.close()  # No ACK here; CPU leases may still exist.

def main():
    p=argparse.ArgumentParser();p.add_argument('--route',choices=['official','lc64_t4','lc64'],default='official')
    p.add_argument('--detector',type=Path,required=True);p.add_argument('--depth',type=Path,required=True)
    p.add_argument('--library',type=Path,required=True);p.add_argument('--roi-library',type=Path,required=True)
    p.add_argument('--input-mode',choices=['standard','bound-fp16'],default='standard',help='bound-fp16 requires matching liby26_rknn_reuse.so; no silent fallback')
    p.add_argument('--depth-size',type=int,choices=[640,768],default=768)
    p.add_argument('--execution',choices=['serial','parallel_split'],default='serial')
    p.add_argument('--cpu-affinity',choices=['all','big'],default='all')
    p.add_argument('--clock-detail',action='store_true',help='Separate detailed CPU/scheduler diagnostic from wall-only FPS')
    p.add_argument('--tracking-library',type=Path,help='Explicit opt-in batch ABI1; no silent Python fallback')
    p.add_argument('--gmc-library',type=Path,help='Explicit native LK pyramid cache; use the fixed profile library')
    p.add_argument('--gmc-buffer-mode',choices=['legacy','reuse'],default='reuse')
    p.add_argument('--fast-near',choices=['off','diagnostic'],default='diagnostic',help='Independent current-frame diagnostic; requires confirmed self geometry; normal voice rules unchanged')
    p.add_argument('--prepared-manifest',required=True);p.add_argument('--acks');p.add_argument('--output',type=Path,required=True)
    p.add_argument('--duration-s',type=float,default=300);p.add_argument('--input-fps',type=int,choices=[10,15,20,30],default=30)
    p.add_argument('--alsa-device',default='default');p.add_argument('--audio',action='store_true')
    p.add_argument('--opencv-threads',type=int,choices=[1,4,8],help='Board tuning may include1; host profile defaults are retained')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    if a.cpu_affinity=='big':
        if not hasattr(os,'sched_setaffinity') or not {4,5,6,7}.issubset(os.sched_getaffinity(0)):raise RuntimeError('RK3576 big-core set4-7 unavailable')
        os.sched_setaffinity(0,{4,5,6,7})
        for task in Path('/proc/self/task').glob('[0-9]*'):
            try:os.sched_setaffinity(int(task.name),{4,5,6,7})
            except ProcessLookupError:pass
    configure_timing(a.clock_detail)
    config=apply_route(read(HOST/'config.json'),a.route);config['cpu_runtime']['profile_stages']=True
    config['cpu_runtime']['clock_detail']=a.clock_detail
    config['cpu_runtime']['gmc_reuse_buffers']=a.gmc_buffer_mode=='reuse'
    config['fast_near']=dict(enabled=a.fast_near=='diagnostic',distance_m=5.)
    if a.tracking_library:config['tracker']['native_library']=str(a.tracking_library.resolve())
    if a.gmc_library:config['cpu_runtime']['gmc_native_library']=str(a.gmc_library.resolve())
    config['depth_input_geometry']=dict(size=a.depth_size,resize='letterbox' if a.route=='official' else 'stretch')
    threads=a.opencv_threads or config['cpu_runtime']['opencv_threads'];cv2.setNumThreads(threads)
    source=Reader(a.prepared_manifest,a.acks);owner=[]
    def factory():
        q=Producer(source,a,config);owner.append(q);return q
    stream=OrderedPipeline(factory,capacity=2,shutdown_timeout_s=15);source.guard_close(stream.shutdown_report);player=Player(a.alsa_device,a.audio)
    current=None;state=tasks=None;counts=collections.Counter();samples=collections.defaultdict(list);first=None;finished=None;seen=set();status='FAILED';error=None;failure=None;placement=[];frame_cleanup_errors=[]
    # <=300s x120fps fits60000; stop rather than silently clip timing samples.
    try:
        stream.__enter__()
        placement=thread_placement()
        with (a.output/'frames.jsonl').open('w',encoding='utf-8',buffering=1) as log:
            for lease in stream:
                upstream=None
                with lease as packet:
                    q=packet.value;desc=q['frame']['descriptor'];upstream=desc['slot'];now=time.monotonic_ns()
                    if first is None:first=q['admitted_ns']
                    try:
                        if counts['frames']>=60000:raise RuntimeError('Timing buffer cap reached')
                        context=(desc['session_id'],desc['epoch'],desc['camera_id'],desc['clock_domain'])
                        scene=':'.join(map(str,context));h,w=q['frame']['source_bgr'].shape[:2]
                        if (w,h)!=(1920,1080):raise ValueError('Current live profile requires1080p source; do not silently rescale ROI/camera geometry')
                        if current!=context:
                            cfg=json.loads(json.dumps(config));cfg['source_views'][scene]=dict(width=w,height=h,view_id=desc['view_id'])
                            state=Evidence(cfg,'Y26D',scene=scene);tasks=DiagnosticTasks(cfg,'Y26D',{})
                            current=context
                        row=dict(index=counts['frames'],scene=scene,source_frame=int(desc['sequence']),capture_timestamp_ns=int(desc['capture_timestamp_ns']),
                            capture_timestamp_s=int(desc['capture_timestamp_ns'])/1e9,clock_domain=desc['clock_domain'],source_timestamp_kind=desc['source_timestamp_kind'])
                        live=desc['clock_domain']=='CLOCK_MONOTONIC';bind_start=time.perf_counter();details={}
                        timer=StageTimer(details if a.clock_detail else None)
                        binding=source.pixel_binding(q['frame']);bind_ms=(time.perf_counter()-bind_start)*1000
                        timer.mark('prepared_pixel_binding')
                        observed=time.monotonic_ns() if live else None;objects=q['objects'];start=time.perf_counter()
                        app=state.process(row,binding.bgr,objects,tracking_candidates=q['weak'],pixel_binding=binding,observed_at_ns=observed)
                        timer.mark('evidence_tracking_depth_rules')
                        decision_ns=time.monotonic_ns() if live else None
                        decision_ms,age_ms=decision_time(row['capture_timestamp_ns'],decision_ns)
                        key=state.last_motion.frame_key
                        result=tasks.process(row,w,h,objects,key,scene,decision_ms,age_ms)
                        timer.mark('geometry_TTC_priority')
                        voice_groups=merged_voice_groups(result['eligible_groups'],result.get('fast_near',{}))
                        voice=player.step(scene,key,row['capture_timestamp_ns'],voice_groups) if live else dict(status='RECORDED_PTS_AUDIO_NOT_RUN')
                        tasks.fast.acknowledge_voice(voice,result.get('fast_near'))
                        timer.mark('voice_control')
                        finish=time.monotonic_ns();adapter_start=time.perf_counter()
                        final_age_ms=(finish-row['capture_timestamp_ns'])/1e6 if live else None
                        outward=build_result(desc,result['task_packet'],voice,w,h,
                            display_eligible=not live or final_age_ms<250,source_age_ms=final_age_ms,expected_application_frame_key=key)
                        finish=time.monotonic_ns();final_age_ms=(finish-row['capture_timestamp_ns'])/1e6 if live else None
                        if live and final_age_ms>=250 and outward['display_eligible']:
                            outward=build_result(desc,result['task_packet'],voice,w,h,display_eligible=False,source_age_ms=final_age_ms,expected_application_frame_key=key)
                            finish=time.monotonic_ns();final_age_ms=(finish-row['capture_timestamp_ns'])/1e6
                        details['result_adapter_ms']=(time.perf_counter()-adapter_start)*1000
                        finished=finish;latency=(finish-q['admitted_ns'])/1e6
                        counts['frames']+=1;counts['over300ms']+=latency>=300
                        shared='source_rgb' in q['frame']
                        counts['strided_pack_bytes']+=q['strided_pack_bytes'];counts['source_binding_copy_bytes']+=0 if shared else binding.bgr.nbytes
                        counts['source_shared_RGB_frames']+=shared
                        counts['CPU_BGR_to_RGB_frames']+=not shared
                        seen.add(desc['original_frame_key']);counts['observations']+=len(objects)
                        counts['stale_source_results']+=bool(live and final_age_ms>=250)
                        counts['source_receive_over300ms']+=bool(live and final_age_ms>=300)
                        tm=dict(q['timing'],**app,CPU_application_ms=(time.perf_counter()-start)*1000,
                            source_binding_prepare_ms=bind_ms,prepared_admission_to_result_ms=latency,ready_queue_wait_ms=(now-q['ready_ns'])/1e6)
                        tm.update({'upstream_'+k:float(v) for k,v in desc.get('upstream_timings_ms',{}).items() if v is not None})
                        tm.update(details)
                        if 'fast_near_ms' in result:tm['fast_near_ms']=result['fast_near_ms']
                        for k,v in tm.items():
                            if v is not None:samples[k].append(float(v))
                        log.write(json.dumps(dict(source=desc,objects=objects,task_packet=result['task_packet'],voice=voice,linux_result=outward,
                            timings_ms={k:v for k,v in tm.items() if not k.endswith('.scheduler_slices')},
                            stage_counts={k:v for k,v in tm.items() if k.endswith('.scheduler_slices')},
                            source_age_at_application_ms=age_ms,source_age_at_result_ms=final_age_ms,display_eligible=not live or final_age_ms<250,
                            source_timestamp_kind=desc['source_timestamp_kind'],
                            HDMI_visible='NOT_MEASURED',physical_acoustic_latency='NOT_MEASURED'),ensure_ascii=False,allow_nan=False)+'\n')
                        log.flush()  # bounded same-frame consumer reads each result immediately
                    finally:
                        processing_error=sys.exc_info()[1]
                        try:source.release(upstream)
                        except BaseException as release_error:
                            frame_cleanup_errors.append(dict(stage='source.release',error=repr(release_error)))
                            if processing_error is None:raise
                            if hasattr(processing_error,'add_note'):
                                processing_error.add_note('Prepared release failed: '+repr(release_error))
                if first is not None and (time.monotonic_ns()-first)/1e9>=a.duration_s:break
        status='COMPLETED_PREPARED_NPU_APPLICATION_NOT_HDMI_QUALIFIED'
    except BaseException as e:error=str(e);failure=e;raise
    finally:
        cleanup=close_runtime(source,stream,player,primary_error=failure,prior_cleanup_errors=frame_cleanup_errors,audit_path=a.output/'shutdown.json')
        if cleanup['state']=='PENDING':status='PENDING_NATIVE_OR_RESOURCE_CLEANUP'
        elif cleanup['first_error'] is not None:status='FAILED'
        if error is None:error=cleanup['first_error']
        elapsed=(finished-first)/1e9 if first and finished else None
        summary=dict(status=status,error=error,cleanup=cleanup,counts=dict(counts),unique_source_frames=len(seen),elapsed_s=elapsed,
            prepared_application_fps=counts['frames']/elapsed if elapsed else None,requested_source_fps=a.input_fps,
            unique_original_frame_rate=len(seen)/elapsed if elapsed else None,replayed_observations=counts['frames']-len(seen),
            opencv_threads=threads,route=a.route,input_mode=a.input_mode,depth_size=a.depth_size,execution=a.execution,
            cpu_affinity=a.cpu_affinity,thread_placement=placement,clock_detail=a.clock_detail,timing_notes=TIMING_NOTES,warmup_inferences_per_model=20,
            tracking_library=str(a.tracking_library.resolve()) if a.tracking_library else None,gmc_buffer_mode=a.gmc_buffer_mode,
            fast_near=a.fast_near,fast_audio_policy='Normal scheduler; no preemption, no gap exemption, once per fast event; normal persistent alerts unchanged',
            stage_ms={k:dict(mean=float(np.mean(v)),p50=float(np.percentile(v,50)),p95=float(np.percentile(v,95)),p99=float(np.percentile(v,99)),maximum=max(v),n=len(v)) for k,v in samples.items()},
            native_metadata=owner[0].metadata if owner else None,pipeline_capacity=2,max_inflight=stream.max_inflight,producer_slot_wait_ms=stream.slot_wait_ms,
            clock_scope='Prepared admission to CPU result; CLOCK_MONOTONIC source age when supplied. Not physical sensor-to-HDMI/ALSA latency.',
            MPP_RGA_cost='Owned upstream; must join Linux telemetry by SOURCE/PTS. Not measured as zero.',NPU=True,
            memory_note='Prepared V1 <=2x3 mapped tensors uses snapshot+RGB conversion; V2 <=2x4 reuses leased source BGR/RGB and retains exact RGB digest. ACK ends lease. Not DMA zero-copy.')
        summary['stage_counts']={k:v for k,v in summary['stage_ms'].items() if k.endswith('.scheduler_slices')}
        summary['stage_ms']={k:v for k,v in summary['stage_ms'].items() if not k.endswith('.scheduler_slices')}
        summary['linux_result_schema']='AI_LINUX_RESULT_V1'
        try:(a.output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
        except BaseException as summary_error:
            if failure is None:raise
            if hasattr(failure,'add_note'):failure.add_note('Summary write failed: '+repr(summary_error))
        if failure is None and (cleanup['state']!='CLOSED' or cleanup['first_error'] is not None):
            raise RuntimeError('Application cleanup '+cleanup['state']+': '+str(cleanup['first_error']))

if __name__=='__main__':main()
