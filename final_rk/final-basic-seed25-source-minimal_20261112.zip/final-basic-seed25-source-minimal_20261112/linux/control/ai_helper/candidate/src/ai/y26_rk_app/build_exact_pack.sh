#!/usr/bin/env bash
# Compile only; do not launch models or change system runtime.
set -euo pipefail
src_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
out_dir="${1:?pass a NEW private library directory}"
mkdir -p -- "$out_dir"
read -r -a flags <<< "$(pkg-config --cflags --libs opencv4)"
g++ -O3 -std=c++17 -shared -fPIC -fno-fast-math -ffp-contract=off \
 "$src_dir/native/exact_cpu_pack.cpp" -o "$out_dir/libexact_cpu_pack.so" "${flags[@]}"
