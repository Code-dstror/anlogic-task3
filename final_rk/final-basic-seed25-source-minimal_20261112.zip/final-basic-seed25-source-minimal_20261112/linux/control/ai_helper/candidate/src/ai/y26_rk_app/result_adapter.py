"""Model-independent outward metadata. No pixels, model decoding or new policy.

Adds a view beside the existing task packet and public display V2. Distances
are current diagnostic estimates; operational validity is not metric approval.
"""
import copy
import math

GROUPS=frozenset(('pedestrian','vehicle','two_wheeler','obstacle'))
LEVELS=frozenset(('UNKNOWN','CLEAR','ATTENTION','DANGER','NOT_APPLICABLE','EXCLUDED'))

def positive(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0

def distance_view(o):
    """Exact existing display-wire range semantics, kept in one place."""
    distance=o.get('display_distance_m')
    if distance is None:distance=o.get('raw_forward_z_m')
    quality=str(o.get('distance_quality',''))
    ownership=o.get('distance_ownership') or {}
    ambiguous=str(ownership.get('status','')).startswith('UNKNOWN_') or quality.startswith('UNKNOWN_')
    return (float(distance) if positive(distance) and not ambiguous else None),quality,ownership

def frame_view(desc,width,height):
    for value,name in ((width,'width'),(height,'height'),(desc['sequence'],'sequence'),(desc['capture_timestamp_ns'],'timestamp')):
        if type(value) is not int or value<(1 if name in ('width','height') else 0):raise ValueError('Invalid original frame '+name)
    if desc.get('clock_domain') not in ('CLOCK_MONOTONIC','RECORDED_PTS'):raise ValueError('Explicit result clock required')
    if not isinstance(desc.get('frame_key'),str) or not desc['frame_key']:raise ValueError('Original frame key required')
    if desc.get('source_timestamp_kind') not in ('sensor_capture','linux_receive','replay_mapped_pts','recorded_pts'):
        raise ValueError('Explicit timestamp boundary required')
    return dict(session_id=desc['session_id'],epoch=desc['epoch'],camera_id=desc['camera_id'],
        frame_no=desc['sequence'],frame_key=desc['frame_key'],timestamp_ns=desc['capture_timestamp_ns'],
        clock_domain=desc['clock_domain'],timestamp_kind=desc['source_timestamp_kind'],original_width=width,original_height=height)

def build_result(desc,task_packet,voice,width,height,*,display_eligible,source_age_ms=None,expected_application_frame_key=None):
    if task_packet.get('schema')!='AI_TASKS_DIAGNOSTIC_V1':raise ValueError('Application task packet required')
    frame=frame_view(desc,width,height)
    source=task_packet['source']
    if source.get('source_frame')!=frame['frame_no']:raise ValueError('Result task belongs to another sequence')
    seconds=source.get('capture_timestamp_s')
    # Application source stores float seconds; nanosecond identity remains in desc.
    if not isinstance(seconds,(int,float)) or isinstance(seconds,bool) or not math.isfinite(seconds):
        raise ValueError('Application timestamp missing')
    expected=frame['timestamp_ns']/1e9
    if abs(seconds-expected)>max(1e-9,math.ulp(expected)*2):raise ValueError('Result task belongs to another timestamp')
    if source_age_ms is not None and (not isinstance(source_age_ms,(int,float)) or not math.isfinite(source_age_ms) or source_age_ms<0):
        raise ValueError('Invalid result age')
    fresh=display_eligible is True and (source_age_ms is None or source_age_ms<250)
    key=task_packet.get('frame_key');targets=[];seen=set()
    if not isinstance(key,str) or not key:raise ValueError('Application frame key required')
    if expected_application_frame_key is not None and key!=expected_application_frame_key:
        raise ValueError('Task packet does not belong to current pixel evidence')
    for o in task_packet['objects']:
        if o.get('frame_key')!=key:raise ValueError('Cross-frame application target')
        oid=o['id']
        if not isinstance(oid,str) or not oid or oid in seen:raise ValueError('Invalid or repeated target ID')
        seen.add(oid)
        group=o['group']
        if group not in GROUPS:raise ValueError('Unknown application group')
        xy=o['xyxy']
        if len(xy)!=4 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in xy):
            raise ValueError('Invalid original rectangle')
        x1,y1,x2,y2=map(float,xy)
        if not (0<=x1<x2<=width and 0<=y1<y2<=height):raise ValueError('Rectangle outside original image')
        level=o.get('display_level','UNKNOWN')
        if level not in LEVELS:raise ValueError('Unknown warning level')
        distance,quality,ownership=distance_view(o)
        if not fresh:distance=None
        metric=task_packet.get('metric_validated') is True
        priority=o.get('pedestrian_priority')
        priority=priority if group=='pedestrian' and type(priority) is int and priority>0 and fresh else None
        status=('UNKNOWN_STALE_RESULT' if not fresh else
            (quality or str(ownership.get('status') or '') or 'UNKNOWN') if distance is None else
            ('VALIDATED_CURRENT_DISTANCE' if metric else 'ESTIMATE_UNCALIBRATED'))
        targets.append(dict(target_id=oid,tracked=o.get('tracked') is True,group=group,x1=x1,y1=y1,x2=x2,y2=y2,
            distance_m=distance,distance_label='估算的碰撞距离',distance_valid=distance is not None,distance_status=status,metric_validated=metric,
            warning_level=level if fresh else 'UNKNOWN',warning_kind=o.get('display_kind'),pedestrian_priority=priority,
            distance_basis='CAMERA_FORWARD_Z_ESTIMATE',true_bumper_clearance_m=None,collision_risk_validated=False,
            proximity_level=o.get('proximity_level','UNKNOWN') if fresh else 'UNKNOWN',
            ttc_level=o.get('ttc_level','UNKNOWN') if fresh else 'UNKNOWN',
            ttc_confirmed=o.get('ttc_confirmed') is True and fresh,voice_basis_kind=o.get('voice_basis_kind','NONE') if fresh else 'NONE',
            display_visible=o.get('display_visible') is True and fresh))
    events=[]
    fast=task_packet.get('fast_near')
    if fast is not None and (fast.get('schema')!='FAST_NEAR_DIAGNOSTIC_V1' or fast.get('frame_key')!=key):
        raise ValueError('Cross-frame fast diagnostic')
    for event in voice.get('events',[]):
        # These are observed scheduler/player events, not new playback commands.
        e=copy.deepcopy(event)
        e.update(observed_frame_key=frame['frame_key'],clock_domain=frame['clock_domain'])
        if e.get('action')=='PLAY_START':
            # Bind a new request only to its own current source observation.
            # Completion from an older request must never inherit today's targets.
            if e.get('frame_key')!=key:raise ValueError('Voice start belongs to another application frame')
            groups=e.get('groups') or [e.get('group')]
            trigger=[o for o in task_packet['objects'] if o.get('voice_eligible') is True and o['group'] in groups]
            e['trigger_target_ids']=[o['id'] for o in trigger]
            e['trigger_kinds']=sorted({o.get('voice_basis_kind','UNSPECIFIED_DIAGNOSTIC') for o in trigger})
            fast_triggers=[a for a in (fast or {}).get('alerts',[]) if a.get('voice_eligible') and a['group'] in groups]
            e['fast_trigger_event_ids']=[a['event_id'] for a in fast_triggers]
            if fast_triggers:e['trigger_kinds']=sorted(set(e['trigger_kinds'])|{'FAST_NEAR_DIAGNOSTIC'})
            e['collision_risk_validated']=False
        events.append(e)
    outward_fast=copy.deepcopy(fast)
    if outward_fast is not None and not fresh:
        outward_fast.update(alerts=[],voice_groups=[],status='UNKNOWN_STALE_RESULT')
    return dict(schema='AI_LINUX_RESULT_V1',frame=frame,application_frame_key=key,targets=targets,voice_events=events,fast_near=outward_fast,
        display_eligible=fresh,result_status='CURRENT_RESULT' if fresh else 'STALE_OR_INELIGIBLE_RESULT',
        voice_status=voice.get('status','RECORDED_VOICE_SIMULATION' if voice.get('physical_audio') is False else 'UNSPECIFIED'),
        voice_events_are_playback_commands=False,
        metric_validated=task_packet.get('metric_validated') is True,
        automatic_lane=task_packet.get('automatic_lane','UNKNOWN'))
