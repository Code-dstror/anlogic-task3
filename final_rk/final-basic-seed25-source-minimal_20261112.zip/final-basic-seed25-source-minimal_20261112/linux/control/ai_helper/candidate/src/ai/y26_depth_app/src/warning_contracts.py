"""Model-independent application contracts. No inference or transport dependency."""
from dataclasses import dataclass
import math
from typing import Protocol

from region_warning import FrameIdentity


@dataclass(frozen=True)
class TimedFrame:
    identity: FrameIdentity
    timestamp_ns: int
    clock_domain: str
    observed_at_ns: int
    time_source: str

    def __post_init__(self):
        if (type(self.timestamp_ns) is not int or type(self.observed_at_ns) is not int
                or not 0<=self.timestamp_ns<=self.observed_at_ns
                or not self.clock_domain or not self.time_source):
            raise ValueError('Explicit same-domain time and nonnegative age required')

    @property
    def age_ms(self): return (self.observed_at_ns-self.timestamp_ns)/1e6


@dataclass(frozen=True)
class ObservedTarget:
    frame_key: str
    track_id: int
    class_id: int
    confidence: float
    bbox_source_xyxy: tuple
    observation_state: str = 'OBSERVED_FILTERED'

    def validate(self,frame):
        b=self.bbox_source_xyxy
        if (self.frame_key!=frame.key or type(self.track_id) is not int or self.track_id<0
                or type(self.class_id) is not int or self.class_id<0
                or type(self.confidence) not in (float,int) or not math.isfinite(self.confidence)
                or not 0<=self.confidence<=1 or len(b)!=4
                or any(type(v) not in (float,int) or not math.isfinite(v) for v in b)
                or not 0<=b[0]<b[2]<=frame.width or not 0<=b[1]<b[3]<=frame.height
                or self.observation_state!='OBSERVED_FILTERED'):
            raise ValueError('Invalid/misbound observed target')


@dataclass(frozen=True)
class RegionContact:
    target: ObservedTarget
    inside_entry: bool | None
    inside_retention: bool | None
    region_id: str
    evidence_source: str
    quality: str

    def validate(self,frame):
        self.target.validate(frame)
        if (not self.region_id or not self.evidence_source or not self.quality
                or any(v is not None and type(v) is not bool for v in (self.inside_entry,self.inside_retention))
                or (self.inside_entry is None)!=(self.inside_retention is None)
                or (self.inside_entry is True and self.inside_retention is not True)):
            raise ValueError('Invalid region membership/hysteresis contract')


class RegionProvider(Protocol):
    region_id: str
    def evaluate(self,frame: FrameIdentity,target: ObservedTarget) -> RegionContact: ...


class Detector(Protocol):
    sha256: str
    def predict(self,rgb,frame: FrameIdentity,**postprocessing) -> tuple: ...
