#!/usr/bin/env bash
set -euo pipefail
src_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
out_dir="${1:?pass candidate board_libs}"
mkdir -p -- "$out_dir"
read -r -a flags <<< "$(pkg-config --cflags --libs opencv4)"
g++ -O3 -std=c++17 -fPIC -shared -fno-fast-math -ffp-contract=off \
 "$src_dir/native/gmc_flow.cpp" -o "$out_dir/liby26_gmc_flow.so" "${flags[@]}"
