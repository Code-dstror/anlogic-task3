"""Y26-specific prepared publisher and exact-source display consumer.

Owned slots are independent of Gst/recording references. No decoder here.
Native gate sends packed NV12 copied BEFORE lane/AI drawing. Two slots maximum.
"""
import argparse,ctypes as C,json,mmap,os,socket,struct,time,threading,queue,select
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
import sys
sys.path.insert(0,str(HERE.parent/'y26_depth_app'))
from model_preprocessing import geometry as det_geometry
from depth_preprocessing import geometry as dep_geometry
from linux_display import VERSION,REQUEST,REPLY,BOX,display_reply,empty_reply
SIZES={'source_bgr':(1080,1920,3),'detector_rgb':(640,640,3),'depth_rgb':(768,768,3)}

class Slots:
    def __init__(self,root,depth_size=768,shared_rgb=False):
        if depth_size not in (640,768):raise ValueError('Unsupported depth size')
        if depth_size!=768 and not shared_rgb:raise ValueError('640 requires prepared V2/shared RGB')
        self.depth_size=depth_size;self.shared_rgb=shared_rgb
        self.sizes=dict(SIZES,depth_rgb=(depth_size,depth_size,3))
        if shared_rgb:self.sizes['source_rgb']=(1080,1920,3)
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        if any(self.root.iterdir()):raise FileExistsError('Use a new empty bridge root')
        self.files={};self.held={};self.lock=threading.Lock()
        for i in range(2):
            for k,shape in dict(self.sizes,nv12=(1080*3//2,1920)).items():
                p=self.root/f'{i}_{k}.bin';n=int(np.prod(shape))
                with p.open('wb') as f:f.truncate(n)
                self.files[i,k]=np.memmap(p,mode='r+',dtype=np.uint8,shape=shape)
    def admit(self,slot,token):
        with self.lock:
            if slot not in (0,1) or slot in self.held:raise ValueError('slot busy/invalid')
            self.held[slot]=token
    def release(self,slot,token):
        with self.lock:
            if self.held.get(slot)!=token:raise ValueError('ACK token mismatch')
            del self.held[slot]

class Rga:
    def __init__(self,library,shared_rgb=False):
        if os.environ.get('Y26_RGB_SWAP_NATIVE') == '1':
            raise RuntimeError('CPU RGB channel conversion forbidden; require Y26_RGB_SWAP_NATIVE=0 and RGA')
        self.shared_rgb=shared_rgb
        self.lib=C.CDLL(str(library));self.lib.y26_prep_open.restype=C.c_void_p
        if shared_rgb:
            if not hasattr(self.lib,'y26_prep_nv12_shared'):raise RuntimeError('Rebuild native shared-RGB library; no legacy fallback')
            self.lib.y26_prep_nv12_shared.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.c_int,
                C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.c_int,C.c_int,
                C.POINTER(C.c_double),C.POINTER(C.c_double),C.POINTER(C.c_int),C.c_char_p,C.c_int]
            self.lib.y26_prep_nv12_shared.restype=C.c_int
        self.lib.y26_prep_nv12.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.c_int,C.c_void_p,C.c_void_p,C.c_void_p,C.c_int,C.POINTER(C.c_double),C.c_char_p,C.c_int]
        self.lib.y26_prep_close.argtypes=[C.c_void_p]
        self.h=self.lib.y26_prep_open()
        if not self.h:raise RuntimeError('RGA prep allocation')
    def prepare(self,slots,slot,official):
        a=slots.files[slot,'nv12'];tm=(C.c_double*4)();err=C.create_string_buffer(512)
        if self.shared_rgb:
            if not slots.shared_rgb:raise ValueError('Shared RGA requires matching prepared slots')
            detail=(C.c_double*3)();facts=(C.c_int*3)()
            rc=self.lib.y26_prep_nv12_shared(self.h,a.ctypes.data,a.ctypes.data+1920*1080,1920,1920,
                *[slots.files[slot,k].ctypes.data for k in ('source_bgr','source_rgb','detector_rgb','depth_rgb')],
                int(official),0,slots.depth_size,tm,detail,facts,err,512)
        else:
            rc=self.lib.y26_prep_nv12(self.h,a.ctypes.data,a.ctypes.data+1920*1080,1920,1920,*[slots.files[slot,k].ctypes.data for k in SIZES],int(official),tm,err,512)
        if rc:raise RuntimeError(err.value.decode())
        result=dict(zip(['mapped_NV12_repack_ms','RGA_NV12_to_source_BGR_ms','RGA_RGB_resize_ms','pad114_copy_ms'],tm))
        if self.shared_rgb:
            result.update(zip(['RGA_BGR_to_shared_RGB_ms','RGA_detector_resize_ms','RGA_depth_resize_or_copy_ms'],detail))
            result.update(direct_packed_NV12=int(facts[0]),shared_640_resize=int(facts[1]),explicit_copy_bytes=int(facts[2]))
        return result
    def close(self):
        if self.h:self.lib.y26_prep_close(self.h);self.h=None

def descriptor(slots,request,official,timings):
    version,slot,token,received,published,session,epoch,sequence,camera,kind,fmt,role=request
    if version!=VERSION or not 0<received<=published:raise ValueError('request version/monotonic interval invalid')
    source=dict(session=session,epoch=epoch,sequence=sequence,camera=camera,kind=kind,format=fmt,role=role)
    key=':'.join(map(str,[session,epoch,camera,sequence,kind,fmt,role]))
    d=dict(schema='Y26_PREPARED_FRAME_V1',session_id=str(session),epoch=epoch,camera_id=camera,sequence=sequence,frame_key=key,original_frame_key=key,
           source=source,association_token=token,source_capture_timestamp_ns=None,original_video_pts=None,original_video_time_base=None,
           received_monotonic_ns=received,published_monotonic_ns=published,capture_timestamp_ns=received,
           timestamp_alias_note='capture_timestamp_ns is legacy field name; value is Linux receive time, NOT sensor capture',
           clock_domain='CLOCK_MONOTONIC',source_timestamp_kind='linux_receive',slot=slot,view_id='source-1080p',
           detector_geometry=det_geometry(1920,1080),depth_geometry=dep_geometry(1920,1080,getattr(slots,'depth_size',768),'letterbox' if official else 'stretch'),
           upstream_timings_ms={k:v for k,v in timings.items() if k.endswith('_ms')},
           upstream_transfer_facts={k:v for k,v in timings.items() if not k.endswith('_ms')})
    if getattr(slots,'shared_rgb',False):
        d.update(schema='Y26_PREPARED_FRAME_V2',shared_rgb_relation='BGR_CHANNEL_PERMUTATION')
    for k,shape in getattr(slots,'sizes',SIZES).items():
        d[k]=dict(path=str((slots.root/f'{slot}_{k}.bin').resolve()),shape=shape,strides_bytes=(shape[1]*3,3,1),offset_bytes=0,backing_bytes=int(np.prod(shape)),color='BGR' if k=='source_bgr' else 'RGB',frame_key=key,capture_timestamp_ns=received,fence_complete=True)
    return d


class TwoStageBridge:
    """Seal admission, then drain existing work without cancelling its consumers.

    stop is fatal-abort only. A close timeout is NOT an abort or a completion.
    The supervisor retains this object and retries close after late completion.
    """
    def __init__(self, slots, prepare, publish, read_result, read_ack, send, official):
        self.slots,self.prepare,self.publish=slots,prepare,publish
        self.read_result,self.read_ack,self.send=read_result,read_ack,send
        self.official=official;self.stop=threading.Event();self.error=None
        self.requests=queue.Queue(maxsize=2);self.pending=queue.Queue(maxsize=2)
        self.send_lock=threading.Lock();self.max_held=0;self.last_token=0
        self._lifecycle_lock=threading.RLock();self.accepting=True;self.started=False
        self.preparation_done=threading.Event();self.cleanup_errors=[];self.close_attempts=0
        self.deliveries={}
        self.threads=[threading.Thread(target=self._guard,args=(self._prepare,),daemon=False,name='y26-rga-owner'),
                      threading.Thread(target=self._guard,args=(self._collect,),daemon=False,name='y26-result-owner')]
    def start(self):
        with self._lifecycle_lock:
            if self.started or not self.accepting:raise RuntimeError('bridge cannot be restarted')
            self.started=True
            for t in self.threads:t.start()
    def _fail(self,exc):
        with self._lifecycle_lock:
            if self.error is None:self.error=exc
            elif exc is not self.error:self.cleanup_errors.append(exc)
            self.accepting=False;self.stop.set()
    def _guard(self, method):
        try:method()
        except BaseException as e:self._fail(e)  # no unknown slot completion
        finally:
            if method.__name__=='_prepare':self.preparation_done.set()
    def _get(self, q, *, preparation=False):
        while not self.stop.is_set():
            try:return q.get(timeout=.05)
            except queue.Empty:
                if preparation:
                    with self._lifecycle_lock:
                        if not self.accepting and q.empty():return None
                elif self.preparation_done.is_set() and q.empty():return None
        return None
    def submit(self, req):
        with self._lifecycle_lock:
            if not self.started or not self.accepting:raise RuntimeError('bridge admission closed') from self.error
            if req[0]!=VERSION or req[2]<=self.last_token or not 0<req[3]<=req[4]<=time.monotonic_ns():raise ValueError('invalid request ordering/version/clock')
            self.slots.admit(req[1],req[2]);self.last_token=req[2]
            with self.slots.lock:self.max_held=max(self.max_held,len(self.slots.held))
            try:self.requests.put_nowait(req)
            except queue.Full:
                error=RuntimeError('two-slot request invariant violated');self._fail(error);raise error
    def _complete(self, req, reply):
        # Release before reply visibility so the native peer can immediately
        # reuse its slot. Track delivery independently: never hold the lifecycle
        # lock across I/O, which would make close's time budget meaningless.
        identity=(req[1],req[2])
        with self._lifecycle_lock:
            self.deliveries[identity]='SENDING'
            self.slots.release(req[1],req[2])
        try:
            with self.send_lock:self.send(reply)
        except BaseException as exc:
            with self._lifecycle_lock:
                self.deliveries[identity]='UNKNOWN'
                self._fail(exc)
                # If the reply actually arrived and a new request raced in,
                # keep that new slot too; never overwrite its identity.
                with self.slots.lock:self.slots.held.setdefault(req[1],req[2])
            raise
        with self._lifecycle_lock:del self.deliveries[identity]
    def _prepare(self):
        while not self.stop.is_set():
            req=self._get(self.requests,preparation=True)
            if req is None:return
            if time.monotonic_ns()-req[3]>=250_000_000:
                self._complete(req,empty_reply(req));continue
            timings=self.prepare(self.slots,req[1],self.official)
            if self.stop.is_set():return  # fatal fence; normal drain does not set stop
            d=descriptor(self.slots,req,self.official,timings)
            self.pending.put_nowait((req,d))
            self.publish(d)
    def _collect(self):
        while not self.stop.is_set():
            item=self._get(self.pending)
            if item is None:return
            req,d=item;row=self.read_result(self.stop);ack=self.read_ack(self.stop)
            if (ack.get('schema')!='Y26_PREPARED_RELEASE_V1' or ack.get('frame_key')!=d['frame_key']
                    or ack.get('slot')!=req[1] or ack.get('sequence')!=d['sequence']):
                raise ValueError('runner ACK identity mismatch')
            self._complete(req,display_reply(req,row,time.monotonic_ns()))
    def raise_if_failed(self):
        if self.error:raise RuntimeError('bridge worker failed; do not treat shutdown as success') from self.error
    def begin_drain(self):
        with self._lifecycle_lock:self.accepting=False
    def shutdown_report(self):
        with self._lifecycle_lock:
            alive=[t.name for t in self.threads if t.is_alive()]
            with self.slots.lock:held=dict(self.slots.held)
            safe=not self.accepting and not alive and not held and not self.deliveries and self.requests.empty() and self.pending.empty()
            return dict(state='CLOSED' if safe else 'PENDING',safe_to_release=safe,
                accepting=self.accepting,worker_alive=alive,held=held,
                queued_requests=self.requests.qsize(),queued_results=self.pending.qsize(),
                deliveries=[dict(slot=k[0],token=k[1],state=v) for k,v in self.deliveries.items()],
                first_error=None if self.error is None else repr(self.error),
                cleanup_errors=[repr(e) for e in self.cleanup_errors],close_attempts=self.close_attempts)
    def close(self,timeout_s=2):
        if not 0<=timeout_s< float('inf'):raise ValueError('finite nonnegative close budget required')
        deadline=time.monotonic()+timeout_s
        self.begin_drain();self.close_attempts+=1
        for t in self.threads:
            if t.ident is not None:t.join(timeout=max(0,deadline-time.monotonic()))
        if not self.shutdown_report()['safe_to_release']:
            raise RuntimeError('bridge resources PENDING; preserve consumer, handles and mappings')


# Includes open files/sockets and RGA, not just the worker. A timeout must not
# unwind their context managers while a worker/native call can still use them.
_PENDING_BRIDGES={}

class BridgeResources:
    """Supervisor-owned lifetime bundle; close from one control thread only.

    timeout_s bounds worker drain/join, not vendor RGA destroy or Python file
    close. Those run synchronously only AFTER consumers have safely retired.
    """
    def __init__(self,engine,rga,resources,*,audit_path=None):
        self.engine=engine;self.rga=rga;self.resources=list(resources)
        self.audit_path=Path(audit_path) if audit_path is not None else None
        self.first_error=None;self.cleanup_errors=[];self.rga_attempted=False;self.rga_closed=False
        self.closed_resources=set();self.attempts=0;self.closed=False
    def _record(self,stage,exc):
        if self.first_error is None:self.first_error=repr(exc)
        if self.cleanup_errors and self.cleanup_errors[-1]['stage']==stage and self.cleanup_errors[-1]['error']==repr(exc):
            self.cleanup_errors[-1]['repeats']+=1;self.cleanup_errors[-1]['attempt']=self.attempts
        else:
            self.cleanup_errors.append(dict(stage=stage,error=repr(exc),attempt=self.attempts,repeats=1))
            self.cleanup_errors=self.cleanup_errors[-64:]
    def close(self,timeout_s=2,primary_error=None):
        self.attempts+=1
        if primary_error is not None and self.first_error is None:self.first_error=repr(primary_error)
        _PENDING_BRIDGES[id(self)]=self
        close_error=None
        if self.engine is not None:
            try:self.engine.close(timeout_s)
            except BaseException as exc:close_error=exc
            pipeline=self.engine.shutdown_report()
        else:pipeline=dict(state='CLOSED',safe_to_release=True,first_error=None,cleanup_errors=[],held={},worker_alive=[])
        if self.first_error is None:self.first_error=pipeline['first_error']
        if close_error is not None:self._record('engine.close',close_error)
        if pipeline['safe_to_release']:
            if not self.rga_attempted:
                self.rga_attempted=True
                try:
                    if self.rga is not None:self.rga.close()
                    self.rga_closed=True
                except BaseException as exc:self._record('rga.close',exc)
            if self.rga_closed:
                for index,resource in enumerate(self.resources):
                    if index in self.closed_resources:continue
                    try:resource.close();self.closed_resources.add(index)
                    except BaseException as exc:self._record('resource.close',exc)
        self.closed=pipeline['safe_to_release'] and self.rga_closed and len(self.closed_resources)==len(self.resources)
        report=dict(state='CLOSED' if self.closed else 'PENDING',safe_to_release=self.closed,
            first_error=self.first_error,cleanup_errors=list(self.cleanup_errors),pipeline=pipeline,
            rga_closed=self.rga_closed,closed_resources=len(self.closed_resources),
            total_resources=len(self.resources),attempts=self.attempts)
        if self.audit_path is not None:
            try:
                temporary=self.audit_path.with_name(self.audit_path.name+'.tmp')
                temporary.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
                os.replace(temporary,self.audit_path)
            except BaseException as exc:
                self._record('shutdown.audit',exc)
                report.update(first_error=self.first_error,cleanup_errors=list(self.cleanup_errors))
        if self.closed:_PENDING_BRIDGES.pop(id(self),None)
        return report


def read_json_line(file,stop,*,fifo=False,timeout_s=15):
    """Regular-file tail may return a partial write: only consume complete lines."""
    data=b'';deadline=None if timeout_s is None else time.monotonic()+timeout_s
    while not stop.is_set():
        if deadline is not None and time.monotonic()>deadline:raise TimeoutError('result/ACK timeout; slots quarantined')
        if fifo and not select.select([file],[],[],.05)[0]:continue
        part=file.readline(2*1024*1024+1-len(data))
        if part:
            data+=part
            if len(data)>2*1024*1024:raise ValueError('bounded result metadata exceeded')
            if data.endswith(b'\n'):return json.loads(data)
        else:stop.wait(.001)
    raise RuntimeError('bridge stopping before matching result/ACK')


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--rga-library',type=Path,required=True)
    p.add_argument('--color-profile',choices=['bt601_full'],required=True);p.add_argument('--route',choices=['official','lc64'],required=True)
    p.add_argument('--shared-rgb',action='store_true',help='Opt-in prepared V2; needs matching Reader and native shared-RGB library')
    p.add_argument('--depth-size',type=int,choices=[640,768],default=768)
    p.add_argument('--runner-output',type=Path,required=True)
    p.add_argument('--shutdown-budget-s',type=float,default=2,help='Each bounded drain attempt; timeout retains resources and retries')
    a=p.parse_args()
    if a.depth_size!=768 and not a.shared_rgb:p.error('640 requires --shared-rgb and matching prepared V2 consumer')
    if not 0<=a.shutdown_budget_s<float('inf'):p.error('finite nonnegative shutdown budget required')
    owner=BridgeResources(None,None,[],audit_path=a.root/'bridge_shutdown.json')
    failure=None;reported_pending=False
    try:
        slots=Slots(a.root,a.depth_size,a.shared_rgb)
        owner.rga=Rga(a.rga_library.resolve(),a.shared_rgb)
        server=socket.socket(socket.AF_UNIX,socket.SOCK_SEQPACKET);owner.resources.append(server)
        server.bind(str(a.root/'bridge.sock'));server.listen(1)
        for name in ['prepared.fifo','acks.fifo']:os.mkfifo(a.root/name,0o600)
        conn,_=server.accept();owner.resources.append(conn);conn.settimeout(.2)
        output=(a.root/'prepared.fifo').open('w',buffering=1);owner.resources.append(output)
        acks=(a.root/'acks.fifo').open('rb',buffering=0);owner.resources.append(acks)
        ready=a.runner_output/'native_ready.json';deadline=time.monotonic()+60
        while not ready.exists() or not (a.runner_output/'frames.jsonl').exists():
            if time.monotonic()>deadline:raise TimeoutError('NPU native_ready absent')
            time.sleep(.01)
        results=(a.runner_output/'frames.jsonl').open('rb',buffering=0);owner.resources.append(results)
        engine=TwoStageBridge(slots,owner.rga.prepare,lambda d:output.write(json.dumps(d)+'\n'),
            lambda stop:read_json_line(results,stop,timeout_s=None),
            lambda stop:read_json_line(acks,stop,fifo=True,timeout_s=None),conn.sendall,a.route=='official')
        owner.engine=engine;engine.start();(a.root/'native_ready.signal').write_text('NPU_CONTEXTS_READY\n')
        while not engine.stop.is_set():
            try:raw=conn.recv(REQUEST.size+1)
            except socket.timeout:continue
            # Native SHUT_WR: all preceding requests have arrived, but the
            # reply direction stays open. This is the ordered drain barrier.
            if not raw:break
            if len(raw)!=REQUEST.size:raise ValueError('bounded request length')
            engine.submit(REQUEST.unpack(raw))
    except BaseException as exc:failure=exc
    finally:
        # Preserve the triggering fault BEFORE readiness/audit cleanup can fail.
        primary=failure if failure is not None else (owner.engine.error if owner.engine is not None else None)
        if primary is not None and owner.first_error is None:owner.first_error=repr(primary)
        try:
            (a.root/'native_ready.signal').unlink(missing_ok=True)
        except OSError as exc:owner._record('ready.unlink',exc)
        while True:
            try:report=owner.close(a.shutdown_budget_s,primary_error=failure)
            except BaseException as exc:
                if failure is None:failure=exc
                owner._record('pending.close_control',exc)
                continue
            if report['state']=='CLOSED':break
            if not reported_pending:
                print('Bridge PENDING: retaining native owners/files/socket; see bridge_shutdown.json',file=sys.stderr,flush=True)
                reported_pending=True
            # Deliberately keep the supervisor process and all resources alive.
            # A second Ctrl-C is not evidence of native completion either.
            try:time.sleep(1)
            except BaseException as exc:
                if failure is None:failure=exc
                owner._record('pending.control',exc)
    if failure is not None:raise failure
    if report['first_error'] is not None:raise RuntimeError('Bridge closed with recorded errors: '+report['first_error'])

if __name__=='__main__':main()
