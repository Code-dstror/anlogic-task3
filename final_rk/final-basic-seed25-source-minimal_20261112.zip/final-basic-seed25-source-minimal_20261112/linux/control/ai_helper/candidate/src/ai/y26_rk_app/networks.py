"""Already-prepared Linux RGB -> NPU -> CPU O2O/precise depth query.

No JPEG/NV12 decoder or resize/color implementation is duplicated here.
One ordered inference worker owns both model contexts and samplers.
"""
from pathlib import Path
import sys
import time
import os
import numpy as np
from concurrent.futures import ThreadPoolExecutor
HERE=Path(__file__).resolve().parent;HOST=HERE.parent/'y26_depth_app'
sys.path[:0]=[str(HOST),str(HOST/'src'),str(HERE.parent/'depth_roi')]
from backend import Engine,canonical
from postprocess import detections,source_boxes
from model_preprocessing import geometry as detector_geometry
from depth_preprocessing import geometry as depth_geometry
from roi_depth import RoiDepthSampler
from cpu_profile import StageTimer,configure_timing

class Networks:
    def __init__(self,detector,depth,kind,library,roi_library,config,copy_input=False,input_mode='standard',depth_size=768,execution='serial',core_mask=None):
        self.clock_detail=config.get('cpu_runtime',{}).get('clock_detail',False)
        self.native_topk=None
        topk_library=config.get('cpu_runtime',{}).get('topk_library') or os.environ.get('Y26_TOPK_LIBRARY')
        if topk_library:
            from native_topk import NativeTopK
            self.native_topk=NativeTopK(topk_library)
        if depth_size not in (512,576,640,768) or execution not in ('serial','parallel_split'):raise ValueError('Invalid selected depth geometry/execution')
        if input_mode not in ('standard','bound-fp16'):raise ValueError('Unknown board input mode')
        engine_type=Engine
        if input_mode=='bound-fp16':
            from reuse_backend import ReuseEngine
            engine_type=ReuseEngine
        detector_mode=os.environ.get('Y26_DETECTOR_INPUT_MODE',input_mode)
        if detector_mode not in ('standard','bound-fp16'):raise ValueError('Unknown detector input mode')
        detector_engine=Engine if detector_mode=='standard' else engine_type
        if detector_mode=='bound-fp16' and input_mode!='bound-fp16':
            from reuse_backend import ReuseEngine
            detector_engine=ReuseEngine
        self.det_pool=self.depth_pool=None;self.execution=execution;self.depth_size=depth_size
        options={} if core_mask is None else dict(core_mask=core_mask)
        if execution=='parallel_split':
            self.det_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='det-core0',initializer=configure_timing,initargs=(self.clock_detail,))
            self.depth_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='depth-core1',initializer=configure_timing,initargs=(self.clock_detail,))
            try:
                masks=[int(os.environ.get('Y26_DETECTOR_NPU_MASK','1')),int(os.environ.get('Y26_DEPTH_NPU_MASK','2'))]
                if any(mask not in (0,1,2,3) for mask in masks):raise ValueError('Invalid NPU mask')
                self.det=self.det_pool.submit(detector_engine,detector,library,core_mask=masks[0]).result()
                self.depth=self.depth_pool.submit(engine_type,depth,library,core_mask=masks[1]).result()
            except BaseException:
                if hasattr(self,'det'):self.det_pool.submit(self.det.close).result()
                self.det_pool.shutdown();self.depth_pool.shutdown();raise
        else:
            self.det=detector_engine(detector,library,**options)
            try:self.depth=engine_type(depth,library,**options)
            except BaseException:self.det.close();raise
        self.kind=kind;self.config=config;self.roi_library=roi_library;self.samplers={};self.copy_input=copy_input;self.inputs={}
    def run_engine(self,engine,rgb):
        extra={};timer=StageTimer(extra if self.clock_detail else None)
        values,timing=engine.infer(rgb);timer.mark('engine_call_detail')
        timing.update(extra);return values,timing
    def infer_prepared(self,det_rgb,depth_rgb,width,height,det_g,depth_g):
        wanted_det=detector_geometry(width,height);wanted_depth=depth_geometry(width,height,self.depth_size,'letterbox' if self.kind=='official' else 'stretch')
        for k in ('width','height','size','left','top','sx','sy'):
            if det_g[k]!=wanted_det[k] or depth_g[k]!=wanted_depth[k]:raise ValueError('Prepared tensor geometry differs from selected model')
        timing={};detail=StageTimer(timing if self.clock_detail else None);start=time.perf_counter()
        for name,rgb,size in [('det',det_rgb,640),('depth',depth_rgb,self.depth_size)]:
            if rgb.shape!=(size,size,3) or rgb.dtype!=np.uint8 or not rgb.flags.c_contiguous:raise ValueError('Input size/layout mismatch')
            if self.copy_input:
                if name not in self.inputs:self.inputs[name]=np.empty_like(rgb)
                np.copyto(self.inputs[name],rgb)
        timing['input_host_copy_ms']=(time.perf_counter()-start)*1000
        detail.mark('network_input_prepare_detail')
        det_input=self.inputs['det'] if self.copy_input else det_rgb;dep_input=self.inputs['depth'] if self.copy_input else depth_rgb
        pair_start=time.perf_counter();future=None
        if self.execution=='parallel_split':
            det_future=self.det_pool.submit(self.run_engine,self.det,det_input);future=self.depth_pool.submit(self.run_engine,self.depth,dep_input)
            values,tm=det_future.result()
        else:values,tm=self.run_engine(self.det,det_input)
        timing.update({'det_'+k:v for k,v in tm.items()})
        detail.mark('detector_call_or_future_wait')
        objects,weak=self.decode_detection(values,det_g,timing)
        detail.mark('detection_postprocess_detail')
        value,tm=future.result() if future is not None else self.run_engine(self.depth,dep_input)
        detail.mark('depth_call_or_future_wait')
        timing['pair_including_TopK_wall_ms']=(time.perf_counter()-pair_start)*1000
        timing.update({'depth_'+k:v for k,v in tm.items()});raw=canonical(value,'depth',self.depth_size//4)[0].squeeze()
        self.sample_depth(raw,objects,width,height,depth_g,timing)
        detail.mark('depth_validation_exact_ROI_detail')
        return objects,weak,timing
    def decode_detection(self,values,det_g,timing):
        values=canonical(values,'detector23');start=time.perf_counter()
        select=self.native_topk.detections if self.native_topk is not None else detections
        rows=select(*values,agnostic=self.config.get('detector_agnostic',False))
        timing['detection_topk_select_ms']=(time.perf_counter()-start)*1000
        mapped=time.perf_counter();rows=source_boxes(rows,det_g)
        timing['detection_box_map_ms']=(time.perf_counter()-mapped)*1000;packed=time.perf_counter()
        high=rows[rows[:,4]>=self.config['detector_threshold']]
        objects=[dict(class_id=int(r[5]),class_name=self.config['model']['names'][int(r[5])],application_group=self.config['model']['groups'][str(int(r[5]))],confidence=float(r[4]),xyxy=r[:4].astype(float).tolist())
            for r in high if r[2]>r[0] and r[3]>r[1]]
        mask=(rows[:,4]>.1)&(rows[:,4]<self.config['tracker']['threshold'])
        weak=[dict(class_id=int(r[5]),confidence=float(r[4]),xyxy=r[:4].astype(float).tolist(),tracking_only=True)
            for r in rows[mask] if r[2]>r[0] and r[3]>r[1]]
        timing['detection_object_pack_ms']=(time.perf_counter()-packed)*1000
        timing['detection_cpu_topk_ms']=(time.perf_counter()-start)*1000
        return objects,weak
    def sample_depth(self,raw,objects,width,height,depth_g,timing):
        if not np.isfinite(raw).all() or (raw<=0).any():raise ValueError('Invalid depth output')
        shape=(height,width);start=time.perf_counter()
        if shape not in self.samplers:self.samplers[shape]=RoiDepthSampler(raw.shape,shape,(self.depth_size,self.depth_size),mode='native_exact',library=self.roi_library,content_box=depth_g['content_box'])
        for obj,distance in zip(objects,self.samplers[shape].sample(raw,[o['xyxy'] for o in objects])):obj.update(distance,distance_kind='DENSE_DEPTH_PATCH')
        timing['depth_exact_ROI_ms']=(time.perf_counter()-start)*1000

    def execute_prepared_owned(self,det_rgb,depth_rgb,width,height,det_g,depth_g):
        """Publish owned outputs; never queue an SDK-borrowed view."""
        if self.copy_input:raise ValueError('Split output pipeline already owns input slots; copy-input profile is separate')
        for rgb,size,g,wanted in ((det_rgb,640,det_g,detector_geometry(width,height)),
            (depth_rgb,self.depth_size,depth_g,depth_geometry(width,height,self.depth_size,'letterbox' if self.kind=='official' else 'stretch'))):
            if rgb.shape!=(size,size,3) or rgb.dtype!=np.uint8 or not rgb.flags.c_contiguous:raise ValueError('Prepared input layout differs')
            for k in ('width','height','size','left','top','sx','sy'):
                if g[k]!=wanted[k]:raise ValueError('Prepared input geometry differs')
        t=time.perf_counter();timing={}
        if self.det_pool is not None:
            a=self.det_pool.submit(self.det.infer,det_rgb,owned=True)
            b=self.depth_pool.submit(self.depth.infer,depth_rgb,owned=True)
            values,tm=a.result();value,zm=b.result()
        else:
            values,tm=self.det.infer(det_rgb,owned=True);value,zm=self.depth.infer(depth_rgb,owned=True)
        for arrays in (values,value):
            for v in arrays:
                if not v.flags.owndata:raise RuntimeError('Queued model output must own storage')
                v.setflags(write=False)
        timing.update({'det_'+k:v for k,v in tm.items()});timing.update({'depth_'+k:v for k,v in zm.items()})
        timing['pair_owned_execution_wall_ms']=(time.perf_counter()-t)*1000
        return (values,value,det_g,depth_g,width,height),timing

    def close(self):
        if self.native_topk is not None:self.native_topk.close()
        for s in self.samplers.values():s.close()
        if self.det_pool is not None:
            self.det_pool.submit(self.det.close).result();self.depth_pool.submit(self.depth.close).result()
            self.det_pool.shutdown();self.depth_pool.shutdown()
        else:self.det.close();self.depth.close()
    def warmup(self,count=20):
        det=np.full((640,640,3),114,np.uint8);depth=np.full((self.depth_size,self.depth_size,3),114,np.uint8)
        for _ in range(count):
            if self.det_pool is not None:
                a=self.det_pool.submit(self.det.infer,det);b=self.depth_pool.submit(self.depth.infer,depth);a.result();b.result()
            else:self.det.infer(det);self.depth.infer(depth)


class CpuPostprocessor:
    """Independent CPU owner; TopK/exact ROI overlap next NPU inference.

    No model contexts. FIFO pipeline retains source leases until state finishes.
    """
    decode_detection=Networks.decode_detection
    sample_depth=Networks.sample_depth
    def __init__(self,config,roi_library,depth_size):
        self.config=config;self.roi_library=roi_library;self.depth_size=depth_size
        self.samplers={};self.native_topk=None
        library=config.get('cpu_runtime',{}).get('topk_library') or os.environ.get('Y26_TOPK_LIBRARY')
        if library:
            from native_topk import NativeTopK
            self.native_topk=NativeTopK(library)
    def process(self,payload):
        values,value,dg,zg,width,height=payload;timing={};start=time.perf_counter()
        objects,weak=self.decode_detection(values,dg,timing)
        raw=canonical(value,'depth',self.depth_size//4)[0].squeeze()
        self.sample_depth(raw,objects,width,height,zg,timing)
        timing['cpu_postprocess_wall_ms']=(time.perf_counter()-start)*1000
        return objects,weak,timing
    def close(self):
        if self.native_topk is not None:self.native_topk.close()
        for s in self.samplers.values():s.close()
