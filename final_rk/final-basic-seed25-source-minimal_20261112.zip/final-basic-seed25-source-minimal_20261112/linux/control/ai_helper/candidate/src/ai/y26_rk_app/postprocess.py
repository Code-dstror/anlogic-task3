"""Current YOLO26 O2O two-stage TopK; no NMS, no COCO80 remapping."""
import numpy as np

def detections(boxes,scores,maximum=300,agnostic=False):
    boxes=np.asarray(boxes,dtype=np.float32);scores=np.asarray(scores,dtype=np.float32)
    if boxes.shape!=(1,4,8400) or scores.shape!=(1,23,8400):raise ValueError('Unexpected dense output layout')
    if not np.isfinite(boxes).all() or not np.isfinite(scores).all():raise ValueError('Nonfinite detection output')
    b=boxes[0].T;s=scores[0].T;k=min(maximum,len(b))
    anchors=np.argsort(-s.max(1),kind='stable')[:k]
    if agnostic:
        cls=s[anchors].argmax(1);values=s[anchors,cls]
        return np.column_stack([b[anchors],values,cls]).astype(np.float32)
    flat=s[anchors].reshape(-1);indices=np.argsort(-flat,kind='stable')[:k]
    chosen=anchors[indices//23]
    return np.column_stack([b[chosen],flat[indices],indices%23]).astype(np.float32)

def source_boxes(rows,g):
    rows=np.asarray(rows,dtype=np.float32).copy()
    rows[:,[0,2]]=(rows[:,[0,2]]-g['left'])/g['sx']
    rows[:,[1,3]]=(rows[:,[1,3]]-g['top'])/g['sy']
    rows[:,:4]=np.clip(rows[:,:4],[0,0,0,0],[g['width'],g['height'],g['width'],g['height']])
    return rows
