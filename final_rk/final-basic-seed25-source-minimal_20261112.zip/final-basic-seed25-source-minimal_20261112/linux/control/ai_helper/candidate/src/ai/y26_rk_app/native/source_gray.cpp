// Exact 1920x1080 BGR -> 640x360 AREA3 -> OpenCV uchar gray, no frame copy.
#include <cstdint>
#ifdef _WIN32
#define API extern "C" __declspec(dllexport)
#else
#define API extern "C"
#endif
API int y26_source_gray3(const uint8_t* src,uint8_t* dst,int width,int height){
 if(!src||!dst||width!=1920||height!=1080)return -1;
 const int stride=width*3;
 for(int y=0;y<height/3;y++){
  const uint8_t* row=src+y*3*stride;
  for(int x=0;x<width/3;x++){
   const uint8_t* a=row+x*9;unsigned b=0,g=0,r=0;
   for(int j=0;j<3;j++){
    const uint8_t* p=a+j*stride;
    b+=p[0]+p[3]+p[6];g+=p[1]+p[4]+p[7];r+=p[2]+p[5]+p[8];
   }
   b=(b+4)/9;g=(g+4)/9;r=(r+4)/9;
   dst[y*(width/3)+x]=static_cast<uint8_t>((b*3735+g*19235+r*9798+16384)>>15);
  }
 }
 return 0;
}
