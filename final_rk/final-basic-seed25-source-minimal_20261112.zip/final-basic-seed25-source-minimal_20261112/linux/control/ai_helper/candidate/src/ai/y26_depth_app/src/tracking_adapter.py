"""Class-aware ByteTrack adapter with explicit source time and gap resets."""
from types import SimpleNamespace
import numpy as np
from bytetrack_cpu.byte_tracker import BYTETracker
from warning_contracts import ObservedTarget
from cpu_profile import StageTimer
import os


class TrackingAdapter:
    def __init__(self,class_count,*,frame_rate,max_gap_ms=250,lost_ms=350,threshold=.25,new_track_threshold=None,score_fusion=True,exact_observation_association=True,optimize_cpu=False,optimize_removed_cpu=False,recover_lost_low=False,use_pts_step=False,lost_recovery_gate=False,gate_lost_high=False,recovery_age_ms=250,native_library=None):
        if class_count<1 or frame_rate<=0: raise ValueError('Invalid tracker profile')
        if not 0<threshold<1 or (new_track_threshold is not None and not threshold<=new_track_threshold<=1):
            raise ValueError('Invalid tracker confidence thresholds')
        self.class_count=class_count; self.fps=frame_rate; self.gap_ms=max_gap_ms
        self.lost_ms=lost_ms; self.threshold=threshold; self.last=None; self.trackers={}
        self.new_track_threshold=new_track_threshold
        self.score_fusion=score_fusion
        self.exact_observation_association=exact_observation_association
        self.current_observation_indices=None
        self.last_seen={}
        self.optimize_cpu=optimize_cpu
        self.last_diagnostics=None
        self.optimize_removed_cpu=optimize_removed_cpu
        self.recover_lost_low=recover_lost_low
        self.use_pts_step=use_pts_step
        self.lost_recovery_gate=lost_recovery_gate
        self.gate_lost_high=gate_lost_high
        if not np.isfinite(recovery_age_ms) or recovery_age_ms<=0:raise ValueError('Invalid candidate recovery age')
        self.recovery_age_ms=recovery_age_ms
        self.native_backend=None
        self.input_buffers={}
        if native_library:
            from native_tracking import NativeTracking
            self.native_backend=NativeTracking(native_library)

    def reset(self):
        self.current_observation_indices=None
        # In the upstream ByteTrack implementation mot20 gates score fusion
        # in both high-score and unconfirmed association; it changes no model.
        config=SimpleNamespace(track_thresh=self.threshold,track_buffer=max(1,round(self.lost_ms*.03)),match_thresh=.8,mot20=not self.score_fusion)
        config.optimize_removed_cpu=self.optimize_removed_cpu
        config.recover_lost_low=self.recover_lost_low
        config.lost_recovery_gate=self.lost_recovery_gate
        config.gate_lost_high=self.gate_lost_high
        config.native_backend=self.native_backend
        self.trackers={i:BYTETracker(config,frame_rate=self.fps) for i in range(self.class_count)}
        if self.new_track_threshold is not None:
            for tracker in self.trackers.values():tracker.det_thresh=self.new_track_threshold
        self.last_seen={}

    def update(self,stamp,detections,*,camera_motion=None,timings=None):
        timer=StageTimer(timings)
        f=stamp.identity
        for d in detections:
            ObservedTarget(d['frame_key'],0,d['class_id'],d['confidence'],tuple(d['bbox_source_xyxy'])).validate(f)
            if d['class_id']>=self.class_count: raise ValueError('Class absent from tracker profile')
        if self.last and f.context==self.last.identity.context and stamp.clock_domain==self.last.clock_domain:
            if f.sequence<=self.last.identity.sequence or stamp.timestamp_ns<=self.last.timestamp_ns:
                raise ValueError('Tracker refuses duplicate/out-of-order observation')
        reset=(not self.last or f.context!=self.last.identity.context or stamp.clock_domain!=self.last.clock_domain
               or (stamp.timestamp_ns-self.last.timestamp_ns)/1e6>self.gap_ms)
        motion=None
        if camera_motion is not None:
            if (camera_motion.frame_key!=f.key or camera_motion.timestamp_ns!=stamp.timestamp_ns
                    or camera_motion.clock_domain!=stamp.clock_domain):
                raise ValueError('Camera motion belongs to another frame or clock')
            if camera_motion.status=='VALID_BACKGROUND_SIMILARITY':
                if (reset or camera_motion.previous_frame_key!=self.last.identity.key
                        or camera_motion.previous_timestamp_ns!=self.last.timestamp_ns):
                    raise ValueError('Camera motion does not connect adjacent tracker observations')
                motion=np.asarray(camera_motion.matrix,float)
                if motion.shape!=(2,3) or not np.isfinite(motion).all():raise ValueError('Invalid camera motion')
        if reset: self.reset()
        prediction_dt=1.
        if self.use_pts_step and not reset:
            prediction_dt=(stamp.timestamp_ns-self.last.timestamp_ns)/1e9*self.fps
            if abs(prediction_dt-1.)<1e-6:prediction_dt=1.
        recovery_allowed_ids=({tid for tid,ns in self.last_seen.items()
            if 0<(stamp.timestamp_ns-ns)/1e6<=min(self.recovery_age_ms,self.lost_ms)} if self.lost_recovery_gate or self.gate_lost_high else None)
        timer.mark('tracker_validation_and_reset')
        diagnostics=dict(reset=reset,elapsed_expired=[],frame_removed=[],lost_ids=[],pending_ids=[]) if timings is not None else None
        # Enforce elapsed-time expiry before a stale track can be associated again.
        for tracker in self.trackers.values():
            for name in ('tracked_stracks','lost_stracks'):
                if diagnostics is not None:
                    diagnostics['elapsed_expired'].extend(t.track_id for t in getattr(tracker,name) if
                        (stamp.timestamp_ns-self.last_seen.get(t.track_id,stamp.timestamp_ns))/1e6>self.lost_ms)
                setattr(tracker,name,[t for t in getattr(tracker,name) if
                    (stamp.timestamp_ns-self.last_seen.get(t.track_id,stamp.timestamp_ns))/1e6<=self.lost_ms])
        result=[]
        indices={}
        grouped=None
        if self.optimize_cpu:
            grouped=[[] for _ in range(self.class_count)]
            for i,d in enumerate(detections):grouped[d['class_id']].append((i,d))
        timer.mark('tracker_elapsed_expiry')
        for cid,tracker in self.trackers.items():
            selected=grouped[cid] if grouped is not None else [(i,d) for i,d in enumerate(detections) if d['class_id']==cid]
            if self.optimize_cpu and not selected and not tracker.tracked_stracks and not tracker.lost_stracks:
                # Empty update has no state work, but its clock must still advance:
                # a class first seen later must not receive first-frame activation.
                tracker.frame_id+=1
                continue
            if os.environ.get('Y26_TRACKING_INPUT_POOL')=='1':
                n=len(selected)
                if cid not in self.input_buffers or len(self.input_buffers[cid][0])<n:
                    cap=max(16,1<<(max(1,n)-1).bit_length())
                    self.input_buffers[cid]=(np.empty((cap,5),np.float64),np.empty(cap,np.int64))
                values,source_ids=self.input_buffers[cid];values=values[:n];source_ids=source_ids[:n]
                for j,(index,d) in enumerate(selected):
                    values[j,:4]=d['bbox_source_xyxy'];values[j,4]=d['confidence'];source_ids[j]=index
            else:
                values=np.asarray([list(d['bbox_source_xyxy'])+[d['confidence']] for _,d in selected],dtype=float).reshape(-1,5)
                source_ids=np.asarray([i for i,_ in selected],dtype=int)
            prior_removed=len(tracker.removed_stracks)
            timer.mark('tracker_input_grouping')
            tracks=tracker.update(values,(f.height,f.width),(f.height,f.width),camera_motion=motion,
                    source_indices=source_ids,timings=timings,
                    prediction_dt=prediction_dt,recovery_allowed_ids=recovery_allowed_ids)
            batch_boxes=self.native_backend.boxes(tracks,f.width,f.height) if self.native_backend is not None else None
            for track_index,track in enumerate(tracks):
                b=(batch_boxes[track_index] if batch_boxes is not None else np.clip(track.tlbr,[0,0,0,0],[f.width,f.height,f.width,f.height])).tolist()
                if b[0]>=b[2] or b[1]>=b[3]: continue
                self.last_seen[track.track_id]=stamp.timestamp_ns
                result.append(ObservedTarget(f.key,int(track.track_id),cid,float(track.score),tuple(b)))
                indices[int(track.track_id)]=track.detection_index
            timer.mark('tracker_update_and_output')
            if diagnostics is not None:
                diagnostics['frame_removed'].extend(t.track_id for t in tracker.removed_stracks[prior_removed:])
                diagnostics['lost_ids'].extend(t.track_id for t in tracker.lost_stracks)
                diagnostics['pending_ids'].extend(t.track_id for t in tracker.tracked_stracks if not t.is_activated)
            timer.mark('tracker_diagnostics')
        live={t.track_id for tracker in self.trackers.values()
              for t in tracker.tracked_stracks+tracker.lost_stracks}
        self.last_seen={tid:t for tid,t in self.last_seen.items() if tid in live}
        self.last=stamp
        self.current_observation_indices=indices if self.exact_observation_association else None
        self.last_diagnostics=diagnostics
        timer.mark('tracker_adapter_cleanup')
        return result
