"""Owned BGR/RGB/model-input storage with one explicit replay-frame lease."""
import numpy as np
import cv2
import time
import os
from frame_pixels import FramePixels
from cpu_profile import StageTimer


class ReplayPixels:
    def __init__(self,depth_size,eager_gmc=False,gmc_width=640,gmc_input='area'):
        self.bgr=np.empty((1080,1920,3),np.uint8)
        self.rgb=np.empty_like(self.bgr)
        self.det=np.empty((640,640,3),np.uint8)
        self.depth=np.empty((depth_size,depth_size,3),np.uint8)
        self.active=False;self.generation=0;self.binding=None
        self.eager_gmc=eager_gmc
        if gmc_input not in ('area','detector'):raise ValueError('Unknown GMC input profile')
        if gmc_input=='detector' and gmc_width!=640:raise ValueError('Detector GMC requires640x360 content')
        self.gmc_input=gmc_input
        self.small=np.empty((round(1080*gmc_width/1920),gmc_width,3),np.uint8) if eager_gmc else None
        self.gray=np.empty(self.small.shape[:2],np.uint8) if eager_gmc else None
        self.native_gray=None
        native=os.environ.get('Y26_SOURCE_GRAY_LIBRARY')
        if native:
            if not eager_gmc or gmc_width!=640 or gmc_input!='area':raise ValueError('Native gray requires unchanged640 AREA GMC')
            from native_source_gray import NativeSourceGray
            self.native_gray=NativeSourceGray(native)

    def begin(self):
        if self.active:raise RuntimeError('Native frame slot still leased')
        self.generation+=1;self.active=True;self.binding=None
        if self.gray is not None:self.gray.setflags(write=True)
        for a in (self.bgr,self.rgb,self.det,self.depth):a.setflags(write=True)

    def publish(self,timings=None):
        if not self.active:raise RuntimeError('No active native write lease')
        timer=StageTimer(timings)
        for a in (self.bgr,self.rgb,self.det,self.depth):a.setflags(write=False)
        generation=self.generation
        self.binding=FramePixels._from_native_replay(self.bgr,self.rgb,
            lambda:self.active and self.generation==generation)
        timer.mark('publish_lease_ms')
        if self.eager_gmc:
            if self.native_gray is not None:
                self.native_gray.prepare(self.bgr,self.gray)
                timer.mark('gmc_source_fused_area3_gray_ms')
            elif self.gmc_input=='area':
                # Baseline pixels remain resize-then-gray, INTER_AREA.
                cv2.resize(self.bgr,(self.small.shape[1],self.small.shape[0]),dst=self.small,interpolation=cv2.INTER_AREA)
                small=self.small;code=cv2.COLOR_BGR2GRAY
            else:
                # Opt-in algorithm change: reuse actual RGB detector content.
                # This is INTER_LINEAR on the current RGA route, not AREA.
                small=self.det[140:500];code=cv2.COLOR_RGB2GRAY
            if self.native_gray is None:
                timer.mark('gmc_source_resize_ms')
                cv2.cvtColor(small,code,dst=self.gray)
                timer.mark('gmc_source_gray_ms')
            self.gray.setflags(write=False);self.binding._gmc_gray=self.gray
            self.binding.rgb_sha256
            timer.mark('source_rgb_sha256_ms')

    def close(self):
        self.active=False

    def __enter__(self):
        if not self.active or self.binding is None:raise RuntimeError('Unpublished native frame')
        return self.binding

    def __exit__(self,*args):self.close()
