#!/usr/bin/env bash
# Compile only, no inference/test/queue launch. Run on the existing RK toolchain.
set -euo pipefail
src_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
out_dir="${1:?pass board_libs directory}"
mkdir -p -- "$out_dir"
dest="$out_dir/liby26_mpp_replay_rgb2.so"
temp="$dest.building.$$"
trap 'rm -f -- "$temp"' EXIT
read -r -a gst_flags <<< "$(pkg-config --cflags --libs gstreamer-app-1.0 gstreamer-video-1.0)"
g++ -O3 -std=c++17 -fPIC -shared -fno-fast-math -ffp-contract=off \
  -I/usr/include/rga "$src_dir/native/mpp_replay.cpp" -o "$temp" "${gst_flags[@]}" -lrga
mv -f -- "$temp" "$dest"
printf 'Built shared-RGB ABI2 candidate: %s\nNo inference or board test started.\n' "$dest"
