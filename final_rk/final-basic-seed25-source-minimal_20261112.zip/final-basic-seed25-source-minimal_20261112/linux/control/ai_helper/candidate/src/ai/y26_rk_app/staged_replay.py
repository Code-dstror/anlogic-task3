"""Three ordered stages, bounded owned pixel slots (default two); no cached inference.

Decoder/RGA, network and state each have one owner. CPU releases a pixel lease
only after its last use. SDK completion precedes all slot/context destruction.
"""
import queue,threading,time,os
from replay_video import NativeReplay
from ordered_pipeline import Packet,FrameKey
from model_preprocessing import geometry as det_geometry
from depth_preprocessing import geometry as dep_geometry
from networks import Networks,CpuPostprocessor
from replay_pixels import ReplayPixels
from cpu_profile import configure_timing,clock_snapshot,record_interval

class Lease:
    def __init__(self,pipeline,slot,packet):self.pipeline=pipeline;self.slot=slot;self.packet=packet;self.closed=False
    def __enter__(self):return self.packet
    def close(self):
        if not self.closed:self.closed=True;self.pipeline.free.put_nowait(self.slot);self.pipeline.active=None
    def __exit__(self,*args):self.close()

class StagedReplay:
    def __init__(self,args,config):
        self.args=args;self.config=config;self.stop=threading.Event();self.net_ready=threading.Event();self.error=None
        self.capacity=args.slots
        self.free=queue.Queue(self.capacity)
        for slot in range(self.capacity):self.free.put(slot)
        self.prepared=queue.Queue(self.capacity);self.done=queue.Queue(1)
        self.split_post=os.environ.get('Y26_SPLIT_POSTPROCESS')=='1'
        self.raw_done=queue.Queue(1)
        self.active=None;self.max_inflight=0;self.slot_wait_ms=0.;self.threads=[];self.queue_profile={}
    def get(self,q):
        while not self.stop.is_set():
            try:return q.get(timeout=.05)
            except queue.Empty:pass
        return None
    def put(self,q,item):
        while not self.stop.is_set():
            try:q.put(item,timeout=.05);return True
            except queue.Full:pass
        return False
    def fail(self,e):self.error=e;self.stop.set();self.net_ready.set()
    def decode(self):
        reader=None;pool={};epoch=0;sequence=0;last_pts=None
        try:
            configure_timing(self.args.clock_detail)
            self.net_ready.wait()
            if self.stop.is_set():return
            reader=NativeReplay(self.args)
            while not self.stop.is_set():
                wait=clock_snapshot() if self.args.clock_detail else None
                t=time.perf_counter();slot=self.get(self.free);self.slot_wait_ms+=(time.perf_counter()-t)*1000
                waited=clock_snapshot() if wait is not None else None
                if slot is None:break
                self.max_inflight=max(self.max_inflight,self.capacity-self.free.qsize());begin=time.monotonic_ns()
                if slot not in pool:pool[slot]=ReplayPixels(self.args.depth_size,
                    eager_gmc=os.environ.get('Y26_REPLAY_EAGER_GMC')=='1',gmc_width=self.config['cpu_runtime'].get('gmc_width',640),gmc_input=os.environ.get('Y26_GMC_INPUT','area'))
                pixels=pool[slot];bgr,det,depth=pixels.bgr,pixels.det,pixels.depth
                rc,pts,tm,metadata=reader.read(pixels)
                if rc==1:
                    if reader.lib.y26_replay_rewind(reader.handle):reader.close();reader.open()
                    epoch+=1;sequence=0;last_pts=None;rc,pts,tm,metadata=reader.read(pixels)
                    if rc:raise RuntimeError('Empty MPP replay')
                if last_pts is not None and pts<=last_pts:raise RuntimeError('MPP PTS reordered')
                last_pts=pts
                if wait is not None:record_interval(tm,'decoder_free_slot_block',wait,waited)
                key=FrameKey(('MPP_RECORDED_VIDEO',epoch,'front'),sequence,int(pts));sequence+=1
                item=dict(bgr=bgr,det=det,depth=depth,pixel_slot=pixels,pixel_binding=pixels.binding,stages=tm,metadata=metadata,admitted_ns=begin,prepared_ns=time.monotonic_ns())
                if not self.put(self.prepared,(slot,Packet(key,item))):break
        except BaseException as e:self.fail(e)
        finally:
            if reader is not None:reader.close()
    def infer(self):
        net=None;original_affinity=None
        try:
            a=self.args
            configure_timing(a.clock_detail)
            request=os.environ.get('Y26_NETWORK_OWNER_CPUS')
            if request:
                if not hasattr(os,'sched_getaffinity'):raise RuntimeError('CPU affinity requires Linux')
                wanted={int(v) for v in request.split(',')}
                original_affinity=os.sched_getaffinity(0)
                if not wanted or not wanted<=original_affinity:raise ValueError('Network CPU affinity outside allowed set')
                # Linux pid=0 changes this native thread only. Its subsequently
                # created NPU workers inherit the mask; decode/state remain all.
                os.sched_setaffinity(0,wanted)
            self.network_owner_placement=dict(tid=threading.get_native_id(),request=request,
                actual=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None)
            net=Networks(a.detector,a.depth,a.route,a.library,a.roi_library,self.config,input_mode='bound-fp16',depth_size=a.depth_size,execution=a.execution,core_mask=3)
            net.warmup(20);self.net_ready.set()
            dg=det_geometry(1920,1080);zg=dep_geometry(1920,1080,a.depth_size,'letterbox' if a.route=='official' else 'stretch')
            while not self.stop.is_set():
                wait=clock_snapshot() if a.clock_detail else None
                item=self.get(self.prepared)
                if item is None:break
                slot,packet=item;q=packet.value;begin=time.monotonic_ns()
                if wait is not None:record_interval(q['stages'],'network_input_queue_block',wait)
                if self.split_post:
                    payload,tm=net.execute_prepared_owned(q['det'],q['depth'],1920,1080,dg,zg)
                else:objects,weak,tm=net.infer_prepared(q['det'],q['depth'],1920,1080,dg,zg)
                q['stages'].update(tm);q['stages']['prepared_queue_wait']=(begin-q['prepared_ns'])/1e6
                if self.split_post:q.update(raw_outputs=payload,post_queued_ns=time.monotonic_ns())
                else:q.update(objects=objects,weak=weak,ready_ns=time.monotonic_ns())
                wait=clock_snapshot() if a.clock_detail else None
                if not self.put(self.raw_done if self.split_post else self.done,(slot,packet)):break
                # Do not mutate a packet after publication to another thread.
                # Output backpressure remains an aggregate, measured below.
                if wait is not None:
                    m={};record_interval(m,'network_output_queue_block',wait)
                    for k,v in m.items():self.queue_profile[k]=self.queue_profile.get(k,0.)+v
        except BaseException as e:self.fail(e)
        finally:
            try:
                if net is not None:net.close()
            finally:
                if original_affinity is not None:os.sched_setaffinity(0,original_affinity)
                self.net_ready.set()
    def postprocess(self):
        post=None
        try:
            configure_timing(self.args.clock_detail)
            post=CpuPostprocessor(self.config,self.args.roi_library,self.args.depth_size)
            while not self.stop.is_set():
                item=self.get(self.raw_done)
                if item is None:break
                slot,packet=item;q=packet.value
                q['stages']['cpu_post_queue_wait_ms']=(time.monotonic_ns()-q['post_queued_ns'])/1e6
                objects,weak,tm=post.process(q.pop('raw_outputs'))
                q['stages'].update(tm);q.update(objects=objects,weak=weak,ready_ns=time.monotonic_ns())
                if not self.put(self.done,(slot,packet)):break
        except BaseException as e:self.fail(e)
        finally:
            if post is not None:post.close()
    def __enter__(self):
        workers=[('MPP-RGA-owner',self.decode),('network-owner',self.infer)]
        if self.split_post:workers.append(('CPU-post-owner',self.postprocess))
        for name,fn in workers:
            t=threading.Thread(target=fn,name=name,daemon=True);self.threads.append(t);t.start()
        return self
    def __iter__(self):return self
    def __next__(self):
        if self.active is not None:raise RuntimeError('Release current pixel slot first')
        while True:
            if self.error is not None:raise self.error
            wait=clock_snapshot() if self.args.clock_detail else None
            item=self.get(self.done)
            if item is None:raise StopIteration
            slot,packet=item
            if wait is not None:record_interval(packet.value['stages'],'consumer_input_queue_block',wait)
            self.active=Lease(self,slot,packet);return self.active
    def close(self):
        self.stop.set();self.net_ready.set()
        if self.active is not None:self.active.close()
        for t in self.threads:t.join(20)
        if any(t.is_alive() for t in self.threads):raise RuntimeError('Native worker still active; buffers were not force-freed')
    def __exit__(self,*args):self.close()
