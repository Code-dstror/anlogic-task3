"""Single-owner organisation-only helpers; original kernels remain authoritative."""
import ctypes as C
import numpy as np

class ObjectPack:
    def __init__(self,path,original):
        self.lib=C.PyDLL(str(path));p=C.c_void_p;l=self.lib
        l.y26_pack_open.restype=p;l.y26_pack_close.argtypes=[p]
        l.y26_predict_objects.argtypes=[p,C.py_object,C.c_int,C.c_int,C.c_double,p,p,C.c_char_p,C.c_int]
        l.y26_predict_objects.restype=C.c_int
        l.y26_cost_objects.argtypes=[p,C.py_object,C.py_object,C.c_int,p,p,p,C.c_char_p,C.c_int]
        l.y26_cost_objects.restype=C.c_int
        self.handle=l.y26_pack_open()
        if not self.handle:raise RuntimeError('Object pack allocation failed')
        self.predict_function=C.cast(original.y26_predict_warp,p)
        self.cost_function=C.cast(original.y26_state_cost,p)
        self.message=C.create_string_buffer(256)
    def predict(self,tracks,predicted,tracked_state,dt,motion):
        h=None if motion is None else np.ascontiguousarray(motion,dtype=np.float64)
        if h is not None and h.shape!=(2,3):raise ValueError('Invalid warp shape')
        rc=self.lib.y26_predict_objects(self.handle,tracks,predicted,tracked_state,dt,None if h is None else h.ctypes.data,self.predict_function,self.message,len(self.message))
        if rc==-2:return False  # Read-only/unusual state uses the original owned-copy path.
        if rc:raise ValueError(self.message.value.decode())
        return True
    def cost(self,tracks,detections,fuse,cost_handle,out):
        rc=self.lib.y26_cost_objects(self.handle,tracks,detections,int(fuse),cost_handle,self.cost_function,out.ctypes.data,self.message,len(self.message))
        if rc:raise ValueError(self.message.value.decode())
        return out
    def close(self):
        if getattr(self,'handle',None):self.lib.y26_pack_close(self.handle);self.handle=None
    def __del__(self):self.close()

class GmcPack:
    def __init__(self,path):
        self.lib=C.CDLL(str(path));p=C.c_void_p;l=self.lib
        l.y26_gmc_mask.argtypes=[p,C.c_int,C.c_int,C.c_int,C.c_int,C.c_int,p];l.y26_gmc_mask.restype=C.c_int
        l.y26_gmc_indices.argtypes=[p,p,p,p,p,p,C.c_int,p,C.c_int,C.c_int,p];l.y26_gmc_indices.restype=C.c_int
        self.capacity=0
    def mask(self,boxes,w,h,source_w,source_h,out):
        boxes=np.ascontiguousarray(boxes,dtype=np.float64).reshape(-1,4)
        rc=self.lib.y26_gmc_mask(boxes.ctypes.data,len(boxes),w,h,source_w,source_h,out.ctypes.data)
        if rc:raise ValueError('Nonfinite/invalid GMC exclusion box or mask')
    def indices(self,a,b,back,ok,backok,error,mask):
        n=len(a)
        if n>self.capacity:self.capacity=max(512,n);self.scratch=np.empty(self.capacity,np.int32)
        # Existing native LK already returns packed float32/uint8 arrays.
        arrays=[a,b,back,ok,backok,error]
        if any(not x.flags.c_contiguous for x in arrays):raise ValueError('GMC buffers must be packed')
        count=self.lib.y26_gmc_indices(*(x.ctypes.data for x in arrays),n,mask.ctypes.data,mask.shape[1],mask.shape[0],self.scratch.ctypes.data)
        if count<0:raise ValueError('GMC correspondence filter failed')
        return self.scratch[:count]
