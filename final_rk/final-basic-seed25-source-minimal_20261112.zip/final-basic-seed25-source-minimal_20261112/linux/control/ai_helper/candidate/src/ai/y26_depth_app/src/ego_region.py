"""Camera-bound ego output filter and road-region exclusion.

The polygon is a reviewed visible-body area, not a detector-derived boundary.
Only a narrow reviewed car signature is suppressed; partial overlaps stay.
"""
from hashlib import sha256
import json
import cv2
import numpy as np
from warning_contracts import RegionContact


class EgoGeometry:
    def __init__(self, camera, rule):
        self.camera = camera
        self.rule = rule
        self.digest = sha256(json.dumps([camera, rule], sort_keys=True).encode()).hexdigest()
        self.mask = np.zeros((camera['height'], camera['width']), np.uint8)
        polygon = camera['ego_polygon']
        if (polygon and camera.get('ego_mask_enabled') is True
                and camera.get('ego_polygon_confirmed') is True):
            points = np.rint(np.array(polygon) * [camera['width']-1, camera['height']-1]).astype(np.int32)
            cv2.fillPoly(self.mask, [points], 1)
        self.mask = self.mask.astype(bool)

    def validate(self, frame):
        if (frame.width, frame.height, frame.geometry) != (self.camera['width'], self.camera['height'], self.camera['view_id']):
            raise ValueError('Ego geometry belongs to another camera/view')

    def split(self, frame, objects, car_class_id):
        self.validate(frame)
        kept, excluded = [], []
        for obj in objects:
            x1, y1, x2, y2 = obj['xyxy']
            a, b = max(0,int(np.floor(x1))), max(0,int(np.floor(y1)))
            c, d = min(frame.width,int(np.ceil(x2))), min(frame.height,int(np.ceil(y2)))
            if not a<c or not b<d:
                raise ValueError('Invalid cached source box')
            overlap = float(self.mask[b:d,a:c].mean())
            r = self.rule
            is_ego = (obj['class_id'] == car_class_id and (x2-x1)/frame.width >= r['minimum_width']
                      and y1/frame.height >= r['minimum_top'] and y2/frame.height >= r['minimum_bottom']
                      and overlap >= r['minimum_overlap'])
            if is_ego:
                excluded.append(dict(obj, exclusion='REVIEWED_DEVELOPMENT_EGO_SIGNATURE',
                                     ego_overlap=overlap, ego_config_id=self.digest))
            else:
                kept.append(obj)
        return kept, excluded

    def contact_unknown_reason(self, frame, bbox):
        self.validate(frame)
        x = min(frame.width-1, int((bbox[0]+bbox[2])/2))
        y = min(frame.height-1, int(np.floor(bbox[3])))
        if self.mask[y,x]:
            return 'UNKNOWN_CONTACT_IN_SELF_OCCLUDED_IMAGE_AREA'
        if bbox[3] > frame.height*self.camera['near_y']:
            return 'UNKNOWN_BELOW_REVIEWED_NEAR_BOUNDARY'
        return None


class ExcludedRegion:
    def __init__(self, base, ego, groups):
        self.base, self.ego, self.groups = base, ego, groups
        self.region_id = base.region_id+':ego:'+ego.digest[:16]

    def evaluate(self, frame, target):
        target.validate(frame)
        reason = self.ego.contact_unknown_reason(frame, target.bbox_source_xyxy)
        if self.groups.get(str(target.class_id)) is None:
            reason = 'UNKNOWN_CLASS_NOT_ASSIGNED_TO_WARNING_EVENT'
        if reason:
            return RegionContact(target,None,None,self.region_id,'ROAD_MINUS_VISIBLE_EGO',reason)
        contact = self.base.evaluate(frame,target)
        return RegionContact(target,contact.inside_entry,contact.inside_retention,self.region_id,
                             contact.evidence_source+'_MINUS_EGO',contact.quality)


class SemanticRegion:
    def __init__(self, base, groups):
        self.base, self.groups, self.region_id = base, groups, base.region_id

    def evaluate(self, frame, target):
        if self.groups.get(str(target.class_id)) is None:
            return RegionContact(target,None,None,self.region_id,'CLASS_POLICY','UNKNOWN_NON_ALERT_CLASS')
        return self.base.evaluate(frame,target)
