"""Opt-in two-stage handoff; one producer owner and one ordered state owner.

Producer factory/read/close run on one worker. read(slot_id) must finish native
work and transfer owned outputs in that slot, never reusable native views.
The consumer releases a lease only after its last pixel/output/state use.
No model, decoder, affinity, OpenCV setting or default application is selected.
"""
from dataclasses import dataclass
import queue
import threading
import time


@dataclass(frozen=True)
class FrameKey:
    context: tuple
    sequence: int
    timestamp_ns: int

    def validate(self):
        if not isinstance(self.context,tuple) or not self.context:
            raise ValueError('Explicit frame/camera/clock context required')
        hash(self.context)
        if type(self.sequence) is not int or self.sequence<0 or type(self.timestamp_ns) is not int or self.timestamp_ns<0:
            raise ValueError('Nonnegative integer source sequence and timestamp required')


@dataclass(frozen=True)
class Packet:
    key: FrameKey
    value: object


class _Lease:
    def __init__(self,pipeline,slot,packet):
        self._pipeline=pipeline;self._slot=slot;self._packet=packet;self.closed=False

    @property
    def packet(self):
        if self.closed:raise RuntimeError('Frame lease already released')
        return self._packet

    def close(self):
        self._pipeline._consumer()
        if not self.closed:
            self.closed=True;self._packet=None
            self._pipeline._available.put_nowait(self._slot)
            self._pipeline._active=None

    def __enter__(self):return self.packet
    def __exit__(self,*args):self.close()


class OrderedPipeline:
    def __init__(self,producer_factory,*,capacity=2,shutdown_timeout_s=5):
        if type(capacity) is not int or not 1<=capacity<=2:raise ValueError('One or two in-flight slots required')
        self._factory=producer_factory;self._pending=queue.Queue(maxsize=1)
        self._available=queue.Queue(maxsize=capacity)
        for slot in range(capacity):self._available.put_nowait(slot)
        self._stop=threading.Event();self._active=None;self._thread=None;self._owner=None;self._finished=False
        self._last={};self._next=0;self._timeout=shutdown_timeout_s;self.producer_thread_id=None
        self.slot_wait_ms=0.;self.max_inflight=0;self._capacity=capacity
        self._worker_error=None;self._cleanup_errors=[];self._producer_closed=False
        self._error_delivered=False;self._close_attempts=0;self._retained_producer=None

    def _consumer(self):
        if threading.get_ident()!=self._owner:raise RuntimeError('State/lease access belongs to one consumer thread')

    def _send(self,item):
        while not self._stop.is_set():
            try:self._pending.put(item,timeout=.05);return True
            except queue.Full:pass
        return False

    def _run(self):
        self.producer_thread_id=threading.get_ident();producer=None;slot=None;error=None;ordinal=0
        try:
            producer=self._factory();self._retained_producer=producer
            while not self._stop.is_set():
                start=time.perf_counter()
                try:slot=self._available.get(timeout=.05)
                except queue.Empty:
                    self.slot_wait_ms+=(time.perf_counter()-start)*1000
                    continue
                self.slot_wait_ms+=(time.perf_counter()-start)*1000
                if self._stop.is_set():break
                self.max_inflight=max(self.max_inflight,self._capacity-self._available.qsize())
                packet=producer.read(slot)
                if packet is None:break
                if not isinstance(packet,Packet):raise TypeError('Producer must return Packet or EOF None')
                packet.key.validate()
                if not self._send(('frame',(ordinal,slot,packet))):break
                slot=None;ordinal+=1
        except BaseException as e:
            error=e;self._worker_error=e
            self._retained_producer=producer or getattr(e,'y26_resource_owner',None)
            self._cleanup_errors.extend(getattr(e,'y26_cleanup_errors',[]))
        finally:
            if slot is not None:self._available.put_nowait(slot)
            if producer is not None:
                try:
                    producer.close();self._producer_closed=True
                except BaseException as e:
                    self._cleanup_errors.append(e)
                    if error is None:error=e
            else:
                # A factory failure may retain partially constructed native owners.
                self._producer_closed=not bool(getattr(error,'y26_resources_pending',False))
            if self._producer_closed:self._retained_producer=None
            self._send(('error',error) if error is not None else ('end',None))

    def __enter__(self):
        if self._thread is not None:raise RuntimeError('Pipeline cannot be restarted')
        self._owner=threading.get_ident()
        self._thread=threading.Thread(target=self._run,name='ordered-inference-owner',daemon=False)
        self._thread.start();return self

    def __iter__(self):return self

    def __next__(self):
        self._consumer()
        if self._finished:raise StopIteration
        if self._active is not None:raise RuntimeError('Release current frame before requesting the next')
        tag,value=self._pending.get()
        if tag=='end':self._finished=True;raise StopIteration
        if tag=='error':
            self._finished=True;self._error_delivered=True;raise value
        ordinal,slot,packet=value
        self._active=_Lease(self,slot,packet)
        if ordinal!=self._next:raise RuntimeError('Out-of-order stage completion')
        previous=self._last.get(packet.key.context)
        if previous is not None and (packet.key.sequence<=previous.sequence or packet.key.timestamp_ns<=previous.timestamp_ns):
            raise ValueError('Duplicate/reordered source frame or PTS')
        self._last[packet.key.context]=packet.key;self._next+=1
        return self._active

    def shutdown_report(self):
        alive=self._thread is not None and self._thread.is_alive()
        safe=not alive and self._producer_closed and not self._cleanup_errors
        return dict(state='CLOSED' if safe else 'PENDING',safe_to_release=safe,
            worker_alive=alive,producer_closed=self._producer_closed,close_attempts=self._close_attempts,
            worker_error=None if self._worker_error is None else repr(self._worker_error),
            cleanup_errors=[repr(e) for e in self._cleanup_errors])

    def close(self):
        self._consumer();self._close_attempts+=1;self._stop.set();self._finished=True
        if self._active is not None:self._active.close()
        if self._thread is not None:self._thread.join(self._timeout)
        if self._thread is not None and self._thread.is_alive():
            raise RuntimeError('Producer/native operation did not finish; resources remain PENDING')
        while True:
            try:tag,value=self._pending.get_nowait()
            except queue.Empty:break
            if tag=='frame':self._available.put_nowait(value[1])
        if not self.shutdown_report()['safe_to_release']:
            raise RuntimeError('Producer cleanup incomplete; resources remain PENDING')
        if self._worker_error is not None and not self._error_delivered:
            self._error_delivered=True
            raise self._worker_error

    def __exit__(self,*args):self.close()
