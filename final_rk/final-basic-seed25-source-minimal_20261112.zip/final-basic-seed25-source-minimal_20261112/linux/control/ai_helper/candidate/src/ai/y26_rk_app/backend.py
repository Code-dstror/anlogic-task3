"""Torch-free board backend. Reuses RKNN contexts and preallocated float outputs.

Native I/O conversion/copy, run, outputs_get and hardware run are separated.
Borrowed outputs expire on this engine's next run; queued results must be owned.
"""
import ctypes as ct
from pathlib import Path
import time
import os
import numpy as np

class Times(ct.Structure):_fields_=[(n,ct.c_double) for n in ('inputs_ms','run_ms','outputs_ms','hardware_run_ms')]

class Engine:
    def __init__(self,model,library,init_flags=0,core_mask=None):
        self.lib=ct.CDLL(str(library));l=self.lib
        l.y26_open.argtypes=[ct.c_char_p];l.y26_open.restype=ct.c_void_p
        l.y26_output_count.argtypes=[ct.c_void_p];l.y26_output_count.restype=ct.c_int
        l.y26_output_info.argtypes=[ct.c_void_p,ct.c_int,ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_float),ct.POINTER(ct.c_int)];l.y26_output_info.restype=ct.c_int
        l.y26_output_data.argtypes=[ct.c_void_p,ct.c_int];l.y26_output_data.restype=ct.POINTER(ct.c_float)
        l.y26_input_info.argtypes=[ct.c_void_p,ct.c_int,ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_int),ct.POINTER(ct.c_int)]
        l.y26_run.argtypes=[ct.c_void_p,ct.POINTER(ct.c_ubyte),ct.c_uint,ct.POINTER(Times)];l.y26_run.restype=ct.c_int
        l.y26_close.argtypes=[ct.c_void_p];l.y26_versions.argtypes=[ct.c_void_p,ct.c_char_p,ct.c_int]
        l.y26_tensor_metadata.argtypes=[ct.c_void_p,ct.c_int,ct.c_int,ct.c_int,ct.c_char_p,ct.c_int,ct.POINTER(ct.c_uint),ct.POINTER(ct.c_uint)]
        path=str(Path(model).resolve()).encode()
        if init_flags:
            l.y26_open_flags.argtypes=[ct.c_char_p,ct.c_uint];l.y26_open_flags.restype=ct.c_void_p
            self.ctx=l.y26_open_flags(path,init_flags)
        else:self.ctx=l.y26_open(path)
        self.views=[];self.attributes=[]
        if not self.ctx:raise RuntimeError('RKNN initialization failed; no CPU fallback')
        try:
            if hasattr(l,'y26_host_output_type'):
                l.y26_host_output_type.argtypes=[ct.c_void_p];l.y26_host_output_type.restype=ct.c_int
                host_bits=l.y26_host_output_type(self.ctx)
            else:host_bits=32
            if os.environ.get('Y26_LOGICAL_FP16_OUTPUT')=='1' and host_bits!=16:raise RuntimeError('FP16 output requires rebuilt bridge')
            if host_bits==16:
                l.y26_output_data16.argtypes=[ct.c_void_p,ct.c_int];l.y26_output_data16.restype=ct.POINTER(ct.c_uint16)
            if core_mask is not None:
                l.y26_core_mask.argtypes=[ct.c_void_p,ct.c_uint];l.y26_core_mask.restype=ct.c_int
                rc=l.y26_core_mask(self.ctx,core_mask)
                if rc:raise RuntimeError('Requested NPU core mask rejected: '+str(core_mask)+' rc='+str(rc))
            for i in range(l.y26_output_count(self.ctx)):
                dims=(ct.c_int*16)();rank=ct.c_int();fmt=ct.c_int();typ=ct.c_int();scale=ct.c_float();zp=ct.c_int()
                count=l.y26_output_info(self.ctx,i,dims,ct.byref(rank),ct.byref(fmt),ct.byref(typ),ct.byref(scale),ct.byref(zp))
                if count<=0:raise ValueError('Invalid RKNN output attributes')
                shape=tuple(dims[:rank.value])
                data=l.y26_output_data16(self.ctx,i) if host_bits==16 else l.y26_output_data(self.ctx,i)
                view=np.ctypeslib.as_array(data,shape=(count,))
                if host_bits==16:view=view.view(np.float16)
                self.views.append(view.reshape(shape))
                self.attributes.append(dict(index=i,shape=list(shape),format=fmt.value,native_type=typ.value,scale=scale.value,zp=zp.value,host_output='preallocated logical float16 want_float=0' if host_bits==16 else 'preallocated float32 want_float=1'))
            self.input_attributes=[]
            for native in (0,1):
                dims=(ct.c_int*16)();rank=ct.c_int();fmt=ct.c_int();typ=ct.c_int();size=ct.c_int();stride=ct.c_int()
                ret=l.y26_input_info(self.ctx,native,dims,ct.byref(rank),ct.byref(fmt),ct.byref(typ),ct.byref(size),ct.byref(stride))
                self.input_attributes.append(dict(native=bool(native),query_status=ret,shape=list(dims[:rank.value]),format=fmt.value,type=typ.value,size_with_stride=size.value,w_stride=stride.value))
            version=ct.create_string_buffer(512);ret=l.y26_versions(self.ctx,version,512);self.versions=version.value.decode() if not ret else 'QUERY_FAILED'
            self.tensor_metadata=[]
            for output in (0,1):
                for native in (0,1):
                    for index in range(l.y26_output_count(self.ctx) if output else 1):
                        name=ct.create_string_buffer(512);dims=(ct.c_uint*16)();values=(ct.c_uint*8)()
                        rc=l.y26_tensor_metadata(self.ctx,output,native,index,name,512,dims,values)
                        self.tensor_metadata.append(dict(output=bool(output),native=bool(native),index=index,query_status=rc,name=name.value.decode(errors='replace') if not rc else None,shape=list(dims[:values[0]]) if not rc else None,attributes=dict(zip(['rank','n_elems','size','format','type','quantization_type','w_stride','size_with_stride'],values)) if not rc else None))
        except BaseException:self.close();raise
    def infer(self,rgb,owned=False):
        if rgb.dtype!=np.uint8 or rgb.ndim!=3 or rgb.shape[2]!=3 or not rgb.flags.c_contiguous:raise ValueError('Prepared contiguous RGB uint8 HWC required; no normalization here')
        tm=Times();t=time.perf_counter();ret=self.lib.y26_run(self.ctx,rgb.ctypes.data_as(ct.POINTER(ct.c_ubyte)),rgb.nbytes,ct.byref(tm))
        if ret:raise RuntimeError('RKNN run failed: '+str(ret))
        timing={n:float(getattr(tm,n)) for n,_ in Times._fields_};timing['wall_inference_ms']=(time.perf_counter()-t)*1000
        if timing['hardware_run_ms']<0:timing['hardware_run_ms']=None
        start=time.perf_counter();values=[v.copy() for v in self.views] if owned else self.views
        timing['output_ownership_copy_ms']=(time.perf_counter()-start)*1000
        return values,timing
    def close(self):
        if getattr(self,'ctx',None):self.lib.y26_close(self.ctx);self.ctx=None;self.views=[]
    def performance_detail(self):
        f=self.lib.y26_perf_detail;f.argtypes=[ct.c_void_p,ct.c_void_p,ct.c_int];f.restype=ct.c_int
        size=f(self.ctx,None,0)
        if size<0:raise RuntimeError('RKNN performance detail unavailable: '+str(size))
        buffer=ct.create_string_buffer(size+1);rc=f(self.ctx,buffer,size+1)
        if rc<0:raise RuntimeError('RKNN performance detail read failed: '+str(rc))
        return buffer.value.decode(errors='replace')
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def canonical(values,kind,expected_depth_side=192):
    if kind=='detector23':
        expected=[(1,4,8400),(1,23,8400)]
        if len(values)!=2 or any(tuple(v.shape)!=shape for v,shape in zip(values,expected)):raise ValueError('Detection layout/order differs: inspect native tensor metadata; no blind flatten')
        return values
    if len(values)!=1:raise ValueError('Depth requires one output')
    v=values[0]
    if expected_depth_side not in (128,144,160,192):raise ValueError('Explicit depth side must follow640/768 contract')
    if tuple(v.shape)==(1,expected_depth_side,expected_depth_side,1):v=v.transpose(0,3,1,2)
    if tuple(v.shape)!=(1,1,expected_depth_side,expected_depth_side):raise ValueError('Depth output geometry differs from selected native contract')
    return [v]
