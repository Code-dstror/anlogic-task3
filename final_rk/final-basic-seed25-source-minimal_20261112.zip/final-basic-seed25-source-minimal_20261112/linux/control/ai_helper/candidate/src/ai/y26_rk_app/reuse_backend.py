"""Experimental queried FP16 native input; scalar normalization and writes timed.

Not DMA end-to-end zero-copy: RGB is still read and FP16 input written by CPU.
Own one instance per ordered worker. Close binding before its RKNN context.
"""
import ctypes as ct
import time
import numpy as np
from backend import Engine,Times

class ReuseEngine(Engine):
    def __init__(self,model,library,**options):
        self.binding=None
        super().__init__(model,library,**options)
        l=self.lib
        l.y26_reuse_open.argtypes=[ct.c_void_p];l.y26_reuse_open.restype=ct.c_void_p
        l.y26_reuse_run.argtypes=[ct.c_void_p,ct.POINTER(ct.c_ubyte),ct.c_uint,ct.POINTER(Times)];l.y26_reuse_run.restype=ct.c_int
        l.y26_reuse_close.argtypes=[ct.c_void_p]
        self.binding=l.y26_reuse_open(self.ctx)
        if not self.binding:self.close();raise RuntimeError('Unsupported native FP16 geometry or bind failure')
    def infer(self,rgb,owned=False):
        if rgb.dtype!=np.uint8 or rgb.ndim!=3 or rgb.shape[2]!=3 or not rgb.flags.c_contiguous:raise ValueError('Contiguous RGB uint8 HWC required')
        tm=Times();t=time.perf_counter()
        rc=self.lib.y26_reuse_run(self.binding,rgb.ctypes.data_as(ct.POINTER(ct.c_ubyte)),rgb.nbytes,ct.byref(tm))
        if rc:raise RuntimeError('Bound input run failed: '+str(rc))
        timing={n:float(getattr(tm,n)) for n,_ in Times._fields_};timing['wall_inference_ms']=(time.perf_counter()-t)*1000
        if timing['hardware_run_ms']<0:timing['hardware_run_ms']=None
        start=time.perf_counter();values=[v.copy() for v in self.views] if owned else self.views
        timing['output_ownership_copy_ms']=(time.perf_counter()-start)*1000
        return values,timing
    def close(self):
        if getattr(self,'binding',None):self.lib.y26_reuse_close(self.binding);self.binding=None
        super().close()
