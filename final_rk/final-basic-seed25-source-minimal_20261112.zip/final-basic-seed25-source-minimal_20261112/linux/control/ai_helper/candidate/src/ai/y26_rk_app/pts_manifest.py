"""Extract integer container PTS with ffprobe, without decoding or nominal substitution."""
import argparse,json,subprocess,shutil
from fractions import Fraction
from pathlib import Path

def main():
 p=argparse.ArgumentParser();p.add_argument('--video',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--ffprobe',default='ffprobe');a=p.parse_args()
 if not shutil.which(a.ffprobe):raise SystemExit('BLOCKED: existing ffprobe executable required; no inferred PTS permitted')
 cmd=[a.ffprobe,'-v','error','-select_streams','v:0','-read_intervals','%+180','-show_entries','stream=time_base,r_frame_rate,avg_frame_rate,width,height:frame=pts,best_effort_timestamp','-of','json',str(a.video)]
 d=json.loads(subprocess.check_output(cmd));tb=Fraction(d['streams'][0]['time_base']);frames=[]
 for index,f in enumerate(d['frames']):
  if 'pts' not in f:raise ValueError('original integer frame PTS missing')
  pts=int(f['pts']);frames.append(dict(source_index=index,pts=pts,time_base=str(tb)))
 if not frames:raise ValueError('no frame PTS')
 origin=frames[0]['pts'];frames=[f for f in frames if Fraction(f['pts']-origin)*tb<180]
 if any(b['pts']<=a['pts'] for a,b in zip(frames,frames[1:])):raise ValueError('duplicate/nonincreasing original PTS')
 selections={}
 for fps in [10,15,20,30]:
  selected=[];next_slot=0
  for f in frames:
   t=Fraction(f['pts']-origin)*tb
   if t>=Fraction(next_slot,fps):selected.append(f['source_index']);next_slot+=1
  selections[str(fps)]=selected
 a.output.write_text(json.dumps(dict(status='ORIGINAL_PTS_EXTRACTED_NOT_MPP_VERIFIED',stream=d['streams'][0],frames=frames,selections=selections,epoch_policy='Each loop increments epoch; original source_index/PTS unchanged; map source time to CLOCK_MONOTONIC per epoch; duplicates do not advance independent observation confirmations'),indent=2))
if __name__=='__main__':main()
