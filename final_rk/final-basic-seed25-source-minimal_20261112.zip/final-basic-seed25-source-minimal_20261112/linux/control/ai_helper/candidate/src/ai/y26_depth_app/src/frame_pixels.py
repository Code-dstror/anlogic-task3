"""Read-only source binding; optionally retain RGB under the frame-slot lease.

Host RGB is derived here from the bound BGR. The internal native replay factory
also accepts a leased RGB channel permutation published by synchronous RGA;
this is not an external image API. Its digest can be deferred to the consumer;
it is still computed before identity/state processing. Pool reuse is only legal
after the prior lease finishes. This is a host CPU pixel adapter, not an extra
NV12->full RGB requirement for Linux's MPP/RGA deployment.
"""
from hashlib import sha256
import cv2
import numpy as np

class FramePixels:
    __slots__=('bgr','_rgb_sha256','_rgb','_hash_buffer','_lease_valid','_gmc_gray')
    def __init__(self,bgr,*,hash_buffer=True,rgb_buffer=None,defer_hash=False):
        self._lease_valid=None
        self._gmc_gray=None
        if bgr.dtype!=np.uint8 or bgr.ndim!=3 or bgr.shape[2]!=3:
            raise ValueError('Expected uint8 BGR frame')
        # Borrow only an owned CPU decode. External views get an owned snapshot.
        self.bgr=bgr if bgr.flags.owndata and bgr.flags.c_contiguous else bgr.copy()
        self.bgr.setflags(write=False)
        if rgb_buffer is not None:
            if (rgb_buffer.dtype!=np.uint8 or rgb_buffer.shape!=self.bgr.shape
                or not rgb_buffer.flags.owndata or not rgb_buffer.flags.c_contiguous
                or not rgb_buffer.flags.writeable or np.shares_memory(rgb_buffer,self.bgr)):
                raise ValueError('RGB pool buffer must be owned, writable and separate from source BGR')
        rgb=cv2.cvtColor(self.bgr,cv2.COLOR_BGR2RGB,dst=rgb_buffer)
        rgb.setflags(write=False)
        # OpenCV returns a contiguous owned RGB array. Hash its buffer directly
        # rather than allocating a second full-frame bytes object.
        self._hash_buffer=hash_buffer;self._rgb_sha256=None
        self._rgb=rgb
        if not defer_hash:
            self._rgb_sha256=self.rgb_sha256
            self._rgb=None

    @classmethod
    def _from_native_replay(cls,bgr,rgb,lease_valid):
        """Internal synchronous RGA adapter, not a generic external-RGB API.

        The native reader writes BGR then its RGB channel permutation into
        distinct caller-owned slot arrays before publishing either. Only that
        reader may call this after a successful read. No resampling/CSC here.
        A generation callback rejects access after the slot is released/reused.
        """
        for a in (bgr,rgb):
            if (a.dtype!=np.uint8 or a.ndim!=3 or a.shape[2]!=3
                or not a.flags.owndata or not a.flags.c_contiguous or a.flags.writeable):
                raise ValueError('Native RGB binding needs immutable owned packed slot arrays')
        if bgr.shape!=rgb.shape or np.shares_memory(bgr,rgb) or not callable(lease_valid) or not lease_valid():
            raise ValueError('Invalid native pixel lease')
        binding=cls.__new__(cls)
        binding._gmc_gray=None
        binding.bgr=bgr;binding._rgb=rgb;binding._rgb_sha256=None
        binding._hash_buffer=True;binding._lease_valid=lease_valid
        return binding

    def gmc_gray(self,width,height):
        self._check_lease()
        gray=self._gmc_gray
        return gray if gray is not None and gray.shape==(height,width) else None

    def _check_lease(self):
        if self._lease_valid is not None and not self._lease_valid():
            raise RuntimeError('Native pixel slot was released or reused')

    @classmethod
    def _from_prepared_shared(cls,bgr,rgb,lease_valid):
        """Internal prepared-V2 adapter; Reader owns mappings until matched ACK.

        The synchronous native publisher supplies both channel permutations.
        Unlike replay buffers these are read-only mmap views, not owned arrays.
        Do not expose this as an arbitrary external-RGB constructor.
        """
        for a in (bgr,rgb):
            if (a.dtype!=np.uint8 or a.ndim!=3 or a.shape[2]!=3
                or not a.flags.c_contiguous or a.flags.writeable):
                raise ValueError('Prepared RGB binding needs immutable packed leased views')
        if bgr.shape!=rgb.shape or np.shares_memory(bgr,rgb) or not callable(lease_valid) or not lease_valid():
            raise ValueError('Invalid prepared pixel lease')
        binding=cls.__new__(cls)
        binding._gmc_gray=None
        binding.bgr=bgr;binding._rgb=rgb;binding._rgb_sha256=None
        binding._hash_buffer=True;binding._lease_valid=lease_valid
        return binding

    @property
    def rgb_sha256(self):
        self._check_lease()
        if self._rgb_sha256 is None:
            self._rgb_sha256=sha256(memoryview(self.rgb) if self._hash_buffer else self.rgb.tobytes()).hexdigest()
        return self._rgb_sha256

    @property
    def rgb(self):
        self._check_lease()
        if self._rgb is None:raise RuntimeError('RGB was not retained for this frame lease')
        if self._rgb.flags.writeable:raise RuntimeError('Published RGB slot was reused before its consumer finished')
        return self._rgb

    def matches(self,bgr,identity):
        self._check_lease()
        return (bgr is self.bgr and not bgr.flags.writeable and (bgr.flags.owndata or self._lease_valid is not None)
                and bgr.shape==(identity.height,identity.width,3)
                and self.rgb_sha256==identity.source_rgb_sha256)
