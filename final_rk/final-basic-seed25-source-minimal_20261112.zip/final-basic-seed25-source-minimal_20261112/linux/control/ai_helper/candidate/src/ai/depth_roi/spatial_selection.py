"""Opt-in diagnostic ROI policies; original exact median remains production default.

All pixels in each requested source ROI are reconstructed with the same two-stage
FP32 interpolation as roi_depth. No grid approximation, GT mask or temporal fill.
"""
import cv2
import numpy as np
from roi_depth import region,bilinear,result

def exact_patch(sampler,raw,box,fraction=.30):
    if fraction!=.30:
        a,b,c,d=map(float,box);cx,cy=(a+c)/2,(b+d)/2
        scale=fraction/.30
        box=[cx-(c-a)*scale/2,cy-(d-b)*scale/2,cx+(c-a)*scale/2,cy+(d-b)*scale/2]
    bounds=region(box,sampler.source_shape);xa,ya,xb,yb=bounds
    xs=np.arange(xa,max(xa,xb),dtype=np.int32);ys=np.arange(ya,max(ya,yb),dtype=np.int32)
    if not len(xs) or not len(ys):return np.empty((0,0),np.float32),bounds
    ux=np.unique(np.concatenate((sampler.x2[0][xs],sampler.x2[1][xs])))
    uy=np.unique(np.concatenate((sampler.y2[0][ys],sampler.y2[1][ys])))
    mid=bilinear(raw,ux,uy,sampler.x1,sampler.y1)
    xm=(np.searchsorted(ux,sampler.x2[0][xs]),np.searchsorted(ux,sampler.x2[1][xs]),sampler.x2[2][xs])
    ym=(np.searchsorted(uy,sampler.y2[0][ys]),np.searchsorted(uy,sampler.y2[1][ys]),sampler.y2[2][ys])
    return bilinear(mid,np.arange(len(xs)),np.arange(len(ys)),xm,ym),bounds

def select(patch,policy):
    valid=np.isfinite(patch)&(patch>0)
    if policy in ('central30','central15') or not valid.any():return valid,'ALL_VALID_PIXELS'
    if policy!='connected30':raise ValueError('Unknown ROI policy')
    # Densest log-depth band, not nearest-depth band. Fixed before VAL/TEST.
    values=np.log(patch[valid]);width=.08
    edges=np.arange(float(values.min()),float(values.max())+2*width,width)
    counts,_=np.histogram(values,bins=edges);peak=int(counts.argmax())
    center=(edges[peak]+edges[peak+1])/2
    mask=valid&(np.abs(np.log(np.maximum(patch,1e-8))-center)<=.12)
    n,labels,areas,centers=cv2.connectedComponentsWithStats(mask.astype(np.uint8),connectivity=8)
    if n<=1:return valid,'FALLBACK_NO_COMPONENT'
    h,w=patch.shape;best=None
    for label in range(1,n):
        area=int(areas[label,cv2.CC_STAT_AREA]);cx,cy=centers[label]
        dist=((cx-(w-1)/2)/max(w,1))**2+((cy-(h-1)/2)/max(h,1))**2
        score=area/(1+dist)
        if best is None or score>best[0]:best=(score,label,area)
    if best[2]<max(4,int(valid.sum()*.25)):return valid,'FALLBACK_SMALL_COMPONENT'
    return labels==best[1],'CONNECTED_LOG_DEPTH_MODE'

def query(sampler,raw,box,policy):
    patch,bounds=exact_patch(sampler,raw,box,.15 if policy=='central15' else .30)
    mask,status=select(patch,policy)
    selected=patch[mask];out=result(selected,bounds,False)
    out.update(policy=policy,selection=status,selected_fraction=float(mask.sum()/patch.size) if patch.size else 0.,
        selected_pixels=int(mask.sum()),reconstructed_pixels=int(patch.size))
    return out,mask,bounds
