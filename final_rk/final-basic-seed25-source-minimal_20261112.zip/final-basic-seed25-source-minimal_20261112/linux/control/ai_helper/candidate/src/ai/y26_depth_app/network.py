"""Native23 O2O plus independent depth with explicit host dtype/buffer controls.

The selected default is exact-result FP32 buffer reuse. This is CUDA execution,
not an implementation or performance claim for RKNN integer quantization.
"""
import os,sys,types,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
os.environ['YOLO_CONFIG_DIR']=str(HERE/'runtime_settings');os.environ['YOLO_AUTOINSTALL']='false'
sys.path.insert(0,str(HERE/'vendor'))
import cv2,numpy as np,torch
sys.path.insert(0,str(HERE.parent/'depth_roi'))
from roi_depth import RoiDepthSampler
from model_preprocessing import CpuPreprocessor
from depth_preprocessing import DepthPreprocessor

def clock():
    torch.cuda.synchronize()
    return time.perf_counter()
def selected(self,x):return self.forward_head(x,**self.one2one)

class Backend:
    def __init__(self,path,kind,precision='fp32',reuse_input=False,fuse=False):
        requested_opencv_threads=cv2.getNumThreads()
        if precision not in ('fp32','fp16','bf16'):raise ValueError('Unknown host execution precision')
        self.dtype={'fp32':torch.float32,'fp16':torch.float16,'bf16':torch.bfloat16}[precision]
        if precision=='bf16' and not torch.cuda.is_bf16_supported():raise RuntimeError('CUDA BF16 unavailable')
        self.reuse_input=reuse_input;self.input_shape=None
        ck=torch.load(path,map_location='cpu',weights_only=False)
        net=ck.get('ema') if ck.get('ema') is not None else ck['model']
        self.net=net.float().eval().cuda();self.kind=kind;self.names=self.net.names
        before=sum(isinstance(m,torch.nn.modules.batchnorm._BatchNorm) for m in self.net.modules())
        if fuse:self.net.fuse(verbose=False,imgsz=768 if kind=='depth' else 640)
        after=sum(isinstance(m,torch.nn.modules.batchnorm._BatchNorm) for m in self.net.modules())
        self.fusion_info=dict(requested=bool(fuse),batchnorm_before=before,batchnorm_after=after)
        self.net=self.net.to(dtype=self.dtype)
        if kind=='detection':
            self.head=self.net.model[-1]
            if self.head.nc!=23 or self.head.reg_max!=1:raise ValueError('Wrong native23 checkpoint')
            self.head.end2end=True;self.head.max_det=300
            self.head.forward=types.MethodType(selected,self.head)
        # Loading a pickle may lazily import Ultralytics, whose global initializer
        # disables OpenCV threading for DataLoader. Preserve the caller's runtime
        # policy after all model imports; this process is inference-only.
        cv2.setNumThreads(requested_opencv_threads)
    @torch.inference_mode()
    def infer(self,rgb):
        # Ordered-pipeline workers have their own thread-local torch mode.
        # Training checkpoints may retain requires_grad=True after eval().
        # Protect the actual call, not just the consumer/warmup thread.
        t=clock()
        if self.reuse_input:
            shape=(1,3,*rgb.shape[:2])
            if shape!=self.input_shape:
                self.host_u8=torch.empty(shape,dtype=torch.uint8,pin_memory=True)
                self.host_array=self.host_u8.numpy()
                self.device_u8=torch.empty(shape,device='cuda',dtype=torch.uint8)
                self.device_input=torch.empty(shape,device='cuda',dtype=self.dtype)
                self.input_shape=shape
            np.copyto(self.host_array[0],rgb.transpose(2,0,1))
            self.device_u8.copy_(self.host_u8,non_blocking=True)
            x=self.device_input.copy_(self.device_u8).div_(255)
        else:
            x=torch.from_numpy(rgb.transpose(2,0,1).copy()[None]).to(device='cuda',dtype=self.dtype).div_(255)
        p=clock();raw=self.net(x);f=clock()
        if self.kind=='detection':raw=self.head.postprocess(self.head._inference(raw).permute(0,2,1))
        elif isinstance(raw,(tuple,list)):raw=raw[0]
        # The C++ exact sampler always receives FP32, including BF16 execution.
        d=clock();value=raw.detach().to(device='cpu',dtype=torch.float32).numpy();e=clock()
        return value,dict(tensor_pack=(p-t)*1000,network_forward=(f-p)*1000,decode_topk=(d-f)*1000,output_copy=(e-d)*1000)

class Network:
    def __init__(self,config):
        if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required for this measured profile')
        self.config=config;spec=config['networks']['Y26D']
        execution=config.get('host_execution',{})
        self.det=Backend(HERE/spec['detector'],'detection',execution.get('det_precision','fp32'),execution.get('reuse_input',False),execution.get('fuse_det',False))
        self.depth=Backend(HERE/spec['depth'],'depth',execution.get('depth_precision','fp32'),execution.get('reuse_input',False),execution.get('fuse_depth',False))
        self.reuse_input=execution.get('reuse_input',False);self.depth_rgb_source=None;self.depth_rgb_input=None
        depth_geometry=config.get('depth_input_geometry',{})
        self.depth_pre=DepthPreprocessor(depth_geometry.get('size',768),depth_geometry.get('resize','stretch'),self.reuse_input)
        if list(self.det.names.values())!=config['model']['names']:raise ValueError('23class order mismatch')
        self.pre=CpuPreprocessor();self.samplers={};self.last_tracking_candidates=[]
    @torch.inference_mode()
    def run(self,bgr,*,pixel_binding=None):
        from runtime import weak_tracking_candidates,FramePixels
        if pixel_binding is not None:
            if not isinstance(pixel_binding,FramePixels) or pixel_binding.bgr is not bgr:
                raise ValueError('Shared network RGB must derive from this bound source frame')
            source=pixel_binding.rgb;pixel_format='RGB'
        else:source=bgr;pixel_format='BGR'
        stages={'original_frame_copy':0.0}
        with self.pre.prepare(source,pixel_format=pixel_format) as p:
            g=dict(p.geometry);stages['det_preprocess']=p.timings['shared_preprocess']
            raw,tm=self.det.infer(p.rgb[0])
        stages.update({'det_'+k:v for k,v in tm.items()})
        rows=raw[0];self.last_tracking_candidates=weak_tracking_candidates(rows,self.config,g)
        start=time.perf_counter();objects=[]
        for r in rows[rows[:,4]>=self.config['detector_threshold']]:
            cid=int(r[5])
            if cid!=r[5] or not 0<=cid<23:raise ValueError('Invalid class output')
            box=r[:4].astype(float).copy();box[[0,2]]=(box[[0,2]]-g['left'])/g['sx'];box[[1,3]]=(box[[1,3]]-g['top'])/g['sy']
            box=np.clip(box,[0,0,0,0],[g['width'],g['height'],g['width'],g['height']])
            if box[0]>=box[2] or box[1]>=box[3]:continue
            objects.append(dict(class_id=cid,class_name=self.config['model']['names'][cid],application_group=self.config['model']['groups'][str(cid)],
                confidence=float(r[4]),xyxy=box.tolist()))
        stages['detection_decode']=(time.perf_counter()-start)*1000
        start=time.perf_counter()
        rgb,depth_geometry=self.depth_pre.prepare(bgr,source_rgb=None if pixel_binding is None else source)
        self.last_depth_geometry=depth_geometry
        stages['depth_preprocess']=(time.perf_counter()-start)*1000
        value,tm=self.depth.infer(rgb);stages.update({'depth_'+k:v for k,v in tm.items()})
        start=time.perf_counter();dense=np.squeeze(value)
        if dense.ndim!=2 or not np.isfinite(dense).all() or (dense<=0).any():raise ValueError('Invalid depth output')
        shape=(dense.shape,bgr.shape[:2],self.depth_pre.size,self.depth_pre.resize)
        if shape not in self.samplers:
            library=None if depth_geometry['content_box'] is None else HERE.parent/'depth_roi/build'/('roi_depth_geometry.dll' if os.name=='nt' else 'libroi_depth.so')
            self.samplers[shape]=RoiDepthSampler(dense.shape,bgr.shape[:2],(self.depth_pre.size,)*2,
                mode='native_exact',library=library,content_box=depth_geometry['content_box'])
        self.last_depth_map=dense;stages['depth_output_validate']=(time.perf_counter()-start)*1000
        start=time.perf_counter();distances=self.samplers[shape].sample(dense,[o['xyxy'] for o in objects])
        for o,d in zip(objects,distances):o.update(d,distance_kind='DENSE_DEPTH_PATCH')
        stages['depth_query_and_association']=(time.perf_counter()-start)*1000
        stages['shared_preprocess']=stages['det_preprocess']+stages['depth_preprocess']
        stages['combined_network_forward']=stages['det_network_forward']+stages['depth_network_forward']
        return objects,stages,g
