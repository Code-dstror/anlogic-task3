"""Python counterpart of the existing browser diagnostic policy.

Application diagnostics only. Metric distance and collision risk remain unverified.
This module never upgrades automatic lane evidence or converts UNKNOWN to CLEAR.
"""
import copy
import math

GROUPS = ('pedestrian', 'vehicle', 'two_wheeler', 'obstacle')
SEVERITY = dict(CLEAR=0, ATTENTION=1, DANGER=2)


def finite(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def inside(box, width, height, polygon):
    x, y = (box[0] + box[2]) / 2 / width, box[3] / height
    hit = False
    for a, b in zip(polygon, polygon[-1:] + polygon[:-1]):
        cross = (x-a[0])*(b[1]-a[1])-(y-a[1])*(b[0]-a[0])
        if abs(cross) < 1e-10 and min(a[0], b[0])-1e-10 <= x <= max(a[0], b[0])+1e-10 and min(a[1], b[1])-1e-10 <= y <= max(a[1], b[1])+1e-10:
            return True
        if (a[1] > y) != (b[1] > y) and x < (b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:
            hit = not hit
    return hit


class Engine:
    def __init__(self, config,*,prune_clear_missing=True):
        self.prune_clear_missing=prune_clear_missing
        self.configure(config)

    def configure(self, config):
        if config['scope'] != 'SIMULATION':
            raise ValueError('This adapter supports the authorized diagnostic scope only')
        for group in GROUPS:
            t = config['thresholds'][group]
            if not all(finite(t[k]) for k in ('danger', 'attention')) or not 0 < t['danger'] < t['attention'] <= 200:
                raise ValueError('Require 0 < danger < attention <= 200m')
        for key in ('confirm_ms', 'release_ms', 'hysteresis_m', 'freshness_ms'):
            if not finite(config[key]) or config[key] < 0:
                raise ValueError('Invalid application timing')
        if config['release_ms'] < 1000 or config['freshness_ms'] <= 0:
            raise ValueError('Release requires 1s valid observations')
        self.config = copy.deepcopy(config)
        self.states, self.context, self.last, self.frame_key = {}, None, -1, None

    def process(self, frame, now):
        c = self.config
        if not finite(now) or not finite(frame['observed_ms']) or now < frame['observed_ms'] or not frame['key'] or not frame['context']:
            raise ValueError('Invalid frame clock/identity')
        same = frame['context'] == self.context
        if same and (frame['observed_ms'] <= self.last or frame['key'] == self.frame_key):
            raise ValueError('Repeated/reordered observation')
        delta = frame['observed_ms']-self.last if same else 0
        if not same:
            self.states.clear()
        self.context, self.last, self.frame_key = frame['context'], frame['observed_ms'], frame['key']
        seen, objects = set(), []
        for o in frame['objects']:
            key, group = o['id'], o['group']
            if not key or key in seen or group not in GROUPS:
                raise ValueError('Invalid/repeated object')
            seen.add(key)
            s = self.states.get(key)
            if s is None or s['group'] != group:
                s = dict(group=group, active='CLEAR', candidate=None, since=None, exit=None)
            if delta > c['freshness_ms']:
                s.update(candidate=None, since=None, exit=None)
            distance = o['distance_m'] if finite(o.get('distance_m')) and o['distance_m'] > 0 else None
            reason = ('SELF_EXCLUDED' if o.get('self') else
                      'STALE' if now-frame['observed_ms'] > c['freshness_ms'] else
                      'FRAME_BINDING_MISMATCH' if o.get('frame_key') != frame['key'] or o.get('distance_frame_key') != frame['key'] else
                      'NOT_OBSERVED' if o.get('observed') is not True else
                      'IDENTITY_UNCONFIRMED' if o.get('identity_valid') is not True else
                      'REGION_UNKNOWN' if not o.get('region_source') or o['region_source'] == 'MANUAL_DEBUG' or o.get('region') not in ('INSIDE', 'OUTSIDE') else
                      'DISTANCE_MISSING' if distance is None else
                      'DISTANCE_UNVERIFIED' if o.get('distance_state') != 'VALID' else None)
            if reason:
                s.update(candidate=None, since=None, exit=None)
                self.states[key] = s
                objects.append(dict(o, distance_m=distance, level='EXCLUDED' if o.get('self') else 'UNKNOWN', reason=reason, latched_level=s['active'], voice_eligible=False))
                continue
            t = c['thresholds'][group]
            next_level = ('DANGER' if distance <= t['danger'] else 'ATTENTION' if distance <= t['attention'] else 'CLEAR') if o['region'] == 'INSIDE' else 'CLEAR'
            if o['region'] == 'INSIDE':
                if s['active'] == 'DANGER' and distance <= t['danger']+c['hysteresis_m']:
                    next_level = 'DANGER'
                elif s['active'] == 'ATTENTION' and next_level == 'CLEAR' and distance <= t['attention']+c['hysteresis_m']:
                    next_level = 'ATTENTION'
            if SEVERITY[next_level] > SEVERITY[s['active']]:
                s['exit'] = None
                if s['candidate'] != next_level:
                    s.update(candidate=next_level, since=frame['observed_ms'])
                if frame['observed_ms']-s['since'] >= c['confirm_ms']:
                    s.update(active=next_level, candidate=None, since=None)
            elif SEVERITY[next_level] < SEVERITY[s['active']]:
                s.update(candidate=None, since=None)
                if s['exit'] is None:
                    s['exit'] = frame['observed_ms']
                if frame['observed_ms']-s['exit'] >= c['release_ms']:
                    s.update(active=next_level, exit=None)
            else:
                s.update(candidate=None, since=None, exit=None)
            self.states[key] = s
            objects.append(dict(o, distance_m=distance, level=s['active'], pending_level=s['candidate'], latched_level=s['active'],
                reason='EXIT_CONFIRMING' if s['exit'] is not None else 'ENTRY_CONFIRMING' if s['candidate'] else 'VALID',
                voice_eligible=o['region'] == 'INSIDE' and next_level != 'CLEAR' and s['active'] != 'CLEAR'))
        retired_clear=[]
        for key, state in self.states.items():
            if key not in seen:
                state.update(candidate=None, since=None, exit=None)
                # No pending confirmation or alert survives for this missing
                # CLEAR ID. Retain every unresolved ATTENTION/DANGER latch.
                if self.prune_clear_missing and state['active']=='CLEAR':retired_clear.append(key)
        for key in retired_clear:del self.states[key]
        visible = [o for o in objects if o['level'] != 'EXCLUDED']
        ranked = sorted([o for o in visible if o['voice_eligible']], key=lambda o: (-SEVERITY[o['level']], o['group'] != 'pedestrian', o['distance_m'], str(o['id'])))
        return dict(objects=visible, excluded=len(objects)-len(visible), ranked=ranked,
                    eligible_groups=[g for g in GROUPS if any(o['group'] == g for o in ranked)],
                    pedestrian_priority=[o['id'] for o in ranked if o['group'] == 'pedestrian'],
                    unresolved=sum(s['active'] != 'CLEAR' and (key not in seen or any(o['id'] == key and o['level'] == 'UNKNOWN' for o in visible)) for key, s in self.states.items()),
                    collision_risk='UNKNOWN', scope='SIMULATION')
