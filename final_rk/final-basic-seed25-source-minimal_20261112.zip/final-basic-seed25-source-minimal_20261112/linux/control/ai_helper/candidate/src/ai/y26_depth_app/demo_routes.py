"""Three retained CPU profiles over two depth models and one application."""
import copy,json
from pathlib import Path
from depth_preprocessing import PROFILES
HERE=Path(__file__).resolve().parent

def routes():return json.loads((HERE/'model_routes.json').read_text(encoding='utf-8'))['routes']

def apply_route(config,name):
    route=routes()[name];c=copy.deepcopy(config)
    c['active_route']=name;c['route_model_key']=route['model_key']
    c['depth_input_profile']=route['input_profile'];c['depth_input_geometry']=dict(PROFILES[route['input_profile']])
    c['depth_candidate_label']='official_published' if name=='official' else 'LC64_student'
    c['networks']['Y26D']=dict(kind='independent_dense_depth',detector='assets/yolo26n23_baseline.pt',depth=route['depth'],label=route['label'])
    c['route_status_note']=route['status_note'];c['route_metric_scale']=route['metric_scale']
    c.setdefault('cpu_runtime',{})['opencv_threads']=route['opencv_threads']
    return c
