"""Source-bound monocular geometry. Estimates never certify metric depth or collision risk."""
import math
from range_readout import current_range


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def valid_intrinsics(k):
    return isinstance(k, dict) and all(number(k.get(n)) for n in ('fx', 'fy', 'cx', 'cy')) and k['fx'] > 0 and k['fy'] > 0


def transform_intrinsics(k, sx, sy, left=0., top=0., crop_x=0., crop_y=0.):
    """Crop then OpenCV-style pixel-centre resize then pad; no rotation/undistortion implied."""
    if not valid_intrinsics(k) or not all(number(v) for v in (sx, sy, left, top, crop_x, crop_y)) or sx <= 0 or sy <= 0:
        raise ValueError('Invalid camera/transform')
    return dict(fx=k['fx']*sx, fy=k['fy']*sy,
                cx=(k['cx']-crop_x+.5)*sx-.5+left,
                cy=(k['cy']-crop_y+.5)*sy-.5+top)


def measurements(box, z, profile, width, height):
    if len(box) != 4 or not all(number(v) for v in box) or box[2] <= box[0] or box[3] <= box[1]:
        raise ValueError('Invalid source-space box')
    pixel_w, pixel_h = box[2]-box[0], box[3]-box[1]
    result = dict(pixel_width=pixel_w, pixel_height=pixel_h,
                  raw_forward_z_m=z if number(z) and z > 0 else None,
                  visible_width_estimate_m=None, visible_height_estimate_m=None,
                  camera_x_estimate_m=None, camera_y_estimate_m=None, slant_range_estimate_m=None,
                  bearing_deg=None, calibration_id=None, calibration_source=None,
                  status='CAMERA_INTRINSICS_UNKNOWN', metric_validated=False,
                  calibration_scope='DATASET_CAMERA_ONLY_IMX415_REQUIRES_ITS_OWN_CALIBRATION',
                  physical_dimensions_m=None, collision_distance_m=None, ttc_s=None,
                  approximation='BOX_CENTER_RAY_AND_SINGLE_TARGET_Z_NOT_PHYSICAL_CENTER',
                  truncated=box[0] <= 2 or box[1] <= 2 or box[2] >= width-2 or box[3] >= height-2)
    if profile is None:
        return result
    result.update(calibration_id=profile.get('id'), calibration_source=profile.get('source'))
    if profile.get('width') != width or profile.get('height') != height:
        result['status'] = 'CAMERA_GEOMETRY_MISMATCH'
        return result
    k = profile.get('intrinsics')
    if not valid_intrinsics(k):
        return result
    if profile.get('projection') != 'PINHOLE_APPROXIMATION':
        result['status'] = 'CAMERA_PROJECTION_UNSUPPORTED'
        return result
    u, v = (box[0]+box[2])/2, (box[1]+box[3])/2
    rx, ry = (u-k['cx'])/k['fx'], (v-k['cy'])/k['fy']
    result['bearing_deg'] = math.degrees(math.atan(rx))
    if result['raw_forward_z_m'] is None:
        result['status'] = 'DEPTH_UNKNOWN'
        return result
    result.update(visible_width_estimate_m=pixel_w*z/k['fx'],
                  visible_height_estimate_m=pixel_h*z/k['fy'],
                  camera_x_estimate_m=rx*z, camera_y_estimate_m=ry*z,
                  slant_range_estimate_m=z*math.sqrt(1+rx*rx+ry*ry),
                  status='VISIBLE_PROJECTION_AND_POSITION_UNVALIDATED',
                  distortion_status=profile.get('distortion_status', 'UNSPECIFIED'))
    return result


def self_excluded(box, width, height, camera):
    """Only an explicitly confirmed fixed camera polygon can hide a target box.

    Bottom-centre contact must be inside and >=configured fraction of box-area
    samples must overlap. This is diagnostic sampled overlap, not segmentation.
    """
    polygon = camera.get('ego_polygon', [])
    if (camera.get('ego_mask_enabled') is not True
            or camera.get('ego_polygon_confirmed') is not True or len(polygon) < 3):
        return False
    from deployment.policy import inside
    if not inside(box, width, height, polygon):
        return False
    threshold = camera.get('ego_overlap_threshold', .8)
    if not number(threshold) or not 0 < threshold <= 1:
        raise ValueError('Invalid explicit ego overlap threshold')
    hits = 0
    for yi in range(7):
        y = box[1]+(yi+.5)*(box[3]-box[1])/7
        for xi in range(7):
            x = box[0]+(xi+.5)*(box[2]-box[0])/7
            hits += inside([x, y, x, y], width, height, polygon)
    return hits/49 >= threshold


def attach_geometry(objects, profile, width, height, camera):
    bound_camera = dict(camera)
    if profile is None or camera.get('ego_profile_id') != profile.get('id'):
        bound_camera['ego_polygon_confirmed'] = False
    for o in objects:
        o['display_distance_m'] = current_range(o)
        o['geometry'] = measurements(o['xyxy'], o['display_distance_m'], profile, width, height)
        o['self_excluded'] = self_excluded(o['xyxy'], width, height, bound_camera)
        o['display_visible'] = not o['self_excluded']


def task_packet(objects, policy, frame_key, source, profile):
    """Explicit same-frame diagnostic application packet; no stale held depth or synthetic GT."""
    rank = {o['id']: i+1 for i, o in enumerate(policy['ranked'])}
    pedestrian = {oid: i+1 for i, oid in enumerate(policy['pedestrian_priority'])}
    rows = []
    for o in objects:
        rows.append(dict(id=o['id'], class_id=o['class_id'], class_name=o['class_name'],
                         group=o['application_group'], confidence=o['confidence'], xyxy=o['xyxy'],
                         tracked=o['tracked'], display_visible=o.get('display_visible', True),
                         raw_forward_z_m=o.get('estimated_depth_m'),display_distance_m=o.get('display_distance_m'),
                         distance_ownership=o.get('distance_ownership'),
                         geometry=o['geometry'], distance_quality=o['distance_quality'],
                         diagnostic_eligible=o['diagnostic_eligible'], level=o['level'], reason=o['reason'],
                         warning_contract=o.get('warning_contract'),
                         proximity_level=o.get('proximity_level'),proximity_reason=o.get('proximity_reason'),
                         ttc_level=o.get('ttc_level'),ttc_confirmed=o.get('ttc_confirmed'),ttc_reason=o.get('ttc_reason'),
                         display_level=o.get('display_level',o['level']),display_reason=o.get('display_reason',o['reason']),
                         display_kind=o.get('display_kind'),voice_basis_level=o.get('voice_basis_level'),
                         motion_diagnostic=o.get('motion_diagnostic'),
                         demo_bumper_clearance_m=o.get('demo_bumper_clearance_m'),distance_display_assumption=o.get('distance_display_assumption'),
                         distance_basis='CAMERA_FORWARD_Z_ESTIMATE',distance_label='估算的碰撞距离',voice_basis_kind=o.get('voice_basis_kind','NONE'),collision_risk_validated=False,
                         warning_rank=rank.get(o['id']), pedestrian_priority=pedestrian.get(o['id']),
                         voice_eligible=o['voice_eligible'], frame_key=frame_key))
    return dict(schema='AI_TASKS_DIAGNOSTIC_V1', warning_contract=policy.get('warning_contract'),frame_key=frame_key, source=source,
                calibration_id=None if profile is None else profile['id'], objects=rows,
                eligible_voice_groups=policy['eligible_groups'],
                pedestrian_priority=policy['pedestrian_priority'], unresolved=policy['unresolved'],
                automatic_lane='UNKNOWN', collision_risk='UNKNOWN', metric_validated=False)
