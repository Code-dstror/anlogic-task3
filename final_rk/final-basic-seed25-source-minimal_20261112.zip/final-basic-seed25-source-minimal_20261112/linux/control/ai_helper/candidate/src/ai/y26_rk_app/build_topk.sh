#!/usr/bin/env bash
set -euo pipefail
src_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
out_dir="${1:?pass candidate board_libs directory}"
mkdir -p -- "$out_dir"
flags=()
mode="${2:-partial}"
case "$mode" in
 partial|nth|partial_neon|nth_neon|partial_keys|nth_keys|partial_neon_keys|nth_neon_keys|partial_half_rank|nth_half_rank) ;;
 *) exit 2 ;;
esac
if [[ "$mode" == nth* ]]; then flags+=(-DY26_TOPK_NTH); fi
if [[ "$mode" == *neon* ]]; then flags+=(-DY26_TOPK_NEON); fi
if [[ "$mode" == *_keys ]]; then flags+=(-DY26_TOPK_KEYS); fi
if [[ "$mode" == *_half_rank ]]; then flags+=(-DY26_TOPK_HALF_RANK); fi
g++ -O3 -std=c++17 -shared -fPIC -fno-fast-math -ffp-contract=off \
 "${flags[@]}" "$src_dir/native/detection_topk.cpp" -o "$out_dir/liby26_topk_v1.so"
