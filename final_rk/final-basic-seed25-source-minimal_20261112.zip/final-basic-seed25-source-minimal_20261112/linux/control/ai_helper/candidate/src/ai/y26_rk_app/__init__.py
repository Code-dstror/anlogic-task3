"""RK3576 preparation and accuracy utilities; not a completed live-board adapter."""
