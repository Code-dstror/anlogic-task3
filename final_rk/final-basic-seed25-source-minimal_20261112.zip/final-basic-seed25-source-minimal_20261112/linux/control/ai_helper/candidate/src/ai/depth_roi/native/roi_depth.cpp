#include "roi_depth.h"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstring>
#include <limits>
#include <vector>

namespace {
struct Axis {
    std::vector<int> lo,hi;
    std::vector<double> w;
    Axis(int in,int out):Axis(in,out,0,in-1) {}
    Axis(int in,int out,int start,int end):lo(out),hi(out),w(out) {
        const double step=out>1?double(end-start)/(out-1):0;
        for(int i=0;i<out;++i){
            // np.linspace(..., dtype=float32), then float32-int32 -> float64.
            float pos=static_cast<float>(start+i*step);
            if(out>1 && i==out-1)pos=static_cast<float>(end);
            lo[i]=int(pos);hi[i]=std::min(lo[i]+1,in-1);w[i]=double(pos)-lo[i];
        }
    }
};
struct Context {
    int rh,rw,mh,mw,sh,sw,max_boxes;
    Axis x1,y1,x2,y2;
    std::vector<float> mid,values;
    std::vector<uint32_t> stamps;
    uint32_t generation=0;
    Context(int a,int b,int c,int d,int e,int f,int n):
        rh(a),rw(b),mh(c),mw(d),sh(e),sw(f),max_boxes(n),
        x1(b,d),y1(a,c),x2(d,f),y2(c,e),mid(size_t(c)*d),stamps(size_t(c)*d,0) {
        values.reserve(size_t(e)*f);
    }
    float intermediate(const float *depth,int stride,int x,int y){
        const size_t k=size_t(y)*mw+x;
        if(stamps[k]!=generation){
            if(rh==mh && rw==mw){mid[k]=depth[size_t(y)*stride+x];stamps[k]=generation;return mid[k];}
            const int xa=x1.lo[x],xb=x1.hi[x],ya=y1.lo[y],yb=y1.hi[y];
            const double dx=x1.w[x],dy=y1.w[y];
            const double a=double(depth[size_t(ya)*stride+xa])*(1-dx)+double(depth[size_t(ya)*stride+xb])*dx;
            const double b=double(depth[size_t(yb)*stride+xa])*(1-dx)+double(depth[size_t(yb)*stride+xb])*dx;
            mid[k]=static_cast<float>(a*(1-dy)+b*dy);stamps[k]=generation;
        }
        return mid[k];
    }
    float sample(const float *depth,int stride,int x,int y){
        const int xa=x2.lo[x],xb=x2.hi[x],ya=y2.lo[y],yb=y2.hi[y];
        const double dx=x2.w[x],dy=y2.w[y];
        const double a=double(intermediate(depth,stride,xa,ya))*(1-dx)+double(intermediate(depth,stride,xb,ya))*dx;
        const double b=double(intermediate(depth,stride,xa,yb))*(1-dx)+double(intermediate(depth,stride,xb,yb))*dx;
        return static_cast<float>(a*(1-dy)+b*dy);
    }
};
int clip_trunc(double v,int maxv){return v<=0?0:(v>=maxv?maxv:int(v));}
int clip_ceil(double v,int maxv){return v<=0?0:(v>=maxv?maxv:int(std::ceil(v)));}
double quantile(const std::vector<float>&v,double q){
    const double p=double(v.size()-1)*q;
    const size_t a=size_t(p),b=std::min(a+1,v.size()-1);
    return double(v[a])+(double(v[b])-v[a])*(p-a);
}
void stats(Context &c,ds_result &r){
    if(c.values.empty())return;
    r.valid=int(c.values.size());r.fraction=double(r.valid)/r.sampled;
    // Select only the ranks needed by median and linearly interpolated IQR.
    std::vector<size_t> ranks;
    for(double q:{.25,.5,.75}){
        size_t a=size_t(double(c.values.size()-1)*q);
        ranks.push_back(a);ranks.push_back(std::min(a+1,c.values.size()-1));
    }
    std::sort(ranks.begin(),ranks.end());ranks.erase(std::unique(ranks.begin(),ranks.end()),ranks.end());
    size_t first=0;
    for(size_t k:ranks){
        std::nth_element(c.values.begin()+first,c.values.begin()+k,c.values.end());
        first=k+1;
    }
    const size_t n=c.values.size();
    // np.median(float32) keeps float32 arithmetic for even lengths.
    r.median=n%2?c.values[n/2]:static_cast<float>((c.values[n/2-1]+c.values[n/2])*.5f);
    r.iqr=quantile(c.values,.75)-quantile(c.values,.25);
}
}

void *ds_create(int rh,int rw,int mh,int mw,int sh,int sw,int max_boxes){
    for(int v:{rh,rw,mh,mw,sh,sw})if(v<1 || v>8192)return nullptr;
    if(max_boxes<1 || max_boxes>4096)return nullptr;
    try{return new Context(rh,rw,mh,mw,sh,sw,max_boxes);}catch(...){return nullptr;}
}
void ds_destroy(void *ctx){delete static_cast<Context*>(ctx);}
int ds_set_content(void *ctx,int left,int top,int width,int height){
    if(!ctx)return 1;
    auto &c=*static_cast<Context*>(ctx);
    if(left<0 || top<0 || width<1 || height<1 || left+width>c.mw || top+height>c.mh)return 2;
    try{c.x2=Axis(c.mw,c.sw,left,left+width-1);c.y2=Axis(c.mh,c.sh,top,top+height-1);return 0;}
    catch(...){return 4;}
}
int ds_process(void *ctx,const float *depth,int stride,const double *boxes,int count,ds_result *out){
    if(!ctx)return 1;
    auto &c=*static_cast<Context*>(ctx);
    if(count<0 || count>c.max_boxes || !depth || stride<c.rw || (count && (!boxes || !out)))return 2;
    for(int i=0;i<count*4;++i)if(!std::isfinite(boxes[i]) || std::abs(boxes[i])>1e9)return 3;
    try {
        if(++c.generation==0){std::fill(c.stamps.begin(),c.stamps.end(),0);c.generation=1;}
        for(int i=0;i<count;++i){
            auto &r=out[i];std::memset(&r,0,sizeof(r));
            const double *b=boxes+i*4;
            if(b[2]<=b[0] || b[3]<=b[1])continue;
            const double cx=(b[0]+b[2])*.5,cy=(b[1]+b[3])*.5;
            const double rx=std::max(1.,(b[2]-b[0])*.15),ry=std::max(1.,(b[3]-b[1])*.15);
            r.bounds[0]=clip_trunc(cx-rx,c.sw);r.bounds[1]=clip_trunc(cy-ry,c.sh);
            r.bounds[2]=clip_ceil(cx+rx,c.sw);r.bounds[3]=clip_ceil(cy+ry,c.sh);
            int nx=std::max(0,r.bounds[2]-r.bounds[0]),ny=std::max(0,r.bounds[3]-r.bounds[1]);
            r.region=nx*ny;
            if(!r.region)continue;
            const int sx=nx,sy=ny;
            r.sampled=r.region;r.approximate=0;
            c.values.clear();
            for(int iy=0;iy<sy;++iy){
                int y=r.bounds[1]+iy;
                for(int ix=0;ix<sx;++ix){
                    const float v=c.sample(depth,stride,r.bounds[0]+ix,y);
                    if(std::isfinite(v) && v>0)c.values.push_back(v);
                }
            }
            stats(c,r);
        }
        return 0;
    }catch(...){return 4;}
}
