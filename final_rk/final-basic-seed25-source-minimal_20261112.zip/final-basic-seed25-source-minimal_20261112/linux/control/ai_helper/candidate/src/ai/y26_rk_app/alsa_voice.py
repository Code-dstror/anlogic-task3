"""One ALSA phrase at a time; completion uses actual aplay exit, not WAV math."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
HERE=Path(__file__).resolve().parent;HOST=HERE.parent/'y26_depth_app'
sys.path.insert(0,str(HOST/'src'))
from voice_scheduler import VoiceScheduler,AlertSnapshot

class Player:
    def __init__(self,device='default',enabled=False):
        self.enabled=enabled;self.device=device;self.scheduler=VoiceScheduler();self.process=None
        self.root=Path(os.environ.get('Y26_VOICE_ROOT',str(HOST/'assets/audio')));self.voices=json.loads((self.root/'manifest.json').read_text(encoding='utf-8'))['voices'];self.scheduler.available_voice_keys=set(self.voices)
    def step(self,context,frame_key,capture_ns,groups):
        if not self.enabled:return dict(status='AUDIO_NOT_RUN',events=[])
        now=time.monotonic_ns();start=len(self.scheduler.events)
        if self.process is not None and self.process.poll() is not None:
            success=self.process.returncode==0;self.scheduler.complete(self.scheduler.current['request_id'],now,success=success);self.process=None
        self.scheduler.observe(AlertSnapshot((context,),frame_key,int(capture_ns),tuple(groups)),now)
        request=self.scheduler.poll(now)
        if request:
            path=self.root/self.voices[request['group']]['file']
            try:self.process=subprocess.Popen(['aplay','-q','-D',self.device,str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            except Exception:
                self.scheduler.complete(request['request_id'],time.monotonic_ns(),success=False);raise
        return dict(status='ALSA_PROCESS_CONTROL',events=self.scheduler.events[start:],physical_acoustic_latency='NOT_MEASURED')
    def close(self):
        if self.process is not None and self.process.poll() is None:
            try:self.process.wait(timeout=15)
            except subprocess.TimeoutExpired:self.process.terminate();self.process.wait(timeout=5)
