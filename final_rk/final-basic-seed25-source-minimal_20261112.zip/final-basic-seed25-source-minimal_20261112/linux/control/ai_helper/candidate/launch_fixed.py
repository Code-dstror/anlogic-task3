"""Print explicit commands for the selected board route. Never executes them."""
import argparse,json,os,shlex
from pathlib import Path

HERE=Path(__file__).resolve().parent


def command(profile,source,mode,output,seconds=180,manifest=None,acks=None,audio=False):
    rk=source/'ai/y26_rk_app'
    env=dict(profile['environment'])
    env['PYTHONPATH']=str(rk)
    env['Y26_VOICE_ROOT']=profile['voice_root']
    args=['/usr/bin/python3','-B',str(rk/('replay_video.py' if mode=='replay' else 'runner.py')),
        '--route','lc64','--detector',profile['detector'],'--depth',profile['depth'],
        '--library',profile['library'],'--roi-library',profile['roi_library'],
        '--tracking-library',profile['tracking_library'],'--gmc-library',profile['gmc_library'],'--depth-size','640',
        '--execution','parallel_split','--opencv-threads','8','--cpu-affinity','all','--output',str(output)]
    if mode=='replay':
        args+=['--video',profile['video'],'--replay-library',profile['replay_library'],
            '--pipeline','staged','--slots','3',
            '--seconds',str(seconds),'--full-log']
        if audio:raise ValueError('Replay uses simulated voice decisions; physical audio is a prepared/live integration option')
    else:
        if not manifest or not acks:raise ValueError('Prepared mode requires manifest and ACK paths')
        args+=['--prepared-manifest',str(manifest),'--acks',str(acks),'--input-mode','bound-fp16',
               '--duration-s',str(seconds)]
        if audio:args+=['--audio']
    return env,args


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['replay','prepared'],required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seconds',type=int,default=180)
    p.add_argument('--manifest',type=Path);p.add_argument('--acks',type=Path)
    p.add_argument('--audio',action='store_true')
    a=p.parse_args()
    if a.seconds<=0:p.error('seconds must be positive')
    profile=json.loads((HERE/'fixed_profile.json').read_text(encoding='utf-8'))
    source=HERE/'src' if (HERE/'src/ai').is_dir() else HERE/'board/src'
    try:env,args=command(profile,source.resolve(),a.mode,a.output,a.seconds,a.manifest,a.acks,a.audio)
    except ValueError as error:p.error(str(error))
    print('# Command only; source revision has NOT been deployed/rebenchmarked. Coordinate device ownership first.')
    print('env '+' '.join(shlex.quote(k+'='+v) for k,v in env.items())+' '+shlex.join(args))


if __name__=='__main__':main()
