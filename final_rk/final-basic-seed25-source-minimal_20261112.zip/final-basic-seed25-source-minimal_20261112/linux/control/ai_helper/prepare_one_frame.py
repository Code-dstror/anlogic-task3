#!/usr/bin/env python3
"""Prepare one owned packed 1080p NV12 file for the existing EOF-driven runner.

Importing this module loads no candidate, RGA, RKNN, OpenCV or NumPy module.
Only the CLI loads the explicitly selected, manifest-checked candidate bridge.
The injected function is host-testable and never proves hardware qualification.
No decoder, CPU color conversion/resize, model change or runner execution here.
"""
import argparse
from dataclasses import dataclass
import hashlib
import importlib.util
import json
import math
import mmap
import os
from pathlib import Path
import stat
import sys
import time

WIDTH, HEIGHT = 1920, 1080
NV12_BYTES = WIDTH * HEIGHT * 3 // 2
SHAPES = {'source_bgr': (HEIGHT, WIDTH, 3), 'source_rgb': (HEIGHT, WIDTH, 3),
          'detector_rgb': (640, 640, 3), 'depth_rgb': (640, 640, 3)}
SOURCE_FIELDS = ('session', 'epoch', 'sequence', 'camera', 'kind', 'format', 'role')


def uint(name, value, bits=32, minimum=0):
    if type(value) is not int or not minimum <= value < 2**bits:
        raise ValueError(f'{name}: explicit uint{bits} >= {minimum} required')


@dataclass(frozen=True)
class SourceIdentity:
    session: int
    epoch: int
    sequence: int
    camera: int
    kind: int
    format: int
    role: int

    def values(self):
        for name in SOURCE_FIELDS:
            uint(name, getattr(self, name), minimum=1 if name in ('session', 'epoch') else 0)
        return tuple(getattr(self, name) for name in SOURCE_FIELDS)


@dataclass(frozen=True)
class Timestamp:
    domain: str
    pts: int | None = None
    time_base_num: int | None = None
    time_base_den: int | None = None
    received_monotonic_ns: int | None = None
    owner_original_receive_confirmed: bool = False

    def timestamp_ns(self, now_ns):
        if self.domain == 'RECORDED_PTS':
            if self.received_monotonic_ns is not None or self.owner_original_receive_confirmed is not False:
                raise ValueError('saved fixture cannot claim a live receive timestamp')
            uint('recorded pts', self.pts, 64)
            uint('time base numerator', self.time_base_num, minimum=1)
            uint('time base denominator', self.time_base_den, minimum=1)
            value = self.pts * self.time_base_num * 1_000_000_000 // self.time_base_den
            uint('recorded timestamp ns', value, 64)
            return value
        if self.domain == 'CLOCK_MONOTONIC':
            if any(value is not None for value in (self.pts, self.time_base_num, self.time_base_den)):
                raise ValueError('live receive cannot substitute recorded PTS')
            if self.owner_original_receive_confirmed is not True:
                raise ValueError('only the true owner may confirm ORIGINAL receive time')
            uint('original receive ns', self.received_monotonic_ns, 64, 1)
            if self.received_monotonic_ns > now_ns:
                raise ValueError('original receive timestamp is in the future')
            return self.received_monotonic_ns
        raise ValueError('explicit RECORDED_PTS or CLOCK_MONOTONIC required')


class PreparationFailure(RuntimeError):
    """No manifest was published. Retain this exception if close is UNKNOWN."""
    def __init__(self, message, *, slots=None, rga=None, close_unknown=False):
        super().__init__(message)
        self.slots, self.rga, self.close_unknown = slots, rga, close_unknown


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as target:
        target.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def _close_mappings(slots):
    # Slots has no close API. These are independent disk-backed file mappings;
    # no consumer exists yet, and successful RGA.close has already retired RGA.
    seen = set()
    for array in slots.files.values():
        mapping = getattr(array, '_mmap', None)
        if mapping is None and isinstance(array, mmap.mmap):
            mapping = array
        if mapping is not None and id(mapping) not in seen:
            mapping.close()
            seen.add(id(mapping))


def prepare_one_frame(input_path, output, *, source, timestamp, color_profile,
                      color_evidence, origin, origin_description,
                      rga_library, slots_factory, rga_factory,
                      descriptor_factory, request_version=2, token=1,
                      environment=None, monotonic_ns=time.monotonic_ns,
                      perf_counter_ns=time.perf_counter_ns,
                      runner_entry=None,
                      backend_scope='INJECTED_TEST_ONLY_NOT_RGA_QUALIFIED'):
    """Copy bytes, invoke shared RGA once, close it, then publish one V2 line.

    Factories must implement candidate Slots/Rga APIs. prepare must synchronously
    retire its native operations; close must synchronously confirm destruction.
    An unknown close retains its resource bundle in PreparationFailure and is
    never retried. Source/color declarations remain caller evidence, not claims
    established by this file. Saved fixtures MUST use RECORDED_PTS.
    """
    if type(source) is not SourceIdentity or type(timestamp) is not Timestamp:
        raise TypeError('immutable explicit source and timestamp required')
    if origin not in ('file_fixture', 'recorded_fpga', 'owner_live'):
        raise ValueError('explicit file_fixture, recorded_fpga or owner_live origin required')
    if type(origin_description) is not str or not 1 <= len(origin_description) <= 1024:
        raise ValueError('explicit bounded original-image provenance description required')
    expected_clock = 'CLOCK_MONOTONIC' if origin == 'owner_live' else 'RECORDED_PTS'
    if timestamp.domain != expected_clock:
        raise ValueError('saved fixture origin requires RECORDED_PTS; only actual owner_live may use receive time')
    identity = source.values()
    stamp = timestamp.timestamp_ns(monotonic_ns())
    uint('association token', token, 64, 1)
    if type(request_version) is not int or request_version != 2:
        raise ValueError('existing bridge request version 2 required')
    if color_profile != 'bt601_full':
        raise ValueError('bridge supports only explicitly confirmed actual BT601 full NV12')
    if type(color_evidence) is not str or not 1 <= len(color_evidence) <= 512:
        raise ValueError('explicit actual source-color evidence required')
    env = os.environ if environment is None else environment
    if env.get('Y26_RGB_SWAP_NATIVE') != '0':
        raise ValueError('explicit Y26_RGB_SWAP_NATIVE=0 required; CPU swap forbidden')
    input_path, output, rga_library = Path(input_path), Path(output), Path(rga_library)
    if input_path.is_symlink() or not input_path.is_file():
        raise ValueError('owned regular NV12 file required, not a symlink')
    with input_path.open('rb') as original:
        info = os.fstat(original.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size != NV12_BYTES:
            raise ValueError(f'exactly {NV12_BYTES} bytes of packed 1920x1080 NV12 required')
        payload = original.read(NV12_BYTES + 1)
    if len(payload) != NV12_BYTES:
        raise ValueError('NV12 file length changed while reading')
    if not rga_library.is_file():
        raise ValueError('explicit existing prepared RGA library required')
    source_sha, library_sha = hashlib.sha256(payload).hexdigest(), digest(rga_library)
    output.mkdir(parents=True, exist_ok=False)  # never overwrite any prior trial
    output = output.resolve()
    slots = rga = None
    close_unknown = False
    report = dict(schema='Y26_ONE_FRAME_PREPARATION_V1', status='FAILED',
                  backend_scope=backend_scope, input=str(input_path.resolve()),
                  input_bytes=NV12_BYTES, input_sha256=source_sha,
                  source=dict(zip(SOURCE_FIELDS, identity)),
                  origin=origin, origin_description=origin_description,
                  source_provenance=('OWNER_DECLARATION_NOT_WIRE_ADMISSION' if origin == 'owner_live'
                                     else 'FILE_ASSOCIATION_LABELS_ONLY_NOT_LIVE_CAMERA_IDENTITY'),
                  clock_domain=timestamp.domain, color_profile=color_profile,
                  color_evidence=color_evidence,
                  rga_library=str(rga_library.resolve()), rga_library_sha256=library_sha,
                  policy=dict(route='lc64', depth_size=640, shared_rgb=True,
                              rgb_swap_native='0', cpu_color_or_resize_fallback=False),
                  warmup_inferences_per_model=20, input_frames=1,
                  scope='single saved/owned frame, not continuous video or production Gst qualification')
    try:
        slots = slots_factory(output / 'slots', depth_size=640, shared_rgb=True)
        if slots.shared_rgb is not True or slots.depth_size != 640:
            raise ValueError('shared V2 RGB and depth640 required')
        if {name: tuple(shape) for name, shape in slots.sizes.items()} != SHAPES:
            raise ValueError('candidate tensor geometry mismatch')
        with memoryview(slots.files[0, 'nv12']) as source_view:
            with source_view.cast('B') as target:
                if target.nbytes != NV12_BYTES:
                    raise ValueError('packed NV12 slot size mismatch')
                target[:] = payload  # byte copy only; never color conversion
        slots.admit(0, token)
        rga = rga_factory(rga_library.resolve(), shared_rgb=True)
        begin = perf_counter_ns()
        timings = rga.prepare(slots, 0, False)  # False selects LC64 stretch depth
        report['prepare_call_wall_ms'] = (perf_counter_ns() - begin) / 1e6
        if (type(timings) is not dict or any(type(key) is not str for key in timings)
                or any(type(value) not in (int, float) or not math.isfinite(value)
                       or value < 0 for value in timings.values())):
            raise ValueError('finite nonnegative RGA timings/facts required')
        report['upstream_timings_and_facts'] = timings
        for array in slots.files.values():
            flush = getattr(array, 'flush', None)
            if flush is not None:
                flush()
        # No descriptor (and therefore no true fence_complete) before close.
        close_unknown = True
        rga.close()
        if getattr(rga, 'h', None) is not None:
            raise RuntimeError('RGA close did not confirm a cleared handle')
        close_unknown = False
        report['rga_close_confirmed'] = True
        # descriptor requires a positive temporary interval. Recorded values
        # are rewritten below: none is exposed as a Linux receive timestamp.
        received = stamp if timestamp.domain == 'CLOCK_MONOTONIC' else max(1, stamp)
        published = monotonic_ns() if timestamp.domain == 'CLOCK_MONOTONIC' else received
        request = (request_version, 0, token, received, published, *identity)
        desc = descriptor_factory(slots, request, False, timings)
        key = ':'.join(map(str, (source.session, source.epoch, source.camera,
                               source.sequence, source.kind, source.format, source.role)))
        if (desc.get('schema') != 'Y26_PREPARED_FRAME_V2' or desc.get('source') != report['source']
                or desc.get('frame_key') != key or desc.get('original_frame_key') != key
                or desc.get('association_token') != token or desc.get('slot') != 0
                or desc.get('shared_rgb_relation') != 'BGR_CHANNEL_PERMUTATION'):
            raise ValueError('descriptor must bind exactly this one V2 SOURCE frame')
        desc.update(clock_domain=timestamp.domain, capture_timestamp_ns=stamp,
                    input_color_profile=color_profile, input_color_evidence=color_evidence,
                    input_origin=origin, input_origin_description=origin_description,
                    source_identity_status=report['source_provenance'])
        if timestamp.domain == 'RECORDED_PTS':
            desc.update(received_monotonic_ns=None, published_monotonic_ns=None,
                        original_video_pts=timestamp.pts,
                        original_video_time_base=dict(num=timestamp.time_base_num, den=timestamp.time_base_den),
                        source_timestamp_kind='recorded_pts',
                        timestamp_alias_note='capture_timestamp_ns is recorded PTS in ns; NOT live receive or sensor capture')
        else:
            desc.update(source_timestamp_kind='linux_receive', received_monotonic_ns=stamp,
                        published_monotonic_ns=published,
                        owner_original_receive_confirmed=True)
        for name, shape in SHAPES.items():
            tensor = desc[name]
            expected = (slots.root / f'0_{name}.bin').resolve()
            size = math.prod(shape)
            if (Path(tensor['path']).resolve() != expected or tuple(tensor['shape']) != shape
                    or tensor['frame_key'] != key or expected.stat().st_size != size
                    or tensor.get('backing_bytes') != size or tensor.get('offset_bytes') != 0
                    or tuple(tensor.get('strides_bytes', ())) != (shape[1] * 3, 3, 1)
                    or tensor.get('color') != ('BGR' if name == 'source_bgr' else 'RGB')):
                raise ValueError('descriptor references wrong tensor frame, geometry, color or path')
            tensor.update(capture_timestamp_ns=stamp, fence_complete=True)
        _close_mappings(slots)
        report.update(status='PREPARED_ONE_FRAME_NOT_NPU_RUN', frame_key=key,
                      prepared_manifest=str(output / 'prepared.jsonl'),
                      acks=str(output / 'acks.jsonl'), descriptor=desc,
                      runner_template=dict(entry=(str(Path(runner_entry).resolve()) if runner_entry else
                                                 'EXPLICIT_CANDIDATE/src/ai/y26_rk_app/runner.py'),
                          arguments=['--route', 'lc64', '--depth-size', '640',
                                     '--prepared-manifest', str(output / 'prepared.jsonl'),
                                     '--acks', str(output / 'acks.jsonl'), '--output', str(output / 'runner-output-NEW')],
                          environment={'Y26_RGB_SWAP_NATIVE': '0'},
                          audio_enabled=False,
                          additional_required=['--detector', '--depth', '--library', '--roi-library'],
                          note='normal JSONL EOF gives one input frame after 20 warmups PER MODEL; no runner execution here'))
        _write_json(output / 'preparation-report.json', report)
        (output / 'acks.jsonl').touch(exist_ok=False)
        with (output / 'prepared.jsonl').open('x', encoding='utf-8') as manifest:
            manifest.write(json.dumps(desc, allow_nan=False) + '\n')
        return report
    except Exception as exc:
        if rga is not None and not report.get('rga_close_confirmed') and not close_unknown:
            close_unknown = True
            try:
                rga.close()
                if getattr(rga, 'h', None) is not None:
                    raise RuntimeError('RGA close did not clear handle')
                close_unknown = False
                report['rga_close_confirmed'] = True
            except Exception as cleanup:
                report['close_error'] = str(cleanup)[:512]
        if slots is not None and not close_unknown:
            try:
                _close_mappings(slots)
            except Exception as cleanup:
                report['mapping_close_error'] = str(cleanup)[:512]
        report.update(status='FAILED_NO_MANIFEST', error=str(exc)[:512], close_unknown=close_unknown)
        if not (output / 'preparation-report.json').exists():
            _write_json(output / 'preparation-report.json', report)
        raise PreparationFailure(str(exc), slots=slots, rga=rga,
                                 close_unknown=close_unknown) from exc


def load_candidate_bridge(candidate):
    """Load this exact checked candidate; reject preloaded foreign support code."""
    candidate = Path(candidate).resolve(strict=True)
    app, depth = candidate / 'src/ai/y26_rk_app', candidate / 'src/ai/y26_depth_app'
    relative = 'src/ai/y26_rk_app/linux_bridge.py'
    record = json.loads((candidate / 'LINUX_CANDIDATE.json').read_text())
    matches = [item['candidate_sha256'] for item in record['overlay'] if item['path'] == relative]
    if len(matches) != 1 or digest(candidate / relative) != matches[0]:
        raise ValueError('explicit candidate bridge differs from its reviewed manifest')
    dependencies = {'model_preprocessing': depth / 'model_preprocessing.py',
                    'depth_preprocessing': depth / 'depth_preprocessing.py',
                    'linux_display': app / 'linux_display.py', 'result_adapter': app / 'result_adapter.py'}
    for name, expected in dependencies.items():
        if name in sys.modules and Path(getattr(sys.modules[name], '__file__', '')).resolve() != expected:
            raise RuntimeError(f'foreign preloaded {name}; use a fresh interpreter')
    sys.path[:0] = [str(app), str(depth)]
    spec = importlib.util.spec_from_file_location('_one_frame_explicit_candidate_bridge', candidate / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for name, expected in dependencies.items():
        if name in sys.modules and Path(sys.modules[name].__file__).resolve() != expected:
            raise RuntimeError(f'candidate imported foreign {name}')
    return module


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('candidate', 'input-nv12', 'output', 'rga-library'):
        parser.add_argument('--' + name, required=True, type=Path)
    for name in SOURCE_FIELDS:
        parser.add_argument('--' + name, required=True, type=int)
    parser.add_argument('--token', type=int, required=True)
    parser.add_argument('--color-profile', choices=['bt601_full'], required=True)
    parser.add_argument('--color-evidence', required=True)
    parser.add_argument('--origin', choices=['file_fixture', 'recorded_fpga', 'owner_live'], required=True)
    parser.add_argument('--origin-description', required=True)
    parser.add_argument('--clock-domain', choices=['RECORDED_PTS', 'CLOCK_MONOTONIC'], required=True)
    for name in ('pts', 'time-base-num', 'time-base-den', 'received-monotonic-ns'):
        parser.add_argument('--' + name, type=int)
    parser.add_argument('--owner-original-receive-confirmed', action='store_true')
    args = parser.parse_args(argv)
    bridge = load_candidate_bridge(args.candidate)
    report = prepare_one_frame(args.input_nv12, args.output,
        source=SourceIdentity(*(getattr(args, name) for name in SOURCE_FIELDS)),
        timestamp=Timestamp(args.clock_domain, args.pts, args.time_base_num,
                            args.time_base_den, args.received_monotonic_ns,
                            args.owner_original_receive_confirmed),
        color_profile=args.color_profile, color_evidence=args.color_evidence,
        origin=args.origin, origin_description=args.origin_description,
        rga_library=args.rga_library, token=args.token, slots_factory=bridge.Slots,
        rga_factory=bridge.Rga, descriptor_factory=bridge.descriptor, request_version=bridge.VERSION,
        runner_entry=args.candidate / 'src/ai/y26_rk_app/runner.py',
        backend_scope='EXPLICIT_CANDIDATE_RGA_CALLS_NOT_LIVE_PIPELINE_QUALIFICATION')
    print(json.dumps({key: report[key] for key in ('status', 'prepared_manifest', 'acks', 'warmup_inferences_per_model')}))


if __name__ == '__main__':
    main()
