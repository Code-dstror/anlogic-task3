"""One cold CAMERA_RAW owner; bounded mode transactions, unlimited session."""
from collections import deque
from dataclasses import asdict
import threading
import time

try:
    from .unified_stereo_owner import StereoOwner
    from .camera_raw_protocol import ColdSession,Router
    from .camera_raw_preview import CameraPreview
    from .display_record_seal import durable_json
except ImportError:
    from unified_stereo_owner import StereoOwner
    from camera_raw_protocol import ColdSession,Router
    from camera_raw_preview import CameraPreview
    from display_record_seal import durable_json


class CameraOwner(StereoOwner):
    def __init__(self,receiver,config,*,boot,run,stop_event,broker,preview_factory=CameraPreview,
                 storage_prepare=None,clock=time.monotonic,reader_factory=None,cold_factory=None):
        self.cameras,self.product=config['cameras'],config['product']
        self.held=deque();self.mode_pending=None;self.command=None;self.grace_deadline=0
        factory=cold_factory or (lambda r,**kw:ColdSession(r,session=config['cold_session'],on_admitted=kw['on_admitted'],evidence=kw.get('evidence')))
        super().__init__(receiver,config,boot=boot,run=run,stop_event=stop_event,broker=broker,
            preview_factory=preview_factory,storage_prepare=storage_prepare,clock=clock,reader_factory=reader_factory,
            cold_factory=factory,profile='camera-raw-r2-seed25-'+config['cold_session'])

    def _storage(self,caps):
        if self.product=='raw':
            if self.stop_event.is_set():raise RuntimeError('stop requested before RAW cold selection')
            durable_json(self.run_dir/'storage-ready.json',dict(status='NOT_APPLICABLE_RAW_RECEIVE_ONLY'))
        else:super()._storage(caps)

    def _accept(self,wire,kwargs):
        item=self.router.feed(wire,**kwargs);return item,kwargs['host_ns']

    def feed(self,wire,*,host_ns=None,transport_identity=None,completion_metadata=None):
        from dual_host.camera_shared import AwaitingApplied
        kwargs=dict(host_ns=host_ns,transport_identity=transport_identity,completion_metadata=completion_metadata)
        if not self.held:
            try:return self._accept(wire,kwargs)
            except AwaitingApplied:pass
        if len(self.held)>=self.receiver.snapshot().slots:raise RuntimeError('unconfirmed copies exceed actual native slot count')
        self.held.append((wire,kwargs,self.clock()));return dict(kind='CFG_AWAITING_APPLIED')

    def _deliver(self,event,display):
        if isinstance(event,dict):
            if event.get('kind')=='CFG_AWAITING_APPLIED':return
            from linux.dma_c2h_candidate.c2h_abi import RESULT_CANCELLED
            if display or event.get('kind')!='TRANSPORT_RESULT' or event.get('result')!=RESULT_CANCELLED:
                raise RuntimeError('unexpected negative CAMERA_RAW completion')
            return
        item,received=event;self.last_rx[item.camera]=self.clock()
        if display and self.preview is not None:self.preview.submit(item,received)

    def _poll(self,display):
        from dual_host.camera_shared import AwaitingApplied
        while self.held:
            wire,kwargs,began=self.held[0]
            if self.clock()-began>self.config.get('mode_confirmation_s',30):raise TimeoutError('unconfirmed epoch copy deadline exceeded')
            try:event=self._accept(wire,kwargs)
            except AwaitingApplied:break
            self.held.popleft();self._deliver(event,display)
        available=self.receiver.snapshot().slots-len(self.held)
        if available:
            self.reader.maximum_batch=min(2,available)
            for event in self.reader.poll_once(.01):self._deliver(event,display)
        elif self.command is not None:
            self.command['done'].wait(.005)

    def _drain_host(self):
        super()._drain_host()
        if self.held:self.drained=False;raise RuntimeError('unconfirmed record copies retained after host drain')

    def _start_mode(self,request):
        if self.command is not None or self.mode_pending is not None:raise RuntimeError('one mode transaction at a time')
        done=threading.Event();self.command=dict(done=done,request=request,value=None,error=None)
        state=self.command
        def apply():
            try:state['value']=self.cold.apply(request['mode'])
            except BaseException as error:state['error']=type(error).__name__+': '+str(error)[:512]
            finally:done.set()
        self.grace_deadline=self.clock()+self.config.get('mode_confirmation_s',30)
        self.preview.transition_until(time.monotonic_ns()+int(self.config.get('mode_confirmation_s',30)*1e9))
        self.command['thread']=threading.Thread(target=apply,name='camera-raw-cfg',daemon=True)
        self._event('MODE_REQUEST',request_id=request['request_id'],mode=request['mode']);self.command['thread'].start()

    def _configuration_applied(self,request,receipt):
        self._event('MODE_APPLIED',request_id=request['request_id'],receipt=asdict(receipt))
        return self.broker.mode_applied(request['request_id'],receipt.mode_epoch)

    def _configuration_video(self,request_id,epoch,rendered):
        if self.broker.completed_mode(request_id,epoch,rendered['ordinal']):
            self._event('MODE_VIDEO_CONFIRMED',mode_epoch=epoch,ordinal=rendered['ordinal'])
        return True

    def _control(self,preview):
        broker=self.broker;broker.heartbeat_update()
        if broker.check_timeout():raise TimeoutError('CAMERA_RAW command confirmation deadline exceeded')
        if self.command is not None and self.command['done'].is_set():
            result=self.command;self.command=None
            if result['error']:raise RuntimeError(result['error'])
            receipt=result['value']
            if not self.stop_event.is_set():
                if self._configuration_applied(result['request'],receipt):
                    self.mode_pending=(result['request']['request_id'],receipt.mode_epoch)
            else:
                self._event('MODE_APPLIED',request_id=result['request']['request_id'],receipt=asdict(receipt))
        if self.stop_event.is_set():return
        if self.product=='raw':
            if not self.ready and all(self.last_rx[c] is not None for c in range(self.cameras)):
                self.ready=broker.started_raw()
            return
        hud=preview.get('hud') or {};rendered=preview.get('rendered') or {}
        if not self.ready and hud.get('frames',0)>0 and hud.get('revision')==1 and hud.get('layout')==1:
            self.ready=broker.started(1,hud['frames'],layout='cam0')
        if self.mode_pending is not None:
            request_id,epoch=self.mode_pending
            visible=range(self.cameras) if rendered.get('layout')=='both' else (0 if rendered.get('layout')=='cam0' else 1,)
            rows={r['camera']:r for r in rendered.get('cameras',[])}
            seen=self.cold.profiles.status()['seen_cameras']
            if (set(seen)==set(range(self.cameras)) and all(c in rows and rows[c]['epoch']==epoch for c in visible)):
                if self._configuration_video(request_id,epoch,rendered):
                    self.mode_pending=None;self.grace_deadline=0;self.preview.transition_until(0)
        if self.pending_layout is not None and hud.get('revision')==self.pending_layout[1] and hud.get('layout')==('both','cam0','cam1').index(self.pending_layout[2]):
            broker.completed(self.pending_layout[0],hud['revision'],hud['frames']);self.pending_layout=None
        if self.stop_event.is_set():return
        request=broker.take()
        if request is None:return
        if request['action']=='mode':self._start_mode(request)
        else:
            self.layout_revision+=1;self.preview.request_layout(request['layout'],self.layout_revision)
            self.pending_layout=(request['request_id'],self.layout_revision,request['layout'])
            self._event('LAYOUT_REQUEST',request_id=request['request_id'],layout=request['layout'],layout_revision=self.layout_revision)

    def run(self):
        if self.state!='NEW':raise RuntimeError('one CAMERA_RAW cold session only; no hot reopen')
        self.state='PREPARING';preview_attempted=False;last_publish=0
        try:
            self.receipt=self.cold.prepare();durable_json(self.run_dir/'cold-preparation.json',self.receipt);self._event('COLD_SELECTION_ACK')
            if self.stop_event.is_set():self.state='STOPPED_BEFORE_START_RETAINED';return self.snapshot()
            self.router=Router(self.cold,self.run_dir)
            if self.reader_factory is None:
                try:from .stereo_owned_record_reader import MetadataOwnedRecordReader
                except ImportError:from stereo_owned_record_reader import MetadataOwnedRecordReader
                self.reader_factory=MetadataOwnedRecordReader
            self.reader=self.reader_factory(self.receiver,self,maximum_batch=2,record_budget=None)
            if self.product=='jpeg':
                self.preview=self.preview_factory(self.run_dir/'preview',self.config,boot=self.boot);preview_attempted=True;self.preview.start()
            if self.stop_event.is_set():self.state='STOPPED_BEFORE_START_RETAINED';return self.snapshot()
            self._event('START_CALL');self.start_intent=True;self.started=self.clock();self.receiver.start();self.start_returned=True;self._event('START_RETURN');self.state='RUNNING'
            while not self.stop_event.is_set() or self.command is not None:
                self._poll(not self.stop_event.is_set())
                if self.preview is not None:self.preview.check()
                self._control({} if self.preview is None else self.preview.snapshot());now=self.clock()
                if self.command is not None and now>self.grace_deadline:raise TimeoutError('control IO still in flight; owner retained')
                if now-self.started>5 and now>=self.grace_deadline and any(self.last_rx[c] is None or now-self.last_rx[c]>3 for c in range(self.cameras)):
                    raise TimeoutError('CAMERA_RAW eye stopped delivering complete records')
                if now-last_publish>=1:self._publish();last_publish=now
            self.state='DRAINING';self._stop_once();self._drain_host();self.state='DRAINED_RETAINED'
        except BaseException as error:
            self.failure=type(error).__name__+': '+str(error)[:512];self.state='FAULTED_RETAINED';self.stop_event.set()
            command_live=self.command is not None and not self.command['done'].is_set()
            if self.start_intent and not self.stop_intent and not command_live:
                try:self._stop_once()
                except BaseException as failure:self.evidence_error=self.evidence_error or str(failure)[:512]
            if (self.start_returned and self.stop_returned and not self.host_drain_attempted and self.reader is not None and self.reader.fault is None):
                try:self._drain_host()
                except BaseException as failure:self.fault_drain_failure=type(failure).__name__+': '+str(failure)[:512]
                finally:self.state='FAULTED_RETAINED'
        finally:
            if preview_attempted:
                try:self.final_preview=self.preview.close(timeout_s=15)
                except BaseException as error:self.failure=self.failure or str(error)[:512];self.state='FAULTED_RETAINED'
                if self.final_preview and (self.final_preview.get('failure') or not self.final_preview.get('worker_done')):
                    self.failure=self.failure or self.final_preview.get('failure') or 'display worker retained pending';self.state='FAULTED_RETAINED'
            self.stop_event.set()
            if self.evidence_error is not None:self.failure=self.failure or self.evidence_error;self.state='FAULTED_RETAINED'
            self.broker.stopped(self.failure);self._publish();self.events.close()
        return self.snapshot()

    def snapshot(self):
        result=super().snapshot();result.update(cold_session=self.config['cold_session'],held_records=len(self.held),
            mode_io_inflight=self.command is not None and not self.command['done'].is_set(),
            raw_scope='COMPLETE_ARAW_TRANSPORT_ONLY_NO_ISP_NO_HDMI' if self.product=='raw' else None)
        return result
