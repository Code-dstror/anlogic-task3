"""Persistent prepared runner owner, isolated from FPGA and display ownership.

No library/device is loaded on import, construction or start's caller thread.
One background owner serializes private MPP, mandatory RGA and runner leases.
At most one offered JPEG, one native in-flight frame and one result are kept.
An uncertain retirement retains that owner; there is no kill or directory reuse.
"""
from dataclasses import dataclass
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import select
import subprocess
import sys
import threading
import time

NV12_BYTES = 1920 * 1080 * 3 // 2
MAX_RECORD = 1024 * 1024
SOURCE_FIELDS = ('session', 'epoch', 'sequence', 'camera', 'kind', 'format', 'role')
MANDATORY_RGA_SHA256 = '0244cf2e23c985deeb773e01f67b132ec89141505c9a1e5842ae58e57fc6c556'


def _uint(name, value, bits=32, minimum=0):
    if type(value) is not int or not minimum <= value < 2**bits:
        raise ValueError(f'{name}: explicit uint{bits} >= {minimum} required')


@dataclass(frozen=True)
class FrameIdentity:
    source: tuple
    receiver_cohort: str
    jpeg_generation: int
    token: int

    def __post_init__(self):
        if type(self.source) is not tuple or len(self.source) != 7:
            raise ValueError('immutable seven-field SOURCE required')
        for name, value in zip(SOURCE_FIELDS, self.source):
            _uint(name, value, minimum=1 if name in ('session', 'epoch') else 0)
        if (type(self.receiver_cohort) is not str or not 1 <= len(self.receiver_cohort) <= 64
                or any(not 33 <= ord(c) <= 126 for c in self.receiver_cohort)):
            raise ValueError('explicit bounded ASCII receiver cohort required')
        _uint('jpeg_generation', self.jpeg_generation, minimum=1)
        _uint('token', self.token, 64, 1)

    @property
    def context(self):
        return (self.receiver_cohort, *self.source[:2], *self.source[3:])

    @property
    def frame_key(self):
        s, e, sequence, camera, kind, fmt, role = self.source
        return ':'.join(map(str, (s, e, camera, sequence, kind, fmt, role)))


@dataclass(frozen=True)
class OfferedFrame:
    generation: int
    identity: FrameIdentity
    host_received_ns: int
    jpeg: bytes


@dataclass(frozen=True)
class CompletedFrame:
    generation: int
    identity: FrameIdentity
    host_received_ns: int
    nv12: bytes
    linux_result: dict
    boxes: tuple
    mpp_details: dict


@dataclass(frozen=True)
class SessionSnapshot:
    state: str
    generation: int
    ready: bool
    accepting: bool
    queued: int
    inflight: int
    results: int
    retained: bool
    worker_alive: bool
    error: str | None
    warmup_inferences_per_model: int = 20


class RetainedError(RuntimeError):
    """Native/resource completion is unknown. Preserve the original owner."""


class PreparedSession:
    """Nonblocking control API; backend_factory/initialize run on the worker.

    Backend contract: initialize(stop_requested), process(OfferedFrame),
    retire()->bool, and optionally retained/error properties. Retire may poll a
    known PENDING child but must never retry an uncertain native destructor.
    All process completions must own immutable tight 1080p NV12 bytes.
    The factory must allocate only its Python backend object; resource creation
    belongs to initialize so partial resources always have an owning backend.
    Caller checks generation and original receive age again before presentation.
    """
    def __init__(self, generation, directory, *, backend_factory,
                 max_duration_s=None, clock_ns=time.monotonic_ns):
        _uint('AI generation', generation, 64, 1)
        if max_duration_s is not None and (type(max_duration_s) not in (int, float) or not 0 < max_duration_s <= 180):
            raise ValueError('session duration must be positive and at most180 seconds')
        self.generation, self.directory = generation, Path(directory)
        self._factory, self._clock, self._duration = backend_factory, clock_ns, max_duration_s
        self._lock = threading.Lock()
        self._wake, self._stop = threading.Event(), threading.Event()
        self._thread = self._backend = None
        self._state, self._ready, self._accepting = 'NEW', False, False
        self._queued = self._result = self._current = None
        self._context = None
        self._last_token = self._last_received = 0
        self._last_sequence = -1
        self._started_ns = None
        self._error = None
        self._retained = False

    def start(self):
        with self._lock:
            if self._state != 'NEW':
                raise RuntimeError('session is single-use; create a fresh generation/directory')
            self._state, self._accepting = 'STARTING', True
            self._started_ns = self._clock()
            self._thread = threading.Thread(target=self._run, name=f'prepared-ai-{self.generation}', daemon=False)
            self._thread.start()
        return self.snapshot()

    def snapshot(self):
        with self._lock:
            self._expire_locked()
            return SessionSnapshot(self._state, self.generation,
                self._ready and not self._stop.is_set(), self._accepting,
                int(self._queued is not None), int(self._current is not None),
                int(self._result is not None), self._retained,
                self._thread is not None and self._thread.is_alive(), self._error)

    def offer(self, jpeg, identity, host_received_ns):
        if type(jpeg) is not bytes or not 4 <= len(jpeg) <= 4 * 1024 * 1024:
            raise ValueError('bounded immutable owned JPEG bytes required')
        if type(identity) is not FrameIdentity:
            raise TypeError('immutable FrameIdentity required')
        _uint('original host receive ns', host_received_ns, 64, 1)
        if host_received_ns > self._clock():
            raise ValueError('original receive time cannot be in the future')
        with self._lock:
            self._expire_locked()
            if not self._accepting or self._stop.is_set():
                return False
            if (self._context is not None and identity.context != self._context):
                self._fail_locked('source context changed; fresh AI generation required')
                return False
            if (identity.token <= self._last_token or (self._last_sequence >= 0 and not 0 < ((identity.source[2] - self._last_sequence) & 0xffffffff) < 0x80000000)
                    or host_received_ns <= self._last_received):
                return False
            self._context = identity.context
            self._last_token, self._last_sequence, self._last_received = (
                identity.token, identity.source[2], host_received_ns)
            self._queued = OfferedFrame(self.generation, identity, host_received_ns, jpeg)
        self._wake.set()
        return True

    def take_latest(self):
        with self._lock:
            self._expire_locked()
            result, self._result = self._result, None
            return None if self._stop.is_set() else result

    def request_stop(self):
        with self._lock:
            self._accepting = self._ready = False
            self._queued = self._result = None
            self._stop.set()
            if self._state == 'NEW':
                self._state = 'CLOSED'
            elif self._state != 'CLOSED':
                self._state = 'DRAINING'
        self._wake.set()

    def poll_retired(self):
        # Only true after all backend resources are definitely retired. Joining
        # a possibly active worker is never a control-thread operation.
        with self._lock:
            self._expire_locked()
            return self._state == 'CLOSED'

    def _expire_locked(self):
        if (self._duration is not None and self._started_ns is not None and not self._stop.is_set()
                and self._clock() - self._started_ns >= self._duration * 1e9):
            self._accepting = self._ready = False
            self._queued = self._result = None
            self._stop.set()
            self._state = 'DRAINING'
            self._wake.set()

    def _fail_locked(self, error):
        self._error = str(error)[:512]
        self._accepting = self._ready = False
        self._queued = self._result = None
        self._stop.set()
        self._state = 'DRAINING'
        self._wake.set()

    def _run(self):
        started = self._started_ns
        try:
            self._backend = self._factory(self.directory, self.generation)
            self._backend.initialize(self._stop.is_set)
            with self._lock:
                if not self._stop.is_set():
                    self._ready, self._state = True, 'READY'
            while not self._stop.is_set():
                if self._duration is not None and self._clock() - started >= self._duration * 1e9:
                    self.request_stop()
                    break
                with self._lock:
                    frame, self._queued = self._queued, None
                    self._current = frame
                if frame is None:
                    self._wake.wait(.02)
                    self._wake.clear()
                    continue
                result = self._backend.process(frame)
                if (type(result) is not CompletedFrame or result.generation != self.generation
                        or result.identity != frame.identity
                        or result.host_received_ns != frame.host_received_ns
                        or type(result.nv12) is not bytes or len(result.nv12) != NV12_BYTES):
                    raise RetainedError('backend returned a cross-frame/generation or unowned result')
                with self._lock:
                    self._current = None
                    if not self._stop.is_set():
                        self._result = result
        except BaseException as error:
            with self._lock:
                self._fail_locked(error)
                self._retained = isinstance(error, RetainedError)
        finally:
            with self._lock:
                self._accepting = self._ready = False
                self._queued = self._result = None
                self._state = 'DRAINING'
            while True:
                try:
                    closed = self._backend is None or self._backend.retire()
                    with self._lock:
                        self._retained = bool(getattr(self._backend, 'retained', False)) or self._retained
                        if self._error is None and getattr(self._backend, 'error', None):
                            self._error = str(self._backend.error)[:512]
                        if closed:
                            self._current = None
                            self._retained = False
                            self._state = 'CLOSED'
                            return
                        self._state = 'RETAINED' if self._retained else 'DRAINING'
                except BaseException as error:
                    with self._lock:
                        self._error = str(error)[:512]
                        self._retained, self._state = True, 'RETAINED'
                    # An unexpected retirement exception has unknown effects.
                    # Never invoke that destructor/poller again.
                    while True:
                        self._wake.wait(.1)
                        self._wake.clear()
                self._wake.wait(.02)
                self._wake.clear()


@dataclass(frozen=True)
class CandidateConfig:
    candidate: Path
    helper_root: Path
    mpp_library: Path
    rga_library: Path
    engineering_color_evidence: str
    allow_unreported_color: bool = False
    duration_s: int = 0
    startup_timeout_s: int = 90

    def __post_init__(self):
        if type(self.duration_s) is not int or not 0 <= self.duration_s <= 180:
            raise ValueError('runner duration must be0 (continuous) or1..180 seconds')
        if type(self.startup_timeout_s) is not int or not 1 <= self.startup_timeout_s <= 180:
            raise ValueError('finite startup timeout1..180 required')
        if type(self.allow_unreported_color) is not bool:
            raise ValueError('explicit unreported-color policy required')
        if type(self.engineering_color_evidence) is not str or not 1 <= len(self.engineering_color_evidence) <= 1024:
            raise ValueError('explicit checked FULL601 engineering color contract required')


class _JsonTail:
    """Bounded one-record tail for a FIFO or regular append-only JSONL file."""
    def __init__(self, fd):
        self.fd, self.buffer = fd, b''

    def read_one(self):
        if b'\n' not in self.buffer:
            try:
                chunk = os.read(self.fd, min(65536, MAX_RECORD + 1 - len(self.buffer)))
            except BlockingIOError:
                chunk = b''
            self.buffer += chunk
        newline = self.buffer.find(b'\n')
        if newline > MAX_RECORD or newline < 0 and len(self.buffer) > MAX_RECORD:
            raise RetainedError('JSONL record exceeds1MiB; owner retained')
        if newline < 0:
            return None
        line, self.buffer = self.buffer[:newline], self.buffer[newline + 1:]
        value = json.loads(line)
        if type(value) is not dict:
            raise RetainedError('JSONL object required')
        return value


def check_first_frame_color(jpeg, source_bgr, *, decode_reference=None):
    """Compare RGA BGR with a software JPEG BGR reference, for validation only.

    No reference pixel enters model inputs; no CPU NV12 conversion or resize
    occurs. Matching the checked FULL601 engineering route is not proof that
    MPP reported full-range BT601 native metadata.
    """
    import numpy as np
    if decode_reference is None:
        import cv2
        reference = cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)
    else:
        reference = decode_reference(jpeg)
    if (not isinstance(source_bgr, np.ndarray) or source_bgr.shape != (1080, 1920, 3)
            or source_bgr.dtype != np.uint8 or not isinstance(reference, np.ndarray)
            or reference.shape != source_bgr.shape or reference.dtype != np.uint8):
        raise ValueError('first JPEG/RGA color check requires matching1920x1080 uint8 BGR')
    difference = source_bgr.astype(np.float32) - reference.astype(np.float32)
    mae = float(np.abs(difference).mean())
    rmse = float(np.sqrt((difference * difference).mean()))
    return dict(schema='FIRST_LIVE_JPEG_RGA_COLOR_CHECK_V1',
        passed=bool(mae <= 3 and rmse <= 6), mae=mae, rmse=rmse,
        mae_limit=3, rmse_limit=6,
        reference='software JPEG BGR decode ONLY; pixels never feed models',
        actual='private MPP NV12 -> mandatory RGA source_bgr',
        native_metadata_proof=False,
        scope='FIRST_FRAME_ENGINEERING_FULL601_CONSISTENCY_NOT_NATIVE_COLOR_METADATA')


class CandidateBackend:
    """Worker-owned persistent runner; no algorithm/postprocessing replacement.

    The backend requires the new no-CPU-color RGA library by exact digest.
    MPP's unreported native color is accepted only through the explicit checked
    engineering contract; original raw color metadata is preserved in results.
    Default launcher audio=False; this module performs no KMS/FPGA operation.
    """
    def __init__(self, config, directory, generation, *, child_factory=subprocess.Popen,
                 color_checker=check_first_frame_color):
        self.config, self.directory, self.generation = config, Path(directory), generation
        self._child_factory = child_factory
        self._color_checker = color_checker
        self._first_color_check = None
        self._color_fault = False
        self.bridge = self.decoder = self.rga = self.slots = self.child = None
        self._input_fd = self._ack_fd = self._result_fd = None
        self._log = self._audit = None
        self._ack_tail = self._result_tail = None
        self._rga_close_attempted = self._mpp_close_attempted = False
        self._retired = self._unknown = False
        self._published = False
        self._slot = 0
        self.error = None

    @property
    def retained(self):
        return self._unknown

    @staticmethod
    def _load(path, name):
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        return module

    def initialize(self, stop_requested):
        cfg = self.config
        if os.environ.get('Y26_RGB_SWAP_NATIVE') != '0':
            raise RuntimeError('publisher requires explicit Y26_RGB_SWAP_NATIVE=0')
        if hashlib.sha256(Path(cfg.rga_library).read_bytes()).hexdigest() != MANDATORY_RGA_SHA256:
            raise RuntimeError('only the new mandatory-RGA/no-CPU-color library is allowed')
        self.directory.mkdir(parents=True, exist_ok=False)
        if stop_requested():
            return
        helper = Path(cfg.helper_root).resolve(strict=True)
        candidate = Path(cfg.candidate).resolve(strict=True)
        preparation = self._load(helper / 'prepare_one_frame.py', '_live_frame_preparation_helper')
        self.bridge = preparation.load_candidate_bridge(candidate)
        loaded = sys.modules.get('mpp_helpers.mpp_decoder')
        expected = helper / 'mpp_helpers/mpp_decoder.py'
        if loaded is not None and Path(loaded.__file__).resolve() != expected:
            raise RuntimeError('foreign MPP helper already imported')
        sys.path.insert(0, str(helper))
        from mpp_helpers.mpp_decoder import PrivateMppDecoder
        from mpp_helpers.nv12 import BT601_FULL
        try:
            self.decoder = PrivateMppDecoder(cfg.mpp_library, colorimetry=BT601_FULL,
                allow_unreported_color=cfg.allow_unreported_color)
        except BaseException as error:
            if getattr(error, 'retained_decoder', None) is not None:
                self.decoder = error.retained_decoder
                self._unknown = True
            raise
        if stop_requested():
            return
        self.slots = self.bridge.Slots(self.directory / 'slots', depth_size=640, shared_rgb=True)
        self.rga = self.bridge.Rga(cfg.rga_library, shared_rgb=True)
        if stop_requested():
            return
        manifest, acks = self.directory / 'prepared.fifo', self.directory / 'acks.fifo'
        os.mkfifo(manifest, 0o600)
        os.mkfifo(acks, 0o600)
        self._input_fd = os.open(manifest, os.O_RDWR | os.O_NONBLOCK)
        self._ack_fd = os.open(acks, os.O_RDONLY | os.O_NONBLOCK)
        self._ack_tail = _JsonTail(self._ack_fd)
        self._audit = (self.directory / 'published-prepared.jsonl').open('x', encoding='utf-8', buffering=1)
        profile = json.loads((candidate / 'fixed_profile.json').read_text())
        launcher = self._load(candidate / 'launch_fixed.py', '_live_reviewed_launcher')
        private_env, argv = launcher.command(profile, candidate / 'src', 'prepared',
            self.directory / 'runner', cfg.duration_s, manifest=manifest, acks=acks, audio=False)
        private_env['Y26_RGB_SWAP_NATIVE'] = '0'
        if not private_env.get('LD_PRELOAD') or not private_env.get('LD_LIBRARY_PATH'):
            raise RuntimeError('explicit process-private RKNN runtime environment required')
        environment = dict(os.environ)
        environment.update(private_env)
        self._log = (self.directory / 'runner.log').open('xb')
        if cfg.duration_s == 0:
            from remote_mono_ai_continuous import runner_command
            argv = runner_command(argv)
        self.child = self._child_factory(argv, env=environment, stdout=self._log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + cfg.startup_timeout_s
        while True:
            if stop_requested():
                self._close_input()
                return
            if self.child.poll() is not None:
                raise RuntimeError('runner exited during initialization; inspect shutdown proof')
            ready, frames = self.directory / 'runner/native_ready.json', self.directory / 'runner/frames.jsonl'
            if ready.is_file() and ready.stat().st_size <= MAX_RECORD and (frames.is_fifo() if cfg.duration_s == 0 else frames.is_file()):
                try:
                    info = json.loads(ready.read_text())
                except json.JSONDecodeError:
                    info = None  # write_text may still be writing its first file
                if info is not None:
                    if info.get('status') != 'NPU_CONTEXTS_READY' or info.get('warmup_inferences_per_model') != 20:
                        raise RuntimeError('unexpected runner readiness contract')
                    self._result_fd = os.open(frames, os.O_RDONLY | (os.O_NONBLOCK if cfg.duration_s == 0 else 0))
                    self._result_tail = _JsonTail(self._result_fd)
                    return
            if time.monotonic() >= deadline:
                self.error = 'runner initialization deadline; retained until real CLOSED proof'
                self._close_input()
                raise RuntimeError(self.error)
            time.sleep(.01)

    def _close_input(self):
        if self._input_fd is not None:
            fd, self._input_fd = self._input_fd, None
            os.close(fd)  # EOF after all already submitted frames; never kill

    def _write_descriptor(self, desc):
        payload = (json.dumps(desc, allow_nan=False) + '\n').encode()
        if len(payload) > MAX_RECORD:
            raise RetainedError('descriptor exceeds bounded metadata')
        offset = 0
        while offset < len(payload):
            if self.child.poll() is not None:
                raise RetainedError('runner exited while publishing; delivery unknown')
            try:
                offset += os.write(self._input_fd, payload[offset:])
            except BlockingIOError:
                select.select([], [self._input_fd], [], .02)
        self._audit.write(payload.decode())

    @staticmethod
    def _validate_pair(frame, desc, row, ack):
        source = dict(zip(SOURCE_FIELDS, frame.identity.source))
        returned = row.get('source', {})
        if type(returned) is not dict or type(returned.get('source')) is not dict:
            raise RetainedError('structured returned SOURCE required')
        if any(type(returned['source'].get(name)) is not int for name in SOURCE_FIELDS):
            raise RetainedError('SOURCE integers cannot be booleans or floats')
        for name, expected in (('source', source), ('association_token', frame.identity.token),
                ('received_monotonic_ns', frame.host_received_ns), ('capture_timestamp_ns', frame.host_received_ns),
                ('frame_key', frame.identity.frame_key), ('clock_domain', 'CLOCK_MONOTONIC'),
                ('source_timestamp_kind', 'linux_receive'), ('ai_generation', frame.generation),
                ('receiver_cohort', frame.identity.receiver_cohort), ('jpeg_generation', frame.identity.jpeg_generation)):
            if returned.get(name) != expected or type(expected) is int and type(returned.get(name)) is not int:
                raise RetainedError('runner result SOURCE/time/generation mismatch: ' + name)
        expected_ack = dict(schema='Y26_PREPARED_RELEASE_V1', slot=desc['slot'],
                            frame_key=desc['frame_key'], sequence=desc['sequence'])
        if (type(ack.get('slot')) is not int or type(ack.get('sequence')) is not int
                or any(ack.get(name) != value for name, value in expected_ack.items())):
            raise RetainedError('runner ACK does not retire this exact frame/slot')
        result = row.get('linux_result')
        if type(result) is not dict or result.get('schema') != 'AI_LINUX_RESULT_V1':
            raise RetainedError('same-frame AI_LINUX_RESULT_V1 required')
        session, epoch, sequence, camera, *_ = frame.identity.source
        expected_frame = dict(session_id=str(session), epoch=epoch, camera_id=camera,
            frame_no=sequence, frame_key=frame.identity.frame_key, timestamp_ns=frame.host_received_ns,
            clock_domain='CLOCK_MONOTONIC', timestamp_kind='linux_receive',
            original_width=1920, original_height=1080)
        if (result.get('frame') != expected_frame or any(
                type(result['frame'].get(name)) is not type(value) for name, value in expected_frame.items())):
            raise RetainedError('outward result belongs to another SOURCE/receive time')
        targets = result.get('targets')
        if type(targets) is not list or len(targets) > 300:
            raise RetainedError('bounded outward target list required')
        return result

    def _check_first_color(self, frame, slot, details):
        if self._color_fault:
            raise RuntimeError('first-frame color qualification failed; no session reuse')
        if self._first_color_check is not None:
            details.update(first_frame_color_check=dict(self._first_color_check),
                           first_frame_color_check_reused=True)
            return
        # Preserve actual first input and completed tensor files even on a color
        # failure. Only the RGA tensor is compared; reference pixels are private
        # temporary validation data and never replace any prepared input.
        with (self.directory / 'first-frame-color-source.jpg').open('xb') as output:
            output.write(frame.jpeg)
        audit = dict(generation=frame.generation, source=dict(zip(SOURCE_FIELDS, frame.identity.source)),
            receiver_cohort=frame.identity.receiver_cohort, jpeg_generation=frame.identity.jpeg_generation,
            token=frame.identity.token, host_received_ns=frame.host_received_ns,
            jpeg_sha256=hashlib.sha256(frame.jpeg).hexdigest(),
            slot=slot, native_mpp_details=dict(details), native_metadata_proof=False)
        error = None
        try:
            check = self._color_checker(frame.jpeg, self.slots.files[slot, 'source_bgr'])
            if type(check) is not dict or type(check.get('passed')) is not bool:
                raise ValueError('structured color qualification required')
            for name in ('mae', 'rmse'):
                if (type(check.get(name)) not in (int, float) or not math.isfinite(check[name])
                        or check[name] < 0):
                    raise ValueError('finite nonnegative color-check metrics required')
            passed = check['passed'] and check['mae'] <= 3 and check['rmse'] <= 6
            check = dict(check, passed=bool(passed), native_metadata_proof=False)
        except BaseException as failure:
            error = failure
            check = dict(passed=False, error=str(failure)[:512], native_metadata_proof=False)
        self._first_color_check = dict(check)
        details.update(first_frame_color_check=dict(check), first_frame_color_check_reused=False)
        audit['check'] = check
        with (self.directory / 'first-frame-color-check.json').open('x', encoding='utf-8') as output:
            json.dump(audit, output, indent=2, allow_nan=False)
            output.write('\n')
        if not check['passed']:
            self._color_fault = True
            raise RuntimeError('first actual live JPEG/RGA color check failed; descriptor not published') from error

    def process(self, frame):
        self._published = False
        try:
            if self._color_fault:
                raise RuntimeError('first-frame color qualification failed; no session reuse')
            decoded = self.decoder.decode_to_nv12(frame.jpeg)
            if (decoded.width, decoded.height, decoded.colorimetry, decoded.layout) != (1920, 1080, 'BT601_FULL', 'linear'):
                raise RuntimeError('private MPP color/geometry conflicts with engineering contract')
            packed = decoded.y.tobytes(order='C') + decoded.uv.tobytes(order='C')
            if len(packed) != NV12_BYTES:
                raise RuntimeError('private MPP active-plane copy is not tight1080p NV12')
            details = dict(self.decoder.last_details())
            details.update(colorimetry='BT601_FULL', color_contract=self.config.engineering_color_evidence)
            slot = self._slot
            with memoryview(self.slots.files[slot, 'nv12']) as original:
                with original.cast('B') as target:
                    if target.nbytes != NV12_BYTES:
                        raise RetainedError('prepared NV12 slot geometry mismatch')
                    target[:] = packed
            try:
                timings = self.rga.prepare(self.slots, slot, False)
            except BaseException:
                self._unknown = True  # uncertain RGA failure still retains resources
                raise
            self._check_first_color(frame, slot, details)
            request = (self.bridge.VERSION, slot, frame.identity.token, frame.host_received_ns,
                       time.monotonic_ns(), *frame.identity.source)
            desc = self.bridge.descriptor(self.slots, request, False, timings)
            desc.update(ai_generation=frame.generation, receiver_cohort=frame.identity.receiver_cohort,
                        jpeg_generation=frame.identity.jpeg_generation,
                        color_contract=self.config.engineering_color_evidence)
            # Admission transfers the completed, qualified slot to the runner.
            # Failed first-frame checks leave no consumer lease and need no ACK.
            self.slots.admit(slot, frame.identity.token)
            self._published = True
            self._write_descriptor(desc)
            row = ack = None
            while row is None or ack is None:
                if row is None:
                    row = self._result_tail.read_one()
                if ack is None:
                    ack = self._ack_tail.read_one()
                if row is not None and ack is not None:
                    break
                if self.child.poll() is not None:
                    raise RetainedError('runner exited before result and exact ACK; slots retained')
                time.sleep(.003)
            result = self._validate_pair(frame, desc, row, ack)
            self.slots.release(slot, frame.identity.token)  # exact ACK is the sole release path
            self._published = False
            self._slot = 1 - slot
            boxes = tuple(target for target in result['targets'] if result.get('display_eligible') is True
                          and target.get('display_visible') is True)
            return CompletedFrame(frame.generation, frame.identity, frame.host_received_ns,
                                  packed, result, boxes, details)
        except BaseException:
            # Any uncertain slot/consumer/native completion retains the whole
            # backend. There is no drain timeout that releases it implicitly.
            if self._published or self.slots is not None and self.slots.held:
                self._unknown = True
            raise

    def retire(self):
        if self._retired:
            return True
        try:
            self._close_input()
            if self._unknown:
                return False
            if self.child is not None:
                code = self.child.poll()
                if code is None:
                    return False
                shutdown = self.directory / 'runner/shutdown.json'
                if not shutdown.is_file() or shutdown.stat().st_size > MAX_RECORD:
                    self._unknown = True
                    self.error = 'child exited without bounded shutdown CLOSED proof'
                    return False
                proof = json.loads(shutdown.read_text())
                if (proof.get('state') != 'CLOSED' or proof.get('source_closed') is not True
                        or proof.get('player_closed') is not True
                        or proof.get('pipeline', {}).get('safe_to_release') is not True):
                    self._unknown = True
                    self.error = 'child shutdown remains PENDING/UNKNOWN; no resource release'
                    return False
                if code and self.error is None:
                    self.error = f'runner failed with code{code}, but resource shutdown is CLOSED'
            if self.rga is not None and not self._rga_close_attempted:
                self._rga_close_attempted = True
                self.rga.close()
                if self.rga.h is not None:
                    raise RetainedError('RGA close did not clear its native handle')
            if self.decoder is not None and not self._mpp_close_attempted:
                self._mpp_close_attempted = True
                self.decoder.close()
                status = self.decoder.status()
                if not status.get('closed') or status.get('native_handle_retained'):
                    raise RetainedError('MPP retirement not confirmed')
            if self.slots is not None:
                if self.slots.held:
                    raise RetainedError('prepared slot has no exact release ACK')
                for array in self.slots.files.values():
                    mapping = getattr(array, '_mmap', None)
                    if mapping is not None:
                        mapping.close()
            for name in ('_ack_fd', '_result_fd'):
                fd = getattr(self, name)
                if fd is not None:
                    os.close(fd)
                    setattr(self, name, None)
            for stream in (self._audit, self._log):
                if stream is not None:
                    stream.close()
            self._retired = True
            return True
        except BaseException as error:
            self._unknown = True
            self.error = 'retirement UNKNOWN; no native destroy retry: ' + str(error)[:400]
            return False
