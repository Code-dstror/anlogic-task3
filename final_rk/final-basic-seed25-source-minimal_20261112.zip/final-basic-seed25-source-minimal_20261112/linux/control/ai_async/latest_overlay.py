"""Latest AI boxes for continuous original video; never replay AI pixels.

The injected endpoint copies metadata to the native filter. It must check the
same generation/context and ORIGINAL receive age on every decoded video frame.
Python service only reports expiry; it never switches a display route or turns
off the AI indicator when boxes expire. A new eligible empty result replaces
the previous boxes immediately.
"""
import math
from threading import get_ident
import time

DEFAULT_TTL_NS = 500_000_000
GROUPS = {'pedestrian':'PERSON','vehicle':'VEHICLE',
          'two_wheeler':'TWO-WHEEL','obstacle':'OBSTACLE'}
LEVELS = {'UNKNOWN':-1,'CLEAR':0,'ATTENTION':1,'DANGER':2,
          'NOT_APPLICABLE':-2,'EXCLUDED':-3}


def _uint(value, name, bits=64, minimum=0):
    if type(value) is not int or not minimum <= value < 2**bits:
        raise ValueError('invalid '+name)
    return value


def _context(value):
    if type(value) is tuple:
        key = value
    else:
        key = (value.receiver_cohort, *(getattr(value,n) for n in
            ('session','epoch','camera','kind','format','role')))
        if (value.width,value.height) != (1920,1080):
            raise ValueError('native 1080p context required')
    if len(key) != 7:
        raise ValueError('full receiver/SOURCE context required')
    cohort,*source = key
    if (type(cohort) is not str or not 1 <= len(cohort) <= 64
            or any(not 33 <= ord(c) <= 126 for c in cohort)):
        raise ValueError('explicit printable receiver cohort required')
    for index,item in enumerate(source):
        _uint(item,'SOURCE context',32,int(index<2))
    if tuple(source[2:]) != (0,1,1,0):
        raise ValueError('CAM0 physical RAW10 SINGLE required')
    return key


def _result_identity(identity):
    source = identity.source
    if type(source) is not tuple or len(source) != 7:
        raise ValueError('immutable seven-field result SOURCE required')
    for index,item in enumerate(source):
        _uint(item,'result SOURCE',32,int(index<2))
    key = _context((identity.receiver_cohort,*source[:2],*source[3:]))
    _uint(identity.jpeg_generation,'JPEG generation',32,1)
    return source,key,_uint(identity.token,'result token',64,1)


def _boxes(result):
    targets = result.get('targets')
    if type(targets) is not list or len(targets)>300:
        raise ValueError('bounded application targets required')
    boxes,seen = [],set()
    for target in targets:
        if type(target) is not dict:
            raise ValueError('application target required')
        if target.get('display_visible') is not True:
            continue
        name = target.get('target_id')
        if type(name) is not str or not 1<=len(name)<=128 or name in seen:
            raise ValueError('unique bounded target ID required')
        seen.add(name)
        group,level = target.get('group'),target.get('warning_level')
        if group not in GROUPS or level not in LEVELS:
            raise ValueError('known application group/level required')
        xy = tuple(target.get(n) for n in ('x1','y1','x2','y2'))
        if any(type(v) not in (int,float) or not math.isfinite(v) for v in xy):
            raise ValueError('finite original coordinates required')
        x1,y1,x2,y2 = xy
        if not (0<=x1<x2<=1920 and 0<=y1<y2<=1080):
            raise ValueError('box outside original image')
        distance = target.get('distance_m')
        if target.get('distance_valid') is True:
            if type(distance) not in (int,float) or not math.isfinite(distance) or distance<=0:
                raise ValueError('positive finite estimated distance required')
            suffix = '~%.1fM'%distance
        else:
            suffix = '--M'
        safe = ''.join(c if c.isascii() and (c.isalnum() or c in '-_') else '?' for c in name.upper())
        label = (GROUPS[group]+' '+safe[:20]+' '+suffix)[:47]
        boxes.append(dict(x1=math.floor(x1),y1=math.floor(y1),x2=math.ceil(x2),
                          y2=math.ceil(y2),level=LEVELS[level],label=label))
    return tuple(boxes)


class LatestOverlay:
    """Owner-only metadata policy compatible with the live application bridge.

    Endpoint API: enable(enabled=,generation=,context=tuple7|None),
    update(generation=,context=tuple7,result_source_seq=,received_ns=,boxes=),
    clear(generation=), stats(). enable/update return True or1 on acceptance.
    The endpoint's native per-video-frame TTL must equal this ttl_ns.
    """
    def __init__(self, endpoint, *, clock_ns=time.monotonic_ns, ttl_ns=DEFAULT_TTL_NS):
        if any(not callable(getattr(endpoint,n,None)) for n in ('enable','update','clear','stats')):
            raise TypeError('native latest-overlay endpoint required')
        _uint(ttl_ns,'overlay TTL',64,1)
        if ttl_ns>2_000_000_000:
            raise ValueError('overlay TTL must be at most2 seconds')
        self.endpoint,self.clock,self.ttl_ns = endpoint,clock_ns,ttl_ns
        self.owner = get_ident()
        self.enabled,self.generation,self.context = False,0,None
        self._last = None
        self._expired = False
        self.reason = 'AI disabled'
        self.counts = dict(result_updates=0,stale_reject=0,invalid_reject=0,
                           empty_updates=0,ineligible_clears=0,ttl_expirations=0)

    def _owner(self):
        if self.owner != get_ident():
            raise RuntimeError('overlay policy requires its owner thread')

    @staticmethod
    def _accepted(value):
        return (type(value) is bool and value) or (type(value) is int and value==1)

    def configure(self, *, enabled, generation, context=None):
        self._owner()
        if type(enabled) is not bool:
            raise ValueError('explicit AI enabled bool required')
        _uint(generation,'AI generation',64,int(enabled))
        key = _context(context) if enabled else None
        if generation<self.generation:
            raise ValueError('AI generation cannot move backward')
        if (enabled,generation,key)!=(self.enabled,self.generation,self.context):
            if not self._accepted(self.endpoint.enable(enabled=enabled,generation=generation,context=key)):
                raise RuntimeError('native overlay rejected enable context/generation')
            self.enabled,self.generation,self.context = enabled,generation,key
            self._last = None
            self._expired = False
            self.reason = 'waiting for latest AI result' if enabled else 'AI disabled'
        return self.status()

    def _reject(self, reason, *, stale=False):
        self.counts['stale_reject' if stale else 'invalid_reject']+=1
        self.reason = reason
        return False

    def submit(self, completed):
        self._owner()
        self.service()
        if (not self.enabled or type(completed.generation) is not int
                or completed.generation!=self.generation):
            return self._reject('disabled or old AI generation',stale=True)
        try:
            source,context,token = _result_identity(completed.identity)
            if context!=self.context:
                return self._reject('result from a different stream context',stale=True)
            received = _uint(completed.host_received_ns,'original host receive time',64,1)
            now = _uint(self.clock(),'current monotonic time')
            if not received<=now<received+self.ttl_ns:
                return self._reject('result source time is expired or future',stale=True)
            if self._last is not None and (token<=self._last['token'] or
                    source[2]<=self._last['sequence'] or received<=self._last['received_ns']):
                return self._reject('duplicate or backward result identity/time',stale=True)
            result = completed.linux_result
            if type(result) is not dict or result.get('schema')!='AI_LINUX_RESULT_V1':
                raise ValueError('application result schema required')
            key = ':'.join(map(str,(source[0],source[1],source[3],source[2],*source[4:])))
            expected = dict(session_id=str(source[0]),epoch=source[1],camera_id=source[3],
                frame_no=source[2],frame_key=key,timestamp_ns=received,
                clock_domain='CLOCK_MONOTONIC',timestamp_kind='linux_receive',
                original_width=1920,original_height=1080)
            frame = result.get('frame')
            if type(frame) is not dict or any(type(frame.get(k)) is not type(v) or frame[k]!=v
                                               for k,v in expected.items()):
                raise ValueError('result own SOURCE/time/geometry mismatch')
            eligible = result.get('display_eligible') is True
            boxes = _boxes(result) if eligible else ()
            # Never access completed.nv12 or compare with the current video
            # frame: only this result's identity/content is checked here.
            if not self._accepted(self.endpoint.update(generation=self.generation,context=context,
                    result_source_seq=source[2],received_ns=received,boxes=boxes)):
                return self._reject('native overlay rejected result identity',stale=True)
        except (ValueError,TypeError,AttributeError,KeyError,OverflowError) as error:
            return self._reject(type(error).__name__+': '+str(error)[:240])
        self._last = dict(token=token,sequence=source[2],received_ns=received,boxes=boxes)
        self._expired = False
        self.counts['result_updates']+=1
        self.counts['empty_updates']+=int(not boxes)
        self.counts['ineligible_clears']+=int(not eligible)
        self.reason = 'latest result metadata accepted; frame lag is allowed'
        return True

    def service(self):
        self._owner()
        if self._last is not None:
            now = _uint(self.clock(),'current monotonic time')
            received = self._last['received_ns']
            if not received<=now<received+self.ttl_ns:
                if not self._expired:
                    self.counts['ttl_expirations']+=1
                self._expired = True
                self.reason = 'boxes expired; AI remains enabled and video continues'
        return self.status()

    def status(self):
        self._owner()
        try:
            native = self.endpoint.stats()
        except Exception as error:
            native = dict(error=type(error).__name__+': '+str(error)[:240])
        received = None if self._last is None else self._last['received_ns']
        return dict(enabled=self.enabled,ai_generation=self.generation,context=self.context,
            route='original',reason=self.reason,counts=dict(self.counts),native=native,
            result_source_seq=None if self._last is None else self._last['sequence'],
            original_received_ns=received,
            result_age_ns=None if received is None else self.clock()-received,
            boxes_count=0 if self._last is None or self._expired else len(self._last['boxes']),
            boxes_expired=self._expired,ttl_ns=self.ttl_ns,same_frame_required=False,
            ttl_enforced_per_video_frame_by_native=True,video_route_changes=0,
            physical_scanout_verified=False,device_owner_created=False)
