"""DUAL R3 seed2, cold MONO/CAM0 mode admission; no topology writes or recovery."""
BIT = '7e9c32ac7a45813bb035d98a3145e319a3d3d63c8b5865c84bc6434e6b126150'
SOURCE = 'e081883222a7cd342d6d1ffcc5836a443334fe11'
PACKAGE_SHA256 = '24e04332e872ca4927d218aee7f7a49c3112475e16e50f3a2ab984a08f5bcce2'
PROFILE = 'dual-r3-mono-kms30'
BASIC_PROFILE = 'dual-r3-mono-basic120'
SEED51_BASIC_PROFILE = 'dual-sdr-seed51-mono-basic120'
HDR_SEED1_PROFILE = 'dual-hdr-seed1-cam0-sdr-hdr-sdr-3x10'
SEED1_RECIPE_PROFILES = ('dual-hdr-seed1-mono-six-stage','dual-hdr-seed1-mono-lane-data',
                       'dual-hdr-seed1-mono-lane-overlay-10-60-10')
BASIC_PROFILES = (BASIC_PROFILE, SEED51_BASIC_PROFILE)
HDR_PROFILE = 'dual-r3-mono-hdr30'
HDR_CFG10_PROFILE = 'dual-r3-mono-hdr-cfg10-30'
HDR_PROFILES = (HDR_PROFILE, HDR_CFG10_PROFILE)
LANE_PROFILE = 'dual-r3-mono-lane30'
PROFILE_ENABLES = {PROFILE: (0,), BASIC_PROFILE: (0, 1, 4, 8),
                   SEED51_BASIC_PROFILE: (0, 1, 4, 8), HDR_PROFILE: (0,),
                   HDR_CFG10_PROFILE: (0,), LANE_PROFILE: (48,), HDR_SEED1_PROFILE: (0,)}
PROFILE_ENABLES.update({SEED1_RECIPE_PROFILES[0]:(0,4,1,8),SEED1_RECIPE_PROFILES[1]:(0,48),
                       SEED1_RECIPE_PROFILES[2]:(0,48)})
VERSION, HEADER_BYTES = 4, 2112
# The retained native allocation bounds the whole record, including its header.
# Exceeding this trial bound is a failure, never truncation or fallback.
MAX_RECORD_BYTES = 4194304
MAX_JPEG_BYTES = MAX_RECORD_BYTES - HEADER_BYTES
CANVAS_TARGET = (1080, 2560)  # future RK composition; this trial is 1920x1080
STEREO_READ_OFFSETS = (0xf80, 0xf84, 0xf88, 0xf94, 0xf98, 0xf9c, 0xfa4)


def profile_source(profile=PROFILE):
    """Resolve a release only when selected; old R3 packages omit seed51."""
    if profile not in PROFILE_ENABLES:
        raise ValueError('unknown fixed MONO profile')
    if profile == SEED51_BASIC_PROFILE:
        if __package__:
            from .dual_sdr_seed51 import SOURCE as source
        else:
            from dual_sdr_seed51 import SOURCE as source
        return source
    if profile in (HDR_SEED1_PROFILE,*SEED1_RECIPE_PROFILES):
        if __package__:
            from .dual_hdr_seed1 import SOURCE as source
        else:
            from dual_hdr_seed1 import SOURCE as source
        return source
    return SOURCE


def cold_profile_admission(read32, profile=PROFILE):
    return cold_admission(read32, source=profile_source(profile))


def require_deployable(root=None, expected_boot=None, expected_bdf=None):
    """Check the actual new KO and loaded target; never load or open native."""
    if root is None or expected_boot is None:
        raise ValueError('R3 execution requires matching KO and current target admission')
    from pathlib import Path
    if __package__:
        from .dual_r3_driver import verify_ko, check_target
    else:
        from dual_r3_driver import verify_ko, check_target
    artifact = verify_ko(Path(root) / 'ph1a_c2h.ko')
    target = check_target(expected_boot, expected_bdf=expected_bdf)
    return dict(artifact=artifact, **target)


def cold_admission(read32, *, source=SOURCE):
    """Same owner's USER-relative reads, before SELECT/START; no topology write.

    Match capability plus actual unlocked MONO BOOT. These reads do not attest
    SRAM contents; bit identity still requires the operator's programming receipt.
    """
    expected = {
        0x200: 0x31474643, 0x204: 1, 0x208: 0x3f,
        0x20c: 1, 0x210: 1, 0x214: 1920, 0x218: 1080,
        0x38c: 4, 0x390: 0, 0x39c: 6, 0x3a0: 5, 0x3a4: 0x3d,
        0x280: 0x32444352, 0x284: 1, 0x288: 0x67, 0x28c: 0x16,
        0xf80: 0x31525453, 0xf84: 2, 0xf88: 0xff000203,
        0xf94: 0, 0xf98: 0, 0xf9c: 0, 0xfa4: 2,
        0x250: 0, 0x254: 75, 0x258: 0, 0x264: 0,
        0x268: 1, 0x26c: 0, 0x270: 0, 0x24c: 0,
        **{0xe80+4*i: 0 for i in range(32)},
    }
    def read(offset):
        value = read32(offset)
        if type(value) is not int or not 0 <= value <= 0xffffffff:
            raise ValueError('R3 invalid BAR read at '+hex(offset))
        return value
    before = read(0x21c)
    rows = {offset: read(offset) for offset in expected}
    for offset, value in expected.items():
        if rows[offset] != value:
            raise ValueError('R3 MONO cold capability/state mismatch at '+hex(offset)+
                             ': got '+hex(rows[offset])+', expected '+hex(value))
    status, control, cfg_status = read(0x01c), read(0x018), read(0x244)
    if (not before or before != read(0x278) or before != read(0x21c) or
            cfg_status != 0x10 or control & 3 or status & 0xbc or not status & 0x40):
        raise ValueError('R3 requires stable session and source-off rearm-ready BOOT')
    return dict(source=source, session=before, topology='MONO', record_version=VERSION,
                header_bytes=HEADER_BYTES, registers={hex(k): v for k,v in rows.items()},
                status=status, control=control, cfg_status=cfg_status,
                bit_identity='OPERATOR_RECEIPT_REQUIRED_NOT_MMIO_ATTESTATION')


def validate_record(record, profile=PROFILE):
    """Physical CAM0 only; schema2 uses 0x80 | enables (fixed seed2 RTL)."""
    from linux.task3_pipeline import pcie_protocol_v1 as p
    if profile in SEED1_RECIPE_PROFILES:
        if __package__:
            from .seed1_mode_recipe import validate_record as validate_recipe
        else:
            from seed1_mode_recipe import validate_record as validate_recipe
        return validate_recipe(record,profile)
    if profile == HDR_SEED1_PROFILE:
        if __package__:
            from .dual_hdr_seed1 import validate_record as validate_seed1
        else:
            from dual_hdr_seed1 import validate_record as validate_seed1
        return validate_seed1(record)
    if profile in HDR_PROFILES:
        if __package__:
            from .dual_r3_hdr import validate_hdr_record
        else:
            from dual_r3_hdr import validate_hdr_record
        return validate_hdr_record(record)
    if profile == LANE_PROFILE:
        if record.metadata is not None and record.metadata.source is not None and record.metadata.source.epoch == 0:
            if record.metadata.processing_mode or record.metadata.record_flags or record.metadata.processing_member:
                raise ValueError('R3 lane startup must be unchanged MONO SDR BOOT')
            return validate_record(record, PROFILE)
        if __package__:
            from .dual_r3_lane import validate_lane_record
        else:
            from dual_r3_lane import validate_lane_record
        return validate_lane_record(record)
    allowed = PROFILE_ENABLES[profile]
    modes = (0,) + tuple(p.PCIE_RECORD_V2_MODE_SCHEMA2_TAG | e for e in allowed)
    m, a = record.metadata, record.s07
    s = None if m is None else m.source
    if (s is None or (record.width, record.height) != (1920, 1080) or
            s.camera != 0 or not 0 <= m.jpeg_slot <= 2 or
            (s.kind, s.format, s.role) != (p.PCIE_RECORD_V2_SOURCE_PHYSICAL,
                p.PCIE_RECORD_V2_FORMAT_RAW10, p.PCIE_RECORD_V2_ROLE_SINGLE) or
            m.processing_mode not in modes or
            (profile in BASIC_PROFILES and (m.record_flags or m.processing_member)) or
            a is None or a.enabled != 0 or a.frame_error or
            any(getattr(a, name) is not None for name in ('f22','f23','f24','f25')) or
            not 4 <= len(record.jpeg) <= MAX_JPEG_BYTES):
        raise ValueError('R3 MONO requires profile-approved bounded CAM0 physical RAW10 SDR without analysis')
    return record


def controls_factory(profile=PROFILE):
    """Reuse the peer CFG worker, but expose only this trial's complete preset.

    Avoid the retired F21 ALGO/LUT window even in discovery. Retain the original
    full transaction/session verification and receive-progress guard.
    """
    from dataclasses import asdict
    from linux.rk_debug.controls import DebugControls
    from linux.task3_pipeline.config_transaction import Configuration
    from linux.task3_pipeline.mono_config_v2 import MonoConfiguration
    allowed = tuple(MonoConfiguration(product_mode=0, processing_enables=e)
                    for e in PROFILE_ENABLES[profile])
    if profile in SEED1_RECIPE_PROFILES:
        if __package__:
            from .seed1_mode_recipe import recipe_for
        else:
            from seed1_mode_recipe import recipe_for
        recipe=recipe_for(profile)
        allowed=tuple(MonoConfiguration(**recipe.configuration(i)['extension'])
                      for i in range(len(recipe.stage_names)))
    if profile == HDR_SEED1_PROFILE:
        if __package__:
            from .dual_hdr_seed1 import configuration
        else:
            from dual_hdr_seed1 import configuration
        allowed = tuple(MonoConfiguration(**configuration(hdr)['extension']) for hdr in (False, True))
    if profile in HDR_PROFILES:
        if __package__:
            from .dual_r3_hdr import hdr_extension
        else:
            from dual_r3_hdr import hdr_extension
        allowed = (MonoConfiguration(), hdr_extension())
    class Controls(DebugControls):
        def _validate(self, base, extension):
            super()._validate(base, extension)
            if base != Configuration(0, 75, 0, 1, 0, 0) or extension not in (None,) + allowed:
                raise ValueError('R3 profile permits only complete profile-approved Q75 CAM0 presets')
        def _lut_idle(self, *, required_generation=None):
            if profile not in (*BASIC_PROFILES, *HDR_PROFILES, LANE_PROFILE, HDR_SEED1_PROFILE,*SEED1_RECIPE_PROFILES):
                return super()._lut_idle(required_generation=required_generation)
            if required_generation is not None:
                raise ValueError('R3 MONO profile forbids F21 LUT generation')
        def query_lut(self):
            if profile in (*BASIC_PROFILES, *HDR_PROFILES, LANE_PROFILE, HDR_SEED1_PROFILE,*SEED1_RECIPE_PROFILES):
                raise ValueError('R3 MONO profile forbids LUT commands')
            return super().query_lut()
        def load_lut(self, generation):
            if profile in (*BASIC_PROFILES, *HDR_PROFILES, LANE_PROFILE, HDR_SEED1_PROFILE,*SEED1_RECIPE_PROFILES):
                raise ValueError('R3 MONO profile forbids LUT commands')
            return super().load_lut(generation)
        def discover(self):
            with self._exclusive('discover'):
                tx = self.transactions
                return dict(source_reference=dict(commit=profile_source(profile), profile=profile),
                    source_identity_scope='OFFLINE_REFERENCE_NOT_LIVE_BIT_ATTESTATION',
                    live=dict(base=asdict(tx.capabilities),
                              schema1=asdict(tx.extension_capabilities()),
                              schema2=asdict(tx.mono_capabilities())),
                    parameters=dict(preset={PROFILE:'COLOR_Q75_SDR',BASIC_PROFILE:'BASIC_Q75_SDR',SEED51_BASIC_PROFILE:'BASIC_Q75_SDR',HDR_PROFILE:'FIRST_HDR_Q75',HDR_CFG10_PROFILE:'FIRST_HDR_Q75_CFG10',LANE_PROFILE:'F22_C1_Q75_DATA',HDR_SEED1_PROFILE:'COLOR_Q75_SDR_HDR_SDR_3X10',SEED1_RECIPE_PROFILES[0]:'SEED1_SIX_STAGE_HDR60',SEED1_RECIPE_PROFILES[1]:'SEED1_SDR_LANE_DATA_NO_OVERLAY',SEED1_RECIPE_PROFILES[2]:'SEED1_SDR_C1_CURVES_10_60_10'}[profile],
                                    processing_enables=list(PROFILE_ENABLES[profile]), record_version=VERSION,
                                    hdr=profile in (*HDR_PROFILES,HDR_SEED1_PROFILE,SEED1_RECIPE_PROFILES[0]),lane=profile in (LANE_PROFILE,*SEED1_RECIPE_PROFILES[1:]),fpga_dehaze=False,dual=False))
    return Controls
