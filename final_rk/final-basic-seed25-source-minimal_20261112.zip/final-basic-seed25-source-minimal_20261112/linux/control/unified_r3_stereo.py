"""Fixed seed8 DUAL/N2/Q75 admission and strict, independently ordered eyes."""
from collections import deque
import hashlib
import json
import os
from pathlib import Path
import threading

try:
    from .unified_r3_mono import BIT,SOURCE,PACKAGE_SHA256,BIT_LABEL
    from .dual_r3_stereo import ColdStereoPreparation,StereoSourceRouter
except ImportError:
    from unified_r3_mono import BIT,SOURCE,PACKAGE_SHA256,BIT_LABEL
    from dual_r3_stereo import ColdStereoPreparation,StereoSourceRouter

PROFILE='dual-unified-r3-seed8-stereo-continuous'
SCOPE='UNIFIED_R3_STEREO_SDR_Q75_N2_STRICT_LAYOUT_FPS_FINAL_RECORD_V1'
RELEASE_ID='dual-unified-r3-seed8-stereo'
BASE_INDEX='c0966e6eb797d20d4d3453aee0785e1fb56e0a6b9be137409387d1dd520e70d6'
ROLE='SEALED_STEREO_SDK_LIBRARY_NOT_FIRMWARE_AUTHORITY'
INITIAL_LAYOUT='both'
TARGET_PREFIX='/userdata/unified-r3-stereo-'
SOURCE_ARCHIVE=Path('/home/uisrc/下载/DUAL_UNIFIED_R3_dfea9eee_seed8_20261105.zip')
BIT_FILENAME='DUAL_UNIFIED_R3_dfea9eee_seed8.bit'
ENTRY='launch_unified_stereo.py'
EXTRA_SOURCES=()
DISPLAY_TIMING_POLICY=None
PERFORMANCE_TARGET=None

def verify_config(value):
    expected=dict(bit_sha256=BIT,source_commit=SOURCE,package_sha256=PACKAGE_SHA256)
    if (value.get('firmware_release')!=RELEASE_ID or value.get('firmware')!=expected or
            value.get('runtime_index_sha256')!=BASE_INDEX or value.get('runtime_role')!=ROLE or
            value.get('profile')!=PROFILE or value.get('topology')!='DUAL' or value.get('quality')!=75 or
            value.get('frame_divisor')!=2 or value.get('source_order_policy')!='strict' or
            value.get('continuous') is not True or value.get('hdr_allowed') is not False or value.get('algorithms')!=[]):
        raise ValueError('fixed Unified R3 DUAL/N2/Q75/strict continuous configuration required')
    retention=dict(mode='circular',low_water_bytes=2147483648,target_free_bytes=3221225472)
    if not isinstance(value.get('recording'),dict) or value['recording'].get('retention')!=retention:raise ValueError('final HDMI circular recording is required')
    return expected

class UnifiedCold(ColdStereoPreparation):
    def __init__(self,receiver,*,evidence=None,on_admitted=None):
        self.storage_attempted=False
        def checkpoint(value):
            if evidence is not None:evidence(value)
            if value['partial'].get('cold_mono') is not None and not self.storage_attempted:
                self.storage_attempted=True
                if on_admitted is not None:on_admitted(value['partial']['cold_mono'])
        super().__init__(receiver,evidence=checkpoint)
        self.profile,self.bit,self.source=PROFILE,BIT,SOURCE

class StrictRouter(StereoSourceRouter):
    """The actual SDK strict demux; bounded extra host evidence, no drop path."""
    profile,bit,source=PROFILE,BIT,SOURCE
    def __init__(self,*,source_sessions,source_epochs,evidence_dir=None):
        super().__init__(source_sessions=source_sessions,source_epochs=source_epochs,source_order_policy='strict')
        self.evidence_dir=None if evidence_dir is None else Path(evidence_dir)
        self.lock=threading.RLock();self.rates=[deque(),deque()];self.first=[None,None]
        self.previous=[deque(maxlen=2),deque(maxlen=2)];self.error_saved=False
        self.last_host=None

    def feed(self,wire,*,host_ns=None,transport_identity=None,completion_metadata=None):
        with self.lock:
            try:
                if type(wire) is not bytes or type(host_ns) is not int or host_ns<=0:raise ValueError('owned wire and original host receive time required')
                if self.last_host is not None and host_ns<self.last_host:raise ValueError('stereo host clock moved backwards')
                item=self.accept(wire)
                samples=self.rates[item.camera]
                if samples and host_ns<samples[-1][0]:raise ValueError('stereo host clock moved backwards')
                while samples and samples[0][0]<=host_ns-60_000_000_000:samples.popleft()
                if len(samples)>=8192:raise ValueError('stereo host rate window exceeded')
                samples.append((host_ns,item.sequence));self.first[item.camera]=self.first[item.camera] or host_ns
                self.last_host=host_ns
                m=item.record.metadata
                self.previous[item.camera].append(dict(session=item.session,epoch=item.epoch,sequence=item.sequence,
                    jpeg_session=m.jpeg_session,jpeg_slot=m.jpeg_slot,jpeg_generation=m.jpeg_generation,host_ns=host_ns))
                return item
            except BaseException as error:
                self.faulted=True;self.failure=type(error).__name__+': '+str(error)[:512]
                self._capture(wire,error,host_ns,transport_identity,completion_metadata)
                raise

    def _capture(self,wire,error,stamp,identity,completion):
        if self.error_saved or self.evidence_dir is None:return
        self.error_saved=True
        value=dict(profile=self.profile,bit_sha256=self.bit,fpga_source=self.source,error=str(error),host_ns=stamp,
                   transport_identity=identity,completion_metadata=completion,previous=[list(x) for x in self.previous],
                   source_policy='STRICT_NO_DROP_OR_REORDER',wire_saved=False)
        try:
            if type(wire) is bytes and 0<len(wire)<=4194304:
                with (self.evidence_dir/'first-stereo-error.ajpg').open('xb') as f:f.write(wire);f.flush();os.fsync(f.fileno())
                value.update(wire_saved=True,wire_sha256=hashlib.sha256(wire).hexdigest(),wire_bytes=len(wire))
            with (self.evidence_dir/'first-stereo-error.json').open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.flush();os.fsync(f.fileno())
            directory=os.open(self.evidence_dir,os.O_RDONLY|os.O_DIRECTORY)
            try:os.fsync(directory)
            finally:os.close(directory)
        except Exception as failure:value['evidence_error']=str(failure)
        self.first_error=value

    def snapshot(self):
        with self.lock:
            result=super().snapshot();windows=[]
            for c,samples in enumerate(self.rates):
                end=None if not samples else samples[-1][0];rows={}
                for seconds in (10,60):
                    selected=[] if end is None else [x for x in samples if x[0]>end-seconds*1_000_000_000]
                    complete=end is not None and end-self.first[c]>=seconds*1_000_000_000
                    count=len({x[1] for x in selected})
                    rows[str(seconds)]=dict(complete=complete,unique_products=count,products_per_second=count/seconds if complete else None,
                                           suggested_30fps_minimum_met=count>=1790 if complete and seconds==60 else None)
                windows.append(dict(camera=c,first_host_ns=self.first[c],last_host_ns=end,windows=rows))
            result.update(profile=self.profile,bit_sha256=self.bit,source_commit=self.source,rate_windows=windows,
                          first_error=getattr(self,'first_error',None),
                          scope='HOST_COMPLETE_STRICT_VALIDATED_PRODUCTS_NOT_PHYSICAL_HDMI_OR_EXPOSURE_RATE')
            return result
