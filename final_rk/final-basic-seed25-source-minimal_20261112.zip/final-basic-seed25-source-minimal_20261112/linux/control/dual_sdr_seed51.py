"""Release identity and SDR-only policy for the 6f9c seed51 trials.

The dual trial exposes no runtime CFG. The separate MONO basic profile admits
only COLOR, Gray, Gaussian and HE. Hardware HDR capability bits do not override
the release policy or cold SDR checks.
"""
import hashlib
import json
from pathlib import Path

BIT = '12320a74248fba27c74d86f1709f9799b9c18ee0182a4f047ec6a67af72e2213'
SOURCE = '6f9c72762bd88abdc13e3a0ee31fd7dc97e4ccb7'
PACKAGE_SHA256 = '576c9ce070894c0132f69b52ac4b804115f28bbda5e19dabc74d6423bff42450'
PROFILE = 'dual-sdr-seed51-color-fixed-cam0-n2-kms60'
SCOPE = 'DUAL_SDR_SEED51_BOTH_COLOR_HDMI_CAM0_ONLY_60S_N2_RETAIN_V1'
RESCUE_PROFILE = 'dual-sdr-seed51-drop-stale-fixed-cam0-n2-kms60'
RESCUE_SCOPE = 'DUAL_SDR_SEED51_DROP_STALE_BOTH_COLOR_HDMI_CAM0_60S_N2_RETAIN_V1'
RESCUE_ALTERNATING_PROFILE = 'dual-sdr-seed51-drop-stale-alternating-n2-kms60'
RESCUE_ALTERNATING_SCOPE = 'DUAL_SDR_SEED51_DROP_STALE_CAM0_CAM1_6X10S_N2_RETAIN_V1'
RESCUE_PROFILES = (RESCUE_PROFILE, RESCUE_ALTERNATING_PROFILE)
SIDE_BY_SIDE_PROFILE = 'dual-sdr-seed51-drop-stale-side-by-side-n2-kms60'
SIDE_BY_SIDE_SCOPE = 'DUAL_SDR_SEED51_DROP_STALE_CAM0_LEFT_CAM1_RIGHT_60S_N2_RETAIN_V1'
LOSSY_PROFILES = (*RESCUE_PROFILES, SIDE_BY_SIDE_PROFILE)
MONO_BASIC_PROFILE = 'dual-sdr-seed51-mono-basic120'
MONO_BASIC_SCOPE = 'DUAL_SDR_SEED51_MONO_BASIC5X20S_V4_NV12_KMS_START120S_V1'
POLICY_FILE = 'seed51-debug-policy.json'
POLICY_SHA256 = '07b90c811e05e8752b55bc139ef78b2476b4b04eec4e9ce127bbae78933995e7'


def verify_policy(root):
    raw = (Path(root) / POLICY_FILE).read_bytes()
    if hashlib.sha256(raw).hexdigest() != POLICY_SHA256:
        raise ValueError('seed51 requires the fixed SDR-only debug policy')
    policy = json.loads(raw)
    if (policy['source_commit'] != SOURCE or policy['hdr_debug_allowed'] is not False
            or policy['fpga_dehaze'] is not False
            or policy['dual_processing'] != ['BASIC_COLOR_JPEG']
            or (policy['stereo_abi'], policy['record_version'], policy['header_bytes']) != (2, 4, 2112)):
        raise ValueError('seed51 HDR/format policy differs')
    return policy


def cold_preparation(receiver, *, evidence=None):
    if __package__:
        from .dual_r3_stereo import ColdStereoPreparation
    else:
        from dual_r3_stereo import ColdStereoPreparation
    return ColdStereoPreparation(receiver, evidence=evidence, profile=PROFILE)


def rescue_cold_preparation(receiver, *, evidence=None, profile=RESCUE_PROFILE):
    if profile not in LOSSY_PROFILES:
        raise ValueError('unknown seed51 rescue profile')
    if __package__:
        from .dual_r3_stereo import ColdStereoPreparation
    else:
        from dual_r3_stereo import ColdStereoPreparation
    return ColdStereoPreparation(receiver, evidence=evidence, profile=profile)
