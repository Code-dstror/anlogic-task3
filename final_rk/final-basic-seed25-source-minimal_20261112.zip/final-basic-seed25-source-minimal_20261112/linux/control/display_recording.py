"""Continuous recording of exactly the common post-overlay NV12 buffers.

No second camera/decoder owner. Non-leaky branches preserve accepted display
frames. Disk/index/encoder errors close the common admission gate and fault the
existing owner rather than silently showing unrecorded frames or deleting old
recordings. Only a separately admitted branch receives EOS; native owners stay.
"""
from collections import deque
import importlib
import json
import os
from pathlib import Path
import queue
import re
import threading
import time
import uuid

try:
    from .display_record_native import NativeRecord
    from .display_record_seal import seal_file,durable_json
    from .circular_recording import policy as circular_policy,CircularReclaimer
except ImportError:
    from display_record_native import NativeRecord
    from display_record_seal import seal_file,durable_json
    from circular_recording import policy as circular_policy,CircularReclaimer


MIN_FREE=1024*1024*1024
WRITE_HEADROOM=64*1024*1024


def clock_segments(directory,boot,*,history_package='mono_record_history'):
    build=importlib.import_module(history_package+'.clock_ledger').build_segments
    files=sorted(Path(directory).glob(boot+'-*.json'))[-2:]
    output=[];seen=set()
    for path in files:
        if path.is_symlink() or path.stat().st_size>4*1024*1024:raise ValueError('bounded ordinary clock ledger required')
        value=json.loads(path.read_text())
        for segment in build(value['samples']):
            if segment['segment_id'] not in seen:seen.add(segment['segment_id']);output.append(segment)
    return output


def admit(config,*,boot,verify_storage=True,history_package='mono_record_history',require_space=True):
    """Read-only before graph construction; never mount or set the clock."""
    required={'mount','uuid','cid','index','clock_dir','min_free_bytes'}
    if (type(config) is not dict or not required.issubset(config)
            or set(config)-required-{'retention','clock_policy'}):
        raise ValueError('complete fixed recording storage/time policy required')
    clock_policy=config.get('clock_policy','NETWORK_VERIFIED')
    if clock_policy not in ('NETWORK_VERIFIED','NETWORK_ANCHORED','LOCAL_UNVERIFIED'):
        raise ValueError('explicit network or operator-approved local recording time policy required')
    circular=circular_policy(config)
    if not require_space and circular is None:raise ValueError('space planning requires explicit circular recording')
    mount=Path(config['mount'])
    if not mount.is_absolute() or any(p.is_symlink() for p in (mount,*mount.parents)):
        raise ValueError('real absolute SD mount required')
    if config['min_free_bytes']!=MIN_FREE:raise ValueError('recording reserve must be1GiB')
    mounted=mount.stat()
    if not mount.is_dir():raise ValueError('recording mount must be a directory')
    if verify_storage:
        rows=[]
        for line in Path('/proc/self/mountinfo').read_text().splitlines():
            fields=line.split()
            if len(fields)>6 and fields[4]==str(mount):rows.append(fields)
        if len(rows)!=1 or 'rw' not in rows[0][5].split(','):raise ValueError('confirmed SD must be mounted read-write')
        device=Path('/dev/disk/by-uuid')/config['uuid']
        if device.stat().st_rdev!=mount.stat().st_dev:raise ValueError('mounted SD UUID differs')
        block=Path('/sys/dev/block')/rows[0][2]
        candidates=[p/'device/cid' for p in (block.resolve(),*block.resolve().parents)]
        ids=[p.read_text().strip() for p in candidates if p.is_file()]
        if config['cid'] not in ids:raise ValueError('SD hardware CID differs')
    space=os.statvfs(mount);free=space.f_frsize*space.f_bavail
    if require_space and free<MIN_FREE+WRITE_HEADROOM:
        raise ValueError('SD circular recording reserve unavailable; prepare reclaimable space before START'
                         if circular is not None else 'SD low-space threshold reached; recordings are not overwritten')
    index=Path(config['index'])
    if not index.is_absolute() or not index.parent.is_dir() or any(p.is_symlink() for p in (index,*index.parents)):
        raise ValueError('real persistent live-index parent required')
    segments=clock_segments(config['clock_dir'],boot,history_package=history_package)
    now=time.monotonic_ns();wall=time.time_ns()
    fresh=[s for s in segments if s.get('clock_quality')==clock_policy and 0<=now-s['end_monotonic_ns']<=60_000_000_000 and
           abs(wall-(s['end_utc_ns']+now-s['end_monotonic_ns']))<=s['uncertainty_ns']+250_000_000]
    if not fresh:raise ValueError('fresh externally checked UTC interval required before recording')
    current=mount.stat()
    if (current.st_dev,current.st_ino)!=(mounted.st_dev,mounted.st_ino):raise OSError('recording mount changed during admission')
    return dict(boot=boot,free_bytes=free,clock_quality=clock_policy,clock_segment=fresh[-1]['segment_id'],
                storage_identity=dict(dev=mounted.st_dev,ino=mounted.st_ino))


def graph_branch(sink,directory,*,software=False):
    directory=str(directory)
    if not re.fullmatch(r'/[A-Za-z0-9_./-]+',directory) or '..' in Path(directory).parts:
        raise ValueError('safe recording directory required')
    encoder=('vp8enc deadline=1 cpu-used=8 threads=2 target-bitrate=8000000 lag-in-frames=0 '
             'keyframe-max-dist=8 ! identity name=record_encoded' if software else
             'mpph265enc name=record_encoder rc-mode=vbr bps=8000000 bps-min=2000000 '
             'bps-max=10000000 gop=120 max-pending=2 ! h265parse config-interval=-1 ! '
             'video/x-h265,stream-format=hvc1,alignment=au,profile=main ! identity name=record_encoded')
    location=directory+'/segment-%010d.partial.mp4'
    return ('tee name=record_tee '
        '! queue name=record_display_queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=no ! '+sink+' '
        'record_tee. ! queue name=record_queue max-size-buffers=4 max-size-bytes=0 max-size-time=0 leaky=no '
        '! identity name=record_stamp ! capssetter caps="video/x-raw,framerate=60/1" '
        '! '+('videoconvert ! video/x-raw,format=I420 ! ' if software else '')+encoder+' '
        '! splitmuxsink name=display_record_mux muxer='+('webmmux' if software else 'mp4mux')+
        ' async-finalize=false max-size-time=5000000000 max-size-bytes=0 max-files=0 '
        'send-keyframe-requests=true location='+location+' ')


class DisplayRecording:
    def __init__(self,config,*,boot,output,history_package='mono_record_history',verify_storage=True):
        self.config=config;self.boot=boot;self.output=Path(output);self.history_package=history_package
        self.admission=admit(config,boot=boot,verify_storage=verify_storage,history_package=history_package)
        self.recording_id='mono-final-'+boot[:8]+'-'+uuid.uuid4().hex[:12]
        self.directory=Path(config['mount'])/'recordings'/self.recording_id
        if self.directory.parent.is_symlink():raise ValueError('real SD recording parent required')
        self.directory.parent.mkdir(mode=0o700,exist_ok=True)
        self.directory.mkdir(mode=0o700)
        self.directory_fd=os.open(self.directory,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        pinned=os.fstat(self.directory_fd)
        self._pinned_identity=(pinned.st_dev,pinned.st_ino)
        self.io_directory=Path('/proc/self/fd')/str(self.directory_fd)
        self.events=queue.Queue(maxsize=32);self.pending_closed=deque();self.encoded=[]
        self.native=None;self.error=None;self.finished=False;self.finish_requested=False
        self._finish=threading.Event();self._done=threading.Event();self._lock=threading.Lock()
        self._state=dict(status='PREPARED',directory=str(self.directory),closed=0,frames=0,
            clock_quality=self.admission['clock_quality'],last_asset=None,error=None,retained=True,
            policy='FINAL_OVERLAY_NV12_NO_RECORDING_FRAME_DROP_NO_AUTODELETION',reserve_bytes=MIN_FREE)
        self._counts={1:0,2:0,3:0};self._thread=None;self._common={};self._first_common=0
        self._open_fragments=set()
        self._retention=(CircularReclaimer(config,history_package=history_package,storage_check=self._check_storage,
                                          storage_admitted=verify_storage)
                         if circular_policy(config) is not None else None)
        if getattr(self,'_retention',None) is not None:
            self._state.update(policy='FINAL_OVERLAY_NV12_CIRCULAR_OLDEST_SEALED',
                               retention=self._retention.snapshot())
        self.history=importlib.import_module(history_package+'.live_index')
        catalog=importlib.import_module(history_package+'.catalog');self._parser=catalog._mp4;self._boxes=catalog._boxes

    def attach(self,display,library):
        self.display=display;self.Gst=display._Gst
        self.native=NativeRecord(library,display._pipeline)
        # Sync bus callback copies only fragment/error messages. The existing
        # display error poll may discard ELEMENT messages afterwards.
        display._pipeline.get_bus().set_sync_handler(self._message,None)
        if getattr(self,'_retention',None) is not None:self._retention.start()
        self._thread=threading.Thread(target=self._run,name='final-display-recorder',daemon=False)
        self._thread.start()

    def _message(self,bus,message,unused):
        row=None
        if message.type==self.Gst.MessageType.ELEMENT:
            structure=message.get_structure()
            if structure and structure.get_name() in ('splitmuxsink-fragment-opened','splitmuxsink-fragment-closed'):
                row=dict(kind=structure.get_name(),location=structure.get_value('location'),running_time=int(structure.get_value('running-time')))
        elif message.type==self.Gst.MessageType.ERROR:
            error,debug=message.parse_error();row=dict(kind='ERROR',error=str(error),debug=debug)
        if row is not None:
            try:self.events.put_nowait(row)
            except queue.Full:self._fail('fragment event queue overflow')
        return self.Gst.BusSyncReply.PASS

    def _fail(self,error):
        self.error=self.error or str(error)
        if self.native is not None:self.native.fail()
        with self._lock:self._state.update(status='FAULTED_RETAINED',error=self.error)

    def check(self):
        if self.error:raise RuntimeError('final display recording failed: '+self.error)

    def snapshot(self):
        with self._lock:value=dict(self._state)
        if getattr(self,'_retention',None) is not None:value['retention']=self._retention.snapshot()
        return value

    def _drain(self):
        while True:
            batch=self.native.read()
            if not batch:break
            for event in batch:
                kind=event['kind']
                if kind not in self._counts or event['ordinal']!=self._counts[kind]+1:raise ValueError('record native event order differs')
                self._counts[kind]+=1
                key=event['ordinal']
                if kind==1:
                    self._common[key]=(event['original_pts'],event['monotonic'],event['pts']);self._first_common=self._first_common or event['monotonic']
                elif kind==2:
                    if self._common.get(key)!=(event['original_pts'],event['monotonic'],event['pts']):raise ValueError('encoder input differs from common post-overlay frame')
                    del self._common[key]
                else:self.encoded.append(event)
                if len(self._common)>64 or len(self.encoded)>16384:raise ValueError('recording bounded in-flight evidence exceeded')

    def _publish(self):
        while self.pending_closed:
            row=self.pending_closed[0];path=Path(row['location'])
            if path.parent!=self.io_directory or not re.fullmatch(r'segment-[0-9]{10}\.partial\.mp4',path.name):raise ValueError('fragment path differs from admitted recording root')
            self._check_storage()
            try:
                result=seal_file(path,self.encoded,parser=self._parser,boxes=self._boxes,boot=self.boot,recording_id=self.recording_id,published_root=self.directory)
            except Exception as error:
                # A quarantined container must keep its original AU identity
                # evidence too; never infer those rows later from the MP4.
                try:
                    durable_json(self.output/'recording-error-evidence.json',dict(
                        schema=1,boot=self.boot,recording_id=self.recording_id,
                        directory=str(self.directory),closed_event=row,
                        encoded_pending=self.encoded,native=self.native.stats(),
                        error=str(error),published=False))
                except Exception:pass # Preserve the first failure even if evidence storage failed.
                raise
            if result is None:break
            asset,count=result;self.history.ingest_verified_asset(self.config['index'],asset)
            del self.encoded[:count];self.pending_closed.popleft()
            self._open_fragments.remove(row['location'])
            with self._lock:
                self._state.update(closed=self._state['closed']+1,frames=self._state['frames']+count,last_asset=asset['asset_id'])

    def _clock_and_space(self):
        self._check_storage()
        if getattr(self,'_retention',None) is not None:self._retention.check()
        segments=clock_segments(self.config['clock_dir'],self.boot,history_package=self.history_package)
        self.history.update_clock(self.config['index'],self.boot,segments)
        now=time.monotonic_ns();policy=self.config.get('clock_policy','NETWORK_VERIFIED')
        good=any(s.get('clock_quality')==policy and 0<=now-s['end_monotonic_ns']<=60_000_000_000 for s in segments)
        st=os.statvfs(self.directory);free=st.f_frsize*st.f_bavail
        with self._lock:self._state.update(clock_quality=policy if good else 'UNKNOWN',free_bytes=free)
        if getattr(self,'_retention',None) is not None:
            with self._lock:self._state['retention']=self._retention.snapshot()
        if free<MIN_FREE+WRITE_HEADROOM:
            raise OSError('SD circular recording could not reclaim enough sealed files; reserve reached; stop display/recording'
                          if getattr(self,'_retention',None) is not None else 'SD low-space threshold reached; preserve old files and stop display/recording')

    def _check_storage(self):
        current=self.directory.stat()
        if (current.st_dev,current.st_ino)!=self._pinned_identity:
            raise OSError('recording SD path changed; pinned original retained, no fallback writes')

    def _run(self):
        last_maintenance=0;ending=False
        try:
            with self._lock:self._state['status']='RECORDING'
            while True:
                self._drain()
                for unused in range(32):
                    try:row=self.events.get_nowait()
                    except queue.Empty:break
                    if row['kind']=='ERROR':raise RuntimeError(row['error'])
                    if row['kind']=='splitmuxsink-fragment-opened':
                        if row['location'] in self._open_fragments:raise ValueError('duplicate fragment OPENED')
                        self._open_fragments.add(row['location'])
                    if row['kind']=='splitmuxsink-fragment-closed':
                        if row['location'] not in self._open_fragments:raise ValueError('fragment CLOSED without OPENED')
                        self.pending_closed.append(row)
                self._publish()
                stats=self.native.stats()
                if stats['error']:raise RuntimeError('native final-frame recorder error '+str(stats['error']))
                with self._lock:self._state['native']=stats
                if time.monotonic()-last_maintenance>=5:
                    self._clock_and_space();last_maintenance=time.monotonic()
                if self._finish.is_set() and not ending:
                    self.native.finish();ending=True
                    # A finish-before-IDLE snapshot cannot prove the last tee
                    # push or mux CLOSED message has completed.
                    continue
                if (ending and stats['closing']==1 and
                        stats['common']==stats['input']==stats['encoded']==stats['display'] and
                        not stats['queued'] and not self._common and not self.encoded and
                        not self.pending_closed and not self._open_fragments and self.events.empty()):
                    self.finished=True
                    with self._lock:self._state.update(status='SEALED_RETAINED',all_common_frames_encoded_and_sealed=True)
                    break
                self._finish.wait(.05) if not ending else time.sleep(.01)
        except BaseException as error:self._fail(error)
        finally:
            if getattr(self,'_retention',None) is not None:
                retained=self._retention.stop()
                with self._lock:self._state['retention']=retained
            try:durable_json(self.output/'recording-final.json',self.snapshot())
            except BaseException as error:self._fail(error)
            self._done.set()

    def finish(self,timeout=12):
        self.finish_requested=True;self._finish.set()
        if not self._done.wait(timeout):
            self._fail('recording tail completion unconfirmed; retain owner and branch')
        return self.snapshot()
