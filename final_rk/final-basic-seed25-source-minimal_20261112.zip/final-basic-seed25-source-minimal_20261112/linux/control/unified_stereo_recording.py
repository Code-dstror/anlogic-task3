"""Same final HDMI recording, adding the actual selected pair to each AU."""
try:
    from .display_recording import DisplayRecording
except ImportError:
    from display_recording import DisplayRecording

class StereoRecording(DisplayRecording):
    def __init__(self,*args,hud,**kwargs):
        super().__init__(*args,**kwargs)
        self.hud=hud;self._pairs={}

    def _drain(self):
        while True:
            batch=self.native.read()
            if not batch:break
            for event in batch:
                kind=event['kind'];key=event['ordinal']
                if kind not in self._counts or key!=self._counts[kind]+1:raise ValueError('stereo native record order differs')
                self._counts[kind]+=1
                if kind==1:
                    self._common[key]=(event['original_pts'],event['monotonic'],event['pts'])
                    self._first_common=self._first_common or event['monotonic']
                    self._pairs[key]=self.hud.take(key,event['original_pts'])
                elif kind==2:
                    if self._common.get(key)!=(event['original_pts'],event['monotonic'],event['pts']):raise ValueError('stereo encoder differs from common HDMI frame')
                    del self._common[key]
                else:
                    pair=self._pairs.pop(key,None)
                    if pair is None:raise ValueError('encoded AU has no actual stereo composition evidence')
                    self.encoded.append(dict(event,stereo=pair))
                if len(self._common)>64 or len(self._pairs)>64 or len(self.encoded)>16384:raise ValueError('stereo recording association bound exceeded')
