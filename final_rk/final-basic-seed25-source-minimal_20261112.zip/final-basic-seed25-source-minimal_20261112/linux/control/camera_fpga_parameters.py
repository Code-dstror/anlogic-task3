"""final_basic physical parameters: owner-read ACTIVE, exact partial CFG merge.

HTTP consumers use cached dictionaries only. capture() is the sole method that
reads the existing transaction owner; it neither opens a device nor writes it.
"""
from copy import deepcopy
from dataclasses import asdict
import time

SCHEMA='FINAL_BASIC_PARAMETERS_V1'
SOURCE='1a5603c1c8aa58565aa9b5facf40a7478ebcf6ba'
BITS={'GRAY':1,'DEHAZE':2,'GAUSSIAN_IMAGE':4,'HISTOGRAM':8,'MULTISCALE':16,'LANE':32}
LABELS={
 'base.mode':'基础颜色模式','base.quality':'JPEG 请求质量 / 自适应上限 Q','base.min_quality':'自适应最低质量',
 'base.flags':'自适应 JPEG 质量','base.frame_budget':'每帧字节预算','base.restart_mcus':'Restart 间隔',
 'extension.schema':'配置格式','extension.product_mode':'SDR / HDR',
 'extension.processing_enables':'图像处理掩码',
 'extension.hdr_ratio':'HDR 曝光比（编码4＝16×）','extension.hdr_black_long':'长曝光减黑值',
 'extension.hdr_black_short':'短曝光减黑值','extension.hdr_motion_base':'运动残差基础阈值',
 'extension.hdr_motion_shift':'运动阈值移位','extension.hdr_qualification':'HDR 资格掩码',
 'extension.hdr_max_delta_ns':'长短帧时间差上限','extension.hdr_max_wait_ns':'配对等待窗口',
 'extension.hdr_max_age_ns':'成员新鲜度窗口','extension.dehaze_lut_generation':'去雾内建估参选择',
 'GRAY':'灰度','DEHAZE':'去雾','GAUSSIAN_IMAGE':'高斯滤波','HISTOGRAM':'直方图均衡化',
 'MULTISCALE':'多尺度分析','LANE':'车道候选分析'}
HDR_NAMES=('hdr_ratio','hdr_black_long','hdr_black_short','hdr_motion_base','hdr_motion_shift',
           'hdr_qualification','hdr_max_delta_ns','hdr_max_wait_ns','hdr_max_age_ns')
BASE_NAMES=('mode','quality','flags','min_quality','frame_budget','restart_mcus')
EXT_NAMES=('schema','product_mode','processing_enables',*HDR_NAMES,'dehaze_lut_generation')


def _sdk():
    from linux.task3_pipeline.config_transaction import Configuration,ConfigCapabilities
    from linux.task3_pipeline.mono_config_v2 import MonoConfiguration,MonoCapabilities
    return Configuration,ConfigCapabilities,MonoConfiguration,MonoCapabilities


def _catalog(base,mono):
    try:from .final_basic_parameter_catalog import _parameter_catalog
    except ImportError:from final_basic_parameter_catalog import _parameter_catalog
    _,Caps,_,MonoCaps=_sdk()
    return _parameter_catalog(Caps(**base),MonoCaps(**mono))


def _value(document,path):
    group,name=path.split('.',1)
    return document[group][name]


def _policy(candidate):
    if not isinstance(candidate,dict) or set(candidate)!=set(HDR_NAMES):
        raise ValueError('complete owner-confirmed HDR policy required; no injected defaults')
    if any(type(v) is not int for v in candidate.values()):raise ValueError('integer HDR policy required')
    return deepcopy(candidate)


def _fields(snapshot):
    doc=snapshot['active_document'];catalog=snapshot['catalog'];result=[]
    for original in catalog['base']+catalog['schemas']['2']:
        row=deepcopy(original);path=row['path'];value=_value(doc,path)
        row.update(label=LABELS[path],value=value,kind='integer',
                   group='JPEG' if path.startswith('base.') else 'HDR' if '.hdr_' in path else 'ISP',
                   read_only=row.get('access')!='writable',value_origin='ACTIVE')
        if path=='base.flags':row.update(kind='boolean',value=bool(value&1))
        if path in ('extension.product_mode','extension.dehaze_lut_generation'):
            row['kind']='enum'
            row['options']=([dict(value=v,label='SDR' if v==0 else 'HDR') for v in sorted(set(row['symbols'].values()))]
                            if path.endswith('product_mode') else [dict(value=v,label='自动内建' if v==0 else '显式内建') for v in range(row['maximum']+1)])
        if path=='base.mode':row.update(kind='readonly',read_only=True,unit='COLOR=0')
        if path=='extension.schema':row.update(kind='readonly',read_only=True,value_origin='FIXED_SUBMISSION_SCHEMA2')
        if path=='extension.processing_enables':row.update(kind='bitset',read_only=True)
        if '.hdr_' in path:
            row['enabled_when']=dict(path='extension.product_mode',equals=2)
            row['disabled_value']=0
            row['strategy_value']=snapshot['hdr_policy'][path.split('.')[1]]
            if row['read_only']:row['kind']='readonly'
        if path=='extension.dehaze_lut_generation':
            row['enabled_when']=dict(path='extension.processing_enables.DEHAZE',equals=True)
        result.append(row)
        if path=='extension.processing_enables':
            for name,bit in BITS.items():
                allowed=bool(bit & sum(row.get('symbols',{}).values()))
                result.append(dict(path=path+'.'+name,label=LABELS[name],group='ISP',kind='boolean',
                    value=bool(value&bit),minimum=0,maximum=1 if allowed else 0,unit='开关',
                    read_only=not allowed,access='writable' if allowed else 'unavailable',bit=bit,
                    value_origin='ACTIVE',reason=None if allowed else '当前目数或实际 caps 未开放'))
    return result


def capture(cold,*,confirmed_hdr_policy):
    """Read caps/full ACTIVE through cold.transactions on the existing owner."""
    from dual_host.debug_modes import SharedControls
    controls=SharedControls(cold.transactions,lut_timeout_s=10)
    observed=controls.discover()
    active=observed['active'];base=deepcopy(active['configuration'])
    _,_,Mono,_=_sdk()
    extension=asdict(Mono()) if active['extension'] is None else deepcopy(active['extension'])
    if active['extension'] is not None and extension.get('schema')!=2:
        raise ValueError('final_basic panel supports clean BOOT or actual schema2 ACTIVE')
    policy=(_policy({n:extension[n] for n in HDR_NAMES}) if extension['product_mode']==2
            else _policy(confirmed_hdr_policy))
    snapshot=dict(schema=SCHEMA,source_commit=SOURCE,source_identity_scope='EXPECTED_PACKAGE_NOT_SRAM_READBACK',topology='mono' if cold.spec['cameras']==1 else 'dual',
        session=active['session'],epoch=active['mode_epoch'],fingerprint=active['fingerprint'],
        observed_monotonic_ns=time.monotonic_ns(),observation='SAME_OWNER_CAPS_AND_DOUBLE_READ_ACTIVE',
        active_schema=0 if active['extension'] is None else 2,active_raw=deepcopy(active),
        active_document=dict(schema=2,base=base,extension=extension),
        capabilities=dict(base=deepcopy(observed['base']),schema2=deepcopy(observed['schema2'])),
        hdr_policy=policy,hdr_policy_origin='ACTIVE_HDR' if extension['product_mode']==2 else 'OWNER_CONFIRMED_POLICY',
        unavailable=[dict(label='传感器曝光/增益与白平衡',reason='本版未开放在线字段'),
                     dict(label='高斯核、HE内部阈值和车道preset',reason='固定硬件配置'),
                     dict(label='主机去雾LUT上传',reason='此物理profile未开放'),
                     dict(label='目数与JPEG/RAW产品选择',reason='冷态选择；不属于在线参数')])
    snapshot['catalog']=_catalog(snapshot['capabilities']['base'],snapshot['capabilities']['schema2'])
    validate_document(snapshot,snapshot['active_document'])
    if snapshot['capabilities']['schema2']['modes']&4:
        proposed=deepcopy(snapshot['active_document'])
        proposed['extension'].update(policy,product_mode=2)
        validate_document(snapshot,proposed)
    snapshot['fields']=_fields(snapshot)
    return snapshot


def validate_document(snapshot,document):
    if (not isinstance(snapshot,dict) or snapshot.get('schema')!=SCHEMA or
            not isinstance(document,dict) or set(document)!={'schema','base','extension'} or document['schema']!=2
            or set(document['base'])!=set(BASE_NAMES) or set(document['extension'])!=set(EXT_NAMES)):
        raise ValueError('complete physical final_basic schema2 configuration required')
    if any(type(v) is not int for group in ('base','extension') for v in document[group].values()):
        raise ValueError('configuration fields require exact integers, no bool or float')
    Configuration,Caps,Mono,MonoCaps=_sdk()
    caps=Caps(**snapshot['capabilities']['base']);mono=MonoCaps(**snapshot['capabilities']['schema2'])
    base=Configuration(**document['base']);ext=Mono(**document['extension'])
    if base.mode!=0 or ext.product_mode not in (0,2):raise ValueError('only physical SDR/HDR with base COLOR')
    caps.supports(base)
    ext.validate(mono,width=caps.max_width,height=caps.max_height,camera_present=caps.camera_present)
    for row in snapshot['catalog']['base']+snapshot['catalog']['schemas']['2']:
        path=row['path']
        if path=='extension.processing_enables':continue
        if '.hdr_' in path and ext.product_mode!=2:continue
        value=_value(document,path)
        if not row['minimum']<=value<=row['maximum']:
            raise ValueError(path+' outside physical capability range')
        symbols=row.get('symbols')
        if symbols and row.get('unit')=='enum' and value not in symbols.values():raise ValueError(path+' unsupported enumeration')
    if ext.product_mode==2 and ((ext.hdr_ratio,ext.hdr_black_long,ext.hdr_black_short,ext.hdr_qualification)!=(4,50,50,15)
            or ext.hdr_max_delta_ns>0xffffffff or not ext.hdr_max_wait_ns or not ext.hdr_max_age_ns):
        raise ValueError('physical HDR fixed recipe and nonzero timers required')
    return deepcopy(document)


def merge_patch(snapshot,patch):
    if not isinstance(patch,dict) or not patch or len(patch)>32:raise ValueError('bounded nonempty parameter patch required')
    doc=deepcopy(snapshot['active_document']);fields={r['path']:r for r in snapshot['fields']}
    mode=patch.get('extension.product_mode',doc['extension']['product_mode'])
    if mode==2 and doc['extension']['product_mode']!=2:
        doc['extension'].update(_policy(snapshot['hdr_policy']))
    for path,value in patch.items():
        row=fields.get(path)
        if row is None or row['read_only']:raise ValueError('unknown, fixed or unavailable parameter: '+str(path))
        if row['kind']=='boolean':
            if type(value) is not bool:raise ValueError(path+' requires a boolean')
            if path.startswith('extension.processing_enables.'):
                bit=row['bit'];mask=doc['extension']['processing_enables']
                doc['extension']['processing_enables']=(mask|bit) if value else (mask&~bit)
            else:doc['base']['flags']=int(value)
        else:
            if type(value) is not int:raise ValueError(path+' requires an exact integer')
            group,name=path.split('.',1);doc[group][name]=value
    if doc['extension']['product_mode']==0:
        if any('.hdr_' in path for path in patch):raise ValueError('HDR fields require an enabled HDR product')
        doc['extension'].update({n:0 for n in HDR_NAMES})
    if not doc['extension']['processing_enables']&2:
        if patch.get('extension.dehaze_lut_generation',0):raise ValueError('disabled dehaze requires generation0')
        doc['extension']['dehaze_lut_generation']=0
    return validate_document(snapshot,doc)


def preset(snapshot,mode):
    if mode=='custom':return deepcopy(snapshot['active_document'])
    if mode=='hdr':return merge_patch(snapshot,{'extension.product_mode':2})
    masks={'color':0,'yolo':0,'gray':1,'gaussian':4,'histogram':8,'dehaze':2,'lane':48}
    if mode not in masks:raise ValueError('unknown physical processing preset')
    patch={'extension.product_mode':0}
    available={r['path']:r for r in snapshot['fields']}
    for name,bit in BITS.items():
        path='extension.processing_enables.'+name
        if not available[path]['read_only']:patch[path]=bool(masks[mode]&bit)
        elif masks[mode]&bit:raise ValueError('preset not available for this topology')
    return merge_patch(snapshot,patch)


def classify(document):
    ext=document['extension'];mask=ext['processing_enables']
    if ext['product_mode']==2:return 'hdr' if mask==0 else 'custom'
    return {0:'color',1:'gray',4:'gaussian',8:'histogram',48:'lane',2:'dehaze'}.get(mask,'custom')


def baseline(snapshot):return {k:snapshot[k] for k in ('session','epoch','fingerprint')}
