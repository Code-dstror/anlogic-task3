"""Offline by default. One fixed-release cold stereo owner; never hot reopen."""
import argparse
from functools import partial
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import threading
from types import ModuleType
from uuid import UUID

try:from . import unified_r3_stereo as release
except ImportError:import unified_r3_stereo as release

def checked_index(root,name,expected=None):
    root=Path(root)
    raw=(root/name).read_bytes()
    if expected is not None and hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('sealed implementation index differs')
    value=json.loads(raw);rows=value['files'] if name=='runtime-index.json' else value
    actual=set()
    for p in root.rglob('*'):
        if p.is_symlink():raise ValueError('ordinary fixed payload required')
        if p.is_file():actual.add(p.relative_to(root).as_posix())
    if actual!=set(rows)|{name}:raise ValueError('payload closure differs')
    for n,row in rows.items():
        relative=Path(n)
        if relative.is_absolute() or '..' in relative.parts or relative.as_posix()!=n:raise ValueError('unsafe payload member')
        body=(root/n).read_bytes()
        if len(body)!=row['bytes'] or hashlib.sha256(body).hexdigest()!=row['sha256']:raise ValueError('payload member differs: '+n)
    return value

def main(argv=None,*,release_module=release):
    release=release_module
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--integration-config',type=Path,required=True)
    parser.add_argument('--check-only',action='store_true');parser.add_argument('--run',action='store_true')
    parser.add_argument('--run-dir',type=Path);parser.add_argument('--expected-boot');parser.add_argument('--expected-bdf')
    parser.add_argument('--bit-sha256');parser.add_argument('--kms-selection',type=Path);parser.add_argument('--kms-selection-sha256')
    parser.add_argument('--joint-cold-confirmed',action='store_true');parser.add_argument('--programming-note')
    args=parser.parse_args(argv);sys.dont_write_bytecode=True
    control=Path(__file__).resolve().parent;index=checked_index(control,'content-index.json')
    if args.integration_config.stat().st_size>16384:raise ValueError('bounded explicit integration config required')
    config=json.loads(args.integration_config.read_text());release.verify_config(config)
    runtime=Path(config['runtime_root']).resolve(strict=True);checked_index(runtime,'runtime-index.json',release.BASE_INDEX)
    if (config['hud_sha256']!=index['lib/libunified_stereo_hud.so']['sha256'] or
            config['record_library_sha256']!='1163c498f66f33e5aebf70ddc9c69891eeef1f336b9152eecba0ccd8306e7e1b'):
        raise ValueError('fixed stereo HUD/qualified recording library required')
    if args.bit_sha256 is not None and args.bit_sha256!=release.BIT:raise ValueError('exact '+release.RELEASE_ID+' bit SHA256 required')
    if args.check_only or not args.run:
        print(json.dumps(dict(status='OFFLINE_READY_NOT_BOARD_ACCEPTANCE',profile=release.PROFILE,
            bit_sha256=release.BIT,source_commit=release.SOURCE,layouts=['both','cam0','cam1'],quality=75,
            initial_layout=config.get('initial_layout','both'),performance_target=release.PERFORMANCE_TARGET,
            source_order_policy='strict',start_seconds=None,max_browser_commands=None,recording='FINAL_COMPOSED_NV12_CIRCULAR',
            native_release='RETAIN_AFTER_ONE_STOP_DRAIN_AND_RECORD_TAIL',hardware_actions=0)))
        return 0
    if (args.bit_sha256!=release.BIT or not args.joint_cold_confirmed or not args.programming_note or
            args.expected_boot is None or str(UUID(args.expected_boot))!=args.expected_boot or args.run_dir is None or
            args.kms_selection is None or args.kms_selection_sha256 is None):raise ValueError('current boot/programming/exclusive KMS receipts required')
    if Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=args.expected_boot:raise ValueError('live boot differs')
    sys.path[:0]=[str(control),str(runtime)]
    import dual_r3_driver as driver
    from kms_display import load_selection
    from launch_calfix_algorithm_trial import trial_guards
    from handoff import save_new
    selection=load_selection(args.kms_selection,args.kms_selection_sha256,args.expected_boot,live=True)
    if (config['connector_id'],config['plane_id'])!=(selection['connector_id'],selection['plane_id']):raise ValueError('stereo KMS route differs')
    target=driver.check_target(args.expected_boot,expected_bdf=args.expected_bdf,identity='stereo-n2')
    driver.verify_ko(runtime/'ph1a_c2h.ko',identity='stereo-n2')
    guards=trial_guards(args.expected_boot)
    if any(os.path.lexists(x) for x in guards):raise ValueError('prior video attempt in this boot; no hot reopen')
    run=args.run_dir
    if not run.is_absolute() or '..' in run.parts or run.exists() or not run.parent.is_dir() or any(p.is_symlink() for p in (run,*run.parents)):raise ValueError('fresh absolute run directory required')
    space=os.statvfs(run.parent)
    if space.f_bavail*space.f_frsize<128*1024*1024:raise ValueError('128MiB free evidence space required before native open')
    os.environ.update(GST_REGISTRY=str(run/'gst-registry.bin'),GST_REGISTRY_1_0=str(run/'gst-registry.bin'),GST_DEBUG='2',OPENBLAS_NUM_THREADS='1')
    from fps_hud import verify_libraries
    verify_libraries('dual')
    if 'linux' in sys.modules:raise ValueError('fresh standalone stereo process required')
    namespace=ModuleType('linux');namespace.__path__=[str(runtime/'peer/linux')];sys.modules['linux']=namespace
    sys.path.insert(0,str(runtime/'peer'))
    from display_recording import admit
    from circular_recording import require_replay_leases
    require_replay_leases(config['recording']);admit(config['recording'],boot=args.expected_boot,require_space=False)
    from unified_stereo_control import Broker,ControlServer
    from unified_stereo_owner import StereoOwner
    StereoOwner=partial(StereoOwner,cold_factory=release.UnifiedCold,router_factory=release.StrictRouter,profile=release.PROFILE)
    from linux.dma_c2h_candidate.receiver import Receiver
    from linux.rk_debug.cli import hold_retained_owner
    stop=threading.Event();holder={}
    def cached(key):return holder.get('owner').cached().get(key) if holder.get('owner') is not None else None
    broker=Broker(stop,recording_provider=lambda:cached('recording'),source_rates_provider=lambda:cached('source_rates'),
        firmware=dict(bit=release.BIT_LABEL,bit_sha256=release.BIT,fpga_source=release.SOURCE),
        initial_layout=config.get('initial_layout','both'),performance_target=release.PERFORMANCE_TARGET)
    server=ControlServer(broker)
    run.mkdir(mode=0o700)
    save_new(guards[3],dict(boot=args.expected_boot,profile=release.PROFILE,run_dir=str(run),bit_sha256=release.BIT))
    save_new(run/'programming.json',dict(note=args.programming_note,bit_sha256=release.BIT,sram_readback=False,boot=args.expected_boot))
    signal.signal(signal.SIGINT,lambda *_:stop.set());signal.signal(signal.SIGTERM,lambda *_:stop.set())
    threading.Thread(target=server.serve_forever,daemon=True).start();receiver=owner=None
    report=dict(state='STARTUP_RETAINED_RESULT_UNKNOWN')
    try:
        try:
            receiver=Receiver(target['device'],nonblocking=True)
            owner=StereoOwner(receiver,config,boot=args.expected_boot,run=run,stop_event=stop,broker=broker);holder['owner']=owner
            report=owner.run()
        except BaseException as error:
            stop.set();report=dict(state='FAULTED_RETAINED',failure=type(error).__name__+': '+str(error)[:512])
            try:broker.stopped(report['failure'])
            except BaseException as failure:report['control_report_error']=str(failure)[:512]
        save_new(run/'result.json',report)
    finally:
        # A report/FSYNC failure must not bypass native/graph retention.
        hold_retained_owner((receiver,owner,broker,server),report)

if __name__=='__main__':raise SystemExit(main())
