"""Private layout queue for one retained Unified R3 stereo video owner.

HTTP handles bounded commands and sets the supplied stop Event. Only the thread
constructing Broker may take/confirm commands or declare video stopped. Layout
confirmation describes a real composed frame, never an FPGA APPLIED receipt.
Providers must return cached software state; HTTP must not touch native video.
"""
from collections import OrderedDict
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
import threading
import time

try:
    from .unified_r3_mono import BIT, SOURCE, BIT_LABEL
except ImportError:
    from unified_r3_mono import BIT, SOURCE, BIT_LABEL

ORIGIN = 'http://rk3576-history.tail346db8.ts.net'
LAYOUTS = {'both':'左右同屏', 'cam0':'仅显示左眼 CAM0', 'cam1':'仅显示右眼 CAM1'}


class Broker:
    def __init__(self, stop_event, *, clock=time.monotonic,
                 confirmation_timeout_s=10, recording_provider=None, source_rates_provider=None,
                 firmware=None,initial_layout='both',performance_target=None):
        if not callable(getattr(stop_event,'set',None)) or not callable(getattr(stop_event,'is_set',None)):
            raise TypeError('the existing video owner stop Event is required')
        if (type(confirmation_timeout_s) not in (int,float) or
                not 0 < confirmation_timeout_s <= 30):
            raise ValueError('bounded positive layout confirmation timeout required')
        if type(initial_layout) is not str or initial_layout not in LAYOUTS:raise ValueError('unknown initial stereo layout')
        identity=dict(bit=BIT_LABEL,bit_sha256=BIT,fpga_source=SOURCE) if firmware is None else deepcopy(firmware)
        if (type(identity) is not dict or set(identity)!={'bit','bit_sha256','fpga_source'} or
                type(identity['bit']) is not str or not identity['bit'] or
                type(identity['bit_sha256']) is not str or type(identity['fpga_source']) is not str or
                re.fullmatch(r'[0-9a-f]{64}',identity['bit_sha256']) is None or
                re.fullmatch(r'[0-9a-f]{40}',identity['fpga_source']) is None):
            raise ValueError('explicit firmware label, bit SHA256 and source commit required')
        self.firmware,self.initial_layout,self.performance_target=identity,initial_layout,performance_target
        self.stop_event,self.clock=stop_event,clock
        self.confirmation_timeout_s=confirmation_timeout_s
        self.recording_provider,self.source_rates_provider=recording_provider,source_rates_provider
        self.owner=threading.get_ident();self.lock=threading.RLock()
        self.run_id=secrets.token_hex(16);self.token=secrets.token_urlsafe(32)
        self.revision=0;self.phase='WAITING_OWNER';self.current=None
        self.layout_revision=None;self.frame_ordinal=None;self.pending=None
        self.commands=OrderedDict();self.total_commands=0;self.failure=None
        self._heartbeat=None;self._deadline=None

    def _owner(self):
        if threading.get_ident()!=self.owner:raise RuntimeError('only the video owner may confirm or consume layout commands')

    def _sync_stop(self):
        if self.stop_event.is_set() and self.phase not in ('STOPPING','STOPPED','FAULTED'):
            self.phase='STOPPING'
            if self.pending is not None:
                self.commands[self.pending]['status']='CANCELLED_BY_STOP'
                self.pending=None;self._deadline=None

    def heartbeat_update(self):
        self._owner()
        with self.lock:self._heartbeat=self.clock()

    def _fresh(self):
        return self._heartbeat is not None and 0 <= self.clock()-self._heartbeat < 3

    def _available(self):
        return self.phase=='READY' and self.pending is None and self._fresh() and not self.stop_event.is_set()

    @staticmethod
    def _frame(layout_revision,frame_ordinal):
        if (type(layout_revision) is not int or not 0 <= layout_revision < 2**64 or
                type(frame_ordinal) is not int or not 0 < frame_ordinal < 2**64):
            raise ValueError('explicit real layout revision and composed frame ordinal required')

    def started(self,layout_revision,frame_ordinal,*,layout=None):
        self._owner();self._frame(layout_revision,frame_ordinal)
        layout=self.initial_layout if layout is None else layout
        with self.lock:
            self._sync_stop()
            if self.phase!='WAITING_OWNER' or layout!=self.initial_layout:raise ValueError('one initial real configured-layout frame required')
            self.current=layout;self.layout_revision=layout_revision;self.frame_ordinal=frame_ordinal
            self.phase='READY';self._heartbeat=self.clock()

    def submit(self,request):
        with self.lock:
            self._sync_stop()
            if type(request) is not dict:raise ValueError('exact command object required')
            action=request.get('action')
            fields={'run_id','revision','request_id','action'} | ({'layout'} if action=='layout' else set())
            if set(request)!=fields or action not in ('layout','stop'):raise ValueError('exact layout/stop request fields required')
            if (request['run_id']!=self.run_id or type(request['revision']) is not int or
                    request['revision']<0):raise ValueError('stale run or revision')
            key=request['request_id'];prefix=self.run_id+'-'+str(request['revision'])+'-'
            if (type(key) is not str or not key.startswith(prefix) or
                    re.fullmatch(r'[A-Za-z0-9_-]{8,48}',key[len(prefix):]) is None):
                raise ValueError('request ID must bind this run/revision and a fresh nonce')
            if action=='layout' and (type(request['layout']) is not str or request['layout'] not in LAYOUTS):raise ValueError('unknown layout; fixed Q75 pure SDR only')
            if key in self.commands:
                old=self.commands[key]
                if old['request']!=request:raise ValueError('request ID reused with changed content')
                return deepcopy(old)
            if request['revision']!=self.revision or self.phase in ('STOPPING','STOPPED','FAULTED'):
                raise ValueError('owner stopping or stale revision')
            if action=='layout' and (not self._available() or request['layout']==self.current):
                raise ValueError('layout already active, owner unavailable or pending confirmation')
            entry=dict(request=deepcopy(request),status='QUEUED',confirmation=None)
            self.commands[key]=entry;self.total_commands+=1;self.revision+=1
            if action=='stop':
                if self.pending is not None:self.commands[self.pending]['status']='CANCELLED_BY_STOP'
                self.pending=None;self._deadline=None;self.phase='STOPPING'
                entry['status']='STOP_REQUESTED';self.stop_event.set()
            else:
                self.pending=key;self.phase='QUEUED'
                self._deadline=self.clock()+self.confirmation_timeout_s
            while len(self.commands)>64:self.commands.popitem(last=False)
            return deepcopy(entry)

    def take(self):
        self._owner()
        with self.lock:
            self._sync_stop()
            if self.phase!='QUEUED' or self.pending is None:return None
            if self.clock()>self._deadline:
                self._failed_locked('layout confirmation deadline exceeded');return None
            entry=self.commands[self.pending];entry['status']='WAITING_REAL_VIDEO'
            self.phase='VERIFYING_VIDEO'
            return deepcopy(entry['request'])

    def completed(self,request_id,layout_revision,frame_ordinal):
        self._owner();self._frame(layout_revision,frame_ordinal)
        with self.lock:
            self._sync_stop()
            if (self.phase!='VERIFYING_VIDEO' or self.pending!=request_id or
                    layout_revision<=self.layout_revision or frame_ordinal<=self.frame_ordinal):
                raise ValueError('no matching new real composed-frame confirmation')
            if self.clock()>self._deadline:
                self._failed_locked('layout confirmation deadline exceeded')
                raise ValueError('layout confirmation arrived after deadline')
            entry=self.commands[self.pending]
            self.current=entry['request']['layout'];self.layout_revision=layout_revision;self.frame_ordinal=frame_ordinal
            entry.update(status='VIDEO_CONFIRMED',confirmation=dict(layout_revision=layout_revision,frame_ordinal=frame_ordinal))
            self.pending=None;self._deadline=None;self.phase='READY';self._heartbeat=self.clock()

    def _failed_locked(self,error):
        self.failure=str(error)[:512];self.phase='FAULTED'
        if self.pending is not None:self.commands[self.pending]['status']='LAYOUT_NOT_CONFIRMED'
        self.pending=None;self._deadline=None;self.stop_event.set()

    def failed(self,request_id,error):
        self._owner()
        with self.lock:
            self._sync_stop()
            if self.phase not in ('QUEUED','VERIFYING_VIDEO') or request_id!=self.pending:
                raise ValueError('failure must identify the pending owner request')
            self._failed_locked(error)

    def check_timeout(self):
        self._owner()
        with self.lock:
            self._sync_stop()
            if self.phase in ('QUEUED','VERIFYING_VIDEO') and self.clock()>self._deadline:
                self._failed_locked('layout confirmation deadline exceeded');return True
            return False

    def stopped(self,detail=None):
        self._owner()
        with self.lock:
            self._sync_stop()
            if self.phase not in ('STOPPING','FAULTED'):raise ValueError('owner stop must follow a stop request or failure')
            if self.phase!='FAULTED':self.phase='STOPPED'
            if detail is not None:self.failure=str(detail)[:512];self.phase='FAULTED'

    @staticmethod
    def _provided(provider):
        if provider is None:return None
        try:return deepcopy(provider())
        except Exception as error:return dict(status='UNAVAILABLE',error=str(error)[:128])

    def state(self):
        with self.lock:
            self._sync_stop()
            value=deepcopy(dict(schema=1,run_id=self.run_id,revision=self.revision,token=self.token,
                phase=self.phase,current=self.current,layout_revision=self.layout_revision,frame_ordinal=self.frame_ordinal,
                pending=self.pending,failure=self.failure,accepting=self._available(),owner_fresh=self._fresh(),
                can_stop=self.phase not in ('STOPPING','STOPPED','FAULTED'),commands=list(self.commands.values()),
                total_commands=self.total_commands,remaining_s=None,max_commands=None,continuous=True,
                **self.firmware,initial_layout=self.initial_layout,performance_target=self.performance_target,
                quality=75,received_cameras=[0,1],
                sensor_mode='DUAL_SDR_COLOR',layouts=[dict(id=k,label=v) for k,v in LAYOUTS.items()],
                video_evidence='REAL_COMPOSED_FRAME_CONFIRMATION_NOT_FPGA_APPLIED_OR_PHYSICAL_SCANOUT'))
        value['recording']=self._provided(self.recording_provider)
        value['source_rates']=self._provided(self.source_rates_provider)
        return value


class ControlServer(ThreadingHTTPServer):
    daemon_threads=True;request_queue_size=4
    def __init__(self,broker,*,port=8766,origin=ORIGIN,page=None):
        if (origin!=ORIGIN and re.fullmatch(r'http://127\.0\.0\.1:[0-9]{1,5}',origin) is None
                and re.fullmatch(r'http://[a-z0-9-]+\.[a-z0-9-]+\.ts\.net',origin) is None):
            raise ValueError('fixed private control origin required')
        self.broker,self.origin=broker,origin
        self.page=Path(page) if page is not None else Path(__file__).with_suffix('.html')
        self.slots=threading.BoundedSemaphore(4)
        super().__init__(('127.0.0.1',port),ControlHandler)
    def process_request(self,request,address):
        if not self.slots.acquire(False):self.shutdown_request(request);return
        try:super().process_request(request,address)
        except BaseException:self.slots.release();raise
    def process_request_thread(self,request,address):
        try:super().process_request_thread(request,address)
        finally:self.slots.release()


class ControlHandler(BaseHTTPRequestHandler):
    def setup(self):super().setup();self.connection.settimeout(2)
    def log_message(self,*args):pass
    def reply(self,code,value,*,html=False):
        data=value if html else json.dumps(value,ensure_ascii=False,allow_nan=False).encode()
        if len(data)>65536:code=503;html=False;data=b'{"error":"bounded control state unavailable"}'
        self.send_response(code);self.send_header('Content-Type','text/html; charset=utf-8' if html else 'application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.end_headers();self.wfile.write(data)
    def valid_host(self):
        return len(self.headers.get_all('Host',[]))==1 and self.headers['Host']==self.server.origin.removeprefix('http://')
    def do_GET(self):
        if not self.valid_host():self.reply(403,{'error':'invalid host'});return
        if self.path in ('/control','/control/'):self.reply(200,self.server.page.read_bytes(),html=True)
        elif self.path=='/control/api/state':self.reply(200,self.server.broker.state())
        else:self.reply(404,{'error':'not found'})
    def do_POST(self):
        if (not self.valid_host() or len(self.headers.get_all('Origin',[]))!=1 or
                self.headers['Origin']!=self.server.origin or
                len(self.headers.get_all('X-Control-Token',[]))!=1 or
                not self.headers['X-Control-Token'].isascii() or
                not secrets.compare_digest(self.headers['X-Control-Token'],self.server.broker.token)):
            self.reply(403,{'error':'reload this private control page'});return
        if self.path!='/control/api/command':self.reply(404,{'error':'not found'});return
        try:
            if len(self.headers.get_all('Content-Length',[]))!=1:raise ValueError('one length required')
            length=int(self.headers['Content-Length'])
            if (not 0<length<=1024 or self.headers.get('Transfer-Encoding') is not None or
                    self.headers.get_content_type()!='application/json'):raise ValueError('bounded JSON required')
            raw=self.rfile.read(length)
            if len(raw)!=length:raise ValueError('short command')
            self.reply(202,self.server.broker.submit(json.loads(raw)))
        except (ValueError,TypeError,KeyError):
            self.reply(409,{'error':'请求未受理；刷新状态查看本轮记录，不要重发结果未知的请求。'})
