"""Unlimited private 4G mode/layout queue; never accesses FPGA or video IO."""
from copy import deepcopy
from pathlib import Path
import re

try:
    from . import camera_raw_release as release
    from .unified_stereo_control import Broker as LayoutBroker,ControlServer as LayoutServer,LAYOUTS
except ImportError:
    import camera_raw_release as release
    from unified_stereo_control import Broker as LayoutBroker,ControlServer as LayoutServer,LAYOUTS


class Broker(LayoutBroker):
    def __init__(self,stop_event,*,session,**kwargs):
        self.session_name=session;self.spec=release.session_spec(session)
        self.mode_rows=release.modes(session);self.current_mode='raw' if self.spec['product']=='raw' else 'color'
        self.mode_epoch=0
        super().__init__(stop_event,firmware=dict(bit=release.BIT_LABEL,bit_sha256=release.BIT,fpga_source=release.SOURCE),
            initial_layout='cam0',performance_target='按实际新 SOURCE 分别统计输入、解码和显示帧率',**kwargs)

    def _cancelled_by_stop(self):
        self._sync_stop()
        return self.stop_event.is_set() and self.phase in ('STOPPING','STOPPED')

    def started(self,layout_revision,frame_ordinal,*,layout=None):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            try:super().started(layout_revision,frame_ordinal,layout=layout)
            except ValueError:
                if self._cancelled_by_stop():return False
                raise
            return True

    def completed(self,request_id,layout_revision,frame_ordinal):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            try:super().completed(request_id,layout_revision,frame_ordinal)
            except ValueError:
                if self._cancelled_by_stop():return False
                raise
            return True

    def submit(self,request):
        with self.lock:
            self._sync_stop()
            if type(request) is not dict:raise ValueError('exact mode/layout/stop request required')
            action=request.get('action');extra={'mode'} if action=='mode' else {'layout'} if action=='layout' else set()
            if action not in ('mode','layout','stop') or set(request)!={'run_id','revision','request_id','action'}|extra:
                raise ValueError('exact command fields required')
            if request['run_id']!=self.run_id or type(request['revision']) is not int or request['revision']<0:raise ValueError('stale run/revision')
            key=request['request_id'];prefix=self.run_id+'-'+str(request['revision'])+'-'
            if type(key) is not str or not key.startswith(prefix) or re.fullmatch(r'[A-Za-z0-9_-]{8,48}',key[len(prefix):]) is None:
                raise ValueError('fresh run/revision nonce required')
            if action=='mode' and (type(request['mode']) is not str or request['mode'] not in {r['id'] for r in self.mode_rows}):raise ValueError('mode not available in this cold session')
            if action=='mode' and self.spec['product']=='raw':raise ValueError('ARAW product is cold-selected; CFG disabled')
            if action=='layout' and (type(request['layout']) is not str or request['layout'] not in LAYOUTS or self.spec['product']=='raw' or self.spec['cameras']==1 and request['layout']!='cam0'):
                raise ValueError('layout not available for this topology')
            if key in self.commands:
                if self.commands[key]['request']!=request:raise ValueError('request ID reused with changed content')
                return deepcopy(self.commands[key])
            if request['revision']!=self.revision or self.phase in ('STOPPING','STOPPED','FAULTED'):raise ValueError('stale/stopped owner')
            field='mode' if action=='mode' else 'layout'
            if action!='stop' and (not self._available() or request[field]==(self.current_mode if action=='mode' else self.current)):
                raise ValueError('already active or owner busy')
            entry=dict(request=deepcopy(request),status='QUEUED',confirmation=None)
            self.commands[key]=entry;self.total_commands+=1;self.revision+=1
            if action=='stop':
                if self.pending is not None:self.commands[self.pending]['status']='CANCELLED_BY_STOP'
                self.pending=None;self._deadline=None;self.phase='STOPPING';entry['status']='STOP_REQUESTED';self.stop_event.set()
            else:
                self.pending=key;self.phase='QUEUED';self._deadline=self.clock()+self.confirmation_timeout_s
            while len(self.commands)>64:self.commands.popitem(last=False)
            return deepcopy(entry)

    def started_raw(self):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            if self.spec['product']!='raw' or self.phase!='WAITING_OWNER':raise ValueError('one receive-only cold start required')
            self.phase='READY';self._heartbeat=self.clock();return True

    def mode_applied(self,request_id,epoch):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            if self.phase!='VERIFYING_VIDEO' or self.pending!=request_id or type(epoch) is not int or epoch<=self.mode_epoch:
                raise ValueError('matching new actual APPLIED required')
            entry=self.commands[request_id]
            if entry['request']['action']!='mode':raise ValueError('not a mode command')
            entry.update(status='APPLIED_WAITING_REAL_VIDEO',applied_epoch=epoch)
            return True

    def completed_mode(self,request_id,epoch,frame_ordinal):
        self._owner()
        with self.lock:
            if self._cancelled_by_stop():return False
            if self.phase!='VERIFYING_VIDEO' or self.pending!=request_id:raise ValueError('mode confirmation no longer pending')
            entry=self.commands[request_id]
            if entry.get('applied_epoch')!=epoch or type(frame_ordinal) is not int or frame_ordinal<=self.frame_ordinal:
                raise ValueError('actual new mode video evidence required')
            if self.clock()>self._deadline:raise TimeoutError('mode warmup/video confirmation deadline exceeded')
            self.current_mode=entry['request']['mode'];self.mode_epoch=epoch;self.frame_ordinal=frame_ordinal
            entry.update(status='VIDEO_CONFIRMED',confirmation=dict(mode_epoch=epoch,frame_ordinal=frame_ordinal))
            self.pending=None;self._deadline=None;self.phase='READY';self._heartbeat=self.clock()
            return True

    def state(self):
        value=super().state()
        value.update(cold_session=self.session_name,cold_session_label=self.spec['label'],mode=self.current_mode,mode_epoch=self.mode_epoch,
            modes=deepcopy(self.mode_rows),received_cameras=list(range(self.spec['cameras'])),sensor_mode=self.session_name,
            layouts=[] if self.spec['product']=='raw' else [r for r in value['layouts'] if self.spec['cameras']==2 or r['id']=='cam0'],
            cold_selection='目数和JPEG/RAW产品需新冷启动会话',raw_isp_required=False,
            video_evidence='RAW_COMPLETE_RECORDS_ONLY_NO_HDMI' if self.spec['product']=='raw' else value['video_evidence'])
        return value


class ControlServer(LayoutServer):
    def __init__(self,broker,**kwargs):
        super().__init__(broker,page=Path(__file__).with_name('camera_raw_control.html'),**kwargs)
