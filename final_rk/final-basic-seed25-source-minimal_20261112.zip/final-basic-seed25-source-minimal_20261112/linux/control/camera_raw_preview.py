"""One display worker for CAMERA_RAW JPEG, lane, FPS and final recording."""
import ctypes
import hashlib
import json
from pathlib import Path
import time
from types import SimpleNamespace

try:
    from .unified_stereo_preview import StereoPreview
    from .unified_stereo_recording import StereoRecording
    from .camera_raw_native import CameraHud
    from .stereo_display_health import StereoDisplayHealth
    from .remote_mono_logs import RollingStream
    from . import camera_raw_release as release
except ImportError:
    from unified_stereo_preview import StereoPreview
    from unified_stereo_recording import StereoRecording
    from camera_raw_native import CameraHud
    from stereo_display_health import StereoDisplayHealth
    from remote_mono_logs import RollingStream
    import camera_raw_release as release


def graph_spec(sink,directory,*,cameras,product,software=False):
    if cameras not in (1,2) or product!='jpeg':raise ValueError('explicit display topology/product required')
    try:from .display_recording import graph_branch
    except ImportError:from display_recording import graph_branch
    fps=60 if cameras==1 else 30
    graph=('u3stereocompositor name=stereo_mix background=black start-time-selection=first '
        '! video/x-raw,format=NV12,width=1920,height=1080,framerate=%d/1 ! identity name=stereo_final ! '%fps+
        graph_branch(sink,directory,software=software).replace('framerate=60/1','framerate=%d/1'%fps))
    for c in range(cameras):
        decode='jpegparse ! '+('jpegdec ! videoconvert' if software else 'mppjpegdec format=NV12')+' ! '
        caps='image/jpeg'
        graph+=(' appsrc name=cam%d is-live=true format=time block=false max-buffers=2 leaky-type=downstream '
            'caps="%s,width=1920,height=1080,framerate=0/1" ! %s'
            'video/x-raw,format=NV12,width=1920,height=1080 ! identity name=stereo_decoded%d '
            '! queue max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! stereo_mix.sink_%d')%(c,caps,decode,c,c)
    return graph


class CameraPreview(StereoPreview):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.cameras=self.config['cameras'];self.product=self.config['product']
        if self.product!='jpeg':raise ValueError('RAW session is receive-only; no display graph')
        self.camera_display_policy=self.config.get('jpeg_display_policy')
        if 'jpeg_display_policy' in self.config:
            if (self.config.get('firmware_release')!=release.RELEASE_ID or
                    not isinstance(self.camera_display_policy,dict) or
                    self.camera_display_policy!=release.JPEG_DISPLAY_POLICY or
                    type(self.camera_display_policy.get('threads_per_eye')) is not int):
                raise ValueError('explicit CAMERA_RAW JPEG display policy required')
        self.grace_until=0;self.lane_core=None;self.lane_context=None;self.lane_origin=None

    def transition_until(self,deadline_ns):
        with self.cv:self.grace_until=deadline_ns

    def _graph(self,sink,directory):
        return graph_spec(sink,directory,cameras=self.cameras,product=self.product)

    def _graph_ready(self,Gst):
        pass

    def _graph_finish(self):
        pass

    def _publish(self):
        hud=self.hud.snapshot();recording=self.recorder.snapshot()
        if hud['error']:raise RuntimeError('CAMERA_RAW compositor identity/HUD error '+str(hud['error']))
        self.recorder.check();timing=self.hud.timing_snapshot();now=time.monotonic_ns()
        with self.cv:grace=now<self.grace_until
        if grace:self.health=StereoDisplayHealth(started_ns=now)
        health=None if grace else self.health.observe(timing,now_ns=now)
        scaler=self.hud.fast_snapshot() if self.camera_display_policy else None
        frame_timing=self.hud.frame_timing_snapshot() if self.camera_display_policy else None
        with self.cv:self.cache.update(hud=hud,timing=timing,display_health=health,recording=recording,
            rendered=self.hud.latest,scaler=scaler,frame_timing=frame_timing,worker_alive=True,closing=self.closing,mode_warmup=grace)
        return hud

    def _lane(self,item,received):
        if not release.confirmed_processing_mask(item.record.metadata,source_epoch=item.epoch)&48:return None
        if self.cameras!=1:raise ValueError('dual lane is unsupported')
        try:from .dual_r3_lane import analysis_summary
        except ImportError:from dual_r3_lane import analysis_summary
        summary=analysis_summary(item.record)
        if summary['negative_analysis_terminals'] or summary['sparse_frame_error']:raise ValueError('FPGA lane terminal error')
        context=(item.session,item.epoch)
        if context!=self.lane_context:self.lane_core.reset();self.lane_context=context;self.lane_origin=received
        result=self.lane_core.process(summary['lane_points'],session=item.session,epoch=item.epoch,sequence=item.sequence,
            camera=item.camera,seconds=(received-self.lane_origin)/1e9)
        return dict(polylines=result['polylines'],labels=[r['label'] for r in result['curves']],
            packed=result.get('packed'),curve_count=len(result['curves']))

    def _push(self,Gst,item,received):
        payload=item.record.jpeg;lane=self._lane(item,received)
        clock=self.pipeline.get_clock();base=self.pipeline.get_base_time()
        if clock is None or base==Gst.CLOCK_TIME_NONE:raise ValueError('CAMERA_RAW display clock not established')
        pts=max(int(clock.get_time()-base),self.last_pts[item.camera]+1);self.last_pts[item.camera]=pts
        period=self.hud.register(item,pts,received,lane=lane)
        buffer=Gst.Buffer.new_allocate(None,len(payload),None);buffer.fill(0,payload)
        buffer.pts=buffer.dts=pts;buffer.duration=period if period is not None else Gst.CLOCK_TIME_NONE
        if self.sources[item.camera].emit('push-buffer',buffer)!=Gst.FlowReturn.OK:raise RuntimeError('CAMERA_RAW appsrc rejected input')
        with self.cv:self.cache['submitted'][item.camera]+=1

    def _run(self):
        log=None
        try:
            import gi
            gi.require_version('Gst','1.0');from gi.repository import Gst
            Gst.init(None)
            self.hud=CameraHud(self.config['hud_library'],self.config['hud_sha256'],cameras=self.cameras,
                product=self.product,preview_policy=self.camera_display_policy);self.hud.realtime()
            library=Path(self.config['record_library'])
            if hashlib.sha256(library.read_bytes()).hexdigest()!=self.config['record_library_sha256']:raise ValueError('recording library differs')
            self.record_library=SimpleNamespace(lib=ctypes.CDLL(str(library)))
            self.recorder=StereoRecording(self.config['recording'],boot=self.boot,output=self.output,hud=self.hud)
            if self.cameras==1 and self.product=='jpeg':
                try:from .c1_lane_core import LaneCore
                except ImportError:from c1_lane_core import LaneCore
                self.lane_core=LaneCore(self.config['lane_library'],expected_sha256=self.config['lane_sha256'],
                    sampler_library=self.config['lane_sampler_library'],sampler_sha256=self.config['lane_sampler_sha256'])
            sink=('kmssink name=display_sink driver-name=rockchip sync=false force-modesetting=true skip-vsync=true '
                'connector-id=%d plane-id=%d')%(self.config['connector_id'],self.config['plane_id'])
            self.pipeline=Gst.parse_launch(self._graph(sink,str(self.recorder.io_directory)))
            self.hud.attach(self.pipeline);self.hud.layout('cam0',1)
            self.sources=[self.pipeline.get_by_name('cam'+str(c)) for c in range(self.cameras)];self.last_pts=[0,0]
            self.recorder.attach(SimpleNamespace(_Gst=Gst,_pipeline=self.pipeline),self.record_library)
            self._graph_ready(Gst)
            log=RollingStream(self.output/'camera-preview.jsonl','x',encoding='utf-8');self.bus=self.pipeline.get_bus()
            if self.pipeline.set_state(Gst.State.PLAYING)==Gst.StateChangeReturn.FAILURE:raise RuntimeError('CAMERA_RAW graph PLAYING failed')
            began=time.monotonic();self.health=StereoDisplayHealth(started_ns=time.monotonic_ns());self.ready.set()
            last_log=0;last_count=[0]*(self.cameras+1);last_progress=[began]*len(last_count)
            while True:
                with self.cv:
                    if self.closing:break
                    items=list(self.pending);self.pending=[None,None];request=self.request;self.request=None;grace=self.grace_until
                if request is not None:self.hud.layout(*request)
                for entry in items:
                    if entry is not None:self._push(Gst,*entry)
                message=self.bus.pop_filtered(Gst.MessageType.ERROR)
                if message is not None:
                    error,debug=message.parse_error();raise RuntimeError(str(error)+': '+str(debug)[:512])
                state=self._publish();now=time.monotonic()
                for i,key in enumerate([*('decoded'+str(c) for c in range(self.cameras)),'frames']):
                    if time.monotonic_ns()<grace or state[key]!=last_count[i]:last_count[i]=state[key];last_progress[i]=now
                    if now-began>15 and now-last_progress[i]>3:raise TimeoutError('CAMERA_RAW decoder or final output stalled')
                if now-last_log>=1:
                    log.write(json.dumps(dict(host_ns=time.monotonic_ns(),hud=state,timing=self.cache.get('timing'),
                        rendered=self.cache.get('rendered'),recording=self.cache['recording'],
                        scaler=self.cache.get('scaler'),frame_timing=self.cache.get('frame_timing')))+'\n');log.flush();last_log=now
                with self.cv:
                    if not self.closing and all(x is None for x in self.pending) and self.request is None:self.cv.wait(.005)
        except BaseException as error:
            with self.cv:self.cache['failure']=type(error).__name__+': '+str(error)[:512]
        finally:
            try:
                self._graph_finish()
                if self.hud is not None:self.hud.freeze()
                if self.recorder is not None:
                    final=self.recorder.finish(timeout=12)
                    with self.cv:self.cache['recording_final']=final
                    if final.get('error'):raise RuntimeError(final['error'])
            except BaseException as error:
                with self.cv:self.cache['failure']=self.cache['failure'] or str(error)[:512]
            with self.cv:self.closing=True;self.cache.update(worker_done=True,worker_alive=False,closing=True,resources_retained=True)
            if log is not None:log.close()
            self.ready.set()
