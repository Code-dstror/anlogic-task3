"""One retained cold DUAL owner: receive both eyes, local layouts, one STOP."""
from copy import deepcopy
import json
import hashlib
import os
from pathlib import Path
import threading
import time

try:
    from .unified_r3_stereo import UnifiedCold,StrictRouter,PROFILE
    from .unified_stereo_preview import StereoPreview
    from .remote_mono_logs import RollingStream
    from .display_record_seal import durable_json
except ImportError:
    from unified_r3_stereo import UnifiedCold,StrictRouter,PROFILE
    from unified_stereo_preview import StereoPreview
    from remote_mono_logs import RollingStream
    from display_record_seal import durable_json

class StereoOwner:
    def __init__(self,receiver,config,*,boot,run,stop_event,broker=None,preview_factory=StereoPreview,
                 storage_prepare=None,clock=time.monotonic,reader_factory=None,
                 cold_factory=UnifiedCold,router_factory=StrictRouter,profile=PROFILE):
        self.receiver,self.config,self.boot,self.run_dir=receiver,config,boot,Path(run)
        self.stop_event,self.broker,self.clock=stop_event,broker,clock
        self.preview_factory,self.storage_prepare,self.reader_factory=preview_factory,storage_prepare,reader_factory
        self.profile,self.router_factory=profile,router_factory
        self.initial_layout=config.get('initial_layout','both')
        if self.initial_layout not in ('both','cam0','cam1'):raise ValueError('unknown initial stereo layout')
        self.state='NEW';self.failure=None;self.preview=self.router=self.reader=None
        self.evidence_error=None
        self.receipt=None;self.start_intent=self.stop_intent=False;self.start_returned=self.stop_returned=False;self.drained=False
        self.host_drain_attempted=False;self.fault_drain_failure=None
        self.started=None;self.last_rx=[None,None];self.events=RollingStream(self.run_dir/'owner-events.jsonl','x',encoding='utf-8')
        self.cache_lock=threading.Lock();self.cache={};self.layout_revision=1;self.pending_layout=None;self.ready=False
        self.final_preview=None
        self.saved_first=[False,False]
        self.cold=cold_factory(receiver,evidence=self._cold_evidence,on_admitted=self._storage)

    def _event(self,name,**value):
        self.events.write(json.dumps(dict(event=name,host_ns=time.monotonic_ns(),**value),sort_keys=True)+'\n');self.events.flush()

    def _cold_evidence(self,value):durable_json(self.run_dir/'cold-preparation.json',value)

    def _storage(self,caps):
        if self.stop_event.is_set():raise RuntimeError('user stop before stereo storage/topology admission')
        if self.storage_prepare is not None:value=self.storage_prepare(caps)
        else:
            try:from .circular_recording import prepare_space
            except ImportError:from circular_recording import prepare_space
            value=prepare_space(self.config['recording'],boot=self.boot,execute=True)
        durable_json(self.run_dir/'storage-ready.json',value)

    def feed(self,wire,*,host_ns=None,transport_identity=None,completion_metadata=None):
        item=self.router.feed(wire,host_ns=host_ns,transport_identity=transport_identity,completion_metadata=completion_metadata)
        if not self.saved_first[item.camera]:
            self.saved_first[item.camera]=True
            with (self.run_dir/('first-cam%d.ajpg'%item.camera)).open('xb') as stream:
                stream.write(wire);stream.flush();os.fsync(stream.fileno())
            durable_json(self.run_dir/('first-cam%d.json'%item.camera),dict(camera=item.camera,session=item.session,epoch=item.epoch,
                sequence=item.sequence,host_ns=host_ns,completion_metadata=completion_metadata,transport_identity=transport_identity,
                bytes=len(wire),sha256=hashlib.sha256(wire).hexdigest()))
        return item,host_ns

    def _poll(self,display):
        for item in self.reader.poll_once(.01):
            if isinstance(item,dict):
                from linux.dma_c2h_candidate.c2h_abi import RESULT_CANCELLED
                if display or item.get('kind')!='TRANSPORT_RESULT' or item.get('result')!=RESULT_CANCELLED:raise RuntimeError('unexpected negative stereo completion')
            else:
                item,received_ns=item
                self.last_rx[item.camera]=self.clock()
                if display:self.preview.submit(item,received_ns)

    def _stop_once(self):
        if self.stop_intent:return
        self.stop_intent=True
        # Evidence IO must not prevent the one actual STOP. The intent flag
        # remains consumed even if either syscall acceptance or logging is unknown.
        try:self._event('STOP_CALL')
        except BaseException as error:self.evidence_error=str(error)[:512]
        self.receiver.stop();self.stop_returned=True
        try:self._event('STOP_RETURN')
        except BaseException as error:self.evidence_error=self.evidence_error or str(error)[:512]

    def _drain_host(self):
        # A returned STOP does not consume its completion. Use the same healthy
        # reader and exact leases, including CANCELLED tails, before record EOS.
        # Never retry uncertain transport IO or interpret host drain as FPGA
        # global quiet / permission to release native resources.
        self.host_drain_attempted=True;self.state='DRAINING';deadline=self.clock()+3
        while True:
            self._poll(False)
            if self.reader.drained():self.drained=True;return
            if self.clock()>=deadline:raise TimeoutError('stereo host drain unconfirmed; retain owner')

    def cached(self):
        with self.cache_lock:return deepcopy(self.cache)

    def _publish(self):
        preview={} if self.preview is None else self.preview.snapshot()
        value=dict(state=self.state,failure=self.failure,profile=self.profile,
                   source_rates=None if self.router is None else self.router.snapshot(),preview=preview,
                   recording=preview.get('recording_final') or preview.get('recording'),
                   start_intent=self.start_intent,start_returned=self.start_returned,stop_intent=self.stop_intent,
                   stop_returned=self.stop_returned,host_drain_attempted=self.host_drain_attempted,
                   fault_drain_failure=self.fault_drain_failure,host_transport_drained=self.drained)
        with self.cache_lock:self.cache=value
        durable_json(self.run_dir/'status.json',value)
        return value

    def _control(self,preview):
        if self.broker is None:return
        if self.stop_event.is_set():return
        self.broker.heartbeat_update()
        if self.broker.check_timeout():raise TimeoutError('stereo layout video confirmation deadline exceeded')
        hud=preview.get('hud') or {}
        if (not self.ready and hud.get('frames',0)>0 and hud.get('revision')==1 and
                hud.get('layout')==('both','cam0','cam1').index(self.initial_layout)):
            self.broker.started(1,hud['frames'],layout=self.initial_layout);self.ready=True
        request=self.broker.take()
        if request is not None:
            self.layout_revision+=1;self.preview.request_layout(request['layout'],self.layout_revision)
            self.pending_layout=(request['request_id'],self.layout_revision,request['layout'])
            self._event('LAYOUT_REQUEST',request_id=request['request_id'],layout=request['layout'],layout_revision=self.layout_revision)
        if (self.pending_layout is not None and hud.get('revision')==self.pending_layout[1] and
                hud.get('layout')==('both','cam0','cam1').index(self.pending_layout[2])):
            self.broker.completed(self.pending_layout[0],hud['revision'],hud['frames'])
            self._event('LAYOUT_VIDEO_CONFIRMED',layout_revision=hud['revision'],frame_ordinal=hud['frames']);self.pending_layout=None

    def run(self):
        if self.state!='NEW':raise RuntimeError('one cold stereo run only; no retry')
        self.state='PREPARING';preview_attempted=False;last_publish=0
        try:
            self.receipt=self.cold.prepare();self._event('COLD_DUAL_N2_SELECT4_ACK')
            if self.stop_event.is_set():self.state='STOPPED_BEFORE_START_RETAINED';return self.snapshot()
            self.router=self.router_factory(source_sessions=self.receipt['source_sessions'],source_epochs=self.receipt['source_epochs'],evidence_dir=self.run_dir)
            if self.reader_factory is None:
                try:from .stereo_owned_record_reader import MetadataOwnedRecordReader
                except ImportError:from stereo_owned_record_reader import MetadataOwnedRecordReader
                self.reader_factory=MetadataOwnedRecordReader
            self.reader=self.reader_factory(self.receiver,self,maximum_batch=2,record_budget=None)
            self.preview=self.preview_factory(self.run_dir/'preview',self.config,boot=self.boot);preview_attempted=True
            self.preview.start()
            if self.stop_event.is_set():self.state='STOPPED_BEFORE_START_RETAINED';return self.snapshot()
            self._event('START_CALL');self.start_intent=True;self.started=self.clock();self.receiver.start();self.start_returned=True;self._event('START_RETURN');self.state='RUNNING'
            while not self.stop_event.is_set():
                self._poll(True);self.preview.check();preview=self.preview.snapshot();self._control(preview)
                now=self.clock()
                if now-self.started>5 and any(x is None or now-x>3 for x in self.last_rx):raise TimeoutError('one stereo SOURCE has stopped progressing')
                if now-last_publish>=1:self._publish();last_publish=now
            self.state='DRAINING';self._stop_once();self._drain_host()
            self.state='DRAINED_RETAINED'
        except BaseException as error:
            self.failure=type(error).__name__+': '+str(error)[:512];self.state='FAULTED_RETAINED';self.stop_event.set()
            if self.start_intent and not self.stop_intent:
                try:self._stop_once()
                except BaseException as failure:self._event('STOP_UNKNOWN_NO_RETRY',error=str(failure)[:512])
            if (self.start_returned and self.stop_returned and not self.host_drain_attempted and
                    self.reader is not None and self.reader.fault is None):
                try:self._drain_host()
                except BaseException as failure:self.fault_drain_failure=type(failure).__name__+': '+str(failure)[:512]
                finally:self.state='FAULTED_RETAINED'
        finally:
            if preview_attempted:
                try:
                    self.final_preview=self.preview.close(timeout_s=15)
                    if self.final_preview.get('failure') or not self.final_preview.get('worker_done'):raise RuntimeError(self.final_preview.get('failure') or 'stereo display worker retained pending')
                except BaseException as error:
                    self.failure=self.failure or str(error)[:512];self.state='FAULTED_RETAINED'
            self.stop_event.set()
            if self.evidence_error is not None:
                self.failure=self.failure or 'stop evidence: '+self.evidence_error;self.state='FAULTED_RETAINED'
            if self.broker is not None:self.broker.stopped(self.failure)
            self._publish();self.events.close()
        return self.snapshot()

    def snapshot(self):
        return dict(state=self.state,failure=self.failure,cold=self.cold.snapshot(),cold_receipt=self.receipt,
                    start_intent=self.start_intent,start_returned=self.start_returned,stop_intent=self.stop_intent,
                    stop_returned=self.stop_returned,host_drain_attempted=self.host_drain_attempted,
                    fault_drain_failure=self.fault_drain_failure,
                    host_transport_drained=self.drained,global_quiet_proven=False,native_closed=False,safe_reopen=False,
                    evidence_error=self.evidence_error,
                    transport=None if self.reader is None else self.reader.snapshot(),
                    router=None if self.router is None else self.router.snapshot(),preview=self.final_preview,
                    runtime_seconds_limit=None,runtime_commands_limit=None,release='NATIVE_AND_GRAPH_RETAINED_NO_HOT_REOPEN')
