"""Bounded normal JPEG session reconstruction; one Receiver, no reopen/reset retry."""
from dataclasses import asdict
import threading
import time
try:
    from . import camera_session_io as io
    from .camera_raw_protocol import ColdSession
except ImportError:
    import camera_session_io as io
    from camera_raw_protocol import ColdSession


class RebuiltColdSession(ColdSession):
    def __init__(self, *args, session_control, expected_new_session, **kwargs):
        super().__init__(*args, **kwargs)
        self.session_control = session_control
        self.expected_new_session = expected_new_session

    def _check_transport(self, info):
        r = self.receiver
        state = self.session_control.query()
        if (state.phase != io.BOOT_READY or state.cfg_session != self.expected_new_session
                or not info.transport_drained or info.submitted != info.completed
                or r.leased_count or r.poll(0) or r.capacity < 4194304):
            raise RuntimeError('fresh kernel-accepted BOOT and drained same owner required')


class Rebuild:
    """Driven by the owner loop; receiver/release continues between tick calls."""
    def __init__(self, owner, control, request, *, clock=time.monotonic):
        self.owner,self.control,self.request,self.clock = owner,control,request,clock
        self.old_session = owner.cold.receipt['session']
        self.old_identity = owner.receiver.owner_identity()
        self.target = request['cameras']
        self.stage = 'RESTORING_SDR'
        self.deadline = clock()+40
        self.done = threading.Event()
        self.value = self.error = None
        self.stop_issued = self.stop_returned = self.reset_issued = False
        self.new_session = None
        self.deadline_diagnostics = set()
        self.thread = threading.Thread(target=self._restore,name='session-restore-sdr',daemon=True)
        self.thread.start()

    def _restore(self):
        try:
            self.value = self.owner.cold.apply('color')
        except BaseException as error:
            self.error = error
        finally:
            self.done.set()

    def _phase(self, stage, seconds):
        self.stage = stage
        self.deadline = self.clock()+seconds
        self.owner._event('SESSION_REBUILD_STAGE',stage=stage,old_session=self.old_session)
        self.owner.broker.rebuilding(self.request['request_id'],stage)

    def _mutate(self, action):
        # Linearize a mutation with HTTP STOP, including after a blocking seal.
        with self.owner.broker.lock:
            if self.owner.stop_event.is_set():
                raise RuntimeError('stop requested before session mutation')
            if action == io.DRAIN_STOP:
                self.stop_issued = True
            if action == io.RESET_ONCE:
                self.reset_issued = True
            return self.control.call(action,self.old_session)

    def tick(self):
        owner = self.owner
        if io.owner_key(owner.receiver.owner_identity()) != io.owner_key(self.old_identity):
            raise RuntimeError('rebuild changed native owner')
        if self.clock()>self.deadline:
            if self.stage not in self.deadline_diagnostics:
                self.deadline_diagnostics.add(self.stage)
                try:
                    diagnostic = self.control.diagnostic()
                except BaseException as error:
                    diagnostic = dict(error=type(error).__name__+': '+str(error)[:512])
                try:
                    owner._event('SESSION_REBUILD_DEADLINE_DIAG',stage=self.stage,
                        old_session=self.old_session,diagnostic=diagnostic)
                except BaseException:
                    pass  # Preserve the original deadline; no action retry.
            raise TimeoutError('session rebuild deadline: '+self.stage)
        owner.broker.heartbeat_update()
        if owner.stop_event.is_set():
            # Do not issue further reset/select/start after an explicit STOP.
            if not self.done.is_set():
                return False
            raise RuntimeError('session rebuild cancelled; owner retained')
        if self.stage == 'RESTORING_SDR':
            if not self.done.is_set():
                return False
            if self.error is not None:
                raise self.error
            products = owner.router.last_products[:owner.cameras]
            if not all(p and p['session']==self.old_session and p['epoch']==self.value.mode_epoch
                       and p['mode']=='color' for p in products):
                return False
            self._mutate(io.SOURCE_OFF)
            self._phase('DRAINING_SOURCE',2)
        elif self.stage == 'DRAINING_SOURCE':
            state = self.control.query()
            if not state.flags & io.DRAIN_STOP_ELIGIBLE:
                return False
            self._mutate(io.DRAIN_STOP)
            self.stop_returned = True
            owner.state = 'DRAINING'
            self._phase('DRAINING_HOST',2)
        elif self.stage == 'DRAINING_HOST':
            state = self.control.query()
            required = io.HOST_DRAINED | io.OBSERVABLE_IDLE
            if state.flags & required != required or not owner.reader.drained() or owner.held:
                return False
            self._phase('SEALING_RECORDING',15)
            result = owner.preview.retire_for_rebuild(timeout_s=15)
            owner._event('SESSION_OLD_DISPLAY_SEALED',recording=result.get('recording_final'))
            if owner.stop_event.is_set():
                raise RuntimeError('stop requested during recording retirement')
            self._mutate(io.RESET_ONCE)
            self._phase('WAITING_FRESH_BOOT',10)
        elif self.stage == 'WAITING_FRESH_BOOT':
            state = self.control.query()
            if not state.flags & io.FRESH_BOOT:
                return False
            state = self._mutate(io.ACCEPT_BOOT)
            if state.phase != io.BOOT_READY or state.cfg_session == self.old_session:
                raise RuntimeError('kernel did not accept fresh BOOT')
            self.new_session = state.cfg_session
            owner.install_rebuilt_session(self)
            self._phase('WAITING_NEW_VIDEO',30)
        elif self.stage == 'WAITING_NEW_VIDEO':
            rendered = owner.preview.snapshot().get('rendered') or {}
            if (set(owner.cold.profiles.status()['seen_cameras']) != set(range(self.target))
                    or not rendered.get('ordinal')):
                return False
            if owner.broker.completed_topology(self.request['request_id'],
                    cfg_session=self.new_session,old_session=self.old_session,rendered=rendered):
                owner._event('SESSION_REBUILD_VIDEO_CONFIRMED',old_session=self.old_session,
                             new_session=self.new_session,cameras=self.target)
                return True
        return False
