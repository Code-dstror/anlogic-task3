"""Admit only an exact-target-built session driver; SDK-only builds are rejected."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
try:
    from . import camera_raw_driver as raw
except ImportError:
    import camera_raw_driver as raw


def validate_audit(value, *, boot, source_hashes):
    if isinstance(value,dict) and value.get('status')=='PREBUILT_TARGET_REVALIDATED_NOT_LOADED':
        origin=value.get('origin_build_audit')
        if not isinstance(origin,dict) or not isinstance(origin.get('runtime'),dict):
            raise ValueError('unaltered original target build audit required')
        module,info=validate_audit(origin,boot=origin['runtime']['boot_id'],source_hashes=source_hashes)
        runtime=value.get('runtime');candidate=value.get('module')
        expected=dict(origin['runtime'],boot_id=boot)
        if (runtime!=expected or value.get('revalidation')!='EXACT_KERNEL_IDENTITY_AND_UNCHANGED_KO'
                or not isinstance(candidate,dict) or set(candidate)!=set(module)
                or any(candidate.get(k)!=module.get(k) for k in module if k!='path')):
            raise ValueError('fresh revalidation must retain original kernel and module identity')
        return candidate,info
    if type(value) is not dict or type(value.get('runtime')) is not dict:
        raise ValueError('complete session driver receipt required')
    runtime=value.get('runtime',{})
    if (value.get('status')!='TARGET_KERNEL_BUILD_VERIFIED_NOT_LOADED'
            or value.get('target_compatible') is not True
            or runtime.get('boot_id')!=boot or runtime.get('machine')!='aarch64'
            or runtime.get('release')!='6.1.99' or runtime.get('kernel_build_id')!=raw.KERNEL_BUILD
            or runtime.get('config_sha256')!=raw.KERNEL_CONFIG
            or value.get('uapi')!=dict(version=1,bytes=64,ioctl='0xc0404846')):
        raise ValueError('exact target session-driver build required; SDK-only module is blocked')
    if any(type(value.get(k)) is not dict for k in ('exports','source_inputs','module','module_info')):
        raise ValueError('complete session source/module/export audit required')
    # Reuse the existing strict ELF/export/source audit, translating the new
    # target-builder receipt's field names. The build stage itself verifies
    # original headers and reproducible derivation before setting its status.
    normalized=dict(status='TARGET_BUILD_AUDIT_PASSED_NOT_LOADED',boot_id=boot,
        kernel=dict(release='6.1.99',build_id=raw.KERNEL_BUILD,config_sha256=raw.KERNEL_CONFIG),
        audit_exports=value.get('exports'),original_headers_unchanged=True,
        private_source_hashes_verified=True,source_inputs=value.get('source_inputs'),
        module=value.get('module'),module_info=value.get('module_info'))
    return raw.validate_audit(normalized,boot=boot,source_hashes=source_hashes)


def check_target(path,digest,*,boot,source_hashes,expected_bdf=None):
    from dual_r3_driver import note_build_id,PARAMETERS
    path=Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size>32*1024*1024:
        raise ValueError('bounded ordinary session-driver audit required')
    body=path.read_bytes()
    if hashlib.sha256(body).hexdigest()!=digest:
        raise ValueError('session driver audit SHA differs')
    module,info=validate_audit(json.loads(body),boot=boot,source_hashes=source_hashes)
    if (Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=boot
            or os.uname().machine!='aarch64' or os.uname().release!='6.1.99'
            or note_build_id(Path('/sys/kernel/notes').read_bytes())!=raw.KERNEL_BUILD
            or hashlib.sha256(gzip.decompress(Path('/proc/config.gz').read_bytes())).hexdigest()!=raw.KERNEL_CONFIG):
        raise ValueError('live session kernel identity differs')
    ko=Path(module['path'])
    if (not ko.is_absolute() or ko.is_symlink() or not ko.is_file()
            or ko.stat().st_size!=module['bytes'] or hashlib.sha256(ko.read_bytes()).hexdigest()!=module['sha256']):
        raise ValueError('actual session KO differs')
    from raw_module_audit import module_info
    raw.validate_module_bytes(ko.read_bytes(),info,module_info)
    devices=[p for p in Path('/sys/bus/pci/devices').iterdir()
             if (p/'vendor').read_text().strip()=='0x1edb' and (p/'device').read_text().strip()=='0xabcd']
    if len(devices)!=1:
        raise ValueError('one actual FPGA endpoint required')
    dev=devices[0];bdf=dev.name
    if not re.fullmatch(r'[0-9a-f]{4}:[0-9a-f]{2}:[0-1][0-9a-f]\.[0-7]',bdf) or expected_bdf is not None and expected_bdf!=bdf:
        raise ValueError('actual BDF differs')
    driver=Path('/sys/bus/pci/drivers/ph1a_c2h_candidate');loaded=Path('/sys/module/ph1a_c2h')
    if (dev/'driver').resolve(strict=True)!=driver or (driver/'module').resolve(strict=True)!=loaded:
        raise ValueError('session driver association differs')
    if note_build_id((loaded/'notes/.note.gnu.build-id').read_bytes())!=info['build_id']:
        raise ValueError('loaded driver is not the audited session candidate')
    for key,value in dict(PARAMETERS,target_bdf=bdf).items():
        actual=(loaded/'parameters'/key).read_text().strip()
        if actual not in (('N','0') if key=='irq_hint' else (str(value),)):
            raise ValueError('session DMA parameter differs: '+key)
    node=Path('/dev')/('ph1a_c2h_'+bdf);misc=Path('/sys/class/misc')/node.name;n=node.stat()
    if not stat.S_ISCHR(n.st_mode) or (misc/'device').resolve(strict=True)!=dev.resolve(strict=True):
        raise ValueError('actual native node differs')
    if (misc/'dev').read_text().strip()!=f'{os.major(n.st_rdev)}:{os.minor(n.st_rdev)}':
        raise ValueError('native node device number differs')
    from handoff import owner_scan
    scan=owner_scan()
    if scan.get('owners')!=[] or scan.get('errors')!=[]:
        raise ValueError('exclusive native owner admission required')
    if [p.name for p in Path('/dev').glob('ph1a_c2h*')]!=[node.name] or Path('/proc/sys/kernel/random/boot_id').read_text().strip()!=boot:
        raise ValueError('native node or boot changed')
    return dict(device=str(node),bdf=bdf,boot_id=boot,module_build_id=info['build_id'],module_sha256=module['sha256'],native_opened=False)
