/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef C2H_SESSION_CONTROL_UAPI_H
#define C2H_SESSION_CONTROL_UAPI_H
#include <linux/types.h>
#include <linux/ioctl.h>

/* Additive, host-private API. Existing GET_INFO/OWNER/LEGACY are unchanged. */
#define C2H_SESSION_CONTROL_VERSION 1U
#define C2H_SESSION_QUERY 0U
#define C2H_SESSION_SOURCE_OFF 1U
#define C2H_SESSION_DRAIN_STOP 2U
#define C2H_SESSION_RESET_ONCE 3U
#define C2H_SESSION_ACCEPT_BOOT 4U

#define C2H_SESSION_IDLE 0U
#define C2H_SESSION_SOURCE_DISABLED 1U
#define C2H_SESSION_DMA_STOPPED 2U
#define C2H_SESSION_RESET_REQUESTED 3U
#define C2H_SESSION_BOOT_READY 4U
#define C2H_SESSION_FAULTED 5U

#define C2H_SESSION_UPSTREAM_OBSERVABLE_IDLE 1U
#define C2H_SESSION_HOST_DRAINED 2U
#define C2H_SESSION_FRESH_BOOT_OBSERVED 4U
#define C2H_SESSION_DRAIN_STOP_ELIGIBLE 8U

struct c2h_session_control {
	/* Inputs; all output fields must be zero in every request. */
	__u32 version, action, expected_cfg_session, reserved;
	/* Outputs; not an atomic snapshot across FPGA domains. */
	__u32 phase, cfg_session, legacy_status, native_status;
	__u64 submitted, completed;
	__u32 ready, leased, reset_issued, flags;
};
#define C2H_SESSION_CONTROL _IOWR('H', 0x46, struct c2h_session_control)

/* Read-only detailed observations through the same exclusive owner. Optional
 * window status is zero/not-read when the corresponding capability is absent. */
#define C2H_SESSION_DIAGNOSTIC_VERSION 1U
struct c2h_session_diagnostic {
	__u32 version, bytes, reserved0, reserved1;
	__u32 phase, identity_failures, capabilities, control;
	__u32 legacy_status, native_status, native_error, ready_mask;
	__u32 sending_mask, raw_status, jpeg_status, cfg_session;
	__u32 active_session, cfg_status, cfg_error, stereo_status;
	__u32 stereo_error, product, ready, leased;
	__s32 active;
	__u32 slots, reset_issued, flags;
	__u64 submitted, completed;
};
#define C2H_SESSION_DIAGNOSTIC _IOWR('H', 0x47, struct c2h_session_diagnostic)
#endif
