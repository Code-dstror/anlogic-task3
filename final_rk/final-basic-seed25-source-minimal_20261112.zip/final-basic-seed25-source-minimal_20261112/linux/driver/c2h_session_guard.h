/* SPDX-License-Identifier: GPL-2.0 */
#ifndef C2H_SESSION_GUARD_H
#define C2H_SESSION_GUARD_H
/* Fixed protocol capability bits describe optional host debug services.
 * They do not describe private RAW/JPEG pipeline ownership or native ARAW.
 */
#define C2H_SESSION_CAP_RAW_STORE (1U << 31)
#define C2H_SESSION_CAP_JPEG_RING (1U << 29)
#define C2H_SESSION_BAD_LEGACY 1U
#define C2H_SESSION_BAD_NATIVE 2U
#define C2H_SESSION_BAD_RAW 4U
#define C2H_SESSION_BAD_CFG 8U
#define C2H_SESSION_BAD_RECORD 16U
#define C2H_SESSION_BAD_JPEG 32U
#define C2H_SESSION_BAD_STEREO 64U
#define C2H_SESSION_BAD_CAPABILITIES 128U
#define C2H_SESSION_BAD_BINDING 256U
#define C2H_SESSION_BAD_MAPPING 512U
/* Included unchanged by the actual kernel driver and host C fault harness.
 * Caller supplies u32/u64/bool, errno, native ABI and session UAPI constants.
 * All calls execute under the existing exclusive owner's mutex.
 */
struct c2h_session_state {
	u32 phase, old_session, reset_issued;
};
struct c2h_session_observation {
	bool available, running, stopped, quarantined, active_valid, native_identity_matches;
	int active;
	u32 slot_count;
	u32 ready, leased, native_status, native_error, control, legacy_status;
	u32 ready_mask, sending_mask, raw_status, jpeg_status;
	u32 capabilities, identity_failures;
	u32 legacy_magic, legacy_abi, native_magic, native_abi;
	u32 raw_magic, raw_abi, jpeg_magic, jpeg_abi;
	u32 cfg_magic, cfg_abi, record_magic, record_abi, stereo_magic, stereo_abi;
	u32 cfg_session, active_session, cfg_status, cfg_error;
	u32 epoch, mode, quality, profile, cameras;
	u32 stereo_status, stereo_error, stereo_mode, product;
	u32 record_version, record_header;
	u64 submitted, completed;
};
struct c2h_session_ops {
	bool (*source_off)(void *ctx);
	bool (*stop)(void *ctx);
	bool (*reset)(void *ctx);
};

static inline u32 c2h_session_identity_failures(const struct c2h_session_observation *o)
{
	u32 failures = 0;
	if (o->legacy_magic != 0x33434641U || o->legacy_abi != 1U)
		failures |= C2H_SESSION_BAD_LEGACY;
	if (o->native_magic != C2H_MAGIC || o->native_abi != C2H_ABI_VERSION)
		failures |= C2H_SESSION_BAD_NATIVE;
	if (o->cfg_magic != 826754627U || o->cfg_abi != 1U)
		failures |= C2H_SESSION_BAD_CFG;
	if (o->record_magic != 843334482U || o->record_abi != 1U)
		failures |= C2H_SESSION_BAD_RECORD;
	if (o->stereo_magic != 827479123U || o->stereo_abi != 2U)
		failures |= C2H_SESSION_BAD_STEREO;
	if (o->capabilities == ~0U)
		failures |= C2H_SESSION_BAD_CAPABILITIES;
	if ((o->capabilities & C2H_SESSION_CAP_RAW_STORE) &&
	    (o->raw_magic != 827801938U || o->raw_abi != 1U))
		failures |= C2H_SESSION_BAD_RAW;
	if ((o->capabilities & C2H_SESSION_CAP_JPEG_RING) &&
	    (o->jpeg_magic != 826757194U || o->jpeg_abi != 1U))
		failures |= C2H_SESSION_BAD_JPEG;
	return failures;
}

static inline bool c2h_session_public_gates(const struct c2h_session_observation *o,
		bool allow_source_busy)
{
	/* Sequential observable gates only. The hardware fence owns final token /
	 * writer / reader / product quiet qualification. No UART override exists.
	 */
	return o->available && !o->quarantined && o->control == 0 &&
		(o->legacy_status & 3U) == 3U &&
		!(o->legacy_status & (8U | 32U | (allow_source_busy ? 0U : 16U))) &&
		!o->ready_mask && !o->sending_mask &&
		(!(o->capabilities & C2H_SESSION_CAP_RAW_STORE) ||
		 !(o->raw_status & (1U | 4U | 8U | 16U))) &&
		(!(o->capabilities & C2H_SESSION_CAP_JPEG_RING) ||
		 !(o->jpeg_status & (1U | 4U))) && o->product == 0 &&
		!(o->cfg_status & (1U | 8U)) && !o->cfg_error &&
		!(o->stereo_status & 1U) && !o->stereo_error;
}

static inline bool c2h_session_upstream_idle(const struct c2h_session_observation *o)
{
	return c2h_session_public_gates(o, false);
}

static inline bool c2h_session_reservation_stop_gates(const struct c2h_session_observation *o)
{
	struct c2h_session_observation reservation;
	/* STOP-only classification of the fixed legacy one-slot reservation.
	 * Never normalize the observation used for idle, RESET or fresh BOOT.
	 */
	if ((o->legacy_status & (8U | 16U)) != 8U || o->ready_mask || o->sending_mask != 1U)
		return false;
	reservation = *o;
	reservation.legacy_status &= ~8U;
	reservation.sending_mask = 0;
	return c2h_session_public_gates(&reservation, false);
}

static inline bool c2h_session_drain_stop_eligible(const struct c2h_session_state *s,
		const struct c2h_session_observation *o)
{
	u32 unbound = C2H_ST_OWNED | C2H_ST_WAIT_RECORD | C2H_ST_LINK_UP | C2H_ST_BME;
	if (s->phase != C2H_SESSION_SOURCE_DISABLED || !s->old_session ||
	    o->cfg_session != s->old_session || o->active_session != s->old_session)
		return false;
	if (c2h_session_upstream_idle(o))
		return true;
	/* Permission to cancel one unused grant, never upstream-idle or RESET
	 * permission. The original STOP/fence/ACK path retains all ownership.
	 */
	return (c2h_session_public_gates(o, true) || c2h_session_reservation_stop_gates(o)) &&
		o->running && !o->stopped &&
		o->native_status == unbound && !o->native_error &&
		o->active_valid && o->native_identity_matches &&
		o->active >= 0 && (u32)o->active < o->slot_count &&
		!o->ready && !o->leased && o->submitted > o->completed &&
		o->submitted - o->completed == 1;
}

static inline bool c2h_session_host_drained(const struct c2h_session_observation *o)
{
	u32 required = C2H_ST_STOPPED | C2H_ST_LINK_UP | C2H_ST_BME;
	u32 forbidden = C2H_ST_OWNED | C2H_ST_WAIT_RECORD | C2H_ST_SAFE_RESULT |
		C2H_ST_RECORD_BOUND | C2H_ST_QUARANTINE;
	return o->available && !o->quarantined && !o->running && o->stopped &&
		o->active == -1 && !o->ready && !o->leased &&
		o->submitted == o->completed && !o->native_error &&
		(o->native_status & required) == required &&
		!(o->native_status & forbidden);
}

static inline bool c2h_session_fresh_boot(const struct c2h_session_state *s,
		const struct c2h_session_observation *o)
{
	return s->reset_issued && s->old_session &&
		c2h_session_host_drained(o) && c2h_session_upstream_idle(o) &&
		o->cfg_session && o->cfg_session != s->old_session &&
		o->active_session == o->cfg_session &&
		(o->legacy_status & (4U | 8U | 16U | 32U | 128U)) == 0 &&
		(o->legacy_status & (1U | 2U | 64U)) == (1U | 2U | 64U) &&
		o->cfg_status == 16U && !o->cfg_error && !o->epoch &&
		!o->mode && o->quality == 75U && o->profile == 1U && o->cameras == 1U &&
		!o->stereo_status && !o->stereo_error && !o->stereo_mode &&
		o->record_version == 1U && o->record_header == 64U;
}

static inline u32 c2h_session_flags(const struct c2h_session_state *s,
		const struct c2h_session_observation *o)
{
	return (c2h_session_upstream_idle(o) ? C2H_SESSION_UPSTREAM_OBSERVABLE_IDLE : 0) |
		(c2h_session_host_drained(o) ? C2H_SESSION_HOST_DRAINED : 0) |
		(c2h_session_fresh_boot(s, o) ? C2H_SESSION_FRESH_BOOT_OBSERVED : 0) |
		(c2h_session_drain_stop_eligible(s, o) ? C2H_SESSION_DRAIN_STOP_ELIGIBLE : 0);
}

static inline bool c2h_session_request_valid(const struct c2h_session_control *r)
{
	return r->version == C2H_SESSION_CONTROL_VERSION &&
		r->action <= C2H_SESSION_ACCEPT_BOOT && !r->reserved &&
		!r->phase && !r->cfg_session && !r->legacy_status && !r->native_status &&
		!r->submitted && !r->completed && !r->ready && !r->leased &&
		!r->reset_issued && !r->flags;
}

static inline int c2h_session_execute(struct c2h_session_state *s,
		const struct c2h_session_observation *o,
		const struct c2h_session_control *r,
		const struct c2h_session_ops *ops, void *ctx)
{
	u32 expected = s->phase == C2H_SESSION_IDLE ? o->cfg_session : s->old_session;
	if (!c2h_session_request_valid(r))
		return -EINVAL;
	if (r->action == C2H_SESSION_QUERY)
		return r->expected_cfg_session && r->expected_cfg_session != expected ? -ESTALE : 0;
	if (!r->expected_cfg_session || r->expected_cfg_session != expected)
		return -ESTALE;
	if (!o->available || o->quarantined)
		return -EIO;
	switch (r->action) {
	case C2H_SESSION_SOURCE_OFF:
		if (s->phase != C2H_SESSION_IDLE || !o->running || o->product != 0)
			return -EBUSY;
		/* Persist before mutation; a copy_to_user failure must not roll back. */
		s->old_session = r->expected_cfg_session;
		s->reset_issued = 0;
		s->phase = C2H_SESSION_SOURCE_DISABLED;
		if (!ops->source_off(ctx))
			goto fault;
		return 0;
	case C2H_SESSION_DRAIN_STOP:
		if (!c2h_session_drain_stop_eligible(s, o))
			return -EBUSY;
		s->phase = C2H_SESSION_DMA_STOPPED; /* STOP issued; not drain proof. */
		if (!ops->stop(ctx))
			goto fault;
		return 0;
	case C2H_SESSION_RESET_ONCE:
		if (s->reset_issued)
			return -EALREADY;
		if (s->phase != C2H_SESSION_DMA_STOPPED ||
		    o->cfg_session != s->old_session ||
		    !c2h_session_host_drained(o) || !c2h_session_upstream_idle(o))
			return -EBUSY;
		s->reset_issued = 1;
		s->phase = C2H_SESSION_RESET_REQUESTED;
		if (!ops->reset(ctx))
			goto fault;
		return 0;
	case C2H_SESSION_ACCEPT_BOOT:
		if (s->phase != C2H_SESSION_RESET_REQUESTED || !c2h_session_fresh_boot(s, o))
			return -EBUSY;
		s->phase = C2H_SESSION_BOOT_READY;
		return 0;
	default:
		return -EINVAL;
	}
fault:
	s->phase = C2H_SESSION_FAULTED;
	return -EIO;
}

static inline bool c2h_session_diagnostic_request_valid(const struct c2h_session_diagnostic *r)
{
	const unsigned char *outputs = (const unsigned char *)r + 16;
	unsigned int i;
	if (r->version != C2H_SESSION_DIAGNOSTIC_VERSION || r->bytes != sizeof(*r) ||
	    r->reserved0 || r->reserved1)
		return false;
	for (i = 0; i < sizeof(*r) - 16; ++i)
		if (outputs[i])
			return false;
	return true;
}

static inline bool c2h_session_configuration_allowed(const struct c2h_session_state *s)
{
	return s->phase == C2H_SESSION_IDLE || s->phase == C2H_SESSION_BOOT_READY;
}
#endif
