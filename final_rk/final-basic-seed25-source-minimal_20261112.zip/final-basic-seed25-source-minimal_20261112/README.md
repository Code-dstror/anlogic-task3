# final_basic seed25 精简软件源码

对应 `CAMERA_RAW_R2 · 1a5603c1 · seed25` 的最终 V5 软件复现包，整理日期为 2026-11-12。Linux 入口修复提交：`670232df23f1fd89f3f19dc3b25b2569a0695f13`。其余 SDK、AI 和显示模块按已交付复现包的冻结版本保留，原生构建源另按实际库的构建记录核对。

本包用于阅读、修改和维护软件源码。仅包含 Python、C/C++、头文件、网页、必要配置及说明；运行程序请使用完整的 `final-basic-seed25-repro.tar.gz`。本包没有 bit、模型、驱动及动态库二进制、操作系统/SDK依赖、音视频或运行日志，不能直接作为板端安装包运行。

## 源码位置

`linux/` 保留完整复现包中相应目录的相对关系。

| 位置 | 内容和阅读入口 |
|---|---|
| `linux/tools/` | `reproduction_boot.py`：冷启动选择单目/双目、手动联网、校时和唯一 owner 启动；`reproduction_control.py`：终端菜单 |
| `linux/control/` | `launch_camera_parameters.py` / `launch_camera_session.py`：应用入口；相机 owner、HDR/ISP/JPEG 参数、HDMI、车道、YOLO、网页控制 |
| `linux/control/mono_record_history/` | 循环录像的时间账本、索引、HTTP 回放服务和回放网页 |
| `linux/control/ai_*` | 单目检测、跟踪、测距、异步结果与画面叠加；模型及私有库另行提供 |
| `linux/runtime/` | 当前应用依赖的接收、显示、SDK接口和既有基础模块；部分文件沿用历史名称 |
| `linux/driver/` | 当前合格驱动的 C 源码、UAPI、会话保护及 Makefile |
| `linux/network/` | EC200A 手动拨号辅助源码 |
| `linux/enumeration/` | 单次 PCIe 枚举工具及配置模板 |
| `linux/native_build_sources/` | 与当前七类自研原生库构建记录对应的源码，见依赖说明 |

源码未做功能改写。主流程静态依赖和 AI 功能模块保留；历史取证、测试用例、二进制和重复打包材料已省略。`SHA256SUMS` 可核对本精简包中的文件。

## 当前功能与验证范围

- 每次两板共同冷启动、SRAM 下载同一 seed25 后，终端选择单目 CAM0 或双目。本次目数保持到下一次冷启动。
- 单目支持彩色、灰度、高斯、直方图均衡化、HDR、车道曲线叠加、去雾，以及 RK 上的 YOLO 多目标检测与测距叠加。
- 双目支持彩色、灰度、高斯、直方图均衡化、HDR、去雾；HDMI 可选择左右同屏、CAM0 全屏或 CAM1 全屏。
- 终端与 4G/Tailscale 网页控制共用唯一视频 owner；支持当前 caps/ACTIVE 开放的 HDR、ISP、JPEG 参数。固定字段只读，修改等待 APPLIED 和对应新画面确认。
- HDMI 叠加逐眼 FPS；最终显示合成画面同时送入 SD 循环录像，支持按北京时间查询、网页回放和下载。
- 联网须先由操作者确认电脑已加入同一 Tailscale 网络；随后建立4G数据连接、用两个NTP参考校时、严格验证HTTPS，再启动Tailscale和视频。该顺序已修复旧日期导致证书未生效的问题。

2026-11-12 的整包单目离线启动、已操作算法、YOLO、JPEG Q及双目4G三布局/六算法均有正常反馈；双目录像样本已解码确认有两眼图像和 FPS。参数全范围、识别精度及长期稳定性没有因此全部验收。普通单目 SDR 目标60FPS，单目HDR与双目各眼目标30FPS，须区分输入统计和物理HDMI观测。

## 已知边界

- 真实单目↔双目在线重建仍有故障，复现入口关闭该功能。更换目数须共同冷启动并重新下载 bit。
- 录像时间查询和最新同屏样本已验证，长期回放与所有历史录像尚未逐段验收。循环回收仍可能跳过不符合条件的旧文件并保留告警。
- 离线时间依赖用户确认，标为 `LOCAL_UNVERIFIED`；联网初次校时后按本boot单调时钟延伸，标为 `NETWORK_ANCHORED`。
- 报警尚未在本入口集成；AI识别能力和距离标定仍需提高。AI模块中的相关辅助类不代表这些功能已启用。
- RAW传输核验代码不代表已完成RAW→RK ISP→HDMI链路。FPGA图像算法RTL和 `final_high_fps` 不在此软件包范围。
- STOP 后底层资源仍按原政策留置，不支持同boot重新START。

完整运行包的 TAR SHA-256：`233ff54eb360ae727c31033e9a2de1524947af4eea9d2215925dc8fdf1c934bb`。构建依赖及原生源码对应关系见 [依赖与构建说明](docs/依赖与构建说明.md)。
